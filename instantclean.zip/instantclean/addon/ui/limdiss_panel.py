# This file is part of Instant Clean
# Copyright (C) 2023  Ruben Messerschmidt

import bpy
from .super_panel import Super_Panel
from .layout_temps import sub_layout, sub_panel_header, results_layout


class BC_PT_Limdiss_Panel(Super_Panel):
    bl_idname='bc.limdiss_panel'
    bl_label=''

    @classmethod
    def poll(cls, context):
        return not context.scene.bc_misc.results or (context.scene.bc_states.limdiss and bpy.context.scene['Dissolve'] is not None and [v for k, v in bpy.context.scene['Dissolve'].items() if type(v) != type(False)])

    def draw_header(self, context):
        sub_panel_header(self.layout, 'limdiss', context.scene.bc_misc.results, 'Dissolve')

    def draw(self, context):
        layout = self.layout
        layout.enabled = context.scene.bc_states.limdiss
        pg = context.scene.bc_limdiss

        sub = sub_layout(layout, 3)

        if not context.scene.bc_misc.results:
            sub.prop(pg, 'max_angle')
            sub.prop(pg, 'boundaries')

            sub.separator()
            sub.label(text='Protect')
            box = sub.box()
            split = box.split()

            col = split.column()
            col.prop(pg, 'protect_seam')
            col.prop(pg, 'protect_uv')

            col = split.column()
            col.prop(pg, 'protect_sharp')
            col.prop(pg, 'protect_materials')
        else:
            results_layout(sub, bpy.context.scene['Dissolve'])

