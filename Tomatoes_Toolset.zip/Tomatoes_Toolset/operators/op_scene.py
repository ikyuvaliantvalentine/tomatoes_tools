import bpy
from bpy.types import Operator
from bpy.props import *

######################
#   Display Viewport               
######################
class Display_Viewport(Operator):
    bl_idname = "view3d.display_viewport"
    bl_label = "Display Viewport"

    type_view : EnumProperty(
        items = (('show_only_render', "show_only_render", ""),
                 ('show_face_normal', "show_face_normal", ""),
                 ('show_xray', "show_xray", ""),
                 ('show_wireframe', "show_wireframe", ""),
                 ('show_backface', "show_backface", ""),
                 ('show_cavity', "show_cavity", "")),
                 default = 'show_only_render'
                 )
                 
    def execute(self, context):        
        space = bpy.context.space_data.overlay
        shd = bpy.context.space_data.shading
           
        if self.type_view == 'show_only_render':                    
            if space.show_overlays:
                space.show_overlays = False
            else:
                space.show_overlays = True
                
        if self.type_view == 'show_face_normal':                    
            if space.show_face_orientation:
                space.show_face_orientation = False
            else:
                space.show_face_orientation = True
                
        if self.type_view == 'show_xray':                    
            if shd.show_xray:
                shd.show_xray = False
            else:
                shd.show_xray = True
                
        if self.type_view == 'show_wireframe':                    
            if space.show_wireframes:
                space.show_wireframes = False
            else:
                space.show_wireframes = True
            space.wireframe_threshold = 1  

        if self.type_view == 'show_backface':                    
            if shd.show_backface_culling:
                shd.show_backface_culling = False
            else:
                shd.show_backface_culling = True
        
        if self.type_view == 'show_cavity':                    
            if shd.show_cavity:
                shd.show_cavity = False
            else:
                shd.show_cavity = True
                              
        return {'FINISHED'}

class Optimize_Viewport(Operator):
    """
    CLICK - Optimize Clip Start & Clip End (0.1)
    CTRL - Optimize Clip Start & Clip End (0.01)
    SHIFT - Optimize Clip Start & Clip End (0.0001)
    """
    bl_idname = "scene.optimize_viewport"
    bl_label = "Optimize Viewport"
    
    def invoke(self, context, event):
        for a in bpy.context.screen.areas:
                if a.type == 'VIEW_3D':
                    for s in a.spaces:
                        if s.type == 'VIEW_3D':
                            if event.shift:
                                s.clip_start = 0.0001
                                s.clip_end = 100000
                            elif event.ctrl:
                                s.clip_start = 0.01
                                s.clip_end = 100000
                            else:
                                s.clip_start = 0.1
                                s.clip_end = 100000
        return {'FINISHED'}

###############################
#   Setup Scene
###############################
class Set_Scene_Maya(Operator):
    "Set Scene Unit For Maya"
    bl_idname = "scene.set_to_maya"
    bl_label = "Set Scene Maya"
    def execute(self, context):
        bpy.context.scene.unit_settings.system = 'METRIC'
        bpy.context.scene.unit_settings.scale_length = 0.01
        bpy.context.scene.unit_settings.length_unit = 'CENTIMETERS'
        return {'FINISHED'}

class Set_Scene_Blender_Default(Operator):
    "Set Scene Unit Blender Default"
    bl_idname = "scene.blender_default"
    bl_label = "Set Scene Blender Default"
    def execute(self, context):
        bpy.context.scene.unit_settings.system = 'METRIC'
        bpy.context.scene.unit_settings.scale_length = 1.0
        bpy.context.scene.unit_settings.length_unit = 'METERS'
        return {'FINISHED'}

class Toggle_Grid_And_Floor(Operator):
    "Toggle Hide/Unhide Grid And Floor In Viewport"
    bl_idname = "scene.toggle_grid_floor"
    bl_label = "Toggle Grid & Floor"
    def execute(self, context):
        space = bpy.context.space_data.overlay
        if space.show_ortho_grid:
            space.show_ortho_grid = False
        else:
            space.show_ortho_grid = True
        
        if space.show_floor:
            space.show_floor = False
        else:
            space.show_floor = True

        if space.show_axis_x:
            space.show_axis_x = False
        else:
            space.show_axis_x = True

        if space.show_axis_y:
            space.show_axis_y = False
        else:
            space.show_axis_y = True

        if space.show_axis_z:
            space.show_axis_z = True
        else:
            space.show_axis_z = False
        return {'FINISHED'}
