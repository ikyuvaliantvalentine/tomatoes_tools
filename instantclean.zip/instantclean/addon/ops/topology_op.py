# This file is part of Instant Clean
# Copyright (C) 2023  Ruben Messerschmidt

import bpy
from itertools import chain
from ..utils.common_funcs import (
    visible_faces,
    update_bmeshs,
    get_bmeshs,
    get_objects,
)

from ..utils.topology_funcs import *
from ..ui.layout_temps import popup_results


class BC_OT_Topology(bpy.types.Operator):
    bl_idname='bc.topology'
    bl_label='Topology'
    bl_description='Execute Topology operations only'
    bl_options={'UNDO', 'REGISTER'}

    stats = {}

    def execute(self, context):
        if not bpy.context.selected_objects and not bpy.context.objects_in_mode:
            return {'CANCELLED'}

        current_mode = bpy.context.mode
        bpy.ops.object.mode_set(mode='EDIT')
        objects = get_objects()
        bmeshs = get_bmeshs(objects)

        current_faces = len([f for f in list(chain.from_iterable([bm.faces for bm in bmeshs]))])
        current_tris = len([f for f in list(chain.from_iterable([bm.faces for bm in bmeshs])) if len(f.verts) == 3])
        current_quads = len([f for f in list(chain.from_iterable([bm.faces for bm in bmeshs])) if len(f.verts) == 4])

        self.stats = topology(bmeshs, current_faces, current_tris, current_quads)
        update_bmeshs(objects)

        if current_mode == 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')

        return {'FINISHED'}

    def draw(self, context):
        popup_results(self.layout, self.stats)


def topology(bms, current_faces=0, current_tris=0, current_quads=0):
    stats = {}

    pg = bpy.context.scene.bc_topology
    if pg.type == 'TRIS':
        if len([f for f in list(chain.from_iterable([bm.faces for bm in bms]))]) == 0:
            stats['Tris %'] = 0
            stats['Increased %'] = 0
            return stats

        stats['Tris %'] = 0
        stats['Increased %'] = round(current_tris / current_faces * 100, 2)
        print(stats['Increased %'])
        for bm in bms:
            triangulate(bm, visible_faces(bm), pg.quad_method, pg.ngon_method)

        tris = len([f for f in list(chain.from_iterable([bm.faces for bm in bms])) if len(f.verts) == 3])
        stats['Tris %'] = round(tris / len([f for f in list(chain.from_iterable([bm.faces for bm in bms]))]) * 100, 2)
        print(stats['Tris %'])
        stats['Increased %'] = round(stats['Tris %'] - stats['Increased %'], 2)
        if stats['Increased %'] > 0:
            stats['Increased %'] = '+' + str(stats['Increased %'])
        else:
            stats['Increased %'] = str(stats['Increased %'])

        return stats

    for bm in bms:
        if len([f for f in list(chain.from_iterable([bm.faces for bm in bms]))]) == 0:
            stats['Quads %'] = 0
            stats['Increased %'] = 0
            return stats
            
        stats['Quads %'] = 0
        stats['Increased %'] = round(current_quads / current_faces * 100, 2)
        tris_to_quads(bm, visible_faces(bm), pg.compare_sharp, pg.compare_seam, pg.compare_uv, pg.compare_material, pg.compare_vcol)

        quads = len([f for f in list(chain.from_iterable([bm.faces for bm in bms])) if len(f.verts) == 4])
        stats['Quads %'] = round(quads / len([f for f in list(chain.from_iterable([bm.faces for bm in bms]))]) * 100, 2)
        stats['Increased %'] = round(stats['Quads %'] - stats['Increased %'], 2)
        if stats['Increased %'] > 0:
            stats['Increased %'] = '+' + str(stats['Increased %'])
        else:
            stats['Increased %'] = str(stats['Increased %'])
    
    return stats
