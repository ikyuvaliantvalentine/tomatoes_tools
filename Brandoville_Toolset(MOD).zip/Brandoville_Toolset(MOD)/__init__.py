bl_info = {
    "name": "(MOD) Brandoville Toolset",
    "description": "A collection of tools and settings to improve productivity",
    "author": "IkyuValiantValentine (Tomatoes)",
    "version": (0, 0, 1),
    "blender": (2, 80, 0),
    "location": "View3D",
    "warning": "This addon is still in development.",
    "category": "Brandoville" }


# Copy From this 
#https://github.com/baklarrrr/MeshMint/blob/master/MeshMint.py

import bpy
# load and reload submodules
##################################

import importlib
from . import developer_utils
from . import auto_load

from bpy.props import (StringProperty,
                       BoolProperty,
                       FloatVectorProperty,
                       FloatProperty,
                       EnumProperty,
                       IntProperty,
                       PointerProperty)
        
from . properties import *
from . ui.ui_header import *

from bpy.app.handlers import persistent

@persistent
def pref_settings(self):        
    # ui = bpy.context.preferences.themes[0].view_3d
    # face_front = (1, 0, 0, 0)
    # face_back = (0.098, 0, 0, 0.965)
    # ui.face_front = face_front
    # ui.face_back = face_back
#    areas = bpy.context.workspace.screens[0].areas
#    for area in areas:
#        for space in area.spaces:
#            if space.type == 'VIEW_3D':
#                space.overlay.show_face_orientation = True

    # Store Update Set Workflow In Here Too
    addon_preferences = get_addon_preferences()
    set_workflow = addon_preferences.RedSoftwareWorkflowOptions
    if set_workflow == "blender":
        bpy.context.scene.unit_settings.system = 'METRIC'
        bpy.context.scene.unit_settings.scale_length = 1.0
        bpy.context.scene.unit_settings.length_unit = 'METERS'
    elif set_workflow == "maya":
        bpy.context.scene.unit_settings.system = 'METRIC'
        bpy.context.scene.unit_settings.scale_length = 0.01
        bpy.context.scene.unit_settings.length_unit = 'CENTIMETERS'

######################################################
# Set Update For Settings In Preferences
######################################################
def red_set_software_workflow(self,context):
    addon_preferences = get_addon_preferences()
    set_workflow = addon_preferences.RedSoftwareWorkflowOptions
    if set_workflow == "blender":
        bpy.context.scene.unit_settings.system = 'METRIC'
        bpy.context.scene.unit_settings.scale_length = 1.0
        bpy.context.scene.unit_settings.length_unit = 'METERS'
    elif set_workflow == "maya":
        bpy.context.scene.unit_settings.system = 'METRIC'
        bpy.context.scene.unit_settings.scale_length = 0.01
        bpy.context.scene.unit_settings.length_unit = 'CENTIMETERS'


def autosave_pref_set_settings_file_path(self, context):
    # Save user preferences when settingsFilePath is updated
    bpy.ops.wm.save_userpref()

importlib.reload(developer_utils)
modules = developer_utils.setup_addon_modules(__path__, __name__, "bpy" in locals())     

class Red_Project_Preferences(bpy.types.AddonPreferences):
    bl_idname = __name__
    # custom_uvname : StringProperty(name="Custom UV Name",
    #                 description="Store UV name in here",
    #                 default="")

    scale : FloatProperty(
            name="",
            description="Atur Ukuran Kotak Invoke",
            default=0.2,
            min=0.1, max=1
            )      
    

    use_app_handler : BoolProperty(name="Use Application Handler",
                    description="Enabled by default Face orientation and ",
                    default=False)

    RedSoftwareWorkflowOptions : EnumProperty(
            name="Settings",
            items=(
                ("blender", "Use Meter", "Workflow For Blender", 1),
                ("maya", "Use Centimeter", "Workflow For Maya", 2)),
            default='blender',
            update = red_set_software_workflow,
            description = "Choose UI") 
    
    # ------------------------------------------------------------------------              
    #   Asset Path for Asset Loader
    # ------------------------------------------------------------------------   
    # settingsFilePath : StringProperty(
    #         name="Settings",
    #         default="E:/02_PIPELINE/NAME_PROJECTS/02_Maya",
    #         subtype='FILE_PATH',
    #         description="location for the settings save/load\n")  
    
    settingsFilePath : StringProperty(
            name="Settings",
            default="",
            subtype='FILE_PATH',
            description="location for the settings save/load\n",
            update=autosave_pref_set_settings_file_path)  

    def draw(self, context):
        layout = self.layout 
        box = layout.box()     
        box.prop(self, "settingsFilePath", text="Set File Path")   
        # box = layout.box()     
        # box.label(text="Naming")
        # box.prop(self, "save_prefix", text="Prefix")      
        # box.prop(self, "save_suffix", text="Suffix")      
        # box.prop(self, "custom_uvname", text="UV Name")       

        box = layout.box()       
        box.label(text="Notes:")
        box.label(text="Turn On by Default Face Orientation & Set Workflow Settings")
        box.prop(self, "use_app_handler")    

##################################
# register
##################################
auto_load.init()
        
def register():            
    auto_load.register()
    bpy.utils.register_class(Red_Project_Preferences)
    bpy.types.Scene.red_props = PointerProperty(type=Dropdown_RedProject_Props)   

    bpy.types.VIEW3D_MT_editor_menus.append(topbar_info)
    bpy.app.handlers.load_post.append(pref_settings)

def unregister():
    auto_load.unregister()
    bpy.utils.unregister_class(Red_Project_Preferences)    
    del bpy.types.Scene.red_props  

    bpy.types.VIEW3D_MT_editor_menus.remove(topbar_info)   
    bpy.app.handlers.load_post.remove(pref_settings)

    
if __name__ == "__main__":
	register()
