import bpy
from bpy.types import Operator
from bpy.props import *

class VIEW3D_OT_cycle_cameras(bpy.types.Operator):
    """Jump to the next or previous cameras"""
    bl_idname = "view3d.cycle_cameras"
    bl_label = "Jump to Next/Previous Cameras"
    bl_options = {'REGISTER', 'UNDO'}

    direction : EnumProperty(
        name="Direction",
        items=(
            ('FORWARD', "Forward", "Next camera (alphabetically)"),
            ('BACKWARD', "Backward", "Previous camera (alphabetically)"),
        ),
        default='FORWARD'
    )

    def execute(self, context):
        scene = context.scene
        cam_objects = [ob for ob in bpy.data.objects if ob.type == 'CAMERA']

        if len(cam_objects) == 0:
            return {'CANCELLED'}

        try:
            idx = cam_objects.index(scene.camera)
            new_idx = (idx + 1 if self.direction == 'FORWARD' else idx - 1) % len(cam_objects)
        except ValueError:
            new_idx = 0

        context.scene.camera = cam_objects[new_idx]
        return {'FINISHED'}

class PropertiesContextStroll(Operator):
    '''Jump to the next or previous scene'''
    bl_idname = "screen.context_stroll"
    bl_label = "Jump to Next/Previous Context"
    bl_options = {'REGISTER', 'UNDO'}

    next : BoolProperty(
        default=True,
        name="Next Context",
        description="Disable to jump to previous context",
        options={'SKIP_SAVE'},
        )

    def execute(self, context):
        space = bpy.context.space_data

        # There must be a smarter way of getting this        
        contexts = ['RENDER',
                    'OUTPUT',
                    'VIEW_LAYER',
                    'SCENE',
                    'WORLD',
                    'OBJECT',
                    'MODIFIER',
                    'PARTICLES',
                    'PHYSICS',
                    'CONSTRAINT',
                    'DATA',
                    'MATERIAL',
                    'BONE',
                    'BONE_CONSTRAINT',
                    'TEXTURE']


        # Only if we are in the properties editor
        if space.type == 'PROPERTIES':
            context_current = contexts.index(space.context)
            context_go = (context_current + 1) if self.next else (context_current - 1)

            # First try if the context we want to go to is available
            try:
                space.context = contexts[context_go]
            except:
                # Oops! Not found, lets move to the next or previous
                found = False
                context_go += 1 if self.next else -1

                while found is False:
                    try:
                        # Success!
                        space.context = contexts[context_go]
                        found = True
                    except:
                        # Nope, keep trying. If we reach the end, start again
                        if context_go < len(contexts):
                            context_go += 1 if self.next else -1
                        else:
                            context_go = 0
                        continue

        return {'FINISHED'}