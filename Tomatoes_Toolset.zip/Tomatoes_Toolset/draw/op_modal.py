import bpy, bgl, blf, gpu
from gpu_extras.batch import batch_for_shader
from bpy.types import Operator
from .. properties import *
from math import pi

def draw_select_lamp(self, context):

    font_id = 0
    region = context.region
       
    addon_preferences = get_addon_preferences()
    size = addon_preferences.FontSizeModal
    xmod = addon_preferences.PositionXModal
    ymod = addon_preferences.PositionYModal
    space = addon_preferences.Font_Space
    space_y = addon_preferences.Font_Space_Y

    font_color_r, font_color_g, font_color_b, font_color_alpha = addon_preferences.base_color
    font_bool_color_r, font_bool_color_g, font_bool_color_b, font_bool_color_alpha = addon_preferences.bool_color

    wdt2 = 0
    multsp = space / 10

    wdt2 = 0
    if bpy.context.area.type == 'VIEW_3D':
        for r in bpy.context.area.regions:
            if r.type == 'TOOLS':
                wdt2 = r.width - 1
                self.regionwdt = wdt2
                xmod = addon_preferences.PositionXModal + r.width - 1
                
    #Title
    blf.color(font_id, font_color_r, font_color_g, font_color_b, font_color_alpha)
    blf.position(font_id, 450 + xmod, 260 + ymod, 0)
    blf.size(font_id, int(15*(size/10)) + 5, 72)
    blf.draw(font_id, "Lighting Tools " )

    blf.color(font_id, font_color_r, font_color_g, font_color_b, font_color_alpha)
    blf.position(font_id, 450 + xmod, 250 + ymod, 0)
    blf.size(font_id, int(15 * (size / 10)) + 5, 72)
    blf.draw(font_id, "______________")
    
    #Select Lamp
    blf.color(font_id, font_color_r, font_color_g, font_color_b, font_color_alpha)
    blf.position(font_id, 450 + xmod, 230 + ymod + space_y, 0)
    blf.size(font_id, int(15*(size/10)), 72)
    blf.draw(font_id, "Select Lamp" )
            
    blf.color(font_id, font_bool_color_r, font_bool_color_g, font_bool_color_b, font_bool_color_alpha)
    blf.position(font_id, 600 + xmod + 20*multsp , 230 + ymod + space_y, 0)
    blf.size(font_id, int(15*(size/10)), 72)
    blf.draw(font_id, "(LEFTMOUSE)"  )
    
    #Delete All Lamp
    blf.color(font_id, font_color_r, font_color_g, font_color_b, font_color_alpha)
    blf.position(font_id, 450 + xmod, 200 + ymod + space_y, 0)
    blf.size(font_id, int(15*(size/10)), 72)
    blf.draw(font_id, "Delete All" )
    
    blf.color(font_id, font_bool_color_r, font_bool_color_g, font_bool_color_b, font_bool_color_alpha)
    blf.position(font_id, 600 + xmod + 20*multsp , 200 + ymod + space_y, 0)
    blf.size(font_id, int(15*(size/10)), 72)
    blf.draw(font_id, "(ALT + LEFTMOUSE)"  )

    #Keys
    blf.color(font_id, font_color_r, font_color_g, font_color_b, font_color_alpha)
    blf.position(font_id, 450 + xmod, 50, 0)
    blf.size(font_id, int(15*(size/10)), 72)
    blf.draw(font_id, "Exit"  ) 
    
    blf.color(font_id, font_bool_color_r, font_bool_color_g, font_bool_color_b, font_bool_color_alpha)
    blf.position(font_id, 600 + xmod + 20*multsp, 50, 0)
    blf.size(font_id, int(15*(size/10)), 72)
    blf.draw(font_id, "RMB/ESC"  ) 
    
    blf.color(font_id, font_color_r, font_color_g, font_color_b, font_color_alpha)
    blf.position(font_id, 450 + xmod, 30, 0)
    blf.size(font_id, int(15*(size/10)), 72)
    blf.draw(font_id, "Turn Off"  ) 
    
    blf.color(font_id, font_bool_color_r, font_bool_color_g, font_bool_color_b, font_bool_color_alpha)
    blf.position(font_id, 600 + xmod + 20*multsp, 30, 0)
    blf.size(font_id, int(15*(size/10)), 72)
    blf.draw(font_id, "(+ SHIFT)"  ) 
                        
#Quick Select
class SelectLamptype(Operator):
    bl_idname = "sel.lamps"
    bl_label = "Select Lamps"
    bl_description = "Select All Lamps, Ctrl Select Group, Alt Remove All Lamp"
    
    def modal(self, context, event):     
        tomatoes = context.scene.tomatoes_props
        bpy.context.area.tag_redraw()
        
        if event.type in {'MIDDLEMOUSE', 'WHEELUPMOUSE', 'WHEELDOWNMOUSE'}:
            return {'PASS_THROUGH'}
        
        if event.type in {'RIGHTMOUSE', 'ESC'}:
            bpy.types.SpaceView3D.draw_handler_remove(self._handle, 'WINDOW')
            return {'FINISHED'}

        elif event.type == 'LEFTMOUSE':
            self.report({'INFO'}, "Selected All Lamp!") 
            bpy.ops.object.select_by_type(extend=False,type='LIGHT')
            if event.ctrl:
                self.report({'INFO'}, "Removed Lamp From Scene!")
                for ob in bpy.data.objects:
                    if ob.type == 'LIGHT':
                        bpy.data.objects.remove(ob)
                
                for m in bpy.data.lights:
                    if m.users == 0:                    
                        bpy.data.lights.remove(m)
                        
            bpy.types.SpaceView3D.draw_handler_remove(self._handle, 'WINDOW')
            return {'FINISHED'}                         
        return {'RUNNING_MODAL'}
    
    def invoke(self, context, event):
        if context.area.type in ['VIEW_3D']:
            args = (self, context)
            self._handle = bpy.types.SpaceView3D.draw_handler_add(draw_select_lamp, args, 'WINDOW', 'POST_PIXEL')            
            context.window_manager.modal_handler_add(self)
            return {'RUNNING_MODAL'}
        else:
            self.report({'WARNING'}, "Must Use In a 3D Region")
            return {'CANCELLED'} 


def draw_ui_unwrap(self, context):

    font_id = 0
    region = context.region
       
    addon_preferences = get_addon_preferences()
    size = addon_preferences.FontSizeModal
    xmod = addon_preferences.PositionXModal
    ymod = addon_preferences.PositionYModal
    space = addon_preferences.Font_Space
    space_y = addon_preferences.Font_Space_Y
    
    font_color_r, font_color_g, font_color_b, font_color_alpha = addon_preferences.base_color
    font_bool_color_r, font_bool_color_g, font_bool_color_b, font_bool_color_alpha = addon_preferences.bool_color
        
    wdt2=0
    multsp=space/10
            
    wdt2=0
    if bpy.context.area.type=='VIEW_3D':
        for r in bpy.context.area.regions:
            if r.type=='TOOLS': 
                wdt2=r.width-1
                self.regionwdt=wdt2
                xmod = addon_preferences.PositionXModal+r.width-1
                
    #Title
    blf.color(font_id, font_color_r, font_color_g, font_color_b, font_color_alpha)
    blf.position(font_id, 450 + xmod, 200 + ymod, 0)
    blf.size(font_id, int(15*(size/10)) + 5, 72)
    blf.draw(font_id, "Unwrap Object" )
    
    blf.color(font_id, font_color_r, font_color_g, font_color_b, font_color_alpha)
    blf.position(font_id, 450 + xmod, 195 + ymod, 0)
    blf.size(font_id, int(15*(size/10)) + 5, 72)
    blf.draw(font_id, "______________" )
                
    #Unwrap
    blf.color(font_id, font_color_r, font_color_g, font_color_b, font_color_alpha)
    blf.position(font_id, 450 + xmod, 170 + ymod + space_y, 0)
    blf.size(font_id, int(15*(size/10)), 72)
    blf.draw(font_id, "Unwrap")
            
    blf.color(font_id, font_bool_color_r, font_bool_color_g, font_bool_color_b, font_bool_color_alpha)
    blf.position(font_id, 600 + xmod + 20*multsp , 170 + ymod + space_y, 0)
    blf.size(font_id, int(15*(size/10)), 72)
    blf.draw(font_id, "(LMB)")
    
    #Smart Unwrap    
    blf.color(font_id, font_color_r, font_color_g, font_color_b, font_color_alpha)
    blf.position(font_id, 450 + xmod, 140 + ymod + space_y, 0)
    blf.size(font_id, int(15*(size/10)), 72)
    blf.draw(font_id, "Smart UV Unwrap")
    
    blf.color(font_id, font_bool_color_r, font_bool_color_g, font_bool_color_b, font_bool_color_alpha)
    blf.position(font_id, 600 + xmod + 20*multsp , 140 + ymod + space_y, 0)
    blf.size(font_id, int(15*(size/10)), 72)
    blf.draw(font_id, "(LMB+CTRL)")
    
    #Project From View
    blf.color(font_id, font_color_r, font_color_g, font_color_b, font_color_alpha)
    blf.position(font_id, 450 + xmod , 110 + ymod + space_y, 0)
    blf.size(font_id, int(15*(size/10)), 72)
    blf.draw(font_id, "Project From View" )
        
    blf.color(font_id, font_bool_color_r, font_bool_color_g, font_bool_color_b, font_bool_color_alpha)
    blf.position(font_id, 600 + xmod + 20*multsp , 110 + ymod + space_y, 0)
    blf.size(font_id, int(15*(size/10)), 72)
    blf.draw(font_id, "(LMB+SHIFT)")
    
    #Reset    
    blf.color(font_id, font_color_r, font_color_g, font_color_b, font_color_alpha)
    blf.position(font_id, 450 + xmod, 80 + ymod + space_y, 0)
    blf.size(font_id, int(15*(size/10)), 72)
    blf.draw(font_id, "Reset Unwrap" )
    
    blf.color(font_id, font_bool_color_r, font_bool_color_g, font_bool_color_b, font_bool_color_alpha)
    blf.position(font_id, 600 + xmod + 20*multsp, 80 + ymod + space_y, 0)
    blf.size(font_id, int(15*(size/10)), 72)
    blf.draw(font_id, "(LMB+ALT)")
                                
    #Keys
    blf.color(font_id, font_color_r, font_color_g, font_color_b, font_color_alpha)
    blf.position(font_id, 450 + xmod, 50, 0)
    blf.size(font_id, int(15*(size/10)), 72)
    blf.draw(font_id, "Exit"  ) 
    
    blf.color(font_id, font_bool_color_r, font_bool_color_g, font_bool_color_b, font_bool_color_alpha)
    blf.position(font_id, 600 + xmod + 20*multsp, 50, 0)
    blf.size(font_id, int(15*(size/10)), 72)
    blf.draw(font_id, "RMB/ESC"  ) 
    
    blf.color(font_id, font_color_r, font_color_g, font_color_b, font_color_alpha)
    blf.position(font_id, 450 + xmod, 30, 0)
    blf.size(font_id, int(15*(size/10)), 72)
    blf.draw(font_id, "Turn Off"  ) 
    
    blf.color(font_id, font_bool_color_r, font_bool_color_g, font_bool_color_b, font_bool_color_alpha)
    blf.position(font_id, 600 + xmod + 20*multsp, 30, 0)
    blf.size(font_id, int(15*(size/10)), 72)
    blf.draw(font_id, "(+ SHIFT)"  ) 
                            
#############################
#Unwrap       
#############################
class UnwrapMenu(Operator):
    bl_idname = "unwrap.modal"
    bl_label = "Unwrap" 
    bl_description = "Unwrap UI Modal"

    def modal(self, context, event):   
        bpy.context.area.tag_redraw()
        
        if event.type in {'MIDDLEMOUSE', 'WHEELUPMOUSE', 'WHEELDOWNMOUSE'}:
            return {'PASS_THROUGH'}
        
        if event.type in ['RIGHTMOUSE','ESC']:
            bpy.types.SpaceView3D.draw_handler_remove(self._handle, 'WINDOW')
            return {'FINISHED'}
                   
        elif event.type == 'LEFTMOUSE':
            for area in bpy.context.screen.areas:
                if area.type == 'VIEW_3D':
                    for region in area.regions:
                        if region.type == 'WINDOW':
                            override = {'area': area, 'region': region, 'edit_object': bpy.context.edit_object} 

            bpy.ops.mesh.select_mode(use_extend=False, use_expand=False, type='VERT')

            if event.ctrl:
                bpy.ops.uv.smart_project(override) 
                self.report({'INFO'}, "Smart UV Unwrap")     
            elif event.shift:
                bpy.ops.uv.project_from_view(override, camera_bounds=False, correct_aspect=True, scale_to_bounds=False)
                self.report({'INFO'}, "Project From View Unwrap") 
            elif event.alt:
                bpy.ops.uv.reset(override)
                self.report({'INFO'}, "Reset Unwrap") 
            else:    
                bpy.ops.uv.unwrap(override)
                self.report({'INFO'}, "Normal Unwrap")       
            bpy.types.SpaceView3D.draw_handler_remove(self._handle, 'WINDOW')
            return {'FINISHED'}      
        return {'RUNNING_MODAL'}
    
    def invoke(self, context, event):
        if context.area.type in ['VIEW_3D']:
            args = (self, context)
            self._handle = bpy.types.SpaceView3D.draw_handler_add(draw_ui_unwrap, args, 'WINDOW', 'POST_PIXEL')            
            context.window_manager.modal_handler_add(self)
            return {'RUNNING_MODAL'}
        else:
            self.report({'WARNING'}, "Must Use In a 3D Region")
            return {'CANCELLED'} 

#############################
#   Merge Tools    
#############################
def draw_ui_merge(self, context):

    font_id = 0
    region = context.region
       
    addon_preferences = get_addon_preferences()
    size = addon_preferences.FontSizeModal
    xmod = addon_preferences.PositionXModal
    ymod = addon_preferences.PositionYModal
    space = addon_preferences.Font_Space
    space_y = addon_preferences.Font_Space_Y
    
    font_color_r, font_color_g, font_color_b, font_color_alpha = addon_preferences.base_color
    font_bool_color_r, font_bool_color_g, font_bool_color_b, font_bool_color_alpha = addon_preferences.bool_color
        
    wdt2=0
    multsp=space/10
            
    wdt2=0
    if bpy.context.area.type=='VIEW_3D':
        for r in bpy.context.area.regions:
            if r.type=='TOOLS': 
                wdt2=r.width-1
                self.regionwdt=wdt2
                xmod = addon_preferences.PositionXModal+r.width-1
                
    #Title
    blf.color(font_id, font_color_r, font_color_g, font_color_b, font_color_alpha)
    blf.position(font_id, 450 + xmod, 200 + ymod, 0)
    blf.size(font_id, int(15*(size/10)) + 5, 72)
    blf.draw(font_id, "Merge" )
    
    blf.color(font_id, font_color_r, font_color_g, font_color_b, font_color_alpha)
    blf.position(font_id, 450 + xmod, 195 + ymod, 0)
    blf.size(font_id, int(15*(size/10)) + 5, 72)
    blf.draw(font_id, "______" )
                
    #At first
    blf.color(font_id, font_color_r, font_color_g, font_color_b, font_color_alpha)
    blf.position(font_id, 450 + xmod, 170 + ymod + space_y, 0)
    blf.size(font_id, int(15*(size/10)), 72)
    blf.draw(font_id, "At First")
            
    blf.color(font_id, font_bool_color_r, font_bool_color_g, font_bool_color_b, font_bool_color_alpha)
    blf.position(font_id, 600 + xmod + 20*multsp , 170 + ymod + space_y, 0)
    blf.size(font_id, int(15*(size/10)), 72)
    blf.draw(font_id, "(W)")
    
    #At last
    blf.color(font_id, font_color_r, font_color_g, font_color_b, font_color_alpha)
    blf.position(font_id, 450 + xmod, 140 + ymod + space_y, 0)
    blf.size(font_id, int(15*(size/10)), 72)
    blf.draw(font_id, "At Last")
    
    blf.color(font_id, font_bool_color_r, font_bool_color_g, font_bool_color_b, font_bool_color_alpha)
    blf.position(font_id, 600 + xmod + 20*multsp , 140 + ymod + space_y, 0)
    blf.size(font_id, int(15*(size/10)), 72)
    blf.draw(font_id, "(A)")
    
    #At Center
    blf.color(font_id, font_color_r, font_color_g, font_color_b, font_color_alpha)
    blf.position(font_id, 450 + xmod , 110 + ymod + space_y, 0)
    blf.size(font_id, int(15*(size/10)), 72)
    blf.draw(font_id, "At Center" )
        
    blf.color(font_id, font_bool_color_r, font_bool_color_g, font_bool_color_b, font_bool_color_alpha)
    blf.position(font_id, 600 + xmod + 20*multsp , 110 + ymod + space_y, 0)
    blf.size(font_id, int(15*(size/10)), 72)
    blf.draw(font_id, "(S)")
    
    #At Cursor 
    blf.color(font_id, font_color_r, font_color_g, font_color_b, font_color_alpha)
    blf.position(font_id, 450 + xmod, 80 + ymod + space_y, 0)
    blf.size(font_id, int(15*(size/10)), 72)
    blf.draw(font_id, "At Cursor" )
    
    blf.color(font_id, font_bool_color_r, font_bool_color_g, font_bool_color_b, font_bool_color_alpha)
    blf.position(font_id, 600 + xmod + 20*multsp, 80 + ymod + space_y, 0)
    blf.size(font_id, int(15*(size/10)), 72)
    blf.draw(font_id, "(D)")
                                
    #Keys    
    blf.color(font_id, font_color_r, font_color_g, font_color_b, font_color_alpha)
    blf.position(font_id, 450 + xmod, 50, 0)
    blf.size(font_id, int(15*(size/10)), 72)
    blf.draw(font_id, "Exit"  ) 
    
    blf.color(font_id, font_bool_color_r, font_bool_color_g, font_bool_color_b, font_bool_color_alpha)
    blf.position(font_id, 600 + xmod + 20*multsp, 50, 0)
    blf.size(font_id, int(15*(size/10)), 72)
    blf.draw(font_id, "TAB/ESC"  ) 
                                    
#############################
#Merge       
#############################
class MergeMenu(Operator):
    bl_idname = "modal.merge_manual"
    bl_label = "Merge Tool" 
    bl_description = "Merge UI Modal"
    
    @classmethod                                     
    def poll(cls, context):                         
        obj = context.active_object
        if len([obj for obj in context.selected_objects if context.object is not None if obj.type == 'MESH' if bpy.context.object.mode == "EDIT"]) == 1:
            return True

    def modal(self, context, event):   
        bpy.context.area.tag_redraw()
        
        if event.type in {'MIDDLEMOUSE', 'WHEELUPMOUSE', 'WHEELDOWNMOUSE', 'RIGHTMOUSE', 'LEFTMOUSE', 'Z'}:
            return {'PASS_THROUGH'}
                   
        elif event.type == 'W':
            if tuple (bpy.context.tool_settings.mesh_select_mode) != (True, False, False) :
                bpy.ops.mesh.merge(type='CENTER')
            else:
                bpy.ops.mesh.merge(type='FIRST')       
                
        elif event.type == 'A':
            if tuple (bpy.context.tool_settings.mesh_select_mode) != (True, False, False) :
                bpy.ops.mesh.merge(type='CENTER')                
            else:
                bpy.ops.mesh.merge(type='LAST') 
                
        elif event.type == 'S':
            bpy.ops.mesh.merge(type='CENTER') 
            
        elif event.type == 'D':
            bpy.ops.mesh.merge(type='CURSOR')  
            
        elif event.type in ['TAB','ESC', 'RETURN']:
            bpy.types.SpaceView3D.draw_handler_remove(self._handle, 'WINDOW')
            return {'FINISHED'}     
        return {'RUNNING_MODAL'}
    
    def invoke(self, context, event):
        if context.area.type in ['VIEW_3D']:
            args = (self, context)
            self._handle = bpy.types.SpaceView3D.draw_handler_add(draw_ui_merge, args, 'WINDOW', 'POST_PIXEL')            
            context.window_manager.modal_handler_add(self)
            return {'RUNNING_MODAL'}
        else:
            self.report({'WARNING'}, "Must Use In a 3D Region")
            return {'CANCELLED'} 
                
#############################
#Select by      
#############################
def draw_ui_select_by(self, context):

    font_id = 0
    region = context.region

    addon_preferences = get_addon_preferences()
    size = addon_preferences.FontSizeModal
    xmod = addon_preferences.PositionXModal
    ymod = addon_preferences.PositionYModal
    space = addon_preferences.Font_Space
    space_y = addon_preferences.Font_Space_Y

    font_color_r, font_color_g, font_color_b, font_color_alpha = addon_preferences.base_color
    font_bool_color_r, font_bool_color_g, font_bool_color_b, font_bool_color_alpha = addon_preferences.bool_color

    wdt2 = 0
    multsp = space / 10

    wdt2 = 0
    if bpy.context.area.type == 'VIEW_3D':
        for r in bpy.context.area.regions:
            if r.type == 'TOOLS':
                wdt2 = r.width - 1
                self.regionwdt = wdt2
                xmod = addon_preferences.PositionXModal + r.width - 1
                
    #Title
    blf.color(font_id, font_color_r, font_color_g, font_color_b, font_color_alpha)
    blf.position(font_id, 450 + xmod, 200 + ymod, 0)
    blf.size(font_id, int(15*(size/10)) + 5, 72)
    blf.draw(font_id, "Select By" )

    blf.color(font_id, font_color_r, font_color_g, font_color_b, font_color_alpha)
    blf.position(font_id, 450 + xmod, 195 + ymod, 0)
    blf.size(font_id, int(15 * (size / 10)) + 5, 72)
    blf.draw(font_id, "__________")
    
    #Select Group
    blf.color(font_id, font_color_r, font_color_g, font_color_b, font_color_alpha)
    blf.position(font_id, 450 + xmod, 170 + ymod + space_y, 0)
    blf.size(font_id, int(15*(size/10)), 72)
    blf.draw(font_id, "Group Object")
            
    blf.color(font_id, font_bool_color_r, font_bool_color_g, font_bool_color_b, font_bool_color_alpha)
    blf.position(font_id, 600 + xmod + 20*multsp , 170 + ymod + space_y, 0)
    blf.size(font_id, int(15*(size/10)), 72)
    blf.draw(font_id, "(LMB)")
    
    #Select UnGroup  
    blf.color(font_id, font_color_r, font_color_g, font_color_b, font_color_alpha)
    blf.position(font_id, 450 + xmod, 140 + ymod + space_y, 0)
    blf.size(font_id, int(15*(size/10)), 72)
    blf.draw(font_id, "Ungroup Object")
    
    blf.color(font_id, font_bool_color_r, font_bool_color_g, font_bool_color_b, font_bool_color_alpha)
    blf.position(font_id, 600 + xmod + 20*multsp , 140 + ymod + space_y, 0)
    blf.size(font_id, int(15*(size/10)), 72)
    blf.draw(font_id, "(LMB+SHIFT)")
    
    #Type
    blf.color(font_id, font_color_r, font_color_g, font_color_b, font_color_alpha)
    blf.position(font_id, 450 + xmod , 110 + ymod + space_y, 0)
    blf.size(font_id, int(15*(size/10)), 72)
    blf.draw(font_id, "Type Object" )
        
    blf.color(font_id, font_bool_color_r, font_bool_color_g, font_bool_color_b, font_bool_color_alpha)
    blf.position(font_id, 600 + xmod + 20*multsp , 110 + ymod + space_y, 0)
    blf.size(font_id, int(15*(size/10)), 72)
    blf.draw(font_id, "(A)")
    
    #Material    
    blf.color(font_id, font_color_r, font_color_g, font_color_b, font_color_alpha)
    blf.position(font_id, 450 + xmod, 80 + ymod + space_y, 0)
    blf.size(font_id, int(15*(size/10)), 72)
    blf.draw(font_id, "Material Object" )
    
    blf.color(font_id, font_bool_color_r, font_bool_color_g, font_bool_color_b, font_bool_color_alpha)
    blf.position(font_id, 600 + xmod + 20*multsp, 80 + ymod + space_y, 0)
    blf.size(font_id, int(15*(size/10)), 72)
    blf.draw(font_id, "(Z)")

    #Keys
    blf.color(font_id, font_color_r, font_color_g, font_color_b, font_color_alpha)
    blf.position(font_id, 450 + xmod, 50, 0)
    blf.size(font_id, int(15*(size/10)), 72)
    blf.draw(font_id, "Exit"  ) 
    
    blf.color(font_id, font_bool_color_r, font_bool_color_g, font_bool_color_b, font_bool_color_alpha)
    blf.position(font_id, 600 + xmod + 20*multsp, 50, 0)
    blf.size(font_id, int(15*(size/10)), 72)
    blf.draw(font_id, "RMB/ESC"  ) 
    
    blf.color(font_id, font_color_r, font_color_g, font_color_b, font_color_alpha)
    blf.position(font_id, 450 + xmod, 30, 0)
    blf.size(font_id, int(15*(size/10)), 72)
    blf.draw(font_id, "Turn Off"  ) 
    
    blf.color(font_id, font_bool_color_r, font_bool_color_g, font_bool_color_b, font_bool_color_alpha)
    blf.position(font_id, 600 + xmod + 20*multsp, 30, 0)
    blf.size(font_id, int(15*(size/10)), 72)
    blf.draw(font_id, "(+ SHIFT)"  ) 
    
def check_active():
    count = 0
    slist = bpy.context.selected_objects
    for i in slist:
        count += 1
    return count

def check_mode():
    emode = bpy.context.mode
    if emode != 'OBJECT':
        bpy.ops.object.mode_set(mode='OBJECT')
    return emode

class SelectBy(Operator):
    bl_idname = "selectby.modal"
    bl_label = "Select By" 
    bl_description = "Select By UI Modal"

    def modal(self, context, event):   
        bpy.context.area.tag_redraw()
        scene_groups = bpy.data.collections
        # make sure before this, that nothing is selected.
        names_of_grouped_objects = []
        
        for a in bpy.context.selectable_objects:
            for collections in bpy.data.collections:
                for item in collections.objects:
                    if item.name == a.name:
                        print("a.name", a.name, " is grouped in ", collections.name)
                        names_of_grouped_objects.append(a.name)

        if event.type in {'MIDDLEMOUSE', 'WHEELUPMOUSE', 'WHEELDOWNMOUSE'}:
            return {'PASS_THROUGH'}
                        
        if event.type in ['RIGHTMOUSE','ESC']:
            bpy.types.SpaceView3D.draw_handler_remove(self._handle, 'WINDOW')
            return {'FINISHED'}
                        
        elif event.type == 'A' and event.value == 'PRESS':
            check_mode()
            bpy.ops.object.select_grouped(type='TYPE')
            if check_active() == 0:
                return
            bpy.types.SpaceView3D.draw_handler_remove(self._handle, 'WINDOW')
            return {'FINISHED'}
            
        elif event.type == 'Z' and event.value == 'PRESS':
            check_mode()
            bpy.ops.object.select_linked(type='MATERIAL')
            if check_active() == 0:
                return
            bpy.types.SpaceView3D.draw_handler_remove(self._handle, 'WINDOW')
            return {'FINISHED'}
                   
        elif event.type == 'LEFTMOUSE':
             # grouped objects
            for a in bpy.context.selectable_objects:
                if a.name in names_of_grouped_objects:
                    bpy.data.objects[a.name].select_set(True)
                # unselect ungrouped objects
                if a.name not in names_of_grouped_objects:
                    bpy.data.objects[a.name].select_set(False)
                        
            if event.shift:
                # ungrouped objects
                for a in bpy.context.selectable_objects:
                    if a.name not in names_of_grouped_objects:
                        bpy.data.objects[a.name].select_set(True)
                    # unselect grouped objects    
                    if a.name in names_of_grouped_objects:
                        print(">>>",a.name)
                        bpy.data.objects[a.name].select_set(False)
                        
            bpy.types.SpaceView3D.draw_handler_remove(self._handle, 'WINDOW')   
            return {'FINISHED'}      
        return {'RUNNING_MODAL'}
    
    def invoke(self, context, event):
        if context.area.type in ['VIEW_3D']:
            args = (self, context)
            self._handle = bpy.types.SpaceView3D.draw_handler_add(draw_ui_select_by, args, 'WINDOW', 'POST_PIXEL')            
            context.window_manager.modal_handler_add(self)
            return {'RUNNING_MODAL'}
        else:
            self.report({'WARNING'}, "Must Use In a 3D Region")
            return {'CANCELLED'} 

#############################
#Rotate / 180        
#############################
axes = "XYZ"
texts_rotate = []
texts_rotate.append(([            
    "XYZ rotate 90 degree, (+SHIFT) rotate 180 degree"
    ]))
                                                        
def draw_ninety(self, context):
    font_id = 0
    region = context.region
    addon_preferences = get_addon_preferences()
    size = addon_preferences.FontSizeModal
            
    screen_x = context.region.width / 2
    screen_y = context.region.height / 10
    font_id = 0
    col = [0.8, 0.3, 0.4, 1]
    blf.size(font_id, int(15*(size/10)) + 10, 72)
    offset = 25 + 40
    blf.color(0, 1, 1, 1, 1)
    blf.size(0, int(15*(14/10)), 72)
    blf.position(0, 60, offset, 0)
    for data in texts_rotate:
        for d in data:
            blf.draw(0, d)  
    if self.axis in axes:
        col[axes.index(self.axis)] = 1
        blf.color(font_id, *col)
        blf.position(font_id, screen_x, screen_y, 0)
        blf.draw(font_id, "Axis: %s" % self.axis)    
        
class RotateObject(Operator):
    bl_idname = "rotate.toninety"
    bl_label = "Rotate To 90/180 Degree" 
    bl_description = "Auto Rotate Selected Object To 90/180 Degree"
            
    def modal(self, context, event):   
        context.area.tag_redraw()
        if event.type in axes and event.value == 'PRESS':
            self.axis = event.type
            if self.axis == 'X' and event.value == 'PRESS':
                for ob in bpy.context.selected_objects:
                    ob.rotation_euler[0] = pi/2
                    ob.rotation_euler[1] = 0
                    ob.rotation_euler[2] = 0
                    ob.convert_space(from_space='LOCAL', to_space='WORLD')
                    
                if event.shift:
                    for ob in bpy.context.selected_objects:
                        ob.rotation_euler[0] = pi
                        ob.rotation_euler[1] = 0
                        ob.rotation_euler[2] = 0
                        ob.convert_space(from_space='LOCAL', to_space='WORLD')
                    
            elif self.axis == 'Y' and event.value == 'PRESS':
                for ob in bpy.context.selected_objects:
                    ob.rotation_euler[0] = 0
                    ob.rotation_euler[1] = pi/2
                    ob.rotation_euler[2] = 0
                    ob.convert_space(from_space='LOCAL', to_space='WORLD')
                    
                if event.shift:
                    for ob in bpy.context.selected_objects:
                        ob.rotation_euler[0] = 0
                        ob.rotation_euler[1] = pi
                        ob.rotation_euler[2] = 0
                        ob.convert_space(from_space='LOCAL', to_space='WORLD')
                    
                    
            elif self.axis == 'Z' and event.value == 'PRESS':
                for ob in bpy.context.selected_objects:
                    ob.rotation_euler[0] = 0
                    ob.rotation_euler[1] = 0
                    ob.rotation_euler[2] = pi/2
                    ob.convert_space(from_space='LOCAL', to_space='WORLD')
                    
                if event.shift:
                    for ob in bpy.context.selected_objects:
                        ob.rotation_euler[0] = 0
                        ob.rotation_euler[1] = 0
                        ob.rotation_euler[2] = pi
                        ob.convert_space(from_space='LOCAL', to_space='WORLD')

        elif event.type == 'LEFTMOUSE':
            bpy.types.SpaceView3D.draw_handler_remove(self._handle, 'WINDOW')
            #context.area.header_text_set()
            self.report({'INFO'}, "Rotate to " + self.axis)       
            return {'FINISHED'}            
        return {'RUNNING_MODAL'}
    
    def invoke(self, context, event):
        if context.object:
            args = (self, context)
            self._handle = bpy.types.SpaceView3D.draw_handler_add(draw_ninety, args, 'WINDOW', 'POST_PIXEL')        
            #context.area.header_text_set("PRESS X Y Z for Rotate 90 Degree, +SHIFT for Rotate 180 Degree, Press LEFTMOUSE For Confirm")     
            context.window_manager.modal_handler_add(self)
            return {'RUNNING_MODAL'}
        else:
            self.report({'WARNING'}, "Must Use In a 3D Region")
            return {'CANCELLED'} 
                        
# merge    
texts = []
texts.append(([            
    "RIGHTMOUSE CLICK for exit Modal Operator"
    ]))
                                            
def draw_callback_px(self, context):
    if self.started:
        bgl.glEnable(bgl.GL_BLEND)
        bgl.glLineWidth(2)

        coords = [self.start_vertex, self.end_vertex]
        shader = gpu.shader.from_builtin('2D_UNIFORM_COLOR')
        batch = batch_for_shader(shader, 'LINE_STRIP', {"pos": coords})
        shader.bind()
        shader.uniform_float("color", (0.3, 1, 1, 1))
        batch.draw(shader)
        
    # restore opengl defaults
    bgl.glLineWidth(1)
    bgl.glDisable(bgl.GL_BLEND)   
    
    offset = 25 + 40
    blf.color(0, 1, 1, 1, 1)
    blf.size(0, int(15*(14/10)), 72)
    blf.position(0, 60, offset, 0)
    for data in texts:
        for d in data:
            blf.draw(0, d)         

def main(context, event, started):
    """Run this function on left mouse, execute the ray cast"""
    coord = event.mouse_region_x, event.mouse_region_y

    if started:
        result = bpy.ops.view3d.select(extend=True, location=coord)
    else:
        result = bpy.ops.view3d.select(extend=False, location=coord)

    if result == {'PASS_THROUGH'}:
        bpy.ops.mesh.select_all(action='DESELECT')


class Modal_MergeTool(Operator):
    """Modal object selection with a ray cast"""
    bl_idname = "modal.merge_tool"
    bl_label = "Merge Tool"
    
    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and obj.type == "MESH" and bpy.context.mode == 'EDIT_MESH'

    def __init__(self):
        self.started = None
        self.start_vertex = None
        self.end_vertex = None
        self._handle = None

    def modal(self, context, event):
        context.area.tag_redraw()

        if event.type in {'MIDDLEMOUSE', 'WHEELUPMOUSE', 'WHEELDOWNMOUSE', 'Z'}:
            # allow navigation
            return {'PASS_THROUGH'}
        elif event.type == 'MOUSEMOVE':
            if self.started:
                self.end_vertex = (event.mouse_region_x, event.mouse_region_y)

        elif event.type == 'LEFTMOUSE':
            main(context, event, self.started)
            if not self.started:
                if context.object.data.total_vert_sel == 1:
                    self.start_vertex = (event.mouse_region_x, event.mouse_region_y)
                    self.end_vertex = (event.mouse_region_x, event.mouse_region_y)
                    self.started = True
            elif context.object.data.total_vert_sel == 2:
                bpy.ops.mesh.merge(type='LAST')
                bpy.ops.ed.undo_push(message="Add an undo step *function may be moved*")
                self.started = False
            return {'RUNNING_MODAL'}

        elif event.type in {'RIGHTMOUSE', 'ESC'}:
            bpy.types.SpaceView3D.draw_handler_remove(self._handle, 'WINDOW')
            return {'CANCELLED'}

        return {'RUNNING_MODAL'}

    def invoke(self, context, event):
        if context.space_data.type == 'VIEW_3D':
            args = (self, context)

            self.start_vertex = (0, 0)
            self.end_vertex = (0, 0)
            self.started = False
            self._handle = bpy.types.SpaceView3D.draw_handler_add(draw_callback_px, args, 'WINDOW', 'POST_PIXEL')

            context.window_manager.modal_handler_add(self)

            return {'RUNNING_MODAL'}
        else:
            self.report({'WARNING'}, "Active space must be a View3d")
            return {'CANCELLED'}   
        
class Modal_ConnectTool(Operator):
    """Modal object selection with a ray cast"""
    bl_idname = "modal.connect_tool"
    bl_label = "Connect Tool"
    
    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and obj.type == "MESH" and bpy.context.mode == 'EDIT_MESH'

    def __init__(self):
        self.started = None
        self.start_vertex = None
        self.end_vertex = None
        self._handle = None

    def modal(self, context, event):
        context.area.tag_redraw()

        if event.type in {'MIDDLEMOUSE', 'WHEELUPMOUSE', 'WHEELDOWNMOUSE', 'Z'}:
            # allow navigation
            return {'PASS_THROUGH'}
        elif event.type == 'MOUSEMOVE':
            if self.started:
                self.end_vertex = (event.mouse_region_x, event.mouse_region_y)

        elif event.type == 'LEFTMOUSE':
            main(context, event, self.started)
            if not self.started:
                if context.object.data.total_vert_sel == 1:
                    self.start_vertex = (event.mouse_region_x, event.mouse_region_y)
                    self.end_vertex = (event.mouse_region_x, event.mouse_region_y)
                    self.started = True
            elif context.object.data.total_vert_sel == 2:
                bpy.ops.mesh.vert_connect_path()
                bpy.ops.ed.undo_push(message="Add an undo step *function may be moved*")
                self.started = False
            return {'RUNNING_MODAL'}

        elif event.type in {'RIGHTMOUSE', 'ESC'}:
            bpy.types.SpaceView3D.draw_handler_remove(self._handle, 'WINDOW')
            return {'CANCELLED'}

        return {'RUNNING_MODAL'}

    def invoke(self, context, event):
        if context.space_data.type == 'VIEW_3D':
            args = (self, context)

            self.start_vertex = (0, 0)
            self.end_vertex = (0, 0)
            self.started = False
            self._handle = bpy.types.SpaceView3D.draw_handler_add(draw_callback_px, args, 'WINDOW', 'POST_PIXEL')

            context.window_manager.modal_handler_add(self)

            return {'RUNNING_MODAL'}
        else:
            self.report({'WARNING'}, "Active space must be a View3d")
            return {'CANCELLED'}                                                                                                                        