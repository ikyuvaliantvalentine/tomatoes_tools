import bpy
from bpy.types import Panel, UIList
from bpy.props import *
from .. properties import *
from . ui_panel_draw import *
                                                    
class VIEW3D_PT_Object_Data_panel(Panel):
    bl_space_type = "PROPERTIES"
    bl_region_type = "WINDOW"
    bl_context = "object"
    bl_label = "Object Data"
    
    def draw_header(self, context):
        layout = self.layout
        layout.label(text="", icon="OUTLINER_OB_MESH")

    def draw(self, context):
        addon_preferences = get_addon_preferences()
        layout = self.layout
        if addon_preferences.UIObjectData == "light":
            if context.scene.render.engine == "CYCLES":
                UICyclesListLight(self, context)
            elif context.scene.render.engine == "BLENDER_EEVEE":
                UIEeveeListLight(self, context)
        else:
            UIObjectData(context, layout)
                    
class UVTOOLKIT_PT_tools(bpy.types.Panel):
    bl_label = "Tools"
    bl_idname = "UVTOOLKIT_PT_tools"
    bl_space_type = 'IMAGE_EDITOR'
    bl_region_type = 'UI'
    bl_category = "UV Toolkit"

    def draw(self, context):
        layout = self.layout
        UIUVToolkit(context, layout)

class UVTOOLKIT_PT_checker_map(bpy.types.Panel):
    bl_label = "Checker Map"
    bl_idname = "UVTOOLKIT_PT_checker_map"
    bl_space_type = 'IMAGE_EDITOR'
    bl_region_type = 'UI'
    bl_category = "UV Toolkit"

    def draw(self, context):
        layout = self.layout
        UIUVToolkitCheckerMap(context, layout)
                
class VIEW3D_PT_VFX(Panel):
    """A Custom Panel in the Properties Toolbar"""
    bl_label = "VFX Simulation"
    bl_idname = "VIEW3D_PT_VFX"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Custom Menu"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        UIVFX(context, layout)
        
            
                                