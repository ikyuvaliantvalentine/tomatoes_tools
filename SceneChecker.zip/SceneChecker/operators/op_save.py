import bpy, os, re
from bpy.types import Operator

def detect_number(name):
    last_nb_index = -1

    for i in range(1,len(name)):
        if name[-i].isnumeric():
            if last_nb_index == -1:
                last_nb_index = len(name)-i+1 # +1 because last index in [:] need to be 1 more
        elif last_nb_index != -1:
            first_nb_index = len(name)-i+1 #+1 to restore previous index
            return (first_nb_index,last_nb_index,name[first_nb_index:last_nb_index]) #first: index of the number / last: last number index +1
    return False
 
class FileIncrementalSave(bpy.types.Operator):
    bl_idname = "file.save_incremental_backup"
    bl_label = "Save Incremental"
   
    def execute(self, context):
        if bpy.data.filepath:
            sep = os.path.sep
            f_path = bpy.data.filepath
            directory = os.path.dirname(f_path)

            increment_files = [file for file in os.listdir(os.path.dirname(f_path)) if os.path.basename(f_path).split('.blend')[0] in file.split('.blend')[0] and file.split('.blend')[0] != os.path.basename(f_path).split('.blend')[0] and file.endswith(".blend")]
            for file in increment_files:
                if not detect_number(file):
                    increment_files.remove(file)
            numbers_index = [(index, detect_number(file.split('.blend')[0])) for index, file in enumerate(increment_files)]
            numbers = [index_nb[1] for index_nb in numbers_index]  # [detect_number(file.split('.blend')[0]) for file in increment_files]
            if numbers:  # prevent from error with max()
                str_nb = str(max([int(n[2]) for n in numbers]) + 1)  # zfill to always have something like 001, 010, 100

            if increment_files:
                d_nb = detect_number(increment_files[-1].split('.blend')[0])
                str_nb = str_nb.zfill(len(d_nb[2]))
            else:
                d_nb = False
                d_nb_filepath = detect_number(os.path.basename(f_path).split('.blend')[0])
                # if numbers: ## USELESS ??
                #    str_nb.zfill(3)
                if d_nb_filepath:
                    str_nb = str(int(d_nb_filepath[2]) + 1).zfill(len(d_nb_filepath[2]))
            if d_nb:
                if len(increment_files[-1].split('.blend')[0]) < d_nb[1]:   # in case last_nb_index is just after filename's max index
                    output = directory + sep + increment_files[-1].split('.blend')[0][:d_nb[0]] + str_nb + '.blend'
                else:
                    output = directory + sep + increment_files[-1].split('.blend')[0][:d_nb[0]] + str_nb + increment_files[-1].split('.blend')[0][d_nb[1]:] + '.blend'
            else:
                if d_nb_filepath:
                    if len(os.path.basename(f_path).split('.blend')[0]) < d_nb_filepath[1]:   # in case last_nb_index is just after filename's max index
                        output = directory + sep + os.path.basename(f_path).split('.blend')[0][:d_nb_filepath[0]] + str_nb + '.blend'

                    else:
                        output = directory + sep + os.path.basename(f_path).split('.blend')[0][:d_nb_filepath[0]] + str_nb + os.path.basename(f_path).split('.blend')[0][d_nb_filepath[1]:] + '.blend'

                else:
                    output = f_path.split(".blend")[0] + '_' + '001' + '.blend'

            if os.path.isfile(output):
                self.report({'WARNING'}, "Internal Error: trying to save over an existing file. Cancelled")
                print('Tested Output: ', output)
                return {'CANCELLED'}

            bpy.ops.wm.save_as_mainfile(filepath=output, relative_remap=True, compress=True, check_existing=True)  # save

            self.report({'INFO'}, "File: {0} - Created at: {1}".format(output[len(bpy.path.abspath(sep)):], output[:len(bpy.path.abspath(sep))]))
        else:
            self.report({'WARNING'}, "Please save a main file")
        return {'FINISHED'}
        

class WIPSaveBlend(Operator):
    """Saving Blend File For WIP Version"""
    bl_idname = "op.save_wip"
    bl_label = "Initial Save"

    def execute(self, context):        
        scenechk = context.scene.scenechk_props
        my_dir = scenechk.settingsFilePath
        savename = scenechk.save_filename

        wipFolder = os.path.join(my_dir, "WIP")
        if os.path.exists(wipFolder):
            print ("OK")
        else:
            os.makedirs(wipFolder)
            print ("Create WIP")

        for root, dirs, files in os.walk(wipFolder, topdown='true'):
            print (os.path.relpath(root, wipFolder))
            # print("root %s dirs %s files %s" %(root, dirs, files))
            for file in files:
                ext = os.path.splitext(file)[-1].lower()
                if (ext == '.blend'):
                    print(file)
                     
        bpy.ops.wm.save_as_mainfile(filepath=wipFolder + "\\" + savename + "_Mod" + "_WIP" + "_v001.blend", \
            relative_remap=True, compress=True, check_existing=True)

        self.report({"INFO"}, "File Saved")

        return {'FINISHED'}

class PublishSaveBlend(Operator):
    """Saving Blend File For Final Version"""
    bl_idname = "op.save_publish"
    bl_label = "Publish"

    def execute(self, context):         
            
        scenechk = context.scene.scenechk_props
        my_dir = scenechk.settingsFilePath
        savename = scenechk.save_filename

        bpy.ops.wm.save_as_mainfile(filepath=my_dir + "\\" + savename +"_Mod" + "_v001.blend", \
        relative_remap=True, compress=True, check_existing=True)

        self.report({"INFO"}, "File Saved")

        return {'FINISHED'}
    