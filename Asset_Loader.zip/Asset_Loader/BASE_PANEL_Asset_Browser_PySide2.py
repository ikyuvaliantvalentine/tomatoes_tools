import bpy
import os
import sys
from PySide2 import QtWidgets, QtCore, QtUiTools
from PySide2.QtUiTools import QUiLoader
from PySide2.QtWidgets import QApplication, QPushButton, QLineEdit, QDialog, QHBoxLayout, QVBoxLayout, QListWidget, QPushButton, QCheckBox, QLineEdit
from PySide2.QtCore import QFile, QObject, Qt, QSize
from PySide2 import QtGui, QtWidgets, QtGui

class Open_Mtools_Popup(bpy.types.Operator):
    '''Open Mtools popup '''

    bl_idname = "mtools.open_mtools_popup"
    bl_label = "M Tools"
    bl_options = {'REGISTER'}

    def execute(self, context):
        self.app = QtWidgets.QApplication.instance()
        if self.app is None:
            self.app = QtWidgets.QApplication(sys.argv)
        self.widget = Window(r'E:/02_PIPELINE/BVS_Cats_Project/CAT_Trailer/02_Production/3D_Asset/')
        self.widget.show()
        self.app.exec_()
        return {'FINISHED'}
    
class Window(QDialog):
    def __init__(self, base_directory):
        super().__init__()

        self.base_directory = base_directory

        self.initUI()
        

    def initUI(self):
        self.setWindowTitle("Blend File Selector")
        self.setGeometry(100, 100, 800, 300)

        layout = QVBoxLayout()

        subfolder_layout = QHBoxLayout()

        self.subfolder_list = QListWidget()
        self.subfolder_list.itemClicked.connect(self.update_blend_files)

        self.blend_list = QListWidget()

        subfolder_layout.addWidget(self.subfolder_list)
        subfolder_layout.addWidget(self.blend_list)

        layout.addLayout(subfolder_layout)

        # Add a search input field
        search_layout = QHBoxLayout()
        self.search_input = QLineEdit()
        self.search_input.setPlaceholderText("Search...")
        search_layout.addWidget(self.search_input)

        # Add a link/append option checkbox
        self.link_option = QCheckBox("Link")
        self.append_option = QCheckBox("Append")
        search_layout.addWidget(self.link_option)
        search_layout.addWidget(self.append_option)
        
        # Add the "Open Blend File" button
        self.open_button = QPushButton("Open Blend File")
        self.open_button.clicked.connect(self.open_blend_file)
        search_layout.addWidget(self.open_button)

        layout.addLayout(search_layout)

        self.setLayout(layout)

        self.populate_subfolders()

    def populate_subfolders(self):
        subfolders = [f for f in os.listdir(self.base_directory) if os.path.isdir(os.path.join(self.base_directory, f))]
        self.subfolder_list.addItems(subfolders)

    def update_blend_files(self):
        self.blend_list.clear()
        selected_folder = self.subfolder_list.currentItem()
        if selected_folder is not None:
            folder_path = os.path.join(self.base_directory, selected_folder.text())
            blend_files = [f for f in os.listdir(folder_path) if f.endswith(".blend")]
            self.blend_list.addItems(blend_files)

    def open_blend_file(self):
        selected_item = self.blend_list.currentItem()
        if selected_item is not None:
            folder_path = os.path.join(self.base_directory, self.subfolder_list.currentItem().text())
            file_path = os.path.join(folder_path, selected_item.text())
            bpy.ops.wm.open_mainfile(filepath=file_path)
            
class VIEW3D_PT_Global_Properties(bpy.types.Panel):
    bl_label = "PySide2 Blender"
    bl_category = "PySide2 Blender"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    
    def draw(self, context):
        layout = self.layout
        layout.operator("mtools.open_mtools_popup", icon = "EXPORT")

def register():
    bpy.utils.register_class(Open_Mtools_Popup)
    bpy.utils.register_class(VIEW3D_PT_Global_Properties)

def unregister():
    bpy.utils.unregister_class(Open_Mtools_Popup)
    bpy.utils.unregister_class(VIEW3D_PT_Global_Properties)

if __name__ == "__main__":
    register()
