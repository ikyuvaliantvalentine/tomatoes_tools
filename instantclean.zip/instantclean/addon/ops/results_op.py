# This file is part of Instant Clean
# Copyright (C) 2023  Ruben Messerschmidt

import bpy


class BC_OT_Close_Results(bpy.types.Operator):
    bl_idname='bc.close_results'
    bl_label='Close Results'

    def execute(self, context):
        context.scene.bc_misc.results = False
        return {'FINISHED'}