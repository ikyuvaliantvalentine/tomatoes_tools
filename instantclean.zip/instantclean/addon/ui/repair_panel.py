# This file is part of Instant Clean
# Copyright (C) 2023  Ruben Messerschmidt
import bpy
from .super_panel import Super_Panel
from .layout_temps import sub_layout, sub_panel_header, results_layout


class BC_PT_Repair_Panel(Super_Panel):
    bl_idname='bc.repair_panel'
    bl_label=''

    @classmethod
    def poll(cls, context):
        return not context.scene.bc_misc.results or (context.scene.bc_states.repair and bpy.context.scene['Repair'] is not None and [v for k, v in bpy.context.scene['Repair'].items() if type(v) != type(False)])

    def draw_header(self, context):
        sub_panel_header(self.layout, 'repair', context.scene.bc_misc.results, 'Repair')

    def draw(self, context):
        layout = self.layout
        layout.enabled = context.scene.bc_states.repair
        pg = context.scene.bc_repair

        sub = sub_layout(layout, 3)

        if not context.scene.bc_misc.results:
            sub.label(text='Remove')
            box = sub.box()
            col = box.column()
            split = col.split()
            
            col = split.column()
            col.prop(pg, 'loose')
            col.prop(pg, 'doubles')
            col.prop(pg, 'zero_faces')
            col.prop(pg, 'dispensables')
            col.prop(pg, 'interiors') 

            col = split.column()
            row = col.row(align=True)
            row.prop(pg, 'loose_verts',icon='VERTEXSEL' ,icon_only=True)
            row.prop(pg, 'loose_edges',icon='EDGESEL' ,icon_only=True)
            row.prop(pg, 'loose_faces',icon='FACESEL' ,icon_only=True)
            row.enabled = pg.loose
            row = col.row()
            row.prop(pg, 'doubles_dst', icon_only=True)
            row.enabled = pg.doubles

            row = col.row()
            row.prop(pg, 'zero_faces_area', icon_only=True)
            row.enabled = pg.zero_faces
            row = col.row()
            row.prop(pg, 'dispensables_ang', icon_only=True)
            row.enabled = pg.dispensables

        else:
            results_layout(sub, bpy.context.scene['Repair'])

            

