import bpy, os
from bpy.types import Operator

class Append_Smokes(Operator):
    "Add Volume Smokes"
    bl_idname = "op.new_smoke"
    bl_label = "Smokes"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        path = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'Assets/LightRigs_02.blend\\Object\\'))
        object_name = "Smoke_01"
        bpy.ops.wm.append(filename=object_name, directory=path)
        return {'FINISHED'} 

class Append_Threepointlight(Operator):
    "Add Three Point Lights"
    bl_idname = "op.threepointlights"
    bl_label = "Three Point Lights"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        path = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'Assets/LightRigs_02.blend\\Collection\\'))
        coll_name = "ThreePointLight"
        bpy.ops.wm.append(filename=coll_name, directory=path)
        bpy.data.objects['BackLight'].data.energy = 300
        bpy.data.objects['FillLight'].data.energy = 300
        bpy.data.objects['KeyLight'].data.energy = 300
        return {'FINISHED'} 

class Append_Exterior_Lights(Operator):
    "Add Exterior Light"
    bl_idname = "op.exterior_light"
    bl_label = "Exterior Lights"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        path = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'Assets/exteriorLight.blend\\Collection\\'))
        coll_name = "Sun"
        bpy.ops.wm.append(filename=coll_name, directory=path)
        scene = bpy.context.scene
        new_world = bpy.data.worlds["Sky"]
        scene.world = new_world
        return {'FINISHED'} 