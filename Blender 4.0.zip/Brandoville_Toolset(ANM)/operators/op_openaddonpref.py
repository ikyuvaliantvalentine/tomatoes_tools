import bpy
from bpy.types import Operator


class OpenAddonPreferences(Operator):
    bl_label = "Change prefix name in addon preferences"
    bl_idname = "op.open_addon_pref"
    bl_description = "Go to addon preferences Brandoville_Toolset(ANM)"
    dialog_width =  350
              
    def execute(self, context):
        bpy.ops.screen.userpref_show()
        bpy.context.preferences.active_section = 'ADDONS'
        bpy.data.window_managers["WinMan"].addon_search = "(ANM) Brandoville Toolset"
        bpy.ops.preferences.addon_expand(module = "Brandoville_Toolset(ANM)")
        return {"FINISHED"}   