import bpy
from bpy.types import Operator

################################################### 
# Add an Boolean modifier
###################################################       
# Do the Union, Difference and Intersection Operations
def do_operation(context, _operation):
    for selObj in bpy.context.selected_objects:
        if (
            selObj != context.active_object and
            (selObj.type == "MESH" or selObj.type == "CURVE")
        ):
            if selObj.type == "CURVE":
                ConvertToMesh(selObj)
            actObj = context.active_object
            selObj.hide_render = True
            cyclesVis = selObj.cycles_visibility
            
            cyclesVis.camera = False
            cyclesVis.diffuse = False
            cyclesVis.glossy = False
            cyclesVis.shadow = False
            cyclesVis.transmission = False
            cyclesVis.scatter = False
            if _operation == "SLICE":
                clone = context.active_object.copy()
                context.collection.objects.link(clone)
                sliceMod = clone.modifiers.new("Cutter" + selObj.name, "BOOLEAN")  # add mod to clone obj
                sliceMod.object = selObj
                sliceMod.operation = "DIFFERENCE"
                clone["BoolToolRoot"] = True
            newMod = actObj.modifiers.new("Cutter" + selObj.name, "BOOLEAN")
            newMod.object = selObj
            if _operation == "SLICE":
                newMod.operation = "INTERSECT"
            else:
                newMod.operation = _operation

            actObj["BoolToolRoot"] = True
            selObj["BoolToolBrush"] = _operation
            selObj["BoolTool_FTransform"] = "False"
    
    #Make Object Draw Type Wire        
    activeObj = context.active_object
    scene = bpy.context.view_layer
    selected = context.selected_objects

    if selected:
        if len(selected) > 1:
            if len(selected) == 2:
                for ob in selected:
                    if ob != activeObj:
                        nonActive = ob
                        
                bpy.context.view_layer.objects.active = nonActive 
                bpy.context.object.display_type = 'WIRE'
                activeObj.select_set(state=False)
                activeObj.select_set(state=True)
                scene.objects.active = activeObj 

    # Make Boolean To First
    for obj in context.selected_objects:
        for i, mod in enumerate(obj.modifiers):
            if mod.type == 'BOOLEAN':
                scene.objects.active = obj
                for x in range(0, i):
                    bpy.ops.object.modifier_move_up(modifier=mod.name)
                        
class addBoolean(Operator):
    """Boolean the currently selected objects"""
    bl_idname = "mesh.boolean"
    bl_label = "Boolean Operator"
                
    @classmethod        
    def poll(cls, context):
        return len(context.selected_objects) > 0
    
    def execute(self, context): 
        do_operation(context, "DIFFERENCE")                
        return {"FINISHED"}     