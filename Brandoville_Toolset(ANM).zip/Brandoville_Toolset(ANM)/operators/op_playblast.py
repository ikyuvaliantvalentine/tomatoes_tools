import bpy
import os
import shutil
from bpy.types import Operator 

class Playblast(Operator):
    "Render Animation Preview"
    bl_idname = "op.scene_playblast"
    bl_label = "Playblast"
    
    def get_parent_directory(self, path):
        path_components = os.path.normpath(path).split(os.path.sep)
        parent_path = os.path.sep.join(path_components[:-1])
        return parent_path
    
    def execute(self, context):
#        src_folder = "C:/Users/bv0063/Videos/Pipe_Anim/03_ANIMATION/Animation/SC001/000/blast"
#        archive_folder = "C:/Users/bv0063/Videos/Pipe_Anim/03_ANIMATION/Animation/SC001/000/blast/archive/"

        current_file = bpy.data.filepath
        file_name_with_version = os.path.splitext(os.path.basename(current_file))[0]
        
        src_folder = os.path.dirname(os.path.dirname(current_file))
        archive_folder = os.path.join(src_folder, "archive")
        
        # Extract file name and version number
        file_name, version_str = file_name_with_version.rsplit("_v", 1)
        version = int(version_str) if version_str.isdigit() else 1

        # Find the highest existing version number
        existing_versions = [f for f in os.listdir(src_folder) if f.startswith(f"{file_name}_v") and f.endswith(".mp4")]
        if existing_versions:
            existing_versions = [int(v.split("_v")[1].split(".mp4")[0]) for v in existing_versions]
            version = max(existing_versions) + 1
        else:
            version = 1

        # Create a new versioned filepath
        new_filepath = f"{src_folder}/{file_name}_v{version:04d}.mp4"
        new_filepath = bpy.path.native_pathsep(new_filepath)
        bpy.context.scene.render.filepath = new_filepath

        # Check if archive folder exists, if not, create it
        if not os.path.exists(archive_folder):
            os.makedirs(archive_folder)

        # Move old version to the archive folder
        old_version = version - 1
        old_file = f"{src_folder}/{file_name}_v{old_version:04d}.mp4"
        if os.path.exists(old_file):
            shutil.move(old_file, f"{archive_folder}/{os.path.basename(old_file)}")


        bpy.context.space_data.overlay.show_overlays = False
        bpy.context.scene.render.use_stamp = True
        bpy.context.scene.render.use_stamp_frame = True

        previous = bpy.context.scene.render.image_settings.file_format
        if(previous != "FFMPEG"):
            rd = bpy.context.scene.render
            rd.image_settings.file_format = "FFMPEG"
            rd.ffmpeg.format = "MPEG4"
            rd.ffmpeg.codec = "H264"

        try:
            bpy.ops.render.opengl(animation=True)
            bpy.ops.render.play_rendered_anim()
            
        except:
            self.report({'ERROR'}, "Scene has to be saved first!")
                    
        if(previous != "FFMPEG"):
            bpy.context.scene.render.image_settings.file_format = previous

        return {'FINISHED'}
