# This file is part of Instant Clean
# Copyright (C) 2023  Ruben Messerschmidt

import bpy
from bpy.props import (BoolProperty, IntProperty, FloatProperty, EnumProperty)


class BC_PG_Topology_Settings(bpy.types.PropertyGroup):
    type: EnumProperty(
        name='Type',
        items=[
            ('TRIS', 'Tris', '', 'MOD_TRIANGULATE', 0),
            ('QUADS', 'Quads', '', 'MOD_OPACITY', 1),
        ],
        default='TRIS',
        description='Type of topology which the mesh will be converted to'
    )

    # Methods
    quad_method: EnumProperty(
        name='Quad Method',
        items=[
            ('BEAUTY', 'Beauty', '', '', 0),
            ('FIXED', 'Fixed', '', '', 1),
            ('FIXED_ALTERNATE', 'Fixed Alternate', '', '', 2),
            ('SHORTEST_DIAGONAL', 'Shortest Diagonal', '', '', 3),
            ('LONGEST_DIAGONAL', 'Loneges Diagonal', '', '', 4),

        ],
        description='Method which will be used for the quad to triangle computation'
    )

    ngon_method: EnumProperty(
        name='NGon Method',
        items=[
            ('BEAUTY', 'Beauty', '', '', 0),
            ('CLIP', 'Clip', '', '', 1),
        ],
        description='Method which will be used for the ngon to triangle computation'
    )

    # Compare
    compare_sharp: BoolProperty(
        name='Sharp',
        default=True,
        description='Excludes edges marked as sharp from the convertion'
    )

    compare_seam: BoolProperty(
        name='Seam',
        default=True,
        description='Excludes edges marked as seam from the convertion'
    )

    compare_vcol: BoolProperty(
        name='VCol',
        default=True,
        description='Leaves vertex colors unchanged after convertion'
    )

    compare_uv: BoolProperty(
        name='UV',
        default=True,
        description='Leaves uv\'s unchanged after convertion'
    )
    
    compare_material: BoolProperty(
        name='Material',
        default=True,
        description='Excludes edges which delimit two different assigned materials from the convertion'
    )
