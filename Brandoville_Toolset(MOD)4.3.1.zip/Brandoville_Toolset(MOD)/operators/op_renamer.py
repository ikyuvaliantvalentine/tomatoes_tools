import bpy
import re
from bpy.types import Operator
from bpy.props import *
from .. properties import *

######################
#  VIEW SELECTED 
######################    
class red_selectRenameOB(Operator):
    bl_idname = "op.renamer_select"
    bl_label = "select"
    bl_options = {'REGISTER','UNDO'}
    ob : StringProperty()
    type : StringProperty()
    
    def execute(self, context):
        try:
            if self.type=='obj':                    
                bpy.ops.object.select_all(action='DESELECT')
                bpy.data.objects[self.ob].select_set(True)
                bpy.ops.view3d.view_selected(use_all_regions=1)
        except:
            self.report({'ERROR'}, 'ngga ada di viewport')            
        return {'FINISHED'}


######################
#  Click To Rename
###################### 
class ClickToRename(Operator):
    """Click To Rename"""
    bl_idname = "op.click_to_rename"
    bl_label = "OK"
    bl_options = {'UNDO'}
    
    def execute(self, context):
        addon_preferences = get_addon_preferences()
        red = context.scene.red_props
        aob = context.active_object
        if aob.type not in {'EMPTY'} and aob.mode == 'OBJECT':

            for ob in context.selected_editable_objects:
                if red.prefix != '' or red.suffix != '':
                    if ob.name.startswith(red.prefix):
                        ob.name = ob.name
                    else:
                        ob.name = red.prefix + ob.name

                    if ob.name.startswith(red.suffix):
                        ob.name = ob.name
                    else:
                        ob.name = ob.name + red.suffix

                    # if tomatoes.del_prefix:
                    #     ob.name = ob.name.replace(tomatoes.prefix, '')
                ob.data.name = ob.name 
        return {'FINISHED'}
    
######################
#  Click To Replace String
###################### 
class ClickToReplace(Operator):
    """Click To Replace"""
    bl_idname = "op.click_to_replace"
    bl_label = "OK"
    bl_options = {'UNDO'}
    
    def execute(self, context):
        red = context.scene.red_props
        search_str = red.regex_search_pattern
        replacement_str = red.regex_replacement_string
        substring_re = re.compile(search_str)
        if context.mode == "OBJECT":
            item_list = context.selected_objects
        elif context.mode == "POSE":
            item_list = context.selected_pose_bones
        elif context.mode == "EDIT_ARMATURE":
            item_list = context.selected_bones
        else:
            return {"CANCELLED"}

        for item in item_list:
            item.name = substring_re.sub(replacement_str, item.name)

        # In pose mode, operator"s result won"t show immediately. This
        # solves it somehow: only the View3D area will refresh
        # promptly.
        if context.mode == "POSE":
            context.area.tag_redraw()
        
        # Rename Object Data   
        aob = context.active_object
        if aob.type not in {"EMPTY"} and aob.mode == "OBJECT":
            for ob in context.selected_editable_objects:
                if replacement_str != "":
                    if ob.name.startswith(replacement_str):
                        ob.name = ob.name
                    # else:
                    #     ob.name = replacement_str + ob.name
                ob.data.name = ob.name
        return {'FINISHED'}
    
######################
#  Renamer Extra
###################### 
#-------------------------------------------------------        
#Check String is a Number
def StrIsInt(s):
    try: 
        int(s)
        return True
    except ValueError:
        return False
    
#Numbering
class Numbering(Operator):
    """Numbering of Objects"""
    bl_idname = "op.remove_replace_numbering"
    bl_label = "Numbering of Objects"

    def execute(self, context):        
        selected_obj = bpy.context.selected_objects 
        objects_list = []

        for x in selected_obj:
            #List of Objects
            object_class = [x.name, x.location.x]
            
            objects_list.append(object_class)
        
        #Preprocess Delete Blender Numbers and add new numbers
        for y in range(len(objects_list)):
            current_obj = bpy.data.objects[objects_list[y][0]]
            
            #Delete Blender Numbers
            ob_name = current_obj.name
            if StrIsInt(ob_name[-3:]):
                dot_pos = len(ob_name) - 4
                if ob_name[dot_pos] == '.':
                    ob_name = ob_name[:-4]
                        
            #Delete Previous Numbers
            if StrIsInt(ob_name[-1:]):
                unds_pos = len(ob_name) - 2
                if ob_name[unds_pos] == '_':
                    ob_name = ob_name[:-2]
                    
            if StrIsInt(ob_name[-2:]):
                unds_pos = len(ob_name) - 3
                if ob_name[unds_pos] == '_':
                    ob_name = ob_name[:-3]
                    
            if StrIsInt(ob_name[-3:]):
                unds_pos = len(ob_name) - 4
                if ob_name[unds_pos] == '_':
                    ob_name = ob_name[:-4]
                        
            #Format for Numbers
            num_str = ''
            if (y <= 8):
                num_str = '00' + str(y+1)
            elif (y >= 9) and (y <= 98):
                num_str = '0' + str(y+1)
            else:
                num_str = str(y+1)
            bpy.data.objects[objects_list[y][0]].name = ob_name + '_' + num_str;
        return {'FINISHED'}

class Replacedot(Operator):
    bl_idname = "op.replace_dot"
    bl_label = "Replace Dot"
    def execute(self, context):
        for obj in bpy.context.selected_objects:
            if "." in obj.name[-5:]:
                obj.name = obj.name.replace(".", "_")
        return {'FINISHED'}