# Toggle Subsurf & Remove Subsurf pressing ' ` '

import bpy
from bpy.types import Operator

def modifieradd(modifier, name):
    bpy.context.object.modifiers.new(type=modifier, name=name)
    return {"FINISHED"}

class shortcutSubsurf(Operator):
    """Add Subsurf"""
    bl_label = "Subsurf Toggle"
    bl_idname = "object.shortcut_subsurf"
    
    @classmethod
    def poll(cls, context):
        return len(context.selected_objects) > 0

    def execute(self, context):          
        test=True      
        for obj in context.selected_objects:
            bpy.context.view_layer.objects.active = obj

            for mod in obj.modifiers:
                if mod.type == 'SUBSURF':
                    if (mod.levels == 2):
                        test = False
                        break

        if(test):
            if bpy.context.object.mode == "EDIT":   
                bpy.ops.object.mode_set(mode="OBJECT")   
                for obj in context.selected_objects:
                    bpy.context.view_layer.objects.active = obj
                    modifieradd("SUBSURF", "Subsurf")
                
                    for mod in obj.modifiers:
                        if mod.type == 'SUBSURF':
                            mod.show_only_control_edges = True
                            mod.show_on_cage = False
                            mod.levels = 2 
                            bpy.ops.object.shade_smooth() 
                bpy.ops.object.mode_set(mode="EDIT")  
                
            else:        
                for obj in context.selected_objects:
                    bpy.context.view_layer.objects.active = obj
                    modifieradd("SUBSURF", "Subsurf")
                
                    for mod in obj.modifiers:
                        if mod.type == 'SUBSURF':
                            mod.show_only_control_edges = True
                            mod.show_on_cage = False
                            mod.levels = 2 
                            bpy.ops.object.shade_smooth() 
        else:
            for obj in context.selected_objects:
                bpy.context.view_layer.objects.active = obj
                for mod in bpy.context.object.modifiers:
                    if mod.type == 'SUBSURF':
                        bpy.ops.object.modifier_remove(modifier=mod.name)

                # if bpy.context.object.mode == "EDIT":   
                #     bpy.ops.object.mode_set(mode="OBJECT")   
                #     bpy.ops.object.shade_flat()
                #     bpy.ops.object.mode_set(mode="EDIT")  
                # else:
                #     bpy.ops.object.shade_flat()
                    
        return {"FINISHED"}