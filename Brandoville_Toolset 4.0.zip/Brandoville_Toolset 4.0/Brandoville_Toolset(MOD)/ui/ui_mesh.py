import bpy
from .. properties import *

def draw_mesh_ui(self, context, layout):
    red = context.scene.red_props

    col = layout.column(align=True)

    if not red.display_mesh_edit: 
        box = col.box().column(align=True)
        row = box.row(align=True)   
        row.prop(red, "display_mesh_edit", text="", icon="TRIA_RIGHT", toggle = True)                
        row.label(text="Mesh Edit")   

    else:
        box = col.box().column(align=True)
        row = box.row(align=True)   
        row.prop(red, "display_mesh_edit", text="", icon="TRIA_DOWN", toggle = True)                
        row.label(text="Mesh Edit")   

        box1 = col.box().column(align=True)                     
        col1 = box1.column(align=True) 
        col1.scale_x = 1.3
        col1.scale_y = 1.3
        col1.operator("op.clear_normals", icon = "TRASH")
        col1.separator()
        col1.operator("op.rem_mat_slot", icon = "CANCEL")

        col1.separator()

        col1.label(text="Custom Auto Smooth: ")
        col1.operator("mesh.be_auto_smooth")

        col1.separator()

        row1 = box1.row(align=True) 
        row1.operator("op.custom_autosmooth", text="30").type_smooth = '30'
        row1.operator("op.custom_autosmooth", text="60").type_smooth = '60'
        row1.operator("op.custom_autosmooth", text="90").type_smooth = '90'
        row1.operator("op.custom_autosmooth", text="180").type_smooth = '180'

        box2 = col.box().column(align=True)  
        col2 = box2.column(align=True) 
        col2.label(text="Select: ")

        row2 = box2.row(align=True)  
        row2.operator("op.facetype_select", text="Select Tris", icon="TRIA_UP").face_type = "3"
        row2.operator("op.facetype_select", text="Select Ngon", icon="RADIOBUT_ON").face_type = "5"

        col2 = box2.column(align=True) 
        col2.separator()
        col2.operator("mesh.edges_select_sharp")

        box3 = col.box().column(align=True)  
        col3 = box3.column(align=True) 
        col3.label(text="Extras: ")
        col3.separator()
        col3.operator("mesh.transfer_multiple_uvs")