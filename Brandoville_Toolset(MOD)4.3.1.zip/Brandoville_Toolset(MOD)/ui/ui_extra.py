import bpy
from .. properties import *
from .. ui.ui_renamer import *

def draw_shading_ui(self, context, layout):
    red = context.scene.red_props

    overlay = context.space_data.overlay
    shading = context.space_data.shading
    view = context.space_data
    
    col = layout.column(align=True)
   
    box = col.box().column(align=True)
    box.label(text="Extra Tools")
    
    row = box.row(align=True)   
    row.prop(red, 'red_create', emboss = True, expand = True)        

    if red.red_create == "red_c0": 
        pass   

    elif red.red_create == "red_c1": 
        box = layout.box()
        split = box.split()
        col = split.column(align=True)
        row = col.row(align=True)
        row.prop(view.shading, "light", expand=True)
        if view.shading.light in ["STUDIO", "MATCAP"]:
            row = col.row(align=True)
            row.template_icon_view(view.shading, "studio_light", show_labels=True, scale=4, scale_popup=3)
        if view.shading.light == "STUDIO":
            row = col.row(align=True)
            row.prop(shading, "use_world_space_lighting", text="", icon='WORLD')
            row.prop(shading, "studiolight_rotate_z", text="Rotation")

        split = box.split()
        col = split.column(align=True)
        row = col.row(align=True)
        row.grid_flow(columns=3, align=True).prop(view.shading, "color_type", expand=True)
        if shading.light == 'FLAT':
            row = col.row(align=True)
            row.prop(shading, 'single_color', text="")

        split = box.split()
        col = split.column(align=True)
        row = col.row(align=True)
        row.prop(view.shading, "background_type", expand=True)
        if shading.background_type == 'VIEWPORT':
            row = col.row(align=True)
            row.prop(shading, 'background_color', text="")
        
        split = box.split()
        col = split.column(align=True)
        row = col.row(align=True)
        row.prop(overlay, "show_wireframes")
        if overlay.show_wireframes:
            row.prop(overlay, "wireframe_threshold", text="")   

        col.prop(overlay, "show_face_orientation")
        col.prop(overlay, "show_overlays")

    elif red.red_create == "red_c2": 
        Red_UIRenamer(self, context, layout)
        