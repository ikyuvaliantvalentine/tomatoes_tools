import bpy
from .. properties import *

def draw_assetmanagement_ui(self, context, layout):
    red = context.scene.red_props
    addon_preferences = get_addon_preferences()

    box_assetsaver = layout.box()
    box_assetsaver.scale_x = 1.3
    box_assetsaver.scale_y = 1.3
    # box_assetsaver.label(text="Category:")
    # row = box_assetsaver.row()
    # row.prop(red, "asset_type", expand=True)

    box_assetsaver.prop(addon_preferences, "settingsFilePath")
    # box_assetsaver.prop(red, "save_filename")
    row = box_assetsaver.row()
    # row.operator("op.initial_save")
    # row.operator("op.assetsave_wip")
    # row.operator("op.assetsave_incremental_backup")
    # row.operator("op.assetsave_publish")

    layout.separator()
    layout.separator()
    layout.separator()

    box_assetloader = layout.box()
    box_assetloader.scale_x = 1.8
    box_assetloader.scale_y = 1.8
    box_assetloader.operator("op.asset_loader", icon="ASSET_MANAGER")
    
    box_assetloader.separator()
    box_assetloader.separator()

    box_assetloader.operator("op.local_playblast")
    box_assetloader.operator("wm.publish_shot")

#    box_assetchecker = layout.box()
#    box_assetchecker.scale_x = 1.8
#    box_assetchecker.scale_y = 1.8
#    box_assetchecker.operator("op.asset_checker", icon="CHECKMARK")