import bpy, bmesh, math, os, re
from mathutils import Matrix, Vector   
from bpy.types import Operator
from bpy.props import *
from bpy_extras import view3d_utils
from .. properties import *
        
###########################
#    Apply Transforms     #               
###########################
class ApplyTransformObject(Operator):
    bl_idname = "view3d.apply_transform_object"
    bl_label = "Transform Object"
    bl_options = {"REGISTER"}

    type_apply : EnumProperty(
        items = (('location', "location", ""),
                 ('rotation', "rotation", ""),
                 ('scale', "scale", ""),
                 ('rotation_scale', "rotation_scale", ""),
                 ('all', "all", "")),
                 default = 'location'
                 )
                 
    def execute(self, context):                   
        if self.type_apply == 'location':                    
            bpy.ops.object.transform_apply(location=True, rotation=False, scale=False)   
            
        if self.type_apply == 'rotation':                    
            bpy.ops.object.transform_apply(location=False, rotation=True, scale=False)
            
        if self.type_apply == 'scale':                    
            bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)  
            
        if self.type_apply == 'rotation_scale':                    
            bpy.ops.object.transform_apply(location=False, rotation=True, scale=True)
            
        if self.type_apply == 'all':                    
            bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)        
        return {'FINISHED'}

class SwitchWorkspace(bpy.types.Operator):
    bl_idname = "view3d.switch_workspace"
    bl_label = "Switch Workspace"
    bl_options = {'REGISTER'}

    name: bpy.props.StringProperty()

    def execute(self, context):
        bpy.context.window.workspace = bpy.data.workspaces[self.name]
        return {'FINISHED'}
             
######################
#  Switch Cam Resolution
######################      
class SwitchRenderResolution(Operator):
    'Switch Resolution'
    bl_idname="swithres.toggle"
    bl_label="Switch Resolution"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self,context):
        rd = context.scene.render
        rs_x = rd.resolution_x
        rs_y = rd.resolution_y

        if rd.resolution_x == rs_x:
            rd.resolution_x = rs_y
            rd.resolution_y = rs_x
        else:
            rd.resolution_x = rs_x
            rd.resolution_y = rs_y
        return {'FINISHED'}
        
######################
#  Clear Datablock 
######################    
class DataRemove(Operator):
    """Remove Zero User Data
    Delete Datablocks Materials, Images,
    Textures, Meshes, Curves, Lamps,
    Cameras, Particles
    """
    bl_idname = "data.remove"
    bl_label = "Data Remove"
    
    def execute(self, context):
        data = bpy.data
        for m in data.materials:
            if m.users == 0:                    
                data.materials.remove(m)
                
        for m in data.images:
            if m.users == 0:                    
                data.images.remove(m)   
                
        for m in data.textures:
            if m.users == 0:                    
                data.textures.remove(m)   
                
        for m in data.meshes:
            if m.users == 0:                    
                data.meshes.remove(m)   
                
        for m in data.curves:
            if m.users == 0:                    
                data.curves.remove(m)  
                
        for m in data.lights:
            if m.users == 0:                    
                data.lights.remove(m) 
                
        for m in data.cameras:
            if m.users == 0:                    
                data.cameras.remove(m)     
                
        for m in data.particles:
            if m.users == 0:                    
                data.particles.remove(m)                     
        self.report({'INFO'}, "Delete All Datablocks")                                                                                                                       
        return {'FINISHED'}

#Smart Join/Separate
class SmartJoinSeparate(Operator):
    """  
    FOR EDIT MODE:  
    CLICK - Separate By Selected
    SHIFT - Separate By Loose
    """
    bl_idname = "object.duplicate_or_join"
    bl_label = "Duplicate / Join"
    bl_options = {"REGISTER", "UNDO"}
    
    @classmethod                                     
    def poll(cls, context):                         
        obj = context.active_object
        if len([obj for obj in context.selected_objects if context.object is not None if obj.type in ['MESH', 'CURVE']]) >= 1:
            return True
        
    def invoke(self, context, event):
        obj = context.active_object
        if obj.type == 'MESH': 
            if bpy.context.object.mode == 'OBJECT':
                if len(bpy.context.selected_objects) == 1:
                    bpy.ops.mesh.separate(type='LOOSE')
                else:
                    bpy.ops.object.join()
            
            elif bpy.context.object.mode == 'EDIT':
                bpy.ops.mesh.separate(type='SELECTED')
                bpy.ops.object.editmode_toggle()
                    
        elif obj.type == 'CURVE':             
            if bpy.context.object.mode == 'OBJECT':
                bpy.ops.object.join()
                 
            elif bpy.context.object.mode == 'EDIT':             
                bpy.ops.curve.separate()
                bpy.ops.object.editmode_toggle()
                bpy.ops.object.origin_set(type='ORIGIN_GEOMETRY', center='MEDIAN')
        return {"FINISHED"}
    
######################
#  Save Incremental 
######################   
class SaveFileIncrement(Operator):
    'Increments the file name and then saves it'
    bl_idname = 'save_file.increment'
    bl_label = 'Save File Increment'

    def execute(self, context,):
        f_path = bpy.data.filepath      
        if f_path.find("_updated_") != -1:
            str_nb = f_path.rpartition("_updated_")[-1].rpartition(".blend")[0]
            int_nb = int(str_nb)
            new_nb = str_nb.replace(str(int_nb),str(int_nb+1))   
            output = f_path.replace(str_nb,new_nb)
            
            i = 1
            while os.path.isfile(output):
                str_nb = f_path.rpartition("_updated_")[-1].rpartition(".blend")[0]
                i += 1
                new_nb = str_nb.replace(str(int_nb),str(int_nb+i))
                output = f_path.replace(str_nb,new_nb)
        else:
            output = f_path.rpartition(".blend")[0]+"_updated_001"+".blend"
        
        bpy.ops.wm.save_as_mainfile(filepath=output)
        self.report({'INFO'}, "File: {0} - Created at: {1}".format(output[len(bpy.path.abspath("//")):], output[:len(bpy.path.abspath("//"))]))
        return {'FINISHED'}

######################
#   Resize to 0  
######################
class AligntoZero(Operator):
    bl_idname = "mesh.aligntozero"
    bl_label = "Align To Zero"
    bl_options = {"REGISTER", "UNDO"}
    
    type_align : EnumProperty(
        items = (('x', "X", ""),
                 ('y', "Y", ""),
                 ('z', "Z", "")),
                 default = 'x'
                 )                 
    def execute(self, context):
        obj = context.active_object
        if obj.type == 'MESH':
            bpy.context.scene.tool_settings.transform_pivot_point = 'INDIVIDUAL_ORIGINS'
            if self.type_align == 'x':    
                bpy.ops.transform.resize(value=(0, 1, 1))
            elif self.type_align == 'y':
                bpy.ops.transform.resize(value=(1, 0, 1))
            elif self.type_align == 'z':
                bpy.ops.transform.resize(value=(1, 1, 0))
            bpy.context.scene.tool_settings.transform_pivot_point = 'BOUNDING_BOX_CENTER'
        return {'FINISHED'}
                
######################
#   View Split  
######################
# Split area vertical
class SplitVertical(Operator):
    bl_idname = "split.vertical"
    bl_label = "split vertical"
    def execute(self, context):
        if context.screen.show_fullscreen:
            self.report({'INFO'}, "Impossible to do in fullscreen mode")
            bpy.ops.screen.screen_full_area()
        else:
            bpy.ops.screen.area_split(direction='VERTICAL')
        return {'FINISHED'}

# Split area horizontal
class SplitHorizontal(Operator):
    bl_idname = "split.horizontal"
    bl_label = "split horizontal"

    @classmethod
    def poll(cls, context):
        if context.screen.show_fullscreen:
            self.report({'INFO'}, "Impossible to do in fullscreen mode")
            return False
        return True

    def execute(self, context):
        bpy.ops.screen.area_split(direction='HORIZONTAL')
        return {'FINISHED'}

# Join Area
class JoinArea(Operator):
    bl_idname = "area.joinarea"
    bl_label = "Join Area"
    
    def execute(self, context):
        thisarea = context.area
        otherarea = None
        tgxvalue = thisarea.x + thisarea.width + 1
        tgyvalue = thisarea.y + thisarea.height + 1
        thistype = context.area.type
        for area in context.screen.areas:
            if area == thisarea:
                continue
            elif area.x  == tgxvalue and area.y == thisarea.y:
                otherarea = area
                break        
            elif area.y == tgyvalue and area.x == thisarea.x:
                otherarea = area
                break
        if otherarea:
            bpy.ops.screen.area_join('INVOKE_DEFAULT',cursor=(otherarea.x, otherarea.y ))
        return {'FINISHED'}

#View Class menu
class ViewMenu(bpy.types.Operator):
    """Menu to change views"""
    bl_idname = "object.view_menu"
    bl_label = "View_Menu"
    ui_type_variable : bpy.props.StringProperty()

    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        bpy.context.area.ui_type = self.ui_type_variable
        return {'FINISHED'}
    
######################
#    Manipulators    #               
######################
class ManipTranslate(Operator):
    """Gizmo to adjust Location"""
    bl_idname = "manip.translate"
    bl_label = "Manip Translate"
 
    def execute(self, context):
        bpy.context.space_data.show_gizmo = True
        bpy.context.space_data.show_gizmo_context = True
        bpy.context.space_data.show_gizmo_object_translate = True
        bpy.context.space_data.show_gizmo_object_rotate = False
        bpy.context.space_data.show_gizmo_object_scale = False
        return {'FINISHED'}
     
class ManipRotate(Operator):
    """Gizmo to adjust Rotation"""
    bl_idname = "manip.rotate"
    bl_label = "Manip Rotate"
 
    def execute(self, context):
        bpy.context.space_data.show_gizmo = True
        bpy.context.space_data.show_gizmo_context = True
        bpy.context.space_data.show_gizmo_object_translate = False
        bpy.context.space_data.show_gizmo_object_rotate = True
        bpy.context.space_data.show_gizmo_object_scale = False
        return {'FINISHED'}
 
class ManipScale(Operator):
    """Gizmo to adjust Scale"""
    bl_idname = "manip.scale"
    bl_label = "Manip Scale"
 
    def execute(self, context):
        bpy.context.space_data.show_gizmo = True
        bpy.context.space_data.show_gizmo_context = True
        bpy.context.space_data.show_gizmo_object_translate = False
        bpy.context.space_data.show_gizmo_object_rotate = False
        bpy.context.space_data.show_gizmo_object_scale = True
        return {'FINISHED'}

class ManipTranslateRotate(Operator):
    """Gizmo to adjust Location & Rotation"""
    bl_idname = "manip.locrotate"
    bl_label = "Manip Loc & Rotate"
 
    def execute(self, context):
        bpy.context.space_data.show_gizmo = True
        bpy.context.space_data.show_gizmo_context = True
        bpy.context.space_data.show_gizmo_object_translate = True
        bpy.context.space_data.show_gizmo_object_rotate = True
        bpy.context.space_data.show_gizmo_object_scale = False
        return {'FINISHED'}

class ManipTranslateRotate(Operator):
    """Gizmo to adjust Location & Rotation"""
    bl_idname = "manip.locrotate"
    bl_label = "Manip Loc & Rotate"
 
    def execute(self, context):
        bpy.context.space_data.show_gizmo = True
        bpy.context.space_data.show_gizmo_context = True
        bpy.context.space_data.show_gizmo_object_translate = True
        bpy.context.space_data.show_gizmo_object_rotate = True
        bpy.context.space_data.show_gizmo_object_scale = False
        return {'FINISHED'}
       
class WManupulators(Operator):
    """Turn Off/On Gizmo"""
    bl_idname = "w.manupulators"
    bl_label = "W Manupulators"
 
    def execute(self, context): 
        if bpy.context.space_data.show_gizmo == (True):
            bpy.context.space_data.show_gizmo = False 
        elif bpy.context.space_data.show_gizmo == (False):
            bpy.context.space_data.show_gizmo = True 
            bpy.context.space_data.show_gizmo_context = True
        return {'FINISHED'}
     
#####################################
#      Proportional Edit Object     #               
#####################################
class ProportionalEditObj(Operator):
    bl_idname = "proportional_obj.active"
    bl_label = "Proportional Edit Object"
 
    def execute(self, context): 
        if bpy.context.scene.tool_settings.use_proportional_edit_objects == (True):
            bpy.context.scene.tool_settings.use_proportional_edit_objects = False
 
        elif bpy.context.scene.tool_settings.use_proportional_edit_objects == (False) :
            bpy.context.scene.tool_settings.use_proportional_edit_objects = True
 
        return {'FINISHED'}
 
class ProportionalSmoothObj(Operator):
    bl_idname = "proportional_obj.smooth"
    bl_label = "Proportional Smooth Object"
 
    def execute(self, context):
        if bpy.context.scene.tool_settings.use_proportional_edit_objects == (False) : 
            bpy.context.scene.tool_settings.use_proportional_edit_objects = True
            bpy.context.scene.tool_settings.proportional_edit_falloff = 'SMOOTH'
 
        if bpy.context.scene.tool_settings.proportional_edit_falloff != 'SMOOTH': 
            bpy.context.scene.tool_settings.proportional_edit_falloff = 'SMOOTH' 
        return {'FINISHED'}    
 
class ProportionalSphereObj(Operator):
    bl_idname = "proportional_obj.sphere"
    bl_label = "Proportional Sphere Object"
 
    def execute(self, context):
        if bpy.context.scene.tool_settings.use_proportional_edit_objects == (False) : 
            bpy.context.scene.tool_settings.use_proportional_edit_objects = True
            bpy.context.scene.tool_settings.proportional_edit_falloff = 'SPHERE'
 
        if bpy.context.scene.tool_settings.proportional_edit_falloff != 'SPHERE': 
            bpy.context.scene.tool_settings.proportional_edit_falloff = 'SPHERE' 
        return {'FINISHED'}    
 
class ProportionalRootObj(Operator):
    bl_idname = "proportional_obj.root"
    bl_label = "Proportional Root Object"
 
    def execute(self, context):
        if bpy.context.scene.tool_settings.use_proportional_edit_objects == (False) : 
            bpy.context.scene.tool_settings.use_proportional_edit_objects = True
            bpy.context.scene.tool_settings.proportional_edit_falloff = 'ROOT'
 
        if bpy.context.scene.tool_settings.proportional_edit_falloff != 'ROOT': 
            bpy.context.scene.tool_settings.proportional_edit_falloff = 'ROOT' 
        return {'FINISHED'}
 
class ProportionalSharpObj(Operator):
    bl_idname = "proportional_obj.sharp"
    bl_label = "Proportional Sharp Object"
 
    def execute(self, context):
        if bpy.context.scene.tool_settings.use_proportional_edit_objects == (False) : 
            bpy.context.scene.tool_settings.use_proportional_edit_objects = True
            bpy.context.scene.tool_settings.proportional_edit_falloff = 'SHARP'
 
        if bpy.context.scene.tool_settings.proportional_edit_falloff != 'SHARP': 
            bpy.context.scene.tool_settings.proportional_edit_falloff = 'SHARP' 
        return {'FINISHED'}
 
class ProportionalLinearObj(Operator):
    bl_idname = "proportional_obj.linear"
    bl_label = "Proportional Linear Object"
 
    def execute(self, context):
        if bpy.context.scene.tool_settings.use_proportional_edit_objects == (False) : 
            bpy.context.scene.tool_settings.use_proportional_edit_objects = True
            bpy.context.scene.tool_settings.proportional_edit_falloff = 'LINEAR'
 
        if bpy.context.scene.tool_settings.proportional_edit_falloff != 'LINEAR': 
            bpy.context.scene.tool_settings.proportional_edit_falloff = 'LINEAR' 
        return {'FINISHED'}  
 
class ProportionalConstantObj(Operator):
    bl_idname = "proportional_obj.constant"
    bl_label = "Proportional Constant Object"
 
    def execute(self, context):
        if bpy.context.scene.tool_settings.use_proportional_edit_objects == (False) : 
            bpy.context.scene.tool_settings.use_proportional_edit_objects = True
            bpy.context.scene.tool_settings.proportional_edit_falloff = 'CONSTANT'
 
        if bpy.context.scene.tool_settings.proportional_edit_falloff != 'CONSTANT': 
            bpy.context.scene.tool_settings.proportional_edit_falloff = 'CONSTANT'
        return {'FINISHED'}  
 
class ProportionalRandomObj(Operator):
    bl_idname = "proportional_obj.random"
    bl_label = "Proportional Random Object"
 
    def execute(self, context):
        if bpy.context.scene.tool_settings.use_proportional_edit_objects == (False) : 
            bpy.context.scene.tool_settings.use_proportional_edit_objects = True
            bpy.context.scene.tool_settings.proportional_edit_falloff = 'RANDOM'
 
        if bpy.context.scene.tool_settings.proportional_edit_falloff != 'RANDOM': 
            bpy.context.scene.tool_settings.proportional_edit_falloff = 'RANDOM'
        return {'FINISHED'}
     
#######################################
#     Proportional Edit Edit Mode     #               
#######################################
class ProportionalEditEdt(Operator):
    bl_idname = "proportional_edt.active"
    bl_label = "Proportional Edit EditMode"
 
    def execute(self, context):  
        if bpy.context.scene.tool_settings.use_proportional_edit == False:
            bpy.context.scene.tool_settings.use_proportional_edit = True
        elif bpy.context.scene.tool_settings.use_proportional_edit == True:
            bpy.context.scene.tool_settings.use_proportional_edit = False
        return {'FINISHED'}
 
class ProportionalConnectedEdt(Operator):
    bl_idname = "proportional_edt.connected"
    bl_label = "Proportional Connected EditMode"
 
    def execute(self, context):  
        if bpy.context.scene.tool_settings.use_proportional_edit == False:
            bpy.context.scene.tool_settings.use_proportional_edit = True
            bpy.context.scene.tool_settings.use_proportional_connected = True
        elif bpy.context.scene.tool_settings.use_proportional_edit == True:
            bpy.context.scene.tool_settings.use_proportional_connected = True
        return {'FINISHED'}
 
class ProportionalProjectedEdt(Operator):
    bl_idname = "proportional_edt.projected"
    bl_label = "Proportional projected EditMode"
    bl_options = {'REGISTER', 'UNDO'}
 
    def execute(self, context):  
        if bpy.context.scene.tool_settings.use_proportional_edit == False:
            bpy.context.scene.tool_settings.use_proportional_edit = True
            bpy.context.scene.tool_settings.use_proportional_projected = True
        elif bpy.context.scene.tool_settings.use_proportional_edit == True:
            bpy.context.scene.tool_settings.use_proportional_projected = True
        return {'FINISHED'}
 
class ProportionalSmoothEdt(Operator):
    bl_idname = "proportional_edt.smooth"
    bl_label = "Proportional Smooth EditMode"
 
    def execute(self, context):
        if bpy.context.scene.tool_settings.use_proportional_edit == False:
            bpy.context.scene.tool_settings.use_proportional_edit = True
            bpy.context.scene.tool_settings.proportional_edit_falloff = 'SMOOTH'
 
        if bpy.context.scene.tool_settings.proportional_edit_falloff != 'SMOOTH': 
            bpy.context.scene.tool_settings.proportional_edit_falloff = 'SMOOTH' 
        return {'FINISHED'}    
 
class ProportionalSphereEdt(Operator):
    bl_idname = "proportional_edt.sphere"
    bl_label = "Proportional Sphere EditMode"
 
    def execute(self, context):
        if bpy.context.scene.tool_settings.use_proportional_edit == False:
            bpy.context.scene.tool_settings.use_proportional_edit = True
            bpy.context.scene.tool_settings.proportional_edit_falloff = 'SPHERE'
 
        if bpy.context.scene.tool_settings.proportional_edit_falloff != 'SPHERE': 
            bpy.context.scene.tool_settings.proportional_edit_falloff = 'SPHERE' 
        return {'FINISHED'}    
 
class ProportionalRootEdt(Operator):
    bl_idname = "proportional_edt.root"
    bl_label = "Proportional Root EditMode"
 
    def execute(self, context):
        if bpy.context.scene.tool_settings.use_proportional_edit == False:
            bpy.context.scene.tool_settings.use_proportional_edit = True
            bpy.context.scene.tool_settings.proportional_edit_falloff = 'ROOT'
 
        if bpy.context.scene.tool_settings.proportional_edit_falloff != 'ROOT': 
            bpy.context.scene.tool_settings.proportional_edit_falloff = 'ROOT' 
        return {'FINISHED'}
 
class ProportionalSharpEdt(Operator):
    bl_idname = "proportional_edt.sharp"
    bl_label = "Proportional Sharp EditMode"
 
    def execute(self, context):
        if bpy.context.scene.tool_settings.use_proportional_edit == False:
            bpy.context.scene.tool_settings.use_proportional_edit = True
            bpy.context.scene.tool_settings.proportional_edit_falloff = 'SHARP'
 
        if bpy.context.scene.tool_settings.proportional_edit_falloff != 'SHARP': 
            bpy.context.scene.tool_settings.proportional_edit_falloff = 'SHARP' 
        return {'FINISHED'}
 
class ProportionalLinearEdt(Operator):
    bl_idname = "proportional_edt.linear"
    bl_label = "Proportional Linear EditMode"
 
    def execute(self, context):
        if bpy.context.scene.tool_settings.use_proportional_edit == False:
            bpy.context.scene.tool_settings.use_proportional_edit = True
            bpy.context.scene.tool_settings.proportional_edit_falloff = 'LINEAR'
 
        if bpy.context.scene.tool_settings.proportional_edit_falloff != 'LINEAR': 
            bpy.context.scene.tool_settings.proportional_edit_falloff = 'LINEAR' 
        return {'FINISHED'}  
 
class ProportionalConstantEdt(Operator):
    bl_idname = "proportional_edt.constant"
    bl_label = "Proportional Constant EditMode"
 
    def execute(self, context):
        if bpy.context.scene.tool_settings.use_proportional_edit == False:
            bpy.context.scene.tool_settings.use_proportional_edit = True
            bpy.context.scene.tool_settings.proportional_edit_falloff = 'CONSTANT'
 
        if bpy.context.scene.tool_settings.proportional_edit_falloff != 'CONSTANT': 
            bpy.context.scene.tool_settings.proportional_edit_falloff = 'CONSTANT'
        return {'FINISHED'}  
 
class ProportionalRandomEdt(Operator):
    bl_idname = "proportional_edt.random"
    bl_label = "Proportional Random EditMode"
 
    def execute(self, context):
        if bpy.context.scene.tool_settings.use_proportional_edit == False:
            bpy.context.scene.tool_settings.use_proportional_edit = True
            bpy.context.scene.tool_settings.proportional_edit_falloff = 'RANDOM'
 
        if bpy.context.scene.tool_settings.proportional_edit_falloff != 'RANDOM': 
            bpy.context.scene.tool_settings.proportional_edit_falloff = 'RANDOM'
        return {'FINISHED'}
  
######################
#      Shading       #               
###################### 
class ShadingVariable(Operator):
    bl_idname = "object.shadingvariable"
    bl_label = "Shading Variable"
    bl_options = {'REGISTER', 'UNDO'}
    variable : StringProperty()
 
    @classmethod
    def poll(cls, context):
        return True
 
    def execute(self, context):
        bpy.context.space_data.shading.type=self.variable
        return {'FINISHED'} 
                  
class ShadingSmoothAndFlat(Operator):
    """
    CLICK - SMOOTH
    SHIFT - FLAT
    """
    bl_idname = "shading.smoothflat"
    bl_label = "Shading Smooth"
    bl_options = {'REGISTER', 'UNDO'}
 
    def invoke(self, context, event):
        if event.shift:
            if bpy.context.object.mode == "OBJECT":
                bpy.ops.object.shade_flat()
 
            elif bpy.context.object.mode == "EDIT":
                bpy.ops.object.mode_set(mode = 'OBJECT')
                bpy.ops.object.shade_flat()
                bpy.ops.object.mode_set(mode = 'EDIT')        
        else:
            if bpy.context.object.mode == "OBJECT":
                bpy.ops.object.shade_smooth()
     
            elif bpy.context.object.mode == "EDIT":
                bpy.ops.object.mode_set(mode = 'OBJECT')
                bpy.ops.object.shade_smooth()
                bpy.ops.object.mode_set(mode = 'EDIT')
        return {'FINISHED'} 

#######################################################
# Object Select                                       #
####################################################### 
class Selection(Operator):
    """    SELECT/DESELECT
    CLICK - Select Toggle
    SHIFT - Select Invert
    CTRL  - Deselect
    ALT    - Select Camera (Object Mode)"""

    bl_idname = 'object.mesh_selection'
    bl_label = "Select/Deselect"
    bl_options = {'REGISTER', 'UNDO'}
    def invoke(self, context, event):            
        if event.shift:
            if context.object.mode == 'EDIT':
                bpy.ops.mesh.select_all(action='INVERT')
            else:
                bpy.ops.object.select_all(action='INVERT')

        elif event.ctrl:
            if context.object.mode == 'EDIT':
                bpy.ops.mesh.select_all(action='DESELECT')
            else:
                bpy.ops.object.select_all(action='DESELECT')

        elif event.alt:
            bpy.ops.object.select_camera()
                
        else:
            if context.object.mode == 'EDIT':
                bpy.ops.mesh.select_all(action='TOGGLE')
            else:
                bpy.ops.object.select_all(action='TOGGLE')

        return {'FINISHED'}

class ToggleHideEmpty(Operator):
    """CLICK - HIDE EMPTY """    
    bl_idname = 'object.hide_empty'
    bl_label = "Toggle Hide Empty"
    bl_options = {'REGISTER', 'UNDO'}
    def invoke(self, context, event):            
        for ob in bpy.data.objects:
            if ob.type == "EMPTY":
                if ob.hide_viewport == True:
                    ob.hide_viewport  = False
                else:
                    ob.hide_viewport  = True
        return {'FINISHED'}
    
        
#######################################################
# Object Hide/Unhide                                  #
####################################################### 
class RestrictView(Operator):
    """    
    CLICK - Hide View Object
    SHIFT - Clear View Object"""

    bl_idname = "object.viewrestrict"
    bl_label = "Hide/Clear View"
    
    def invoke(self, context, event):
        if context.object is not None:
            if event.shift:
                if context.object.mode == 'OBJECT':
                    bpy.ops.object.hide_view_clear()
                    bpy.ops.object.select_all(action='DESELECT')
                    
                if context.object.mode == 'EDIT':
                    bpy.ops.mesh.reveal()
            else:
                if context.object.mode == 'OBJECT':
                    bpy.ops.object.hide_view_set(unselected=True)
                elif context.object.mode == 'EDIT':
                    bpy.ops.mesh.hide(unselected=True)  
        
        elif context.object is None:
             if event.shift:
                bpy.ops.object.hide_view_clear()
                bpy.ops.object.select_all(action='DESELECT')
             else:
                bpy.ops.object.hide_view_set(unselected=True)       
        return {'FINISHED'}

######################
#      Snapping      #               
######################
class Snap_Elements(Operator):
    bl_idname = "object.snapping"
    bl_label = "Snap Elements"

    snap_elements : EnumProperty(
        items=(('vertex', "VERTEX", "VERTEX"),
               ('edge', "EDGE", "EDGE"),
               ('face', "FACE", "FACE"),
               ('increment', "INCREMENT", "INCREMENT"),
               ('volume', "VOLUME", "VOLUME"),
               ('grid', "GRID", "GRID"),
               ),
        default='vertex'
    )

    def execute(self, context):
        bpy.context.scene.tool_settings.use_snap = True

        #Elements
        if self.snap_elements == 'vertex':
            bpy.context.scene.tool_settings.snap_elements = {'VERTEX'}
        elif self.snap_elements == 'edge':
            bpy.context.scene.tool_settings.snap_elements = {'EDGE'}
        elif self.snap_elements == 'face':
            bpy.context.scene.tool_settings.snap_elements = {'FACE'}
        elif self.snap_elements == 'increment':
            bpy.context.scene.tool_settings.snap_elements = {'INCREMENT'}
        elif self.snap_elements == 'volume':
            bpy.context.scene.tool_settings.snap_elements = {'VOLUME'}
        elif self.snap_elements == 'grid':
            bpy.context.scene.tool_settings.transform_pivot_point = 'BOUNDING_BOX_CENTER'
            bpy.context.scene.tool_settings.snap_elements = {'INCREMENT'}
            bpy.context.scene.tool_settings.use_snap_grid_absolute = True
            bpy.context.scene.tool_settings.use_snap_translate = True
        return {'FINISHED'}
                  
#######################################################     
#Camera Border
#######################################################     
class render_border_camera(Operator):    
    bl_idname = "view3d.render_border_camera"
    bl_label = "Camera as Render Border"

    @classmethod
    def poll(cls, context):
        return context.space_data.region_3d.view_perspective == "CAMERA"

    def execute(self, context):
        render = context.scene.render
        render.use_border = True
        render.border_min_x = 0
        render.border_min_y = 0
        render.border_max_x = 1
        render.border_max_y = 1

        return {"FINISHED"}                                              
                                                                                                          
#--------------------------------------------------------------------------
#Particles
#--------------------------------------------------------------------------
#Particle Path Steps
class ParticlePathSteps(Operator):
    bl_idname = "object.particlepathsteps"
    bl_label = "Particle Path Steps"
    bl_options = {'REGISTER', 'UNDO'}
    variable : bpy.props.IntProperty()

    def execute(self, context):
        bpy.context.scene.tool_settings.particle_edit.draw_step = self.variable
        return {'FINISHED'} 

#Particle Childrens
class ParticleChildrens(Operator):
    bl_idname = "object.particlechildren"
    bl_label = "Particle Childrens"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        if bpy.context.scene.tool_settings.particle_edit.show_particles == True:
            bpy.context.scene.tool_settings.particle_edit.show_particles = False
            bpy.context.area.type = 'VIEW_3D'
        elif bpy.context.scene.tool_settings.particle_edit.show_particles == False:
            bpy.context.scene.tool_settings.particle_edit.show_particles = True 
            bpy.context.area.type = 'VIEW_3D' 
        return {'FINISHED'}            

#Particle Length
class ParticleLength(Operator):
    bl_idname = "object.particlelength"
    bl_label = "Particle Length"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        if bpy.context.scene.tool_settings.particle_edit.use_preserve_length == True:
            bpy.context.scene.tool_settings.particle_edit.use_preserve_length = False
            bpy.context.area.type = 'VIEW_3D'
        elif bpy.context.scene.tool_settings.particle_edit.use_preserve_length == False:
            bpy.context.scene.tool_settings.particle_edit.use_preserve_length = True  
            bpy.context.area.type = 'VIEW_3D' 
        return {'FINISHED'}  

#Particle X Mirror
class ParticleXMirror(Operator):
    bl_idname = "object.particlexmirror"
    bl_label = "Particle X Mirror"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        if bpy.context.object.data.use_mirror_x == True:
            bpy.context.object.data.use_mirror_x = False
            bpy.context.area.type = 'VIEW_3D'
        elif bpy.context.object.data.use_mirror_x == False:
            bpy.context.object.data.use_mirror_x = True  
            bpy.context.area.type = 'VIEW_3D' 
        return {'FINISHED'}  
    
#Particle Root
class ParticleRoot(Operator):
    bl_idname = "object.particleroot"
    bl_label = "Particle Root"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        if bpy.context.scene.tool_settings.particle_edit.use_preserve_root == True:
            bpy.context.scene.tool_settings.particle_edit.use_preserve_root = False
            bpy.context.area.type = 'VIEW_3D'
        elif bpy.context.scene.tool_settings.particle_edit.use_preserve_root == False:
            bpy.context.scene.tool_settings.particle_edit.use_preserve_root = True  
            bpy.context.area.type = 'VIEW_3D' 
        return {'FINISHED'} 
    
#Selection Particles Mode
class SelectionParticlesMode(Operator):
    bl_idname = "object.spm"
    bl_label = "Selection Particles Mode"
    bl_options = {'REGISTER', 'UNDO'}
    variable : bpy.props.StringProperty()

    def execute(self, context):
        bpy.context.scene.tool_settings.particle_edit.select_mode = self.variable
        return {'FINISHED'}             

#Selection Particles Brushes
class SelectionParticlesBrushes(Operator):
    bl_idname = "object.spb"
    bl_label = "Selection Particles Brushes"
    bl_options = {'REGISTER', 'UNDO'}
    variable : bpy.props.StringProperty()

    def execute(self, context):
        bpy.context.scene.tool_settings.particle_edit.tool = self.variable
        bpy.context.area.type = 'VIEW_3D'
        return {'FINISHED'}  

#Particles Interpolate
class ParticlesInterpolate(Operator):
    bl_idname = "object.particleinterpolate"
    bl_label = "Particles Interpolate"
    bl_options = {'REGISTER', 'UNDO'}
    variable : bpy.props.IntProperty()

    def execute(self, context):
        if bpy.context.scene.tool_settings.particle_edit.use_default_interpolate == True:
            bpy.context.scene.tool_settings.particle_edit.use_default_interpolate = False
            bpy.context.area.type = 'VIEW_3D'
        elif bpy.context.scene.tool_settings.particle_edit.use_default_interpolate == False:
            bpy.context.scene.tool_settings.particle_edit.use_default_interpolate = True  
            bpy.context.area.type = 'VIEW_3D' 
        return {'FINISHED'} 

################
#Pin/Unpin
################
class Pin_Unpin(Operator):  
    bl_idname = "uv.pinunpin"  
    bl_label = "Pin, SHIFT to Clear Pin" 
    bl_description = "Add Pin, Ctrl to Remove Pin"
        
    def invoke(self, context, event):        
        if event.shift:
            bpy.ops.uv.pin(clear=True)
            self.report({'INFO'}, "Pin UV Removed")
        else:    
            bpy.ops.uv.pin()
            self.report({'INFO'}, "Pin UV Added")
        return {'FINISHED'}  
            
######################
#       Modes        #               
###################### 
# Define Class Texture Paint
class ClassTexturePaint(Operator):
    bl_idname = "class.pietexturepaint"
    bl_label = "Class Texture Paint"
    bl_options = {'REGISTER', 'UNDO'}
 
    def execute(self, context): 
        if bpy.context.object.mode == "EDIT":
            bpy.ops.object.mode_set(mode="OBJECT")
            bpy.ops.paint.texture_paint_toggle()
        else:
            bpy.ops.paint.texture_paint_toggle()
        return {'FINISHED'}
 
# Define Class Weight Paint
class ClassWeightPaint(Operator):
    bl_idname = "class.pieweightpaint"
    bl_label = "Class Weight Paint"
    bl_options = {'REGISTER', 'UNDO'}
 
    def execute(self, context): 
        if bpy.context.object.mode == "EDIT":
            bpy.ops.object.mode_set(mode="OBJECT")
            bpy.ops.paint.weight_paint_toggle()
        else:
            bpy.ops.paint.weight_paint_toggle()
        return {'FINISHED'}
 
# Define Class Vertex Paint
class ClassVertexPaint(Operator):
    bl_idname = "class.pievertexpaint"
    bl_label = "Class Vertex Paint"
    bl_options = {'REGISTER', 'UNDO'}
 
    def execute(self, context): 
        if bpy.context.object.mode == "EDIT":
            bpy.ops.object.mode_set(mode="OBJECT")
            bpy.ops.paint.vertex_paint_toggle()
        else:
            bpy.ops.paint.vertex_paint_toggle()
        return {'FINISHED'}
 
# Define Class Particle Edit
class ClassParticleEdit(Operator):
    bl_idname = "class.pieparticleedit"
    bl_label = "Class Particle Edit"
    bl_options = {'REGISTER', 'UNDO'}
 
    def execute(self, context): 
        if bpy.context.object.mode == "EDIT":
            bpy.ops.object.mode_set(mode="OBJECT")
            bpy.ops.particle.particle_edit_toggle()
        else:
            bpy.ops.particle.particle_edit_toggle()
 
        return {'FINISHED'}    
 
# Define Class Object Mode
class ClassObject(Operator):
    bl_idname = "class.object"
    bl_label = "Class Object"
    bl_options = {'REGISTER', 'UNDO'}
 
    def execute(self, context): 
        if bpy.context.object.mode == "OBJECT":
            bpy.ops.object.mode_set(mode="EDIT")
        else:
            bpy.ops.object.mode_set(mode="OBJECT") 
        return {'FINISHED'} 
######################
#   Selection Mode   #               
######################
# Define Class Vertex
class ClassVertex(Operator):
    bl_idname = "class.vertex"
    bl_label = "Class Vertex"
    bl_options = {'REGISTER', 'UNDO'}
 
    def execute(self, context): 
        if bpy.context.object.mode != "EDIT":
            bpy.ops.object.mode_set(mode="EDIT")
            bpy.ops.mesh.select_mode(use_extend=False, use_expand=False, type='VERT')
        if bpy.ops.mesh.select_mode != "EDGE, FACE":
            bpy.ops.mesh.select_mode(use_extend=False, use_expand=False, type='VERT') 
            return {'FINISHED'}
 
# Define Class Edge
class ClassEdge(Operator):
    bl_idname = "class.edge"
    bl_label = "Class Edge"
    bl_options = {'REGISTER', 'UNDO'}
 
    def execute(self, context):
        if bpy.context.object.mode != "EDIT":
            bpy.ops.object.mode_set(mode="EDIT")
            bpy.ops.mesh.select_mode(use_extend=False, use_expand=False, type='EDGE')
        if bpy.ops.mesh.select_mode != "VERT, FACE":
            bpy.ops.mesh.select_mode(use_extend=False, use_expand=False, type='EDGE') 
            return {'FINISHED'}
 
# Define Class Face
class ClassFace(Operator):
    bl_idname = "class.face"
    bl_label = "Class Face"
    bl_options = {'REGISTER', 'UNDO'}
 
    def execute(self, context): 
        if bpy.context.object.mode != "EDIT":
            bpy.ops.object.mode_set(mode="EDIT")
            bpy.ops.mesh.select_mode(use_extend=False, use_expand=False, type='FACE')
        if bpy.ops.mesh.select_mode != "VERT, EDGE":
            bpy.ops.mesh.select_mode(use_extend=False, use_expand=False, type='FACE')
            return {'FINISHED'}
         
# Components Selection Mode
class VertsEdges(Operator):
    bl_idname = "verts.edges"
    bl_label = "Verts Edges"
    bl_options = {'REGISTER', 'UNDO'}
 
    def execute(self, context):
        if bpy.context.object.mode != "EDIT":
            bpy.ops.object.mode_set(mode="EDIT")
            bpy.context.tool_settings.mesh_select_mode = (True, True, False)
        if bpy.context.object.mode == "EDIT":
            bpy.context.tool_settings.mesh_select_mode = (True, True, False)
            return {'FINISHED'}
 
 
class EdgesFaces(Operator):
    bl_idname = "edges.faces"
    bl_label = "EdgesFaces"
    bl_options = {'REGISTER', 'UNDO'}
 
    def execute(self, context): 
        if bpy.context.object.mode != "EDIT":
            bpy.ops.object.mode_set(mode="EDIT")
            bpy.context.tool_settings.mesh_select_mode = (False, True, True)
        if bpy.context.object.mode == "EDIT":
            bpy.context.tool_settings.mesh_select_mode = (False, True, True)
            return {'FINISHED'}
 
class VertsFaces(Operator):
    bl_idname = "verts.faces"
    bl_label = "Verts Faces"
    bl_options = {'REGISTER', 'UNDO'}
 
    def execute(self, context):  
        if bpy.context.object.mode != "EDIT":
            bpy.ops.object.mode_set(mode="EDIT")
            bpy.context.tool_settings.mesh_select_mode = (True, False, True)
        if bpy.context.object.mode == "EDIT":
            bpy.context.tool_settings.mesh_select_mode = (True, False, True)
            return {'FINISHED'}
 
class VertsEdgesFaces(Operator):
    bl_idname = "verts.edgesfaces"
    bl_label = "Verts Edges Faces"
    bl_options = {'REGISTER', 'UNDO'}
 
    def execute(self, context):  
        if bpy.context.object.mode != "EDIT":
            bpy.ops.object.mode_set(mode="EDIT")
            bpy.context.tool_settings.mesh_select_mode = (True, True, True)
        if bpy.context.object.mode == "EDIT":
            bpy.context.tool_settings.mesh_select_mode = (True, True, True)
            return {'FINISHED'} 
                 
###########################
#   Recalculate / Flip Objects              
###########################
class RecalcNormalsObjects(Operator):
    """ 
    CLICK - Recalculate normals of all selected objects
    ALT  - Flip Direnction of all selected objects
    """
    bl_idname = 'recalculate.normals'
    bl_label = 'Recalculate / Flip'
    
    type_flip : EnumProperty(
        items = (('object', "objectmode", ""),
                 ('edit_rec', "edit recalculate", ""),
                 ('edit_flip', "edit flip", "")),
                 default = 'object'
                 )
                     
    def invoke(self, context, event):        
        objs = context.selected_objects
        oldactive = context.active_object
        
        if self.type_flip == 'edit_rec':   
            bpy.ops.mesh.normals_make_consistent(inside=False)
            
        if self.type_flip == 'edit_flip':  
            bpy.ops.mesh.flip_normals()
        
        if self.type_flip == 'object':            
            if event.alt:
                for obj in objs:
                    if obj.type == 'MESH':
                        if bpy.context.object.mode == "OBJECT":
                            context.view_layer.objects.active = obj
                            bpy.ops.object.editmode_toggle()
                            bpy.ops.mesh.select_all(action='SELECT')
                            bpy.ops.mesh.flip_normals()
                            bpy.ops.object.editmode_toggle()
                            
                        elif bpy.context.mode == 'EDIT_MESH':
                            context.view_layer.objects.active = obj
                            bpy.ops.mesh.select_all(action='SELECT')
                            bpy.ops.mesh.flip_normals()
                            bpy.ops.object.editmode_toggle()                    
                        self.report({'INFO'}, "Flip Direction of " + obj.name)
                        
            else:
                for obj in objs:
                    if obj.type == 'MESH':
                        if bpy.context.object.mode == "OBJECT":
                            context.view_layer.objects.active = obj
                            bpy.ops.object.editmode_toggle()
                            bpy.ops.mesh.select_all(action='SELECT')
                            bpy.ops.mesh.normals_make_consistent(inside=False)
                            bpy.ops.object.editmode_toggle()
                                                
                        elif bpy.context.mode == 'EDIT_MESH':
                             context.view_layer.objects.active = obj
                             bpy.ops.mesh.select_all(action='SELECT')
                             bpy.ops.mesh.normals_make_consistent(inside=False)
                             bpy.ops.object.editmode_toggle()
                        self.report({'INFO'}, "Recalculated normals of " + obj.name)
        return {'FINISHED'}

#############
#Mark Sharp
#############
class Mesh_Toogle_Mark(Operator):
    "Toggle Mark Seam, Sharp, Edge bevel, Edge Crease"
    bl_idname = "object.toggle_mark"
    bl_label = "Toggle Mark" 
    
    type_toggle : EnumProperty(
        items = (('bevel', "Bevel", ""),
                 ('crease', "Crease", ""),
                 ('seam', "Seam", ""),
                 ('sharp', "Sharp", "")),
                 default = 'seam'
                 )
                     
    def execute(self,context):     
        obj = bpy.context.object
        me = obj.data
        bm = bmesh.from_edit_mesh(me) 
        bw = bm.edges.layers.bevel_weight.verify()
        cl = bm.edges.layers.crease.verify()
        cr = bm.edges.layers.crease.verify()
        selected = [e for e in bm.edges if e.select]
    
        if self.type_toggle == 'bevel': 
           if any(e[bw] == 1 for e in selected):                    
               bpy.ops.transform.edge_bevelweight(value=-1)
           else:
               bpy.ops.transform.edge_bevelweight(value=1)
           bmesh.update_edit_mesh(me, True)
        
        if self.type_toggle == 'crease': 
            if any(e[cl] == 1 for e in selected):                    
                bpy.ops.transform.edge_crease(value=-1)
            else:
                bpy.ops.transform.edge_crease(value=1)
                
        if self.type_toggle == 'sharp': 
            if any(e.smooth == True for e in selected):
                bpy.ops.mesh.mark_sharp()
            else:
                bpy.ops.mesh.mark_sharp(clear=True)
                
        if self.type_toggle == 'seam': 
            for e in me.edges:
                if e.select and e.use_seam == False:
                    bpy.ops.mesh.mark_seam()

                elif e.select and e.use_seam == True:
                    bpy.ops.mesh.mark_seam(clear=True)
                    
        bmesh.update_edit_mesh(me, True)            
        return {'FINISHED'}   

######################
#  Switch Cam Resolution
######################      
class SwitchRenderResolution(Operator):
    'Switch Resolution'
    bl_idname="swithres.toggle"
    bl_label="Switch Resolution"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self,context):
        rd = context.scene.render
        rs_x = rd.resolution_x
        rs_y = rd.resolution_y

        if rd.resolution_x == rs_x:
            rd.resolution_x = rs_y
            rd.resolution_y = rs_x
        else:
            rd.resolution_x = rs_x
            rd.resolution_y = rs_y
        return {'FINISHED'}
                    
################    
#Create Hole
################
class MeshCreateHole(Operator):
    """    CREATE CIRCLES    
    CLICK - Add Circle
    SHIFT - Add Circle with Loop
    CTRL  - Add Circle on Individual Faces
    ALT    - Subdivide Circle
    
    You can combine CTRL+SHIFT+ALT
    """                               
    bl_idname = "object.meshcreatehole"
    bl_label = "Create Hole on a Selection"    

    @classmethod                                     
    def poll(cls, context):                         
        obj = context.active_object
        if len([obj for obj in context.selected_objects if context.object is not None if obj.type == 'MESH' if bpy.context.object.mode == "EDIT"]) == 1:
            return True

    def invoke(self, context, event):
        WM = context.window_manager  
        obj = bpy.context.active_object
        mesh = obj.data
        bm = bmesh.from_edit_mesh(mesh)
        sel_vert=[v.index for v in bm.verts if v.select]  
        faces_list=[] 
        
        #If faces
        if tuple (bpy.context.tool_settings.mesh_select_mode) == (False, False, True) :               
            #Individual
            if event.ctrl :
                bpy.ops.mesh.inset(thickness=0.02, use_individual=True)
            else:
                bpy.ops.mesh.inset(thickness=0.02)
            
            #Subdivide
            if event.alt :
                bpy.ops.mesh.subdivide(smoothness=0)
                bpy.ops.mesh.dissolve_mode()

                bpy.ops.mesh.poke()
            bpy.ops.mesh.looptools_circle()
            
            #Add Loop
            if event.shift :
                bpy.ops.mesh.inset(thickness=0.02)
                bpy.ops.mesh.select_more()
            
            bpy.context.scene.tool_settings.transform_pivot_point = 'INDIVIDUAL_ORIGINS'
            bpy.ops.transform.resize('INVOKE_DEFAULT')                     
        
        elif tuple (bpy.context.tool_settings.mesh_select_mode) == (True, False, False) :
                 
            if event.alt :
                for v in sel_vert:
                    bpy.ops.mesh.select_all(action='DESELECT')
                    bm.verts.ensure_lookup_table()
                    bm.verts[v].select = True
                    
                    bpy.ops.mesh.bevel(offset=0.1, vertex_only=True)
                    bpy.ops.mesh.select_mode(use_extend=False, use_expand=False, type='FACE')
                    bpy.ops.mesh.subdivide(smoothness=0)
                    bpy.ops.mesh.dissolve_mode()
                    bpy.ops.mesh.looptools_circle()
                    bpy.ops.mesh.poke()
                    
                    if event.shift :
                        bpy.ops.mesh.inset(thickness=0.02)
                        bpy.ops.mesh.select_more()
                    
                    for f in bm.faces:
                        if f.select:
                            faces_list.append(f)
                                    
                for f in faces_list:
                    f.select = True

            elif event.shift :
                bpy.ops.mesh.bevel(offset=0.1, vertex_only=True)
                bpy.ops.mesh.select_mode(use_extend=False, use_expand=False, type='FACE') 
                bpy.ops.mesh.inset(thickness=0.02)
                bpy.ops.mesh.select_more()
            
            else:
                bpy.ops.mesh.bevel(offset=0.1, vertex_only=True)
                bpy.ops.mesh.select_mode(use_extend=False, use_expand=False, type='FACE')                    
                
            bpy.context.scene.tool_settings.transform_pivot_point = 'INDIVIDUAL_ORIGINS'
            bpy.ops.transform.resize('INVOKE_DEFAULT')         
        else:
            pass   
        
        del(sel_vert[:])   
        del(faces_list[:])         
        return {'FINISHED'}

#######################################################
#   Change Draw Type
####################################################### 
class ToogleBackground(Operator):
    """
    CLICK - Change Unselected Objects Draw Type To Wire
    SHIFT - Hide Unselected Objects
    """
    bl_idname = "view3d.toggle_background"
    bl_label = "Background Hide/Wire"
 
    def invoke(self, context, event):
        if event.shift:
            if bpy.context.mode == 'EDIT_MESH' and bpy.context.object.type == "MESH":
                bpy.ops.object.editmode_toggle()
                active = bpy.context.active_object
                selected = bpy.context.selected_objects
                bpy.ops.object.select_all(action='INVERT')
                bg = bpy.context.selected_objects
                if len(bg) != 0: #If BG is visible
                    for o in bg:  #Hide BG
                        o.hide = True
                    for o in selected:
                        o.select = True

                else:     #Else BG is hidden so unhide it
                    bpy.ops.object.hide_view_clear()
                    selectednew = bpy.context.selected_objects
                    for o in selectednew:
                        o.select = False
                    for o in selected:
                        o.select = True
                    active.select=True
                bpy.ops.object.editmode_toggle()
                
            else: #Object Mode
                active = bpy.context.active_object
                selected = bpy.context.selected_objects
                bpy.ops.object.select_all(action='INVERT')

                bg = bpy.context.selected_objects
                if len(bg) != 0: #If BG is visible
                    for o in bg:  #Hide BG
                        o.hide = True
                    for o in selected:
                        o.select = True
                     
        else:
            if bpy.context.mode == 'EDIT_MESH' and bpy.context.object.type == "MESH":
                bpy.ops.object.editmode_toggle()
                active = bpy.context.active_object
                if active.display_type == 'WIRE':
                    bpy.ops.object.select_all(action='INVERT')
                    selected = bpy.context.selected_objects
                    for o in selected:
                        if o.display_type == 'TEXTURED':
                            o.display_type = 'WIRE'
                    bpy.ops.object.select_all(action='INVERT')
                    active.display_type = 'TEXTURED'
                    bpy.ops.object.editmode_toggle()
                    return {'FINISHED'}

                bpy.ops.object.select_all(action='INVERT')
                selected = bpy.context.selected_objects
                if True in (o.display_type == 'WIRE' for o in selected):
                    for o in selected:
                        if o.display_type == 'WIRE':
                            o.display_type = 'TEXTURED'
                else:
                    for o in selected:
                        if o.display_type == 'TEXTURED':
                            o.display_type = 'WIRE'
                bpy.ops.object.select_all(action='INVERT')
                bpy.ops.object.editmode_toggle()
            else:
                active = bpy.context.active_object
                if active.display_type == 'WIRE':
                    bpy.ops.object.select_all(action='INVERT')
                    selected = bpy.context.selected_objects
                    for o in selected:
                        if o.display_type == 'TEXTURED':
                            o.display_type = 'WIRE'
                    bpy.ops.object.select_all(action='INVERT')
                    active.display_type = 'TEXTURED'
                    return {'FINISHED'}

                bpy.ops.object.select_all(action='INVERT')
                selected = bpy.context.selected_objects
                if True in (o.display_type == 'WIRE' for o in selected):
                    for o in selected:
                        if o.display_type == 'WIRE':
                            o.display_type = 'TEXTURED'
                else:
                    for o in selected:
                        if o.display_type == 'TEXTURED':
                            o.display_type = 'WIRE'
                bpy.ops.object.select_all(action='INVERT')
        return {'FINISHED'}         

####################################################### 
#Change Draw Type To Bounds
#######################################################  
class BoundstoTextured(Operator):
    """
    CLICK - DRAW SOLID
    SHIFT - DRAW WIRE
    ALT - DRAW BOUNDS
    """
    bl_idname='boundstextured.toggle'
    bl_label='Bounds to Textured Toggle'

    def invoke(self, context, event):
        s = bpy.context.active_object.display_type
        if event.shift :
            for o in bpy.context.selected_objects:
                o.display_type = 'WIRE' 
                    
        elif event.alt :
            for o in bpy.context.selected_objects:
                o.display_type = 'BOUNDS'
                            
        else:          
            for o in bpy.context.selected_objects:
                o.display_type = 'TEXTURED' 
        return {'FINISHED'}
            
#################################
#    Origin In Edit Mode
#################################  
class OriginToSel(Operator):
    'Moves object origin to selection (Edit mode only, cannot undo)'
    bl_idname = "ob.origin_to_selected"
    bl_label = "Origin to Sel"

    @classmethod
    def poll(cls, context):
        return context.active_object and (bpy.context.mode == 'EDIT_MESH' or bpy.context.mode == 'EDIT_CURVE')

    def execute(self, context,):
        bpy.ops.view3d.snap_cursor_to_selected()
        bpy.ops.object.editmode_toggle()
        bpy.ops.object.origin_set(type='ORIGIN_CURSOR', center='MEDIAN')
        bpy.ops.object.editmode_toggle()
        return {'FINISHED'}
    
#################################
#    Origin To Bottom
#################################  
class ObjectPivotBottom(Operator):
    bl_idname = "ob.pivotobottom"
    bl_label = "Pivot To Bottom"
    bl_description = ("Set the Pivot Point To Lowest Point\n"
                      "Needs an Active Object of the Mesh type")

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and obj.type == "MESH"

    def execute(self, context):
        bpy.ops.object.mode_set(mode='OBJECT')
        bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)
        bpy.ops.object.origin_set(type='ORIGIN_GEOMETRY')
        o = context.active_object
        init = 0
        for x in o.data.vertices:
            if init == 0:
                a = x.co.z
                init = 1
            elif x.co.z < a:
                a = x.co.z

        for x in o.data.vertices:
            x.co.z -= a

        o.location.z += a
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.object.editmode_toggle()
        bpy.ops.object.location_clear(clear_delta=False)
        return {'FINISHED'}

        
#################################
#    Select Ngons & Tris
#################################      
class DATA_OP_facetype_select(Operator):
    """Select all faces of a certain type"""
    bl_idname = "datamesh.facetype_select"
    bl_label = "Select by face type"
    face_type : EnumProperty(
        name="Select faces:",
        items = (("3","Triangles","Faces made up of 3 vertices"),
                 ("5","Ngons","Faces made up of 5 and more vertices")),
        default = "5")
    
    # @classmethod
    # def poll(cls, context):
    #     return context.object is not None and context.object.type == 'MESH' and bpy.context.object.mode == "EDIT"

    @classmethod
    def poll(cls, context):
        return context.object is not None and context.object.type == 'MESH'

    def execute(self, context):
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.mesh.select_mode(use_extend=False, use_expand=False, type='FACE')
        bpy.ops.mesh.select_all(action='DESELECT')
        if self.face_type == "3":
            bpy.ops.mesh.select_face_by_sides(number=3, type='EQUAL')
        else:
            bpy.ops.mesh.select_face_by_sides(number=4, type='GREATER')     
        return {'FINISHED'}

#################################
#   Merge Tool
#################################
class mesh_smart_merge(Operator):
    """
    CLICK - MERGE LAST
    SHIFT - MODAL MERGE
    """
    bl_idname = "object.smart_merge"
    bl_label = "Merge Tool"
    
    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and obj.type == "MESH" and bpy.context.mode == 'EDIT_MESH'
    
    def invoke(self, context, event):        
        if event.shift:
            bpy.ops.modal.merge_tool('INVOKE_DEFAULT', True) 
        else:    
            bpy.ops.modal.merge_manual('INVOKE_DEFAULT', True) 
        return {'FINISHED'}  

#################################
#   Smart Connect
#################################
class mesh_smart_connect(Operator):
    """
    CLICK - MANUAL CONNECT
    ALT - MODAL CONNECT
    """
    bl_idname = "object.smart_connect"
    bl_label = "Connect"
    
    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and obj.type == "MESH" and bpy.context.mode == 'EDIT_MESH'
    
    def invoke(self, context, event):        
        if event.alt:
            bpy.ops.modal.connect_tool('INVOKE_DEFAULT', True) 
        else:    
            bpy.ops.mesh.vert_connect_path()
        return {'FINISHED'} 
            
#################################
#    Reload Multiple Images
#################################  
class ReloadMultipleImages(Operator):
    "Auto Reload Multiple Images"
    bl_idname = "reload.image"
    bl_label = "Reload Multiple Images"

    def execute(self, context):
        for img in bpy.data.images:
            img.reload()
        bpy.ops.wm.redraw_timer(type='DRAW_WIN_SWAP', iterations=1)
        self.report({'INFO'}, "Reload All Image Textures")  
        return {'FINISHED'}

######################
#   Resize to 0  
######################
class ClearParent(Operator):
    "Clear Parent & Keep Tranfrom + Delete Empty"
    bl_idname = "ob.clear_parent"
    bl_label = "Clear Parent"

    def execute(self, context):
        bpy.ops.object.parent_clear(type='CLEAR_KEEP_TRANSFORM')
        childless_empties = [e for e in bpy.data.objects
                if not (e.data or e.children)]

        while childless_empties:
            bpy.data.objects.remove(childless_empties.pop(), do_unlink=True)
        return {'FINISHED'}
    
#################################
#    AutoSmooth
#################################  
class AutoSmoothOption(Operator):
    bl_idname = "auto.smooth_options"
    bl_label = "Auto Smooth"
    
    type_smooth : EnumProperty(
        items = (('30', "30", ""),
                 ('60', "60", ""),
                 ('90', "90", ""),
                 ('180', "180", "")),
                 default = '30'
                 )

    @classmethod
    def poll(cls, context):
        return context.active_object is not None
        
    def execute(self, context):
        bpy.context.object.data.use_auto_smooth = True
        if self.type_smooth == '30':                     
            bpy.context.object.data.auto_smooth_angle = 0.523599
        if self.type_smooth == '60':                     
            bpy.context.object.data.auto_smooth_angle = 1.0472
        if self.type_smooth == '90':                     
            bpy.context.object.data.auto_smooth_angle = 1.5708
        if self.type_smooth == '180':                     
            bpy.context.object.data.auto_smooth_angle = 3.14159
        return {'FINISHED'}
            
######################################
#   Select Seam Edge From Object Mode
#####################################
class Mesh_Edge_select_seams(Operator):
    bl_idname = "meshedge.select_seams"
    bl_label = "Select Seams"
    bl_description = "Set seam edges selected"
        
    def execute(self, context):
        is_editmode = (context.mode == 'EDIT_MESH')
        if is_editmode:
            obList = context.objects_in_mode_unique_data
        else:
            obList = [
                ob for ob in context.selected_editable_objects
                if ob.type == 'MESH' and ob.data.library is None
            ]
        
        if(context.mode == 'OBJECT'):
            bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.mesh.select_all(action='DESELECT')
        context.tool_settings.mesh_select_mode = (False, True, False)
        bpy.ops.object.mode_set(mode='OBJECT')
        
        for ob in obList:
            m = ob.data
            for e in m.edges:
                if(e.use_seam):
                    e.select = True
        bpy.ops.object.mode_set(mode='EDIT')
        return {'FINISHED'}

######################################
#   Select Sharp Edge From Object Mode
#####################################
class select_sharp_edge_mode(Operator):
    bl_idname = "meshedge.select_sharp"
    bl_label = "Select Sharp"
    bl_description = "Set sharp edges selected"
        
    def execute(self, context):
        is_editmode = (context.mode == 'EDIT_MESH')
        if is_editmode:
            obList = context.objects_in_mode_unique_data
        else:
            obList = [
                ob for ob in context.selected_editable_objects
                if ob.type == 'MESH' and ob.data.library is None
            ]
            
        if(context.mode == 'OBJECT'):
            bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.mesh.select_all(action='DESELECT')
        context.tool_settings.mesh_select_mode = (False, True, False)
        bpy.ops.object.mode_set(mode='OBJECT')
        
        for ob in obList:
            m = ob.data
            for e in m.edges:
                if(e.use_edge_sharp):
                    e.select = True                    
            if ob.type == 'MESH':
                context.object.data.use_auto_smooth = True
                context.object.data.auto_smooth_angle = 3.14159
        bpy.ops.object.mode_set(mode='EDIT')
        return {'FINISHED'}

#################################
#  Clean Faces
#################################
class ngons_edit_cleanup(Operator):
    bl_idname = "object.clean_ngons"
    bl_label = "Clean Ngons"
    bl_description = "Clean Ngons"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return context.object is not None and context.object.type == 'MESH'

    def execute(self, context):
        bpy.ops.mesh.quads_convert_to_tris(quad_method='BEAUTY', ngon_method='BEAUTY')
        bpy.ops.mesh.tris_convert_to_quads(shape_threshold=2.18166)
        return {"FINISHED"}
    
#################################
#   Seam From Island Object Mode
#################################
class Object_mark_seams_from_uv_islands(Operator):
    bl_idname = "object.mark_seams_from_uv_islands"
    bl_label = "Mark Seams From UV Islands"
    bl_description = "Mark Seams From UV Islands"
    
    @classmethod
    def poll(cls, context):
        ob = context.active_object
        return (ob and ob.type == 'MESH' and (context.mode == 'EDIT_MESH' or context.mode == 'OBJECT') and len(ob.data.uv_layers) > 0)
    
    def execute(self, context):
        e = True
        if(context.mode != 'EDIT_MESH'):
            e = False
            bpy.ops.object.mode_set(mode='EDIT')
        if bpy.context.area.type != 'UV':
            bpy.context.area.ui_type = 'UV'
            bpy.ops.uv.select_all()
            bpy.ops.uv.seams_from_islands()
        bpy.context.area.ui_type = 'VIEW_3D'
        if(not e):
            bpy.ops.object.mode_set(mode='OBJECT')
        return {'FINISHED'}

###########################################
#   Pivot UV Editing
###########################################
class Pivot_UV_Editor(Operator):
    bl_idname = "uv.pivot_point"
    bl_label = "Pivot Point"

    uv_pivot_point : EnumProperty(
        items=(('bbox', "BBOX", "Bounding Box"),
               ('median', "Median", "Median Point"),
               ('cursor', "Cursor", "Cursor Point"),
               ('individual', "Individual", "Individual Origin")),
        default='bbox'
    )

    def execute(self, context):
        sima = context.space_data
        show_uvedit = sima.show_uvedit
        show_maskedit = sima.show_maskedit

        if show_uvedit or show_maskedit:

            #Elements
            if self.uv_pivot_point == 'bbox':
                bpy.context.space_data.pivot_point = 'CENTER'
            elif self.uv_pivot_point == 'median':
                bpy.context.space_data.pivot_point = 'MEDIAN'
            elif self.uv_pivot_point == 'cursor':
                bpy.context.space_data.pivot_point = 'CURSOR'
            elif self.uv_pivot_point == 'individual':
                bpy.context.space_data.pivot_point = 'INDIVIDUAL_ORIGINS'
        return {'FINISHED'}
        
class ApplyMaterial(bpy.types.Operator):
    bl_idname = "object.apply_material"
    bl_label = "Apply material"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if len(bpy.context.selected_objects) > 0:
            for obj in bpy.context.selected_objects:
                if obj.type == 'MESH':
                    return True
        return False

    def execute(self, context):
        tomatoes = context.scene.tomatoes_props
        material_list = tomatoes.selected_material_index
        mat = bpy.data.materials[tomatoes.selected_material_index]

        ob = bpy.context.active_object
        
        if context.object.mode == 'EDIT':
            obj = context.object
            bm = bmesh.from_edit_mesh(obj.data)
 
            selected_face = [f for f in bm.faces if f.select]  
 
            mat_name = [mat.name for mat in bpy.context.object.material_slots if len(bpy.context.object.material_slots)] 
 
            if material_list in mat_name: 
                context.object.active_material_index = material_list 
                bpy.ops.object.material_slot_assign() 
            else:
                bpy.ops.object.material_slot_add() 
                bpy.context.object.active_material = mat 
                bpy.ops.object.material_slot_assign()
                

        if context.object.mode == 'OBJECT':
            for ob in bpy.context.selected_objects:
                # Activate current object to assign material
                bpy.context.view_layer.objects.active = ob

                #Set only one material
                for s in ob.material_slots:
                    bpy.ops.object.material_slot_remove()

                # re-add them and asmatsign material
                ob.data.materials.append(mat)
        return {'FINISHED'}
            
#################################
#   Delete Material
#################################  
class MATERIAL_OT_delete_material(Operator):
    bl_idname = "material.delete_material"
    bl_label = "Delete Material"
    bl_description = "This will delete the material"
    bl_options = {"REGISTER", "UNDO"}

    material_name : StringProperty(name="Material Name")

    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        if self.material_name in bpy.data.materials:
            mat = bpy.data.materials[self.material_name]
            bpy.data.materials.remove(mat,do_unlink=True)
        return {'FINISHED'}

    # def invoke(self,context,event):
    #     wm = context.window_manager
    #     return wm.invoke_props_dialog(self, width=400)

    # def draw(self, context):
    #     layout = self.layout
    #     layout.label(text="Are you sure you want to delete the material?")  
    #     layout.label(text="Material Name: " + self.material_name)    

#################################
#   Delete All Material
#################################  
class MATERIAL_OT_delete_all_material(Operator):
    bl_idname = "material.delete_all_material"
    bl_label = "Delete All Material On Selected Objects"
    bl_description = "This will delete all the material on selected objects"
    bl_options = {"REGISTER", "UNDO"}

    material_name : StringProperty(name="Material Name")

    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        if bpy.context.object.mode == 'EDIT':
            bpy.ops.object.editmode_toggle()
        #CLEAN UP SLOT MATERIAL FOR SELECTED OBJECT --------
        selection_names = bpy.context.selected_objects
        listOfObj=[]
        for obj in selection_names:
            listOfObj.append(obj)
            bpy.context.view_layer.objects.active = obj
            for x in obj.material_slots: #For all of the materials in the selected object:
                obj.active_material_index = 0 #select the top material
                bpy.ops.object.material_slot_remove() #delete it
        bpy.ops.object.editmode_toggle()
        return {'FINISHED'}

#################################
#   Set Transform Preset
#################################  
class UVMode(Operator):
    bl_idname = "op.uv_mode"
    bl_label = "UV Mode"
    bl_options = {'REGISTER'}

    mode: StringProperty()

    def execute(self, context):
        toolsettings = context.scene.tool_settings
        view = context.space_data

        if view.mode != "UV":
            view.mode = "UV"

        if toolsettings.use_uv_select_sync:
            bpy.ops.mesh.select_mode(type=self.mode.replace("VERTEX", "VERT"))

        else:
            toolsettings.uv_select_mode = self.mode

        return {'FINISHED'}

#################################
#   Custom Orientation
#################################      
class SetCustomOrientationPivot(Operator):
    bl_idname = "op.set_custom_orient"
    bl_label = "Set Custom Orient"
    bl_description = "Create Transformation Orientation from Selection"
    bl_options = {'REGISTER', 'UNDO'}
    
    @classmethod
    def poll(cls, context):
        return bpy.context.mode == 'EDIT_MESH'

    def execute(self, context):
        trans_name = "New_Transform"
        bpy.ops.transform.create_orientation(name = trans_name, use = True, overwrite=True)
        return {'FINISHED'}

class DeleteCustomOrientationPivot(Operator):
    bl_idname = "op.delete_custom_orient"
    bl_label = "Delete Custom Orient"
    bl_description = "Delete Transformation Orientation from Selection"
    bl_options = {'REGISTER', 'UNDO'}
    
    @classmethod
    def poll(cls, context):
        return bpy.context.mode == 'EDIT_MESH'

    def execute(self, context):
        trans_name = "New_Transform"
        try:
            context.window.scene.transform_orientation_slots[0].type = trans_name
            bpy.ops.transform.delete_orientation('INVOKE_DEFAULT')
            self.report({'INFO'}, "Delete " + trans_name)
            return {'FINISHED'}
        except:
            return {'FINISHED'}
        return {'FINISHED'}
    
#################################
#   Colorize Object
#################################      
def get_last_node(mat):
    if mat.use_nodes:
        tree = mat.node_tree
        output = tree.nodes.get("Material Output")
        if output:
            surf = output.inputs.get("Surface")
            if surf:
                if surf.links:
                    return surf.links[0].from_node


def lighten_color(color, amount):
    def remap(value, new_low):
        old_range = (1 - 0)
        new_range = (1 - new_low)
        return (((value - 0) * new_range) / old_range) + new_low
    return tuple(remap(c, amount) for c in color)    

class ColorizeObjectsFromMaterials(Operator):
    bl_idname = "object.colorize_from_mat"
    bl_label = "Colorize Objects from Materials"
    bl_description = "Set Object Viewport Colors of selected Objects from their active Materials"
    bl_options = {'REGISTER', 'UNDO'}

    lighten_amount: FloatProperty(name="Lighten", default=0.05, min=0, max=1)

    @classmethod
    def poll(cls, context):
        return bpy.data.materials

    def execute(self, context):
        for mat in bpy.data.materials:
            node = get_last_node(mat)

            if node:
                color = node.inputs.get("Base Color")

                if not color:
                    color = node.inputs.get("Color")

                if color:
                    mat.diffuse_color = lighten_color(color=color.default_value, amount=self.lighten_amount)

        return {'FINISHED'}

    




