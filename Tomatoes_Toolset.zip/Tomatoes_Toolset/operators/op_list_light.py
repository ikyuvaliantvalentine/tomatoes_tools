import bpy
from bpy.types import Operator
from bpy.props import *

class NameSelect(Operator):
    bl_idname = "scene.object_select"
    bl_label = "Select Object"
    bl_description = "Select Object Dengan Nama"
    object : StringProperty()
    
    def execute(self, context):    
        if self.object:
            object = bpy.data.objects[self.object]
            bpy.ops.object.select_all(action="DESELECT")
            object.select_set(True)
            context.view_layer.objects.active = object         
        else:
            object = bpy.data.objects[self.object]
            object.select = True
            context.view_layer.objects.active = object
        return {"FINISHED"}   