import bpy
from bpy.props import *
from bpy.types import PropertyGroup

def update_cb(self, context):    
    CollectonAvaible = False
    for cl in bpy.data.collections:
        print(cl.name)
        if cl.name == "BackupCollection":
            CollectonAvaible = True
            break


    if CollectonAvaible == False:
        bpy.ops.object.mode_set(mode = 'OBJECT')
        bpy.ops.object.select_all(action='DESELECT')
        bpy.ops.collection.create(name="BackupCollection")
        BackupCollection = bpy.data.collections['BackupCollection']
        C = bpy.context
        C.scene.collection.children.link(BackupCollection)
        
    def ShowMessageBox(message = "", title = "Message Box", icon = 'INFO'):

        def draw(self, context):
            self.layout.label(text=message)

        bpy.context.window_manager.popup_menu(draw, title = title, icon = icon)


    src_obj = bpy.context.active_object
    new_obj = src_obj.copy()
    new_obj.data = src_obj.data.copy()
    new_obj.animation_data_clear()
    bpy.data.collections['BackupCollection'].objects.link(new_obj)
    for ob in bpy.data.collections['BackupCollection'].objects:
        ob.hide_viewport = True
        print(ob)

    try:
        bpy.ops.object.modifier_apply(modifier=self.M_prop)
        # bpy.ops.object.modifier_remove(modifier=self.M_prop)
        ShowMessageBox("applied.")

    except:
        ShowMessageBox(self.M_prop +" modifier settings are not complete.", "Error", 'ERROR')
    objects = bpy.context.scene.objects


def update_remove_cb(self, context):    
    def ShowMessageBox(message = "", title = "Message Box", icon = 'INFO'):
        def draw(self, context):
            self.layout.label(text=message)

        bpy.context.window_manager.popup_menu(draw, title = title, icon = icon)

    try:
        bpy.ops.object.modifier_remove(modifier=self.M_prop)
        ShowMessageBox("removed.")

    except:
        ShowMessageBox(self.M_rem_prop +" modifier settings are not complete.", "Error", 'ERROR')
    objects = bpy.context.scene.objects


def items_cb(self, context):
    l = []
    Ml = [item[0] for item in bpy.context.object.modifiers.items()]
    l = [(str(x),x,x) for i,x in enumerate(Ml)]
    #print(itemsL)
    return l

# ------------------------------------------------------------------------              
#   Property Group
# ------------------------------------------------------------------------    
class AdvancedModProperties(PropertyGroup):
    
    M_prop : EnumProperty(items=items_cb, update=update_cb)
    M_rem_prop : bpy.props.EnumProperty(items=items_cb, update=update_remove_cb)