# This file is part of Instant Clean
# Copyright (C) 2023  Ruben Messerschmidt

import bpy


def unused_material_slots(obj):
    bpy.context.view_layer.objects.active = obj
    count = len(bpy.context.active_object.material_slots)
    bpy.ops.object.material_slot_remove_unused()
    count -= len(bpy.context.active_object.material_slots)

    return count

def empty_vertex_groups(obj, bm):
    count = 0
    used_vgs = set()
    bpy.context.view_layer.objects.active = obj
    print(f'{bpy.context.active_object.vertex_groups.items()}')
    for key, value in bpy.context.active_object.vertex_groups.items():
        for vert in bm.verts:
            try:
                v = value.weight(vert.index)
            except:
                continue
            
            if v == 0.0:
                continue
            used_vgs.add(key)
            break
    
    for key, value in bpy.context.active_object.vertex_groups.items():
        if key not in used_vgs:
            bpy.ops.object.vertex_group_set_active(group=key)
            bpy.ops.object.vertex_group_remove()
            count += 1

    return count