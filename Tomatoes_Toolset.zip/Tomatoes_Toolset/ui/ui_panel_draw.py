import bpy
from bpy.types import Panel, UIList
from bpy.props import *
from .. properties import *

####################################
# Panel Polycount
####################################   
def UIObjectData(context, layout):
    tomatoes = context.scene.tomatoes_props
    object_total = []
    selectedMeshes = [o for o in bpy.context.selected_objects if o.type == 'MESH']
    
    totalTriInSelection = 0
    totalNgonsInSelection = 0
    totalEdgesInSelection = 0
    totalFacesInSelection = 0
    totalVertsInSelection = 0
 
    layout.prop(tomatoes, "object_list_by", expand=False)
    
    scriptBox = layout.box()
    row = scriptBox.row(align = True)
    row.label(text = "Object")
    row.label(text = "Verts")
    row.label(text = "Edges")
    row.label(text = "Faces")
    row.label(text = "Tris")
    row.label(text = "Ngons")
    row.label(text = "UV Map")
    
    filter_objects = []
    if tomatoes.object_list_by == "SCENE":
        filter_objects = [
            o for o in bpy.context.scene.objects if o.type == 'MESH']
    else:
        filter_objects = [
            o for o in context.selected_objects if o.type == 'MESH']

    for element in filter_objects:
        tris_count = 0
        ngonCount = 0
        for p in element.data.polygons:
            if len(p.vertices) > 3:
                tris_count = tris_count + len(p.vertices) - 2
            else:
                tris_count = tris_count +1 
            pass
        
            count = p.loop_total
            if count > 4:
                ngonCount += 1 
        
        # adding element stats to total count
        totalTriInSelection += tris_count
        totalNgonsInSelection += ngonCount
        totalVertsInSelection += len(element.data.vertices)
        totalEdgesInSelection += len(element.data.edges)
        totalFacesInSelection += len(element.data.polygons)
        uvmaplist = len(element.data.uv_layers)
        # generate table
        row = scriptBox.row(align = True)
        row.label(text = "%s" % (element.name))
        row.label(text = "%d " % (len(element.data.vertices)))
        row.label(text = "%d " % (len(element.data.edges)))
        row.label(text = "%d " % (len(element.data.polygons)))
        row.label(text = "%d" % (tris_count))
        row.label(text = "%d" % (ngonCount))
        row.label(text = "%d" % (uvmaplist) + " UVMAP ")
                        
    scriptBox.row().separator() 
    row = scriptBox.row(align = True)
    row.label(text = "TOTAL")
    row.label(text = "%d" % (totalVertsInSelection))
    row.label(text = "%d" % (totalEdgesInSelection))
    row.label(text = "%d" % (totalFacesInSelection))
    row.label(text = "%d" % (totalTriInSelection))
    row.label(text = "%d" % (totalNgonsInSelection))
    row.label(text = "")
  
####################################
# Panel List Light Cycles
####################################       
def UICyclesListLight(self, context):
    layout = self.layout  
    objects = bpy.data.objects
    ob_act = context.active_object
    lamps = bpy.data.lights
    maincol = layout.column(align=True)
    box = layout.box()

    if objects:
        rowmain = box.row()
        split = rowmain.split()
        col = split.column()
        row = box.row(align=True)
        
        split = row.split(factor=1.0)
        col = split.column()
        col.label(text="Type")
        
        split = row.split(factor=0.21)
        col = split.column()
        col.label(text="Name")
        
        split = split.split(factor=0.24)
        col = split.column()
        col.label(text="Color")
        
        split = split.split(factor=0.48)
        col = split.column()
        col.label(text="Strength")
        
        split = split.split(factor=0.54)
        col = split.column()
        col.label(text="Use")

        split = split.split(factor=1.0)
        col = split.column()
        col.label(text="Visibility")
        
#        for a in objects:
#            meshlight = a.type == "MESH"
#            
#            if a and meshlight:
#                mesh = a.data
#                
#                row = box.row(align=True)
#                split = row.split(factor=1.0)
#                col = split.column()
#                row = col.row(align=True)
#                
#                for a in bpy.context.object.material_slots:
#                    if not a.material:
#                        continue
#                    if a.material.node_tree and a.material.node_tree.nodes:
#                        for node in a.material.node_tree.nodes:
#                            if node.type == "EMISSION":
#                                row.label(text="", icon='MESH_GRID')
#                                
#                                split = row.split(factor=0.3)
#                                col = split.column()
#                                row = col.row(align=True)
#                                row.active = True
#                                row.operator("scene.object_select", text=mesh.name, emboss=False).object = mesh.name
#                
#                                
#                                ### COLOR ###
#                                if not node.inputs[0].is_linked:
#                                    row.prop(node.inputs[0], 'default_value', text='')
#                                else:
#                                    row.label(text='Connected')
#                                
#                                ### STRENGHT ###
#                                split = split.split(factor=0.45)
#                                col = split.column()
#                                row = col.row(align=True)
#                                if not node.inputs[1].is_linked:
#                                    row.prop(node.inputs[1], 'default_value', text='')
#                                    
#                                split = split.split(factor=0.6)
#                                col = split.column()
#                                row = col.row(align=True)
#                                row.prop(context.object.cycles_visibility, "camera", text='Cam', toggle=True)
#                                row.prop(context.object.cycles_visibility, "diffuse", text='Diff', toggle=True)
#                                row.prop(context.object.cycles_visibility, "glossy", text='Gloss', toggle=True)
#                               
                               
#                                split = split.split(factor=1.0)
#                                col = split.column()
#                                row = col.row(align=True)
#                                row.prop(a, "hide_viewport", text="", emboss=False)
#                                row.prop(a, "hide_select", text="", emboss=False)
#                                row.prop(a, "hide_render", text="", emboss=False)
                                 
        for ob in objects:
#            is_lamp = ob.type in {"LIGHT", "MESH"}
            is_lamp = ob.type in {"LIGHT"}

            if ob and is_lamp:
                lamp = ob.data
        
                row = box.row(align=True)
                split = row.split(factor=1.0)
                col = split.column()
                row = col.row(align=True)
#                col.active = ob == ob_act
            
                row.prop(lamp, "type", text='', icon_only=True, emboss=False, icon="%s" %("LIGHT_%s" %ob.data.type))
                        
                
                split = row.split(factor=0.3)
                col = split.column()
                row = col.row(align=True)
                row.active = True
                row.operator("scene.object_select", text=ob.name, emboss=False).object = ob.name
                
                split = split.split(factor=0.1)
                col = split.column()
                row = col.row()
                if lamp.use_nodes:
                    for node in lamp.node_tree.nodes:
                        if node.type == 'EMISSION':                                       
                            ### COLOR ###
                            if not node.inputs[0].is_linked:
                                row.prop(node.inputs[0], 'default_value', text='')
                            else:
                                row.label(text='Connected')
                            
                            ### STRENGHT ###
                            split = split.split(factor=0.45)
                            col = split.column()
                            row = col.row(align=True)
                            if not node.inputs[1].is_linked:
                                row.prop(node.inputs[1], 'default_value', text='')
                else:
                    split = split.split(factor=0.5)
                    col = split.column()
                    row = col.row(align=True)
                    row.prop(lamp, 'use_nodes', toggle=True)
                             
                split = split.split(factor=0.6)
                col = split.column()
                row = col.row(align=True)
                row.prop(context.object.cycles_visibility, "camera", text='Cam', toggle=True)
                row.prop(context.object.cycles_visibility, "diffuse", text='Diff', toggle=True)
                row.prop(context.object.cycles_visibility, "glossy", text='Gloss', toggle=True)
               
               
                split = split.split(factor=1.0)
                col = split.column()
                row = col.row(align=True)
                row.prop(ob, "hide_viewport", text="", emboss=False)
                row.prop(ob, "hide_select", text="", emboss=False)
                row.prop(ob, "hide_render", text="", emboss=False)

####################################
# Panel List Light Eevee
####################################       
def UIEeveeListLight(self, context):
    layout = self.layout  
    objects = bpy.data.objects
    ob_act = context.active_object
    lamps = bpy.data.lights
    maincol = layout.column(align=True)
    box = layout.box()

    if objects:
        rowmain = box.row()
        split = rowmain.split()
        col = split.column()
        row = box.row(align=True)
        
        split = row.split(factor=1.0)
        col = split.column()
        col.label(text="Type")
        
        split = row.split(factor=0.21)
        col = split.column()
        col.label(text="Name")
        
        split = split.split(factor=0.24)
        col = split.column()
        col.label(text="Color")
        
        split = split.split(factor=0.48)
        col = split.column()
        col.label(text="Strength")
        
        split = split.split(factor=0.54)
        col = split.column()
        col.label(text="Specular")

        split = split.split(factor=1.0)
        col = split.column()
        col.label(text="Visibility")
        
#        for a in objects:
#            meshlight = a.type == "MESH"
#            
#            if a and meshlight:
#                mesh = a.data
#                
#                row = box.row(align=True)
#                split = row.split(factor=1.0)
#                col = split.column()
#                row = col.row(align=True)
#                
#                for a in bpy.context.object.material_slots:
#                    if not a.material:
#                        continue
#                    if a.material.node_tree and a.material.node_tree.nodes:
#                        for node in a.material.node_tree.nodes:
#                            if node.type == "EMISSION":
#                                row.label(text="", icon='MESH_GRID')
#                                
#                                split = row.split(factor=0.3)
#                                col = split.column()
#                                row = col.row(align=True)
#                                row.active = True
#                                row.operator("scene.object_select", text=mesh.name, emboss=False).object = mesh.name
#                
#                                
#                                ### COLOR ###
#                                if not node.inputs[0].is_linked:
#                                    row.prop(node.inputs[0], 'default_value', text='')
#                                else:
#                                    row.label(text='Connected')
#                                
#                                ### STRENGHT ###
#                                split = split.split(factor=0.45)
#                                col = split.column()
#                                row = col.row(align=True)
#                                if not node.inputs[1].is_linked:
#                                    row.prop(node.inputs[1], 'default_value', text='')
#                                    
#                                split = split.split(factor=0.6)
#                                col = split.column()
#                                row = col.row(align=True)
#                                row.prop(context.object.cycles_visibility, "camera", text='Cam', toggle=True)
#                                row.prop(context.object.cycles_visibility, "diffuse", text='Diff', toggle=True)
#                                row.prop(context.object.cycles_visibility, "glossy", text='Gloss', toggle=True)
#                               
                               
#                                split = split.split(factor=1.0)
#                                col = split.column()
#                                row = col.row(align=True)
#                                row.prop(a, "hide_viewport", text="", emboss=False)
#                                row.prop(a, "hide_select", text="", emboss=False)
#                                row.prop(a, "hide_render", text="", emboss=False)
                                 
        for ob in objects:
#            is_lamp = ob.type in {"LIGHT", "MESH"}
            is_lamp = ob.type in {"LIGHT"}

            if ob and is_lamp:
                lamp = ob.data
        
                row = box.row(align=True)
                split = row.split(factor=1.0)
                col = split.column()
                row = col.row(align=True)
            
                row.prop(lamp, "type", text='', icon_only=True, emboss=False, icon="%s" %("LIGHT_%s" %ob.data.type))
                        
                split = row.split(factor=0.3)
                col = split.column()
                row = col.row(align=True)
                row.active = True
                row.operator("scene.object_select", text=ob.name, emboss=False).object = ob.name
                
                split = split.split(factor=0.1)
                col = split.column()
                row = col.row()
                col.prop(lamp, "color", text="")
                
                split = split.split(factor=0.3)
                col = split.column()
                row = col.row()
                col.prop(lamp, "energy")
                
                split = split.split(factor=0.3)
                col = split.column()
                row = col.row()
                col.prop(lamp, "specular_factor", text="Specular")
                             
                split = split.split(factor=1.0)
                col = split.column()
                row = col.row(align=True)
                row.prop(ob, "hide_viewport", text="", emboss=False)
                row.prop(ob, "hide_select", text="", emboss=False)
                row.prop(ob, "hide_render", text="", emboss=False)
            
####################################
# Panel VFX 
####################################     
def UIVFX(context, layout):
    layout.label(text= "Rain Creator", icon= 'TRIA_RIGHT')
    layout.operator('add.new_emit_operator', text= "New Add Emitter")         
    layout.operator('add.collision_operator', text= "Make Collide")
    layout.label(text= "Add Ground", icon= 'TRIA_RIGHT')
    layout.operator('add.groundwater_operator', text= "Water")
    layout.label(text= "Add Field", icon= 'TRIA_RIGHT')
    layout.operator('add.wind_operator', text= "Wind")
    layout.operator('add.turbulance_operator', text= "Turbulance")
    layout.label(text= "Add Rigid body", icon= 'TRIA_RIGHT')
    row = layout.row()
    row.operator("add.rigidbody_operator", text="Active").type_rigid='active'
    row.operator("add.rigidbody_operator", text="Passive").type_rigid='passive'
    layout.operator("apply.rigidbody_operator", text="Apply")

####################################
# Panel Jin Kepepet 
####################################     
def UIJinKepepetRender(context, layout):
    tomatoes = context.scene.tomatoes_props
    row = layout.row()
    col = row.column(align=True)
    col.label(text="Scenes:" , icon='SCENE_DATA')
    col.separator()
    col.operator("world.create_gradient_sky", text ="Pagi").world_type ='world_pagi'
    col.operator("world.create_gradient_sky", text ="Sore").world_type ='world_sore'
    col.operator("world.create_gradient_sky", text ="Malam").world_type ='world_malam'
    col.operator("world.create_gradient_sky", text ="Fajar").world_type ='world_fajar'
    col.operator("world.create_gradient_sky", text ="Terbenam").world_type ='world_terbenam'
    col.operator("world.create_gradient_sky", text ="Mendung").world_type ='world_mendung'

    col = row.column(align=True)
    col.label(text="Presets:" , icon='NODE_COMPOSITING')
    col.separator()
    col.operator("op.jkbasicbg")
    col.operator("op.jkbasicchar")
    col.operator("op.jktest")
    col.operator("node.compose_image")
    col.operator("op.shadowjinkepepet")

    col = row.column(align=True)
    col.label(text="Final:" , icon='NODE_COMPOSITING')
    col.separator()
    col.operator("op.nodebg")
    col.operator("op.nodechar")
    col.operator("op.nodeshdchar")
    
    box = layout.box()
    box.label(text="Auto Replace & Save File Name", icon="FILE_TICK")  
    box.prop(tomatoes, "apply_file_rev")
    box.label(text="Default String:")     
    row = box.row(align=True)          
    row.prop(tomatoes, "str_default", text="")
    if tomatoes.apply_file_rev == True:
        row.active = tomatoes.apply_file_rev
        row.prop(tomatoes, "file_rev", text="")     
    col = box.column()  
    col.label(text="Replace String:") 
    col.prop(tomatoes, "final_str", text ="")
    col.separator()
    col1 = box.column()   
    col1.scale_x = 1.5
    col1.scale_y = 1.5
    col1.operator("test.save_jinkepepet")
    col1.operator("file.open_save_directory")