# This file is part of Instant Clean
# Copyright (C) 2023  Ruben Messerschmidt

import bpy
from itertools import chain
from .repair_op import repair
from .limdiss_op import limdiss
from .topology_op import topology
from .normals_op import normals
from .objectdata_op import objectdata
from ..utils.common_funcs import (
    get_objects,
    get_bmeshs,
    update_bmeshs,
    visible_faces,
    visible_edges,
    visible_verts,
    get_triangle_count
)


class BC_OT_Clean(bpy.types.Operator):
    bl_idname='bc.clean'
    bl_label='Clean'
    bl_description='Clean the selected objects based on your settings'
    bl_options={'UNDO', 'REGISTER'}

    def execute(self, context):         
        if not bpy.context.selected_objects and not bpy.context.objects_in_mode:
            return {'CANCELLED'}

        if bpy.context.active_object not in bpy.context.selected_objects:
            if bpy.context.selected_objects:
                bpy.context.view_layer.objects.active = bpy.context.selected_objects[0]
            else:
                bpy.context.view_layer.objects.active = bpy.context.objects_in_mode[0]
            
        pg = context.scene.bc_states
        current_mode = bpy.context.mode
        current_active = bpy.context.active_object

        bpy.ops.object.mode_set(mode='EDIT')
        objects = get_objects()
        bmeshs = get_bmeshs(objects)

        bpy.context.scene['Stats'] = {
            'Triangles': 0,
            'Vertices': 0,
            'Edges': 0,
            'Faces': 0
        }

        bpy.context.scene['Repair'] = False
        bpy.context.scene['Normals'] = False
        bpy.context.scene['Dissolve'] = False
        bpy.context.scene['Topology'] = False
        bpy.context.scene['Objectdata'] = False

        for bm in bmeshs:
            bpy.context.scene['Stats']['Triangles'] += get_triangle_count(visible_faces(bm))
            bpy.context.scene['Stats']['Vertices'] += len(visible_verts(bm))
            bpy.context.scene['Stats']['Edges'] += len(visible_edges(bm))
            bpy.context.scene['Stats']['Faces'] += len(visible_faces(bm))

        current_faces = len([f for f in list(chain.from_iterable([bm.faces for bm in bmeshs]))])
        current_tris = len([f for f in list(chain.from_iterable([bm.faces for bm in bmeshs])) if len(f.verts) == 3])
        current_quads = len([f for f in list(chain.from_iterable([bm.faces for bm in bmeshs])) if len(f.verts) == 4])

        if pg.repair: 
            bpy.context.scene['Repair'] = repair(objects, bmeshs)
            bmeshs = get_bmeshs(objects)
        
        if pg.normals:
            bpy.context.scene['Normals'] = normals(bmeshs, objects)
        if pg.limdiss:
            bpy.context.scene['Dissolve'] = limdiss(bmeshs)
        if pg.topology:
            bpy.context.scene['Topology'] = topology(bmeshs, current_faces, current_tris, current_quads)
        if pg.objectdata:
            bpy.context.scene['Objectdata'] = objectdata(objects, bmeshs)
        
        update_bmeshs(objects)

        bmeshs = get_bmeshs(objects)
        for bm in bmeshs:
            bpy.context.scene['Stats']['Triangles'] -= get_triangle_count(visible_faces(bm))
            bpy.context.scene['Stats']['Vertices'] -= len(visible_verts(bm))
            bpy.context.scene['Stats']['Edges'] -= len(visible_edges(bm))
            bpy.context.scene['Stats']['Faces'] -= len(visible_faces(bm))


        for k in bpy.context.scene['Stats'].keys():
            if bpy.context.scene['Stats'][k] >= 0:
                bpy.context.scene['Stats'][k] = -bpy.context.scene['Stats'][k]
            else:
                bpy.context.scene['Stats'][k] = '+' + str(-bpy.context.scene['Stats'][k])

        if current_mode == 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
        
        bpy.context.view_layer.objects.active = current_active
        bpy.context.scene.bc_misc.results = True
        
        return {'FINISHED'}