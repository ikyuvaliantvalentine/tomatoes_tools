import bpy, math
from math import * 
from bpy.props import * 
import bgl
import blf
import gpu
from gpu_extras.batch import batch_for_shader

vertices = (
    (60, 150), (500, 150), # bawah
    (60, 560), (500, 560)) # atas

indices = (
    (0, 1, 2), (2, 1, 3))

shader = gpu.shader.from_builtin('2D_UNIFORM_COLOR')
batch = batch_for_shader(shader, 'TRIS', {"pos": vertices}, indices=indices)
    
def draw_bevel(self, context):

    #box
    shader.bind()
    shader.uniform_float("color", (0.3, 0.3, 0.3, 0.7))
    batch.draw(shader)

    #text
    font_id = 0  
    x_offset = 0
    y_offset = 0

    if context.active_object.type == 'LIGHT': 
        for obj in context.visible_objects:              
            if obj != context.selected_objects:  
                if obj == context.view_layer.objects.active: 
                    if obj:

                        blf.color(font_id, 1, 1, 1, 0.7)
                        blf.position(font_id, 83, 530, 0)
                        blf.size(font_id, 15, 100)
                        blf.draw(font_id, obj.name + " - " + str(bpy.context.object.data.type))
                        
                        blf.color(font_id, 1, 1, 1, 0.7)
                        blf.position(font_id, 83, 520, 0)
                        blf.size(font_id, 15, 81)
                        blf.draw(font_id, "________________________________________________" )
                        
                        blf.color(font_id, 1, 1, 1, 0.7)
                        blf.position(font_id, 83, 500, 0)
                        blf.size(font_id, 15, 81)
                        blf.draw(font_id, "Lighting Shadow Parameters..." )
                        
                        blf.color(font_id, 1, 1, 1, 0.7)
                        blf.position(font_id, 83, 480, 0)
                        blf.size(font_id, 15, 81)
                        blf.draw(font_id, "Light R" )
                        
                        blf.color(font_id, 1, 1, 1, 0.7)
                        blf.position(font_id, 83, 460, 0)
                        blf.size(font_id, 15, 81)
                        blf.draw(font_id, "Light G" )
                        
                        blf.color(font_id, 1, 1, 1, 0.7)
                        blf.position(font_id, 83, 440, 0)
                        blf.size(font_id, 15, 81)
                        blf.draw(font_id, "Light B" )
                        
                        blf.color(font_id, 1, 1, 1, 0.7)
                        blf.position(font_id, 83, 420, 0)
                        blf.size(font_id, 15, 81)
                        blf.draw(font_id, "Energy" )
                        
                        blf.color(font_id, 1, 1, 1, 0.7)
                        blf.position(font_id, 83, 400, 0)
                        blf.size(font_id, 15, 81)
                        blf.draw(font_id, "Specular" )
                        
                        if context.object.data.type in {'POINT', 'SPOT'}:
                            blf.color(font_id, 1, 1, 1, 0.7)
                            blf.position(font_id, 83, 380, 0)
                            blf.size(font_id, 15, 81)
                            blf.draw(font_id, "Radius" )
                            
                            blf.color(font_id, 0, 1, 0.232, 0.7)
                            blf.position(font_id, 400, 380, 0)
                            blf.size(font_id, 15, 81)
                            blf.draw(font_id, str(round(bpy.context.object.data.shadow_soft_size, 2)))  
                            
                            if context.object.data.type == 'SPOT':
                                
                                blf.color(font_id, 1, 1, 1, 0.7)
                                blf.position(font_id, 83, 360, 0)
                                blf.size(font_id, 15, 81)
                                blf.draw(font_id, "Spot Shape" )
                                
                                blf.color(font_id, 0, 1, 0.232, 0.7)
                                blf.position(font_id, 400, 360, 0)
                                blf.size(font_id, 15, 81)
                                blf.draw(font_id, str(round(math.degrees(bpy.context.object.data.spot_size), 1))+ "°")
                                
                                blf.color(font_id, 1, 1, 1, 0.7)
                                blf.position(font_id, 83, 340, 0)
                                blf.size(font_id, 15, 81)
                                blf.draw(font_id, "Spot Blend" )
                                
                                blf.color(font_id, 0, 1, 0.232, 0.7)
                                blf.position(font_id, 400, 340, 0)
                                blf.size(font_id, 15, 81)
                                blf.draw(font_id, str(round(bpy.context.object.data.spot_blend, 2)))  
                            
                        
                        elif context.object.data.type == 'SUN':
                            blf.color(font_id, 1, 1, 1, 0.7)
                            blf.position(font_id, 83, 380, 0)
                            blf.size(font_id, 15, 81)
                            blf.draw(font_id, "Angle" )
                            
                            blf.color(font_id, 0, 1, 0.232, 0.7)
                            blf.position(font_id, 400, 380, 0)
                            blf.size(font_id, 15, 81)
                            blf.draw(font_id, str(round(math.degrees(bpy.context.object.data.angle), 1))+ "°")
                            
                        elif context.object.data.type == 'AREA':
                            blf.color(font_id, 1, 1, 1, 0.7)
                            blf.position(font_id, 83, 380, 0)
                            blf.size(font_id, 15, 81)
                            blf.draw(font_id, "Shape" )
                            
                            blf.color(font_id, 0, 1, 0.232, 0.7)
                            blf.position(font_id, 400, 380, 0)
                            blf.size(font_id, 15, 81)
                            blf.draw(font_id, str(bpy.context.object.data.shape))
                            
                            if bpy.context.object.data.shape in {'SQUARE', 'DISK'}:
                                blf.color(font_id, 1, 1, 1, 0.7)
                                blf.position(font_id, 83, 360, 0)
                                blf.size(font_id, 15, 81)
                                blf.draw(font_id, "Size" )
                                
                                blf.color(font_id, 0, 1, 0.232, 0.7)
                                blf.position(font_id, 400, 360, 0)
                                blf.size(font_id, 15, 81)
                                blf.draw(font_id, str(round(bpy.context.object.data.size, 2)))  
                         
                            elif bpy.context.object.data.shape in {'RECTANGLE', 'ELLIPSE'}:
                                
                                blf.color(font_id, 1, 1, 1, 0.7)
                                blf.position(font_id, 83, 360, 0)
                                blf.size(font_id, 15, 81)
                                blf.draw(font_id, "Size X" )
                                
                                blf.color(font_id, 0, 1, 0.232, 0.7)
                                blf.position(font_id, 400, 360, 0)
                                blf.size(font_id, 15, 81)
                                blf.draw(font_id, str(round(bpy.context.object.data.size, 2)))  
                                
                                blf.color(font_id, 1, 1, 1, 0.7)
                                blf.position(font_id, 83, 340, 0)
                                blf.size(font_id, 15, 81)
                                blf.draw(font_id, "Size Y" )
                                
                                blf.color(font_id, 0, 1, 0.232, 0.7)
                                blf.position(font_id, 400, 340, 0)
                                blf.size(font_id, 15, 81)
                                blf.draw(font_id, str(round(bpy.context.object.data.size_y, 2)))  
                        
                        blf.color(font_id, 1, 1, 1, 0.7)
                        blf.position(font_id, 83, 330, 0)
                        blf.size(font_id, 15, 81)
                        blf.draw(font_id, "________________________________________________" )
                
                        blf.color(font_id, 1, 1, 1, 0.7)
                        blf.position(font_id, 83, 300, 0)
                        blf.size(font_id, 15, 81)
                        blf.draw(font_id, "Shadow" )  
                            
                        blf.color(font_id, 1, 1, 1, 0.7)
                        blf.position(font_id, 83, 280, 0)
                        blf.size(font_id, 15, 81)
                        blf.draw(font_id, "Clip Start" )
                        
                        blf.color(font_id, 1, 1, 1, 0.7)
                        blf.position(font_id, 83, 260, 0)
                        blf.size(font_id, 15, 81)
                        blf.draw(font_id, "Bias" )
                        
                        blf.color(font_id, 1, 1, 1, 0.7)
                        blf.position(font_id, 83, 250, 0)
                        blf.size(font_id, 15, 81)
                        blf.draw(font_id, "________________________________________________" )
                        
                        blf.color(font_id, 1, 1, 1, 0.7)
                        blf.position(font_id, 83, 220, 0)
                        blf.size(font_id, 15, 81)
                        blf.draw(font_id, "Rotation X" )
                        
                        blf.color(font_id, 1, 1, 1, 0.7)
                        blf.position(font_id, 83, 200, 0)
                        blf.size(font_id, 15, 81)
                        blf.draw(font_id, "Rotation Y" )
                        
                        blf.color(font_id, 1, 1, 1, 0.7)
                        blf.position(font_id, 83, 180, 0)
                        blf.size(font_id, 15, 81)
                        blf.draw(font_id, "Rotation Z" )
                        
                        ################################### LIGHTING VALUE #############################################

                        blf.color(font_id, 0, 1, 0.232, 0.7)
                        blf.position(font_id, 400, 480, 0)
                        blf.size(font_id, 15, 81)
                        blf.draw(font_id, str(round(bpy.context.object.data.color[0], 3)))
                        
                        blf.color(font_id, 0, 1, 0.232, 0.7)
                        blf.position(font_id, 400, 460, 0)
                        blf.size(font_id, 15, 81)
                        blf.draw(font_id, str(round(bpy.context.object.data.color[1], 3)))
                        
                        blf.color(font_id, 0, 1, 0.232, 0.7)
                        blf.position(font_id, 400, 440, 0)
                        blf.size(font_id, 15, 81)
                        blf.draw(font_id, str(round(bpy.context.object.data.color[2], 3)))
                        
                        blf.color(font_id, 0, 1, 0.232, 0.7)
                        blf.position(font_id, 400, 420, 0)
                        blf.size(font_id, 15, 81)
                        blf.draw(font_id, str(round(bpy.context.object.data.energy, 2)))   
                        
                        blf.color(font_id, 0, 1, 0.232, 0.7)
                        blf.position(font_id, 400, 400, 0)
                        blf.size(font_id, 15, 81)
                        blf.draw(font_id, str(round(bpy.context.object.data.specular_factor, 2)))  
                        
                        if bpy.context.object.data.use_shadow == True: 
                            blf.color(font_id, 0, 1, 0.232, 0.7)
                            blf.position(font_id, 400, 300, 0)
                            blf.size(font_id, 15, 81)
                            blf.draw(font_id, str(bpy.context.object.data.use_shadow))   
                        else:
                            blf.color(font_id, 1, 0.053, 0.074, 1)
                            blf.position(font_id, 400, 300, 0)
                            blf.size(font_id, 15, 81)
                            blf.draw(font_id, str(bpy.context.object.data.use_shadow)) 
                            
                        blf.color(font_id, 0, 1, 0.232, 0.7)
                        blf.position(font_id, 400, 280, 0)
                        blf.size(font_id, 15, 81)
                        blf.draw(font_id, str(round(bpy.context.object.data.shadow_buffer_clip_start, 2)))  
                        
                        blf.color(font_id, 0, 1, 0.232, 0.7)
                        blf.position(font_id, 400, 260, 0)
                        blf.size(font_id, 15, 81)
                        blf.draw(font_id, str(round(bpy.context.object.data.shadow_buffer_bias, 2)))         
                        
                        ################################### ROTATION VALUE #############################################
                        blf.color(font_id, 0, 1, 0.232, 0.7)
                        blf.position(font_id, 400, 220, 0)
                        blf.size(font_id, 15, 81)
                        rotationX = obj.rotation_euler[0]
                        blf.draw(font_id, str(round(math.degrees(rotationX) ,2)))
                        
                        blf.color(font_id, 0, 1, 0.232, 0.7)
                        blf.position(font_id, 400, 200, 0)
                        blf.size(font_id, 15, 81)
                        rotationY = obj.rotation_euler[1]
                        blf.draw(font_id, str(round(math.degrees(rotationY) ,2)))
                        
                        blf.color(font_id, 0, 1, 0.232, 0.7)
                        blf.position(font_id, 400, 180, 0)
                        blf.size(font_id, 15, 81)
                        rotationZ = obj.rotation_euler[2]
                        blf.draw(font_id, str(round(math.degrees(rotationZ) ,2)))     
                                  

class BevelSetModal(bpy.types.Operator):
    """Move an object with the mouse, example"""
    bl_idname = "bevel.set_operator"
    bl_label = "Bevel Set modal"

    first_mouse_x : IntProperty()
    first_value : FloatProperty()

    def modal(self, context, event):
        ob = context.object 
        lamp = ob.data
        if context.area and context.area.type == 'VIEW_3D':
            context.area.tag_redraw()  
            
            # if event.type == 'E':
            #     delta = event.mouse_x - self.first_mouse_x
            #     lamp.energy  = self.first_value + delta * 0.02

            if event.type in {'MOUSEMOVE', 'WHEELUPMOUSE', 'WHEELDOWNMOUSE'}:
                return {'PASS_THROUGH'}

            if event.type == "ESC":
                bpy.types.SpaceView3D.draw_handler_remove(self._handle, 'WINDOW')
                return {'CANCELLED'}            
        return {'PASS_THROUGH'} 
        
    def invoke(self, context, event):
        
        if context.area.type == 'VIEW_3D':         
            args = (self, context)            
            self._handle = bpy.types.SpaceView3D.draw_handler_add(draw_bevel, args, 'WINDOW', 'POST_PIXEL')
            self.mouse_path = []
            
        if context.object:
            self.first_mouse_x = event.mouse_x
#            ob = context.object 
#            lamp = ob.data
#            self.first_value = lamp.energy
            context.window_manager.modal_handler_add(self) 

            return {'RUNNING_MODAL'}
        else:
            self.report({'WARNING'}, "No active object, could not finish")
            return {'CANCELLED'}
        