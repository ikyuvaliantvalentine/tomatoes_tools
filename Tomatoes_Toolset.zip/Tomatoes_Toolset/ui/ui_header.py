import bpy
from bpy.types import Menu
from .. properties import *

def topbar_shortcut_info(self, context):    
    layout = self.layout
    layout.scale_x = 1.2
    layout.scale_y = 1.2
    layout.separator()
    layout.prop(context.space_data.overlay, "show_face_orientation", toggle=True)

    addon_preferences = get_addon_preferences()
    row = layout.row()
    row.prop(addon_preferences, "SetSoftwareWorkflowOptions", expand = True)

def menu_final_res(self, context):
    layout = self.layout
    rend = context.scene.render
    rend_percent = rend.resolution_percentage * 0.01
    x = (str(rend.resolution_x * rend_percent).split("."))[0]
    y = (str(rend.resolution_y * rend_percent).split("."))[0]
    layout.label(text="Resolution: " + x + " x " + y)
    layout.operator("swithres.toggle", icon="FILE_REFRESH")


########################################################
#   Outliner Menu Header
########################################################
class VIEW3D_MT_menu_add_collection(Menu):
    bl_label = "Extra Collection Menu"
    bl_description = "Extra Collection Menu"

    def draw(self, context):
        layout = self.layout
        layout.operator("op.sort_collections_alphabetically")
        layout.operator("op.hierarcy_to_collection")

def topbar_outliner_menu(self, context):    
    layout = self.layout
    layout.menu("VIEW3D_MT_menu_add_collection", text="", icon="SOLO_ON")

def topbar_outliner_context_menu(self, context):    
    layout = self.layout
    layout.menu("VIEW3D_MT_menu_add_collection")

class VIEW3D_MT_custom_extra(Menu):
    bl_label = "Custom Extra"
    bl_description = "Custom Extra Menu"

    def draw(self, context):
        layout = self.layout
        layout.operator("export_scene.batch_obj") 
        layout.operator("export.batch_obj") 

def topbar_extra_context_menu(self, context):    
    layout = self.layout
    layout.menu("VIEW3D_MT_custom_extra")