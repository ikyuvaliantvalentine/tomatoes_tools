# This file is part of Instant Clean
# Copyright (C) 2023  Ruben Messerschmidt

import bpy
from ..utils.common_funcs import (
    visible_verts,
    visible_edges,
    visible_faces,
    update_bmeshs,
    get_objects,
    get_bmeshs
)

from ..utils.repair_funcs import *
from ..ui.layout_temps import popup_results


class BC_OT_Repair(bpy.types.Operator):
    bl_idname='bc.repair'
    bl_label='Repair'
    bl_description='Execute Repair operations only'
    bl_options={'UNDO', 'REGISTER'}

    stats = {}

    def execute(self, context):
        if not bpy.context.selected_objects and not bpy.context.objects_in_mode:
            return {'CANCELLED'}

        current_mode = bpy.context.mode
        bpy.ops.object.mode_set(mode='EDIT')
        objects = get_objects()
        bmeshs = get_bmeshs(objects)
        self.stats = repair(objects, bmeshs)
        update_bmeshs(objects)

        if current_mode == 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')

        return {'FINISHED'}

    def draw(self, context):
        popup_results(self.layout, self.stats)

def repair(objs, bms):
    stats = {
        'Loose Verts': False,
        'Loose Edges': False,
        'Loose Faces': False,
        'Doubles': False,
        'Zero Faces': False,
        'Dispensables': False,
        'Interiors': False
    }

    pg = bpy.context.scene.bc_repair
    for obj, bm in zip(objs, bms):
        # doubles
        if pg.doubles:
            stats['Doubles'] += dissolve_doubles(bm, visible_verts(bm), pg.doubles_dst)

        # loose
        if pg.loose:
            if pg.loose_verts:
                stats['Loose Verts'] += dissolve_loose_verts(bm, visible_verts(bm))
            if pg.loose_edges:
                stats['Loose Edges'] += dissolve_loose_edges(bm, visible_edges(bm))
            if pg.loose_faces:
                stats['Loose Faces'] += dissolve_loose_faces(bm, visible_faces(bm))
    
        # zeros
        if pg.zero_faces:
            stats['Zero Faces'] += dissolve_zero_faces(bm, visible_edges(bm), pg.zero_faces_area)

        # dispensables
        if pg.dispensables:
            stats['Dispensables'] += dissolve_dispensables(bm, visible_verts(bm), pg.dispensables_ang)

        # interiors
        if pg.interiors:
            stats['Interiors'] += dissolve_interior_faces(bm, visible_faces(bm))
            dissolve_loose_edges(bm, visible_edges(bm))

    return stats