import bpy
from bpy.types import Operator

class Test_Redshift_Settings(Operator):
    "Speed Up Redshift Settings"
    bl_idname = "op.test_redshift"
    bl_label = "Test Redshift"

    def execute(self, context):

        bpy.context.scene.render.resolution_x = 1920
        bpy.context.scene.render.resolution_y = 1080
        bpy.context.scene.render.resolution_percentage = 50
        bpy.context.scene.render.use_border = True

        bpy.context.scene.redshift.UnifiedMinSamples = 16
        bpy.context.scene.redshift.UnifiedMaxSamples = 64
        bpy.context.scene.redshift.UnifiedAdaptiveErrorThreshold = 0.05


        bpy.context.scene.redshift.MaxTraceDepthReflection = 3
        bpy.context.scene.redshift.MaxTraceDepthRefraction = 3
        bpy.context.scene.redshift.MaxTraceDepthCombined = 3
        bpy.context.scene.redshift.MaxTraceDepthTransparency = 3

        bpy.context.scene.redshift.PrimaryGIEngine = 'RS_GIENGINE_BRUTE_FORCE'
        bpy.context.scene.redshift.SecondaryGIEngine = 'RS_GIENGINE_BRUTE_FORCE'
        bpy.context.scene.redshift.BruteForceGINumRays = 32
      
        return {'FINISHED'}

class Test_Max_Redshift_Settings(Operator):
    "Testing Maxiumum Redshift Settings Half Resolution"
    bl_idname = "op.test_max_redshift"
    bl_label = "Test Max Redshift"

    def execute(self, context):

        bpy.context.scene.render.resolution_x = 1920
        bpy.context.scene.render.resolution_y = 1080
        bpy.context.scene.render.resolution_percentage = 50
        bpy.context.scene.render.use_border = True

        bpy.context.scene.redshift.UnifiedMinSamples = 128
        bpy.context.scene.redshift.UnifiedMaxSamples = 256
        bpy.context.scene.redshift.UnifiedAdaptiveErrorThreshold = 0.05

        bpy.context.scene.redshift.MaxTraceDepthReflection = 4
        bpy.context.scene.redshift.MaxTraceDepthRefraction = 6
        bpy.context.scene.redshift.MaxTraceDepthCombined = 6
        bpy.context.scene.redshift.MaxTraceDepthTransparency = 12

        bpy.context.scene.redshift.PrimaryGIEngine = 'RS_GIENGINE_BRUTE_FORCE'
        bpy.context.scene.redshift.SecondaryGIEngine = 'RS_GIENGINE_BRUTE_FORCE'
        bpy.context.scene.redshift.BruteForceGINumRays = 512
      
        return {'FINISHED'}    

class Max_Redshift_Settings(Operator):
    "Maxiumum Redshift Settings"
    bl_idname = "op.max_redshift"
    bl_label = "Max Redshift"

    def execute(self, context):

        bpy.context.scene.render.resolution_x = 1920
        bpy.context.scene.render.resolution_y = 1080
        bpy.context.scene.render.resolution_percentage = 100
        bpy.context.scene.render.use_border = True

        bpy.context.scene.redshift.UnifiedMinSamples = 128
        bpy.context.scene.redshift.UnifiedMaxSamples = 256
        bpy.context.scene.redshift.UnifiedAdaptiveErrorThreshold = 0.05

        bpy.context.scene.redshift.MaxTraceDepthReflection = 4
        bpy.context.scene.redshift.MaxTraceDepthRefraction = 6
        bpy.context.scene.redshift.MaxTraceDepthCombined = 6
        bpy.context.scene.redshift.MaxTraceDepthTransparency = 12

        bpy.context.scene.redshift.PrimaryGIEngine = 'RS_GIENGINE_BRUTE_FORCE'
        bpy.context.scene.redshift.SecondaryGIEngine = 'RS_GIENGINE_BRUTE_FORCE'
        bpy.context.scene.redshift.BruteForceGINumRays = 512
      
        return {'FINISHED'}
