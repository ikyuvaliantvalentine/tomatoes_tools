# This file is part of Instant Clean
# Copyright (C) 2023  Ruben Messerschmidt

import bpy
from itertools import chain
from ..utils.common_funcs import (
    visible_verts,
    visible_edges,
    update_bmeshs,
    get_bmeshs,
    get_objects,
    get_triangle_count
)

from ..utils.limdiss_funcs import *
from ..utils.repair_funcs import dissolve_dispensables
from ..ui.layout_temps import popup_results


current_tris = 0
current_quads = 0

class BC_OT_Limdiss(bpy.types.Operator):
    bl_idname='bc.limdiss'
    bl_label='Dissolve'
    bl_description='Execute Dissolve operations only'
    bl_options={'UNDO', 'REGISTER'}

    stats = {}

    def execute(self, context):
        if not bpy.context.selected_objects and not bpy.context.objects_in_mode:
            return {'CANCELLED'}

        current_mode = bpy.context.mode
        bpy.ops.object.mode_set(mode='EDIT')
        objects = get_objects()
        bmeshs = get_bmeshs(objects)
        self.stats = limdiss(bmeshs)
        update_bmeshs(objects)

        if current_mode == 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')

        return {'FINISHED'}

    def draw(self, context):
        popup_results(self.layout, self.stats)


def limdiss(bms):
    stats = {
        'Triangles': get_triangle_count([f for f in list(chain.from_iterable([bm.faces for bm in bms])) if f.is_valid]),
        'Vertices': len([v for v in list(chain.from_iterable([bm.verts for bm in bms])) if v.is_valid]),
        'Edges': len([e for e in list(chain.from_iterable([bm.edges for bm in bms])) if e.is_valid]),
        'Faces': len([f for f in list(chain.from_iterable([bm.faces for bm in bms])) if f.is_valid])
    }

    pg = bpy.context.scene.bc_limdiss
    protect_mask = [True, pg.protect_materials, pg.protect_seam, pg.protect_sharp, pg.protect_uv]
    protect = ['NORMAL', 'MATERIAL', 'SEAM', 'SHARP', 'UV']
    delimiter = [d for i, d in enumerate(protect) if protect_mask[i]]
    for bm in bms:
        limited_dissolve(bm, visible_verts(bm), visible_edges(bm), pg.max_angle, pg.boundaries, set(delimiter))
        dissolve_dispensables(bm, visible_verts(bm), pg.max_angle)

    stats['Triangles'] -= get_triangle_count([f for f in list(chain.from_iterable([bm.faces for bm in bms])) if f.is_valid])
    stats['Vertices'] -= len([v for v in list(chain.from_iterable([bm.verts for bm in bms])) if v.is_valid])
    stats['Edges'] -= len([e for e in list(chain.from_iterable([bm.edges for bm in bms])) if e.is_valid])
    stats['Faces'] -= len([f for f in list(chain.from_iterable([bm.faces for bm in bms])) if f.is_valid])

    return stats
