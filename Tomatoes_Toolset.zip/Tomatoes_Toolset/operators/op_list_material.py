import bpy, bmesh
from bpy.types import Operator
from bpy.props import *

#################################
#   Create New  Material
#################################  
class MATERIAL_OT_create_new(Operator):
    bl_idname = "material.create_new_material"
    bl_label = "Create New Material"
    bl_description = "This will create new material"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod                                     
    def poll(cls, context):  
        return context.object is not None

    def execute(self, context):
        create_new = bpy.data.materials.new(name='Material')
        bpy.context.view_layer.objects.active.data.materials.append(create_new)
        return {'FINISHED'}

#################################
#   Apply Material
#################################  
class ApplyMaterial(bpy.types.Operator):
    bl_idname = "tomatoes.apply_material"
    bl_label = "Apply material"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if len(bpy.context.selected_objects) > 0:
            for obj in bpy.context.selected_objects:
                if obj.type in ['MESH', 'CURVE', 'TEXT']:
                    return True
        return False

    def execute(self, context):
        tomatoes = context.scene.tomatoes_props
        material_list = tomatoes.selected_material_index
        mat = bpy.data.materials[tomatoes.selected_material_index]

        ob = bpy.context.active_object
        
        if context.object.mode == 'EDIT':
            obj = context.object
            bm = bmesh.from_edit_mesh(obj.data)
 
            selected_face = [f for f in bm.faces if f.select]  
 
            mat_name = [mat.name for mat in bpy.context.object.material_slots if len(bpy.context.object.material_slots)] 
 
            if material_list in mat_name: 
                context.object.active_material_index = material_list 
                bpy.ops.object.material_slot_assign() 
            else:
                bpy.ops.object.material_slot_add() 
                bpy.context.object.active_material = mat 
                bpy.ops.object.material_slot_assign()
                

        if context.object.mode == 'OBJECT':
            for ob in bpy.context.selected_objects:
                # Activate current object to assign material
                bpy.context.view_layer.objects.active = ob

                #Set only one material
                for s in ob.material_slots:
                    bpy.ops.object.material_slot_remove()

                # re-add them and asmatsign material
                ob.data.materials.append(mat)
        return {'FINISHED'}
            
#################################
#   Delete Material
#################################  
class MATERIAL_OT_delete_material(Operator):
    bl_idname = "material.delete_material"
    bl_label = "Delete Material"
    bl_description = "This will delete the material"
    bl_options = {"REGISTER", "UNDO"}

    material_name : StringProperty(name="Material Name")

    def execute(self, context):
        if self.material_name in bpy.data.materials:
            mat = bpy.data.materials[self.material_name]
            bpy.data.materials.remove(mat,do_unlink=True)
        return {'FINISHED'}

    # def invoke(self,context,event):
    #     wm = context.window_manager
    #     return wm.invoke_props_dialog(self, width=400)

    # def draw(self, context):
    #     layout = self.layout
    #     layout.label(text="Are you sure you want to delete the material?")  
    #     layout.label(text="Material Name: " + self.material_name)    

#################################
#   Delete All Material
#################################  
class MATERIAL_OT_delete_all_material(Operator):
    bl_idname = "material.delete_all_material"
    bl_label = "Delete All Material On Selected Objects"
    bl_description = "This will delete all the material on selected objects"
    bl_options = {"REGISTER", "UNDO"}

    material_name : StringProperty(name="Material Name")
    
    def execute(self, context):
        if bpy.context.object.mode == 'EDIT':
            bpy.ops.object.editmode_toggle()
        #CLEAN UP SLOT MATERIAL FOR SELECTED OBJECT --------
        selection_names = bpy.context.selected_objects
        listOfObj=[]
        for obj in selection_names:
            listOfObj.append(obj)
            bpy.context.view_layer.objects.active = obj
            for x in obj.material_slots: #For all of the materials in the selected object:
                obj.active_material_index = 0 #select the top material
                bpy.ops.object.material_slot_remove() #delete it
        bpy.ops.object.editmode_toggle()
        bpy.ops.object.editmode_toggle()
        return {'FINISHED'}

#################################
#   Rename Material
#################################  
class MATERIAL_OT_rename_material(Operator):
    bl_idname = "material.rename_material"
    bl_label = "Rename Material"
    bl_description = "Rename Material by Object Name"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        obs = bpy.context.selected_objects
        for ob in obs:
            if ob.material_slots:
                for m_slot in ob.material_slots:
                    if m_slot.material:
                        if m_slot.material.users == 1:
                            m_slot.material.name = ob.name + "_MAT"
        return {'FINISHED'}