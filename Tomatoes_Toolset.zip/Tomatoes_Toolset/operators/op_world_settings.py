import bpy, os
from bpy.types import Operator, Panel
from bpy.props import *

#####################################
# All is Broken Script Need To FIX
#####################################
class SetHdri(Operator):
    "Set Cycles HDRI Node"
    bl_label="Set HDRI Cycles"
    bl_idname="cycles.hdri_world"

    filename_ext = "*.png;*.jpg;*.hdr;*.jpeg"

    filter_glob: StringProperty(
        default="*.png;*.jpg;*.hdr;*.jpeg",
        options={'HIDDEN'},
        maxlen=255,  # Max internal buffer length, longer would be clamped.
    )

    filepath : bpy.props.StringProperty(subtype="FILE_PATH")

    def draw(self, context):
        self.layout.operator('file.select_all_toggle')  

    def invoke(self, context, event):
        wm = context.window_manager
        wm.fileselect_add(self)
        return {'RUNNING_MODAL'}
    
    def execute(self,context):        
        scn = bpy.context.scene
        file_path, file_name = os.path.split(self.filepath)
        filename , ext = os.path.splitext(file_name)
        new_image = bpy.data.images.load(self.filepath)
        
        scn.world.use_nodes = True

        #Select World Node Tree
        wd = scn.world
        nt = bpy.data.worlds[wd.name].node_tree
        
        #clear default nodes            
        for n in nt.nodes:
            nt.nodes.remove(n)
            
        #Create New Node
        backNode = nt.nodes.new(type="ShaderNodeBackground")
        enviNode = nt.nodes.new(type="ShaderNodeTexEnvironment")
        mapNode = nt.nodes.new(type="ShaderNodeMapping")
        coordNode = nt.nodes.new(type="ShaderNodeTexCoord")
        outNode = nt.nodes.new('ShaderNodeOutputWorld')

        #Location Node    
        backNode = nt.nodes['Background']
        backNode.location = 0, 300
        enviNode.location.x = backNode.location.x-200
        enviNode.location.y = backNode.location.y
        
        outNode = nt.nodes['World Output']
        outNode.location.x = backNode.location.x+200
        outNode.location.y = backNode.location.y

        enviNode = nt.nodes['Environment Texture']
        enviNode.image = new_image
        mapNode.location.x = enviNode.location.x-350
        mapNode.location.y = enviNode.location.y

        mapNode = nt.nodes['Mapping']
        coordNode.location.x = mapNode.location.x-200
        coordNode.location.y = mapNode.location.y
        
        #Connect Background To Output
        backOut = backNode.outputs[0]
        outIn = outNode.inputs[0]
        nt.links.new(backOut, outIn)

        #Connect Environment To Background
        enviOut = enviNode.outputs[0]
        backIn = backNode.inputs[0]
        nt.links.new(enviOut, backIn)

        #Connect Mapping To Environment
        mapOut = mapNode.outputs[0]
        enviIn = enviNode.inputs[0]
        nt.links.new(mapOut, enviIn)

        #Connect Texture Coord To Mapping
        coordOut = coordNode.outputs[0]
        mapIn = mapNode.inputs[0]
        nt.links.new(coordOut, mapIn)
        return {'FINISHED'}

class SetHdri_Two(Operator):
    "Set Cycles HDRI Node type 2"
    bl_label="Set HDRI Cycles 02"
    bl_idname="cycles.hdri_world_two"

    filename_ext = "*.png;*.jpg;*.hdr;*.jpeg"

    filter_glob: StringProperty(
        default="*.png;*.jpg;*.hdr;*.jpeg",
        options={'HIDDEN'},
        maxlen=255,  # Max internal buffer length, longer would be clamped.
    )

    filepath : bpy.props.StringProperty(subtype="FILE_PATH")

    def draw(self, context):
        self.layout.operator('file.select_all_toggle')  

    def invoke(self, context, event):
        wm = context.window_manager
        wm.fileselect_add(self)
        return {'RUNNING_MODAL'}
    
    def execute(self,context):        
        scn = bpy.context.scene
        file_path, file_name = os.path.split(self.filepath)
        filename , ext = os.path.splitext(file_name)
        new_image = bpy.data.images.load(self.filepath)
                
        scn.world.use_nodes = True

        #Select World Node Tree
        wd = scn.world
        nt = bpy.data.worlds[wd.name].node_tree
        
        #clear default nodes            
        for n in nt.nodes:
            nt.nodes.remove(n)

        #Create New Node
        back2Node = nt.nodes.new(type="ShaderNodeBackground")
        backNode = nt.nodes.new(type="ShaderNodeBackground")
        outNode = nt.nodes.new('ShaderNodeOutputWorld')
        lightpathNode = nt.nodes.new(type="ShaderNodeLightPath")
        enviNode = nt.nodes.new(type="ShaderNodeTexEnvironment")
        mixshdNode = nt.nodes.new(type="ShaderNodeMixShader")
        mapNode = nt.nodes.new(type="ShaderNodeMapping")
        coordNode = nt.nodes.new(type="ShaderNodeTexCoord")
        gamNode = nt.nodes.new(type="ShaderNodeGamma")
        gam2Node = nt.nodes.new(type="ShaderNodeGamma")

        #Location Node
        backNode = nt.nodes['Background']
        backNode.location = 0, 300
        enviNode.location.x = backNode.location.x-200
        enviNode.location.y = backNode.location.y
        
        outNode = nt.nodes['World Output']
        outNode.location.x = backNode.location.x+400
        outNode.location.y = backNode.location.y
        
        enviNode.location.x = backNode.location.x-500
        enviNode.location.y = backNode.location.y

        back2Node = nt.nodes['Background.001']
        back2Node.location.x = backNode.location.x
        back2Node.location.y = backNode.location.y -150

        lightpathNode = nt.nodes['Light Path']
        lightpathNode.location.x = backNode.location.x
        lightpathNode.location.y = backNode.location.y+400

        mixshdNode = nt.nodes['Mix Shader']
        mixshdNode.location.x = backNode.location.x+180
        mixshdNode.location.y = backNode.location.y

        gamNode = nt.nodes['Gamma']
        gamNode.location.x = backNode.location.x-250
        gamNode.location.y = backNode.location.y
        
        gam2Node = nt.nodes['Gamma.001']
        gam2Node.location.x = back2Node.location.x-250
        gam2Node.location.y = back2Node.location.y

        enviNode = nt.nodes['Environment Texture']
        enviNode.image = new_image
        mapNode.location.x = enviNode.location.x-400
        mapNode.location.y = enviNode.location.y

        mapNode = nt.nodes['Mapping']
        coordNode.location.x = mapNode.location.x-200
        coordNode.location.y = mapNode.location.y
        
        outputNode = nt.nodes['World Output']

        ##############################################       
        #Connect LightPath To Mix
        LightPathOut = lightpathNode.outputs[0]
        mixIn = mixshdNode.inputs[0]
        nt.links.new(LightPathOut, mixIn)

        #Connect Background To Mix
        backOut = backNode.outputs[0]
        mixIn = mixshdNode.inputs[1]
        nt.links.new(backOut, mixIn)

        #Connect Background 2 To Mix
        back2Out = back2Node.outputs[0]
        mixIn2 = mixshdNode.inputs[2]
        nt.links.new(back2Out, mixIn2)

        #Connect MixShader To Output
        mixOut = mixshdNode.outputs[0]
        outIn = outputNode.inputs[0]
        nt.links.new(mixOut, outIn)

        #Connect Environment To Gamma
        enviOut = enviNode.outputs[0]
        gamIn = gamNode.inputs[0]
        nt.links.new(enviOut, gamIn)

        #Connect Environment To Gamma 02
        enviOut = enviNode.outputs[0]
        gam2In = gam2Node.inputs[0]
        nt.links.new(enviOut, gam2In)

        #Connect Gamma To Background
        gamOut = gamNode.outputs[0]
        backIn = backNode.inputs[0]
        nt.links.new(gamOut, backIn)

        #Connect Gamma 02 To Background 02
        gam2Out = gam2Node.outputs[0]
        back2In = back2Node.inputs[0]
        nt.links.new(gam2Out, back2In)

        #Connect Mapping To Environment
        mapOut = mapNode.outputs[0]
        enviIn = enviNode.inputs[0]
        nt.links.new(mapOut, enviIn)

        #Connect Texture Coord To Mapping
        coordOut = coordNode.outputs[0]
        mapIn = mapNode.inputs[0]
        nt.links.new(coordOut, mapIn)
        return {'FINISHED'}

class WORLD_OT_create_sky_world(Operator):
    """Creates a New Sky World"""
    bl_idname = "world.create_sky_world"
    bl_label = "Create Sky World"

    def execute(self, context):
        world = bpy.data.worlds.new("Sky")
        world.use_nodes = True
        world.node_tree.nodes.clear()
        
        context.scene.world = world

        output = world.node_tree.nodes.new("ShaderNodeOutputWorld")
        output.location = (0,0)
        
        background = world.node_tree.nodes.new("ShaderNodeBackground")
        background.location = (-200,0)        
        
        sky = world.node_tree.nodes.new("ShaderNodeTexSky")
        sky.location = (-400,0)

        new_links = world.node_tree.links.new
        new_links(output.inputs[0], background.outputs[0])
        new_links(background.inputs[0], sky.outputs[0]) 
        return {'FINISHED'}   
    
class WORLD_OT_create_world_from_hdr(Operator):
    """Creates a New World from a HDR"""
    bl_idname = "world.create_new_world_from_hdr"
    bl_label = "Create New World From HDR"

    filename_ext = "*.png;*.jpg;*.hdr;*.jpeg"

    filter_glob: StringProperty(
        default="*.png;*.jpg;*.hdr;*.jpeg",
        options={'HIDDEN'},
        maxlen=255,  # Max internal buffer length, longer would be clamped.
    )

    filepath : bpy.props.StringProperty(subtype="FILE_PATH")

    def draw(self, context):
        self.layout.operator('file.select_all_toggle')  

    def invoke(self, context, event):
        wm = context.window_manager
        wm.fileselect_add(self)
        return {'RUNNING_MODAL'}

    def execute(self, context):
        file_path, file_name = os.path.split(self.filepath)
        filename , ext = os.path.splitext(file_name)        
        
        world = bpy.data.worlds.new(filename)
        world.use_nodes = True
        world.node_tree.nodes.clear()
        
        context.scene.world = world
        new_image = bpy.data.images.load(self.filepath)

        output = world.node_tree.nodes.new("ShaderNodeOutputWorld")
        output.location = (0,0)
        
        mix_shader = world.node_tree.nodes.new("ShaderNodeMixShader")
        mix_shader.location = (-200,0)
        
        background = world.node_tree.nodes.new("ShaderNodeBackground")
        background.location = (-400,0)
        
        background_2 = world.node_tree.nodes.new("ShaderNodeBackground")
        background_2.location = (-400,-200)        
        
        light_path = world.node_tree.nodes.new("ShaderNodeLightPath")
        light_path.location = (-400,400)        
        
        #ENVIRONMENT LIGHTING
        math_add = world.node_tree.nodes.new("ShaderNodeMath")
        math_add.name = "ADD"
        math_add.operation = 'ADD'
        math_add.location = (-600,-300)
         
        #SHADOWS
        math_multiply = world.node_tree.nodes.new("ShaderNodeMath")
        math_multiply.name = "MULTIPLY"
        math_multiply.operation = 'MULTIPLY'
        math_multiply.inputs[1].default_value = 1     
        math_multiply.location = (-800,-300) 
        
        texture = world.node_tree.nodes.new("ShaderNodeTexEnvironment")
        texture.image = new_image
        texture.location = (-1000,0)

        mapping = world.node_tree.nodes.new("ShaderNodeMapping")
        mapping.location = (-1500,0)
 
        texcord = world.node_tree.nodes.new("ShaderNodeTexCoord")
        texcord.location = (-1700,0)
        
        new_links = world.node_tree.links.new
        new_links(output.inputs[0], mix_shader.outputs[0])
        new_links(mix_shader.inputs[0], light_path.outputs[0]) 
        new_links(mix_shader.inputs[2], background.outputs[0])
        new_links(mix_shader.inputs[1], background_2.outputs[0])  
        new_links(background_2.inputs[1], math_add.outputs[0])  
        new_links(math_add.inputs[0], math_multiply.outputs[0]) 
        new_links(math_multiply.inputs[0], texture.outputs[0]) 
        new_links(background_2.inputs[0], texture.outputs[0]) 
        new_links(background.inputs[0], texture.outputs[0])     
        new_links(texture.inputs[0], mapping.outputs[0])
        new_links(mapping.inputs[0], texcord.outputs[0])        
        return {'FINISHED'}

class WORLD_OT_create_world_sky_world(Operator):
    """Creates a New Sky World"""
    bl_idname = "world.create_gradient_sky"
    bl_label = "Create Sky World"

    world_type : EnumProperty(
        items=(('world_pagi', "Pagi", "Pagi"),
               ('world_sore', "Sore", "Sore"),
               ('world_malam', "Malam", "Malam"),
               ('world_fajar', "Fajar", "Fajar"),
               ('world_terbenam', "Terbenam", "Terbenam"),
               ('world_mendung', "Mendung", "Mendung"),
               ),
        default='world_pagi'
    )

    def execute(self, context):
        worlds = bpy.data.worlds
        if not 'Gradient_Sky' in worlds:
            world = bpy.data.worlds.new("Gradient_Sky")
        else:
            world = worlds['Gradient_Sky']
        context.scene.world = world       

        world.use_nodes = True
        world.node_tree.nodes.clear()

        #Select World Node Tree
        wd = context.scene.world
        nt = bpy.data.worlds[world.name].node_tree
        
        #clear default nodes            
        for n in nt.nodes:
            nt.nodes.remove(n)
        
        context.scene.world = world

        output = world.node_tree.nodes.new("ShaderNodeOutputWorld")
        output.location = (0,0)
        
        background = world.node_tree.nodes.new("ShaderNodeBackground")
        background.location = (-200,0)        
        background.inputs[1].default_value = 0.5
        
        sky_grad = world.node_tree.nodes.new("ShaderNodeValToRGB")
        sky_grad.location = (-500,0)

        if self.world_type == 'world_pagi':
            sky_grad.color_ramp.elements[0].color = (0.236652, 0.608759, 1, 1)
            sky_grad.color_ramp.elements[1].position = 0.395454
            sky_grad.color_ramp.elements[1].color = (0, 0.182776, 0.709736, 1)
        elif self.world_type == 'world_sore':
            sky_grad.color_ramp.elements[0].color = (1, 0.715694, 0.40724, 1)
            sky_grad.color_ramp.elements[1].position = 0.395454
            sky_grad.color_ramp.elements[1].color = (0.0843762, 0.304987, 1, 1)
        elif self.world_type == 'world_malam':
            sky_grad.color_ramp.elements[0].color = (0.00913406, 0.0152085, 0.0395462, 1)
            sky_grad.color_ramp.elements[1].position = 0.395454
            sky_grad.color_ramp.elements[1].color = (0.00242821, 0.0103298, 0.0528607, 1)
        elif self.world_type == 'world_fajar':
            sky_grad.color_ramp.elements[0].color = (1, 0.982251, 0.730461, 1)
            sky_grad.color_ramp.elements[1].position = 0.395454
            sky_grad.color_ramp.elements[1].color = (0.0241576, 0.0703601, 0.171441, 1)
        elif self.world_type == 'world_terbenam':
            sky_grad.color_ramp.elements[0].color = (0.921582, 0.3564, 0.107023, 1)
            sky_grad.color_ramp.elements[1].position = 0.395454
            sky_grad.color_ramp.elements[1].color = (0.165132, 0.266356, 0.520996, 1)
        elif self.world_type == 'world_mendung':
            sky_grad.color_ramp.elements[0].color = (0.181164, 0.318547, 0.341914, 1)
            sky_grad.color_ramp.elements[1].position = 0.395454
            sky_grad.color_ramp.elements[1].color = (0.552011, 0.745404, 0.752943, 1)
        
        gradient = world.node_tree.nodes.new("ShaderNodeTexGradient")
        gradient.location = (-700,0)
        gradient.gradient_type = 'LINEAR'

        mapping = world.node_tree.nodes.new("ShaderNodeMapping")
        mapping.location = (-900,0)
        mapping.vector_type = 'POINT'
        mapping.inputs[2].default_value[1] = 1.5708
        mapping.inputs[3].default_value[0] = 2
        mapping.inputs[3].default_value[1] = 2
        mapping.inputs[3].default_value[2] = 2

        coord = world.node_tree.nodes.new("ShaderNodeTexCoord")
        coord.location = (-1200,0)

        new_links = world.node_tree.links.new
        new_links(output.inputs[0], background.outputs[0])
        new_links(background.inputs[0], sky_grad.outputs[0]) 
        new_links(sky_grad.inputs[0], gradient.outputs[0]) 
        new_links(gradient.inputs[0], mapping.outputs[0]) 
        new_links(mapping.inputs[0], coord.outputs[0]) 
        
        return {'FINISHED'}   

######################################
#   World UI List
######################################
class WORLD_OT_delete_world(Operator):
    bl_idname = "world.delete_world"
    bl_label = "Delete World"
    bl_description = "This will delete the world"

    world_name : bpy.props.StringProperty(name="World Name")

    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        if self.world_name in bpy.data.worlds:
            wrl = bpy.data.worlds[self.world_name]
            bpy.data.worlds.remove(wrl,do_unlink=True)
        return {'FINISHED'}

    def invoke(self,context,event):
        wm = context.window_manager
        return wm.invoke_props_dialog(self, width=400)

    def draw(self, context):
        layout = self.layout
        layout.label(text="Are you sure you want to delete the world?")
        layout.label(text="World Name: " + self.world_name)

######################################
#   Quick Open World Node Editor
######################################
class WORLD_OT_open_world_node_editor(Operator):
    bl_idname = "word.open_world_editor"
    bl_label = "Open World Editor"
        
    def execute(self, context):
        bpy.ops.screen.userpref_show('INVOKE_DEFAULT')
        for window in context.window_manager.windows:
            if len(window.screen.areas) == 1 and window.screen.areas[0].type == 'PREFERENCES':
                window.screen.areas[0].ui_type = 'ShaderNodeTree'
                for space in window.screen.areas[0].spaces:
                    if space.type == 'NODE_EDITOR':
                        space.shader_type = 'WORLD'
                        
        return {'FINISHED'} 