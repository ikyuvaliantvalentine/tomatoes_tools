import bpy
from bpy import ops
from bpy.types import Operator

class SubsurfHideSel(Operator):
    'Sets the Subsurf modifier of all objects in selection to be invisible in the viewport'
    bl_idname = 'ob.subsurfhidesel'
    bl_label = 'Subsurf Hide'
    show : bpy.props.BoolProperty(default=False)

    def execute(self, context):
        for e in bpy.context.selected_objects:
            try:
                e.modifiers['Subsurf'].show_viewport = self.show
            except KeyError:
                print("No subsurf on " + e.name + " or it is not named Subsurf")
        return {'FINISHED'}
    
class SubsurfHideAll(Operator):
    'Sets the Subsurf modifier of all objects to be invisible in the viewport'
    bl_idname = 'subsurf.hideall'
    bl_label = 'Subsurf Hide (All)'
    show : bpy.props.BoolProperty(default=False)

    def execute(self, context):
        for e in bpy.data.objects:
            try:
                e.modifiers['Subsurf'].show_viewport = self.show
            except KeyError:
                print("No subsurf on " + e.name + " or it is not named Subsurf")
        return {'FINISHED'}

class KillSubsurfs(Operator):
    'Deletes all Subsurf modifiers in the scene'
    bl_idname = 'remove.all_subsurfs'
    bl_label = 'Kill All Subsurfs'

    def execute(self, context,):
        counter = 0
        for obj in bpy.data.objects:
            bpy.context.view_layer.objects.active = obj
            for mod in bpy.context.object.modifiers:
                if mod.type == 'SUBSURF':
                    if context.mode == "EDIT_MESH":
                        bpy.ops.object.editmode_toggle()
                        bpy.ops.object.modifier_remove(modifier=mod.name)
                        bpy.ops.object.editmode_toggle()
                    else:
                        bpy.ops.object.modifier_remove(modifier=mod.name)
                    counter = counter + 1
        self.report({'INFO'}, str(counter) + " subsurfs removed!")
        return {'FINISHED'}
        
class CopyModifier(Operator):
    bl_idname = 'copy.modifier'
    bl_label = "Copy Modifiers"
    bl_description = "Copy Modifier To selected Objects"
    
    def execute(self, context):
        active_object = bpy.context.object
        selected_objects = [o for o in bpy.context.selected_objects
                            if o != active_object and o.type == active_object.type]

        for obj in selected_objects:
            for mSrc in active_object.modifiers:
                mDst = obj.modifiers.get(mSrc.name, None)
                if not mDst:
                    mDst = obj.modifiers.new(mSrc.name, mSrc.type)

                # collect names of writable properties
                properties = [p.identifier for p in mSrc.bl_rna.properties
                              if not p.is_readonly]

                # copy those properties
                for prop in properties:
                    setattr(mDst, prop, getattr(mSrc, prop))            
        return {'FINISHED'}  


class ParticleHideAll(Operator):
    'Sets the Particle modifier of all objects to be invisible / visible in the viewport'
    bl_idname = 'op.particlehideall'
    bl_label = 'Particle Hide / Unhide (All)'

    def invoke(self, context, event):   
        show = 0
        for object in bpy.data.objects:
            if bpy.context.scene in object.users_scene:
                try:
                    for modifier in object.modifiers:
                        if modifier.type == 'PARTICLE_SYSTEM':
                            if (modifier.show_viewport):
                                show += 1
                            else:
                                show -= 1
                        is_hide = False
                        if (0 < show):
                            is_hide = True
                        for modifier in object.modifiers:
                            modifier.show_viewport = not is_hide
                except:
                    pass
        return {'FINISHED'}


class collapse_all_modifiers(Operator):
    bl_idname = "collapse.allmod"
    bl_label = "Collapse All Modifiers"

    def execute(self, context):
        obj = context.active_object
        if (len(obj.modifiers)):
            vs = 0
            for mod in obj.modifiers:
                if (mod.show_expanded):
                    vs += 1
                else:
                    vs -= 1
            is_close = False
            if (0 < vs):
                is_close = True
            for mod in obj.modifiers:
                mod.show_expanded = not is_close
        return {'FINISHED'} 
    
######################################################################################################    
applyModifier = ops.object.modifier_apply
removeModifier = ops.object.modifier_remove
################################################### 
# Apply only subsurf modifiers   
################################################### 
class applySubsurf(Operator):
    """
    CLICK - APPLY SUBSURF
    SHIFT - REMOVE SUBSURF
    """
    bl_label = "Apply Subsurf"
    bl_idname = "object.apply_subsurf"
    
    @classmethod    
    def poll(cls, context):
        obj = context.active_object
        if obj:
           for mod in obj.modifiers:
               if mod.type == 'SUBSURF':
                   return True
        return False
    
    def invoke(self, context, event):     
        scene = bpy.context.view_layer                           
        if event.shift :      
            for obj in context.selected_objects:
                scene.objects.active = obj
                for mod in obj.modifiers:
                    if mod.type == 'SUBSURF':
                        removeModifier(modifier=mod.name)
                        self.report({'INFO'}, "Removed " + mod.name + " Modifier(s)")              
                            
        else:  
            for obj in context.selected_objects:
                scene.objects.active = obj
                for mod in obj.modifiers:
                    if mod.type == 'SUBSURF':
                        applyModifier(apply_as='DATA', modifier=mod.name)
                        self.report({'INFO'}, "Applied " + mod.name + " Modifier(s)")                
        return {"FINISHED"}
    
################################################### 
# Apply only mirror modifiers   
################################################### 
class applymoveMirror(Operator):
    """
    CLICK - APPLY MIRROR
    SHIFT - REMOVE MIRROR
    CTRL - MOVE UP MIRROR
    """
    bl_label = "Apply Mirror"
    bl_idname = "object.apply_mirror"
    
    @classmethod    
    def poll(cls, context):
        obj = context.active_object
        if obj:
           for mod in obj.modifiers:
               if mod.type == 'MIRROR':
                   return True
        return False
    
    def invoke(self, context, event):
        obj = context.active_object  
        if event.ctrl :
            sel = bpy.context.selected_objects
            for ob in sel:
                for i, mod in enumerate(ob.modifiers):
                    if mod.type == 'MIRROR':
                        bpy.context.scene.objects.active = ob
                        for x in range(0, i):
                            bpy.ops.object.modifier_move_up(modifier=mod.name)
                            self.report({'INFO'}, "Move Up " + mod.name + " to first") 
        
        elif event.shift :
            for mod in obj.modifiers:
                if mod.type == 'MIRROR':
                    removeModifier(modifier=mod.name)
                    self.report({'INFO'}, "Removed " + mod.name + " Modifier(s)")       
                            
        else:   
            for mod in obj.modifiers:
                if mod.type == 'MIRROR':
                    applyModifier(apply_as='DATA', modifier=mod.name)
                    self.report({'INFO'}, "Applied " + mod.name + " Modifier(s)")             
        return {"FINISHED"}

################################################### 
# Apply only Array modifiers   
################################################### 
class applymoveArray(Operator):
    """
    CLICK - APPLY ARRAY
    SHIFT - REMOVE ARRAY
    CTRL - MOVE UP ARRAY
    """
    bl_label = "Apply Array"
    bl_idname = "object.apply_array"
    
    @classmethod    
    def poll(cls, context):
        obj = context.active_object
        if obj:
           for mod in obj.modifiers:
               if mod.type == 'ARRAY':
                   return True
        return False
    
    def invoke(self, context, event):
        obj = context.active_object  
        if event.ctrl :
            sel = bpy.context.selected_objects
            for ob in sel:
                for i, mod in enumerate(ob.modifiers):
                    if mod.type == 'ARRAY':
                        bpy.context.scene.objects.active = ob
                        for x in range(0, i):
                            bpy.ops.object.modifier_move_up(modifier=mod.name)
                            self.report({'INFO'}, "Move Up " + mod.name + " to first") 
        
        elif event.shift :
            for mod in obj.modifiers:
                if mod.type == 'ARRAY':
                    removeModifier(modifier=mod.name)
                    self.report({'INFO'}, "Removed " + mod.name + " Modifier(s)")          
                            
        else:   
            for mod in obj.modifiers:
                if mod.type == 'ARRAY':
                    applyModifier(apply_as='DATA', modifier=mod.name)
                    self.report({'INFO'}, "Applied " + mod.name + " Modifier(s)")             
        return {"FINISHED"}
        
################################################### 
# Apply only solidify modifiers   
################################################### 
class applymoveSolidify(Operator):
    """
    CLICK - APPLY SOLIDIFY
    CTRL - MOVE UP SOLIDIFY
    SHIFT - REMOVE SOLIDIFY
    """
    bl_label = "Apply Solidify"
    bl_idname = "object.apply_solidify"
    
    @classmethod    
    def poll(cls, context):
        obj = context.active_object
        if obj:
           for mod in obj.modifiers:
               if mod.type == 'SOLIDIFY':
                   return True
        return False
    
    def invoke(self, context, event):
        scene = bpy.context.view_layer
        obj = context.active_object  
        if event.ctrl :
            sel = bpy.context.selected_objects
            for ob in sel:
                for i, mod in enumerate(ob.modifiers):
                    if mod.type == 'SOLIDIFY':
                        scene.objects.active = ob
                        for x in range(0, i):
                            bpy.ops.object.modifier_move_up(modifier=mod.name)
                            self.report({'INFO'}, "Move Up " + mod.name + " to first")                           
        elif event.shift :
            for mod in obj.modifiers:
                if mod.type == 'SOLIDIFY':
                    removeModifier(modifier=mod.name)
                    self.report({'INFO'}, "Removed " + mod.name + " Modifier(s)")     
                    
        else:    
            for mod in obj.modifiers:
                if mod.type == 'SOLIDIFY':
                    applyModifier(apply_as='DATA', modifier=mod.name)
                    self.report({'INFO'}, "Applied " + mod.name + " Modifier(s)")                
        return {"FINISHED"}

################################################### 
# Apply only bevel modifiers   
################################################### 
class applymoveBevel(Operator):
    """
    CLICK - APPLY BEVEL
    CTRL - MOVE UP BEVEL
    SHIFT - REMOVE BEVEL
    """
    bl_label = "Apply Bevel"
    bl_idname = "object.apply_bevel"
    
    @classmethod    
    def poll(cls, context):
        obj = context.active_object
        if obj:
           for mod in obj.modifiers:
               if mod.type == 'BEVEL':
                   return True
        return False
    
    def invoke(self, context, event):
        scene = bpy.context.view_layer
        obj = context.active_object  
        if event.ctrl :
            sel = bpy.context.selected_objects
            for ob in sel:
                for i, mod in enumerate(ob.modifiers):
                    if mod.type == 'BEVEL':
                        scene.objects.active = ob
                        for x in range(0, i):
                            bpy.ops.object.modifier_move_up(modifier=mod.name)
                            self.report({'INFO'}, "Move Up " + mod.name + " to first")                           
        elif event.shift :
            for mod in obj.modifiers:
                if mod.type == 'BEVEL':
                    removeModifier(modifier=mod.name)
                    self.report({'INFO'}, "Removed " + mod.name + " Modifier(s)")     
                    
        else:    
            for mod in obj.modifiers:
                if mod.type == 'BEVEL':
                    applyModifier(apply_as='DATA', modifier=mod.name)
                    self.report({'INFO'}, "Applied " + mod.name + " Modifier(s)")    

        # Make Boolean To First
        for obj in context.selected_objects:
            for i, mod in enumerate(obj.modifiers):
                if mod.type == 'BOOLEAN':
                    scene.objects.active = obj
                    for x in range(0, i):
                        bpy.ops.object.modifier_move_up(modifier=mod.name)
        return {"FINISHED"}   

################################################### 
# Apply all modifiers on selected objects
###################################################
class applyModifiers(Operator):
    """Apply All Modifiers From Selected Objects"""
    bl_idname = "object.modifier_apply_all"
    bl_label = "Apply All Mod"    
    
    @classmethod
    def poll(cls, context):
        return len(context.selected_objects) > 0

    def execute(self, context):
        scene = bpy.context.view_layer
        selected = context.selected_objects
        
        for obj in selected:
            scene.objects.active = obj
            for mod in obj.modifiers:
                ops.object.modifier_apply(modifier=mod.name)
        self.report({'INFO'}, "Apply all modifiers on selected objects")
        return {'FINISHED'}
        
################################################### 
# Remove all modifiers on selected objects
###################################################
class removeModifiers(Operator):
    """Remove All Modifiers From Selected Objects"""
    bl_idname = "object.modifier_remove_all"
    bl_label = "Remove All Mod"    
    
    @classmethod
    def poll(cls, context):
        return len(context.selected_objects) > 0

    def execute(self, context):
        scene = bpy.context.view_layer
        selected = context.selected_objects
        
        for obj in selected:
            scene.objects.active = obj
            for mod in obj.modifiers:
                ops.object.modifier_remove(modifier=mod.name)
        self.report({'INFO'}, "Removed all modifiers on selected objects")
        return {'FINISHED'}
        
################################################### 
# Add Modifier function
################################################### 
def modifieradd(modifier, name):
    bpy.context.object.modifiers.new(type=modifier, name=name)
    return {"FINISHED"}

################################################### 
# Add a Subsurf Modifier at level 2 and optimal display enabled  +  Shade Smooth 
################################################### 
class addSubsurf(Operator):
    """Add Subsurf"""
    bl_label = "Subsurf"
    bl_idname = "object.subsurf"
    
    @classmethod
    def poll(cls, context):
        return len(context.selected_objects) > 0

    def execute(self, context):                
        scene = bpy.context.view_layer
        sel = context.selected_objects
        
        if bpy.context.object.mode == "EDIT":   
            bpy.ops.object.mode_set(mode="OBJECT")   
            for obj in sel:
                scene.objects.active = obj
                modifieradd("SUBSURF", "Subsurf")
            
                for mod in obj.modifiers:
                    if mod.type == 'SUBSURF':
                        mod.show_only_control_edges = True
                        mod.show_on_cage = False
                        mod.levels = 2 
                        bpy.ops.object.shade_smooth() 
            bpy.ops.object.mode_set(mode="EDIT")  
            
        else:        
            for obj in sel:
                scene.objects.active = obj
                modifieradd("SUBSURF", "Subsurf")
            
                for mod in obj.modifiers:
                    if mod.type == 'SUBSURF':
                        mod.show_only_control_edges = True
                        mod.show_on_cage = False
                        mod.levels = 2 
                        bpy.ops.object.shade_smooth()     
        return {"FINISHED"}

################################################### 
# Add a Solidify Modifier 
################################################### 
class addSolidify(Operator):
    """Add Solidify"""
    bl_label = "Solidify"
    bl_idname = "object.solidify"
    
    @classmethod
    def poll(cls, context):
        return len(context.selected_objects) > 0

    def execute(self, context):       
        scene = bpy.context.view_layer
        sel = context.selected_objects
        
        for obj in sel:
            scene.objects.active = obj
            modifieradd("SOLIDIFY", "Solidify")      
        return {"FINISHED"}

################################################### 
# Add a Bevel Modifier 
################################################### 
class addBevel(Operator):
    """Add Bevel"""
    bl_label = "Bevel"
    bl_idname = "object.bevel"
    
    @classmethod
    def poll(cls, context):
        return len(context.selected_objects) > 0

    def execute(self, context):       
        scene = bpy.context.view_layer
        sel = context.selected_objects
        
        for obj in sel:
            scene.objects.active = obj
            bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
            modifieradd("BEVEL", "Bevel")  
            for mod in obj.modifiers:
                if mod.type == 'BEVEL':
                    mod.segments = 2

            # Make Bevel To First
            for obj in context.selected_objects:
                for i, mod in enumerate(obj.modifiers):
                    if mod.type == 'BEVEL':
                        scene.objects.active = obj
                        for x in range(0, i):
                            bpy.ops.object.modifier_move_up(modifier=mod.name)
                            self.report({'INFO'}, "Move Up " + mod.name + " to first")  

            modifieradd("WEIGHTED_NORMAL", "Weight Normal")    
            bpy.ops.object.shade_smooth()
            bpy.context.object.data.use_auto_smooth = True
            bpy.context.object.data.auto_smooth_angle = 1.5708
        return {"FINISHED"}
        
################################################### 
# Add a Mirror Modifier with clipping enabled   
###################################################     
class addMirror(Operator):
    """
    CLICK - ADD MIRROR
    SHIFT - MOVE UP MIRROR
    """
    bl_label = "Add Mirror Modifier"
    bl_idname = "object.mirror"   
    
    @classmethod
    def poll(cls, context):
        return len(context.selected_objects) > 0
    
    def execute(self, context):                                      
        scene = bpy.context.view_layer
        
        # Check for active object
        activeObj = context.active_object
        selected = context.selected_objects
        
        # Store the mesh object
        origActive = activeObj        
        
        # Set status of mirror object usage
        useTarget = False
        
        # Apply rotation for better result
        bpy.ops.object.transform_apply(location=False, rotation=True, scale=False)

        # If no Empty is selected, don't use mirror object
        for obj in context.selected_objects:
            if obj.type == 'EMPTY':
                useTarget = True
        
        # Find all selected objects
        for obj in context.selected_objects:
            scene.objects.active = obj
            if obj.type == 'EMPTY':
                targetObj = obj
            elif obj.type == 'MESH' or obj.type == 'CURVE':
                modifieradd("MIRROR", "Mirror")
                
        # Make Mirror To First
        for obj in context.selected_objects:
            for i, mod in enumerate(obj.modifiers):
                if mod.type == 'MIRROR':
                    scene.objects.active = obj
                    for x in range(0, i):
                        bpy.ops.object.modifier_move_up(modifier=mod.name)
                        self.report({'INFO'}, "Move Up " + mod.name + " to first")      

        #Make the targetObj active
        try:
            scene.objects.active = [obj for obj in targetObj if obj != activeObj][0]
        except:
            pass
                
        # Check for active object
        activeObj = context.active_object
        
#        # Swap the selected and active objects
#        origActive, activeObj = activeObj, origActive
#        
#        # Deselect the empty object and select the mesh object again, making it active
#        origActive.select = False
#        activeObj.select = True
        scene.objects.active = activeObj
        
        
        for obj in selected:
            scene.objects.active = obj
            # Find the added modifier, enable clipping, set the mirror object
            for mod in obj.modifiers:
                if mod.type == 'MIRROR':
                    mod.use_clip = True
                    if useTarget:
                        mod.mirror_object = bpy.data.objects[targetObj.name]
                        self.report({'INFO'}, "Assigned target object to modifier")                             
        return {"FINISHED"}

################################################### 
# Add an Array modifier with object offset enabled 
###################################################      
class addArray(Operator):
    """Add Array"""
    bl_label = "Add Array Modifier"
    bl_idname = "object.array"
          
    @classmethod
    def poll(cls, context):
        return len(context.selected_objects) > 0
    
    # Add the modifier
    def execute(self, context):
        scene = bpy.context.view_layer
        sel = context.selected_objects
        
        for obj in sel:
            bpy.context.view_layer.objects.active = obj
            modifieradd("ARRAY", "Array")    
        return {"FINISHED"}

##########################
# Add an Lattice modifier
#########################    
class addLattice(Operator):
    """Add Lattice"""
    bl_label = "Add Lattice Modifier"
    bl_idname = "object.lattice"
          
    @classmethod
    def poll(cls, context):
        return len(context.selected_objects) > 0
    
    # Add the modifier
    def execute(self, context):
        scene = bpy.context.view_layer
         
        modName = "Lattice"
    
        activeObj = context.active_object
        selected = context.selected_objects

        if selected:
            if len(selected) > 1:
                if len(selected) == 2:
                    for ob in selected:
                        if ob != activeObj:
                            nonActive = ob
    
                    bpy.ops.object.modifier_add(type="LATTICE")   
                    
                    for mod in activeObj.modifiers:
                        if mod.type == 'LATTICE':
                            mod.object = nonActive
                            mod.name = modName
                            
                    for ob in bpy.context.selected_objects:
                        if ob.type != 'MESH':
                            ob.select_set(state=False)  

                else:
                    self.report({'INFO'}, "Select only 2 objects at a time")
            else:
                self.report({'INFO'}, "Only 1 object selected")
        else:
            self.report({'INFO'}, "No objects selected")
        return {"FINISHED"}

##########################
# Add an Lattice modifier
#########################        
class addShrinkwrap(Operator):
    """Add Shrinkwrap"""
    bl_label = "Add Shrinkwrap Modifier"
    bl_idname = "object.shrinkwrap"
          
    @classmethod
    def poll(cls, context):
        return len(context.selected_objects) > 0
    
    # Add the modifier
    def execute(self, context):
        scene = bpy.context.view_layer
         
        modName = "Shrinkwrap"
    
        activeObj = context.active_object
        selected = context.selected_objects

        if selected:
            if len(selected) > 1:
                if len(selected) == 2:
                    for ob in selected:
                        if ob != activeObj:
                            nonActive = ob
    
                    bpy.ops.object.modifier_add(type="SHRINKWRAP")   
                    
                    for mod in activeObj.modifiers:
                        if mod.type == 'SHRINKWRAP':
                            mod.target = nonActive
                            mod.name = modName
                            
                    for ob in bpy.context.selected_objects:
                        if ob.type != 'MESH':
                            ob.select_set(state=False)  

                else:
                    self.report({'INFO'}, "Select only 2 objects at a time")
            else:
                self.report({'INFO'}, "Only 1 object selected")
        else:
            self.report({'INFO'}, "No objects selected")
        return {"FINISHED"}

##########################
# Add Weignted Normal
#########################        
class addWeightedNRM(Operator):
    """Add Weighted Normal"""
    bl_label = "Add Weighted Normal Modifier"
    bl_idname = "object.weightednormal"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        if not context.selected_objects and not context.active_object:
            self.report({'ERROR'}, "Nothing is selected & there is no Active Object")
            return{'FINISHED'}

        if context.active_object:
            bpy.ops.object.mode_set(mode='OBJECT')

        for ob in context.selected_objects:
            if ob.type == 'MESH':
                context.view_layer.objects.active = ob

                bpy.ops.object.shade_smooth()
                ob.data.use_auto_smooth = True
                ob.data.auto_smooth_angle = 1.0472
                
                for mod in ob.modifiers:
                    if mod.type == 'WEIGHTED_NORMAL':
                        break
                else:
                    ob.modifiers.new('Weighted Normal', 'WEIGHTED_NORMAL')
                    ob.modifiers["Weighted Normal"].weight = 100

        self.report({'INFO'}, "Automatically Face Weighted selection")
        return{'FINISHED'}
    
