# This file is part of Instant Clean
# Copyright (C) 2023  Ruben Messerschmidt

__all__ = ['register', 'unregister']

from . import props
from . import ops
from . import ui

def register():
    props.register()
    ops.register()
    ui.register()

def unregister():
    ui.unregister()
    ops.unregister()
    props.unregister()