import bpy
from mathutils import Matrix, Vector   
from bpy.types import Operator


######################################
#   Select Seam Edge From Object Mode
#####################################
class Mesh_Edge_select_seams(Operator):
    bl_idname = "meshedge.select_seams"
    bl_label = "Select Seams"
    bl_description = "Set seam edges selected"
        
    def execute(self, context):
        is_editmode = (context.mode == 'EDIT_MESH')
        if is_editmode:
            obList = context.objects_in_mode_unique_data
        else:
            obList = [
                ob for ob in context.selected_editable_objects
                if ob.type == 'MESH' and ob.data.library is None
            ]
        
        if(context.mode == 'OBJECT'):
            bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.mesh.select_all(action='DESELECT')
        context.tool_settings.mesh_select_mode = (False, True, False)
        bpy.ops.object.mode_set(mode='OBJECT')
        
        for ob in obList:
            m = ob.data
            for e in m.edges:
                if(e.use_seam):
                    e.select = True
        bpy.ops.object.mode_set(mode='EDIT')
        return {'FINISHED'}

######################################
#   Select Sharp Edge From Object Mode
#####################################
class select_sharp_edge_mode(Operator):
    bl_idname = "meshedge.select_sharp"
    bl_label = "Select Sharp"
    bl_description = "Set sharp edges selected"
        
    def execute(self, context):
        is_editmode = (context.mode == 'EDIT_MESH')
        if is_editmode:
            obList = context.objects_in_mode_unique_data
        else:
            obList = [
                ob for ob in context.selected_editable_objects
                if ob.type == 'MESH' and ob.data.library is None
            ]
            
        if(context.mode == 'OBJECT'):
            bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.mesh.select_all(action='DESELECT')
        context.tool_settings.mesh_select_mode = (False, True, False)
        bpy.ops.object.mode_set(mode='OBJECT')
        
        for ob in obList:
            m = ob.data
            for e in m.edges:
                if(e.use_edge_sharp):
                    e.select = True                    
            if ob.type == 'MESH':
                context.object.data.use_auto_smooth = True
                context.object.data.auto_smooth_angle = 3.14159
        bpy.ops.object.mode_set(mode='EDIT')
        return {'FINISHED'}

#################################
#   Seam From Island Object Mode
#################################
class Object_mark_seams_from_uv_islands(Operator):
    bl_idname = "object.mark_seams_from_uv_islands"
    bl_label = "Mark Seams From UV Islands"
    bl_description = "Mark Seams From UV Islands"
    
    @classmethod
    def poll(cls, context):
        ob = context.active_object
        return (ob and ob.type == 'MESH' and (context.mode == 'EDIT_MESH' or context.mode == 'OBJECT') and len(ob.data.uv_layers) > 0)
    
    def execute(self, context):
        e = True
        if(context.mode != 'EDIT_MESH'):
            e = False
            bpy.ops.object.mode_set(mode='EDIT')
        if bpy.context.area.type != 'UV':
            bpy.context.area.ui_type = 'UV'
            bpy.ops.uv.select_all()
            bpy.ops.uv.seams_from_islands()
        bpy.context.area.ui_type = 'VIEW_3D'
        if(not e):
            bpy.ops.object.mode_set(mode='OBJECT')
        return {'FINISHED'}

#################################
#   Smart UV + Seams From Island
#################################
class Object_SmartUV_Extra(Operator):
    bl_idname = "object.samrtuvplus"
    bl_label = "SmartUV+"
    bl_description = "Smart UV + Mark Seams From UV Islands"
    
    @classmethod
    def poll(cls, context):
        ob = context.active_object
        return (ob and ob.type == 'MESH' and (context.mode == 'EDIT_MESH' or context.mode == 'OBJECT') and len(ob.data.uv_layers) > 0)
    
    def execute(self, context):        
        bpy.ops.uv.smart_project(island_margin=0.001)
        
        if bpy.context.area.type != 'UV':
            bpy.context.area.ui_type = 'UV'
            bpy.ops.uv.select_all()
            bpy.ops.uv.seams_from_islands()
        bpy.context.area.ui_type = 'VIEW_3D'

        return {'FINISHED'}