import bpy
from .. properties import *

def draw_assetmanagement_ui(self, context, layout):
    red = context.scene.red_props
    addon_preferences = get_addon_preferences()

    box_prefix = layout.box()
    box_prefix.scale_x = 1.3
    box_prefix.scale_y = 1.3
    row1 = box_prefix.row()
    row1.enabled = False
    row1.prop(addon_preferences, "set_prefix", text="Prefix Name")
    row2 = box_prefix.row()
    row2.operator("op.open_addon_pref")

    box_assetsaver = layout.box()
    box_assetsaver.scale_x = 1.3
    box_assetsaver.scale_y = 1.3
    # box_assetsaver.label(text="Category:")
    # row = box_assetsaver.row()
    # row.prop(red, "asset_type", expand=True)

    box_assetsaver.prop(addon_preferences, "settingsFilePath")
    # box_assetsaver.prop(red, "save_filename")
    row = box_assetsaver.row()
    # row.operator("op.initial_save")
    # row.operator("op.assetsave_wip")
    # row.operator("op.assetsave_incremental_backup")
    # row.operator("op.assetsave_publish")

    layout.separator()
    layout.separator()
    layout.separator()

    box_shotloader = layout.box()
    box_shotloader.scale_x = 1.8
    box_shotloader.scale_y = 1.8
    box_shotloader.operator("op.shot_loader", icon="ASSET_MANAGER")
    box_shotloader.operator("op.anim_asset_loader", icon="ASSET_MANAGER")
    
    box_shotloader.separator()
    box_shotloader.separator()
   
    box_shotloader.operator("op.local_playblast")
    box_shotloader.operator("wm.publish_shot")

#    box_assetchecker = layout.box()
#    box_assetchecker.scale_x = 1.8
#    box_assetchecker.scale_y = 1.8
#    box_assetchecker.operator("op.asset_checker", icon="CHECKMARK")