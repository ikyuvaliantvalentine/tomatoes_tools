import bpy
from .. properties import *

def draw_uv_sets_ui(self, context, layout):
    red = context.scene.red_props
    # addon_preferences = get_addon_preferences()
    # uvname = addon_preferences.custom_uvname 

    col = layout.column(align=True)

    if not red.display_uv_sets: 
        box = col.box().column(align=True)
        row = box.row(align=True)   
        row.prop(red, "display_uv_sets", text="", icon="TRIA_RIGHT", toggle = True)                
        row.label(text="Check UV Sets")    

    else:
        box = col.box().column(align=False)
        box.scale_x = 1.2
        box.scale_y = 1.2
        row = box.row(align=True)   
        row.prop(red, "display_uv_sets", text="", icon="TRIA_DOWN", toggle = True)                
        row.label(text="Check UV Sets")   
        
        obj = context.object
        if obj.type == "MESH":
            if context.object is None:
                box.label(text="Need One Active Object!!!")
            else:
                me = context.object.data

                row = box.row()
                col = row.column()

                col.template_list("MESH_UL_uvmaps", "uvmaps", me, "uv_layers", me.uv_layers, "active_index", rows=2)

                col = row.column(align=True)
                col.operator("mesh.uv_texture_add", icon='ADD', text="")
                col.operator("mesh.uv_texture_remove", icon='REMOVE', text="")

                box.label(text="Utility")

                box.operator("reduv.del_unused_uvmap", icon ="CANCEL")
                box.operator("op.get_object_more_than_one_map")
                # box.operator("redop.uv_rename_all", text = "Rename UVmap to " + uvname)
        else:
            box.label(text="Only Mesh!!!")