# This file is part of Instant Clean
# Copyright (C) 2023  Ruben Messerschmidt

from .main_panel import BC_PT_Main_Panel
from .repair_panel import BC_PT_Repair_Panel
from .limdiss_panel import BC_PT_Limdiss_Panel
from .topology_panel import BC_PT_Topology_Panel
from .normals_panel import BC_PT_Normals_Panel
from .objectdata_panel import BC_PT_Objectdata_Panel


classes = [
    BC_PT_Main_Panel,
    BC_PT_Repair_Panel,
    BC_PT_Limdiss_Panel,
    BC_PT_Topology_Panel,
    BC_PT_Normals_Panel,
    BC_PT_Objectdata_Panel
]

import bpy

def register():
    for cls in classes:
        bpy.utils.register_class(cls)

def unregister():
    for cls in classes:
        bpy.utils.unregister_class(cls)