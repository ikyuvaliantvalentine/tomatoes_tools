import bpy
from bpy.types import Operator

################################################### 
# Add Modifier function
################################################### 
def modifieradd(modifier, name):
    bpy.context.object.modifiers.new(type=modifier, name=name)
    return {"FINISHED"}

################################################### 
# Add Bevel Modifier with Weight Method
################################################### 
class addBevelWeight(Operator):
    """Add Bevel Weight"""
    bl_label = "Bevel Weight"
    bl_idname = "object.bevel_weight"
    
    @classmethod
    def poll(cls, context):
        return len(context.selected_objects) > 0

    def execute(self, context):                
        scene = bpy.context.view_layer
        sel = context.selected_objects
        
        for obj in sel:
            scene.objects.active = obj
            bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
            modifieradd("BEVEL", "Bevel")   

            for mod in obj.modifiers:
                if mod.type == 'BEVEL':
                    mod.segments = 3
                    mod.offset_type = 'WIDTH'
                    mod.limit_method = 'WEIGHT'
                    
        return {"FINISHED"}