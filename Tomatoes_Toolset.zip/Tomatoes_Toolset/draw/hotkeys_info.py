import bpy, bgl, blf
from bpy.types import Operator
from .. properties import *

pos_x = 20 # Initial X position.
pos_y = 80 # initial Y position. This value gets substracted from the screen height.
subpos_y = 0 # needed to calculate the position of the array strings below the title.

# The main text. Always shown. Navigation is the same everywhere.
def draw_maintext(self, context):
    addon_preferences = get_addon_preferences()
    tomatoes = context.scene.tomatoes_props
    xmod = addon_preferences.PositionXModal
    wdt2=0
    if bpy.context.area.type=='VIEW_3D':
        for r in bpy.context.area.regions:
            if r.type=='TOOLS': 
                wdt2=r.width-1
                self.regionwdt=wdt2
                xmod = addon_preferences.PositionXModal+r.width-1
      
    # ------------------- Draw the text

    font_id = 0  # XXX, need to find out how best to get this.
    
    # color variables
    font_color_r, font_color_g, font_color_b, font_color_alpha = tomatoes.important_hotkeys_text_color

    # Calculate the text
    blf.position(0, pos_x, context.region.height-pos_y, 0) #titleposition
    blf.size(font_id, tomatoes.important_hotkeys_font_size, 72)
    blf.color(font_id, font_color_r, font_color_g, font_color_b, font_color_alpha * 1.0) # color variables
    
    texts = []
    texts.append(([            
        "Shortcut List",
        "----------------------------",
        "Cycles Settings (CTRL + RIGHTMOUSE)",
        "World Toolbox (CTRL + ALT + RIGHTMOUSE)",
        "Lamp Toolbox (SHIFT + CTRL + ALT + RIGHTMOUSE)",
        "Renamer Object (ALT + LEFTMOUSE) (Object Mode)",
        "Camera Projection (CTRL + ALT + LEFTMOUSE)",
        "Modifier Toolbox (SHIFT + ALT + LEFTMOUSE)",
        "Set Scene (SHIFT + ALT + Z)",
        "Modal Rotate (SHIFT + ALT + R)",
        "Polycount Display (F3)",
        "New Custom Transform (CTRL + SHIFT + Z) (Edit Mode)",
        "Delete Custom Transform (CTRL + SHIFT + X) (Edit Mode)",
        "Origin To Selected (CTRL + SHIFT + ALT + Z) (Edit Mode)",
        "----------------------------",
        "Quick Add Object (CTRL + ALT + SHIFT + A)",
        "Toggle Edit Menu (SHIFT + ALT + X) (Edit Mode)",
        "Reload All Image (CTRL + SHIFT + Z)",
        "Sculpt Menu (ALT + SPACE)",
        "----------------------------",
        "Pie View Numpad (Q)",
        "Pie Mode (TAB)",
        "Pie Select Mode (A)",
        "Pie Quick Menu (ALT + MIDDLEMOUSE)",
        "Pie Quick Area Views (SPACE)",
        "Pie Save & Open (CTRL + S)",
        "Pie Manipulators (CTRL + SPACE)",
        "Pie Pivot 3D View & UV Editor (ALT + Q)",
        "Pie Animation (ALT + A)",
        "Pie Shading View (Z)",
        "Pie Proportional Editing (ALT + W)",
        "Pie Particle Edit Options (ALT + W)",
        "Pie UV Wield/Align (W)",
        "Pie Select In UV Mapping (A)",
        "Pie More Menu (SHIFT + LEFTMOUSE)",
        "Pie Text Edit (ALT + RIGHTMOUSE)",
        ]))
                    
    # Draw the text
    for data in texts:
        subpos_y = context.region.height-pos_y-tomatoes.important_hotkeys_font_size # initial texts position
        for d in data:
            blf.position(0, pos_x + xmod, subpos_y, 0)
            blf.draw(0, d)
            subpos_y -= tomatoes.important_hotkeys_font_size + 1 # Our spacing between the lines is the font size plus 1 to have a gap between the lines.
                    
# ----------------------- Mainclass. Here happens the work.

class ModalDrawOperator(Operator):
    """Shows a list with important hotkeys"""
    bl_idname = "view3d.modal_operator"
    bl_label = "Simple Modal View3D Operator"
    
    # Our modal function. The text will display as long as it is not cancelled.
    def modal(self, context, event):
        tomatoes = context.scene.tomatoes_props
        if context.area:
            context.area.tag_redraw()
            
            if not tomatoes.showhide_flag:
                # stop script
                bpy.types.SpaceView3D.draw_handler_remove(self._handle, 'WINDOW')
                return {'CANCELLED'}
            
        return {'PASS_THROUGH'}

    def invoke(self, context, event):
        tomatoes = context.scene.tomatoes_props
        if context.area.type == 'VIEW_3D':
            if tomatoes.showhide_flag is False:
                tomatoes.showhide_flag = True # operator is called for the first time, start everything
                
                # Add draw handler
                self._handle = bpy.types.SpaceView3D.draw_handler_add(draw_maintext, (self, context), 'WINDOW', 'POST_PIXEL')
                context.window_manager.modal_handler_add(self)
                
                return {'RUNNING_MODAL'}
            else:
                # operator is called again, stop displaying
                tomatoes.showhide_flag = False
                self.key = []
                return {'CANCELLED'}
        else:
            self.report({'WARNING'}, "View3D not found, cannot run operator")
            return {'CANCELLED'}
        
        
class HotkeyInfo(Operator):
    bl_label = "Shortcut List"
    bl_idname = "shortcut.info"
    bl_description = "List Of Shortcut"
    dialog_width =  200             
    
    def draw(self, context):
        tomatoes = context.scene.tomatoes_props
        layout = self.layout
        layout.label(text="Hotkeys Info")
        if not tomatoes.showhide_flag:
            layout.operator("view3d.modal_operator", text="Show text")
        else:
            layout.operator("view3d.modal_operator", text="Hide text")
        
        # another method to split the elements
        row = layout.row(align=True)
        split = row.split()
        left_side = split.column(align=True)
        left_side.prop(tomatoes , "important_hotkeys_text_color", text="")
        split = split.split()
        right_side = split.column()
        right_side.prop(tomatoes, "important_hotkeys_font_size", text="Fontsize")
                                                                
    def check(self, context):
        return True        
    def execute(self, context):
        return {'FINISHED'}    
    def invoke(self, context, event):
        wm = context.window_manager
        return wm.invoke_popup(self)

    
        

    

