# This file is part of Instant Clean
# Copyright (C) 2023  Ruben Messerschmidt

import bpy
import bmesh
from .common_funcs import deselect_all_geo


def dissolve_loose_verts(bm, verts):
    count = 0
    loose = []
    for vert in verts:
        if len(vert.link_edges) == 0:
            loose.append(vert)
            count += 1

    bmesh.ops.dissolve_verts(bm, verts=loose)
    return count

def dissolve_loose_edges(bm, edges):
    count = 0
    for edge in edges:
        if len(edge.link_faces) == 0:
            verts = edge.verts
            bm.edges.remove(edge)
            dissolve_loose_verts(bm, verts)
            count += 1

    return count

def dissolve_loose_faces(bm, faces):
    count = 0
    for face in faces:
        flag = 0
        edges = []
        for edge in face.edges:
            edges.append(edge)
            if not len(edge.link_faces) == 1:
                flag = 1
                break
        if flag == 1:
            continue
        
        bm.faces.remove(face)
        dissolve_loose_edges(bm, edges)
        count += 1
    
    return count


def dissolve_doubles(bm, verts, dst):
    count = len(verts)
    bmesh.ops.remove_doubles(bm, verts=verts, dist=dst)
    return count - len([v for v in verts if v.is_valid])


def dissolve_zero_faces(bm, edges, dst):
    count = len(edges)
    bmesh.ops.dissolve_degenerate(bm, dist=dst, edges=edges)
    return count - len([e for e in edges if e.is_valid])


def dissolve_dispensables(bm, verts, ang):
    count = len(verts)
    disps = []
    for vert in [v for v in verts if len(v.link_edges) == 2 and v.calc_edge_angle(0) < ang]:
        disps.append(vert)

    bmesh.ops.dissolve_verts(bm, verts=disps)
    return count - len([v for v in verts if v.is_valid])


def dissolve_interior_faces(bm, faces):
    count = len(faces)
    deselect_all_geo(bm)
    bpy.ops.mesh.select_interior_faces()
    bmesh.ops.delete(bm, geom=[f for f in faces if f.select == True], context='FACES_ONLY')
    deselect_all_geo(bm)
    return count - len([f for f in faces if f.is_valid])