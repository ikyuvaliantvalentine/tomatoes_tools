import bpy
import blf
import bgl
import bmesh
from .. properties import *
from bpy.types import Operator
import math
from math import *

class Polycount_Display(Operator):
    bl_label = "Polycount Display"
    bl_idname = "shortcut.polycount"
    bl_description = "Show Mesh Data"
    dialog_width =  200             
    
    def draw(self, context):
        tomatoes = context.scene.tomatoes_props
        layout = self.layout
 
        if not tomatoes.polycount_run:
            layout.operator("view3d.polycount", text="Start display",
                icon='PLAY')
        else:
            layout.operator("view3d.polycount", text="Stop display",
                icon='PAUSE')
               
        col = layout.column(align=True)
        row = col.row(align=True)
        row.prop(tomatoes, "polycount_pos_x")
        row.prop(tomatoes, "polycount_pos_y")
        row = col.row(align=True)
        row.prop(tomatoes, "polycount_font_size")
 
        layout.prop(tomatoes, "polycount_font_color")
                                                                
    def check(self, context):
        return True        
    def execute(self, context):
        return {'FINISHED'}    
    def invoke(self, context, event):
        wm = context.window_manager
        return wm.invoke_popup(self)
                         
class PolyCountOperator(Operator):
    bl_idname = "view3d.polycount"
    bl_label = "Polygon Count Display Tool"
    bl_description = "Display polygon count in the 3D-view"
 
    _handle = None
    
    def modal(self, context, event):
        tomatoes = context.scene.tomatoes_props
        if context.area:
            context.area.tag_redraw()
              
        if not tomatoes.polycount_run:
            # stop script
            bpy.types.SpaceView3D.draw_handler_remove(self._handle, 'WINDOW')
            return {'CANCELLED'}
 
        return {'PASS_THROUGH'}
           
    def cancel(self, context):
        tomatoes = context.scene.tomatoes_props
        if tomatoes.polycount_run:
            context.region.callback_remove(self._handle)
            tomatoes.polycount_run = False
        return {'CANCELLED'}
   
    def invoke(self, context, event):      
        tomatoes = context.scene.tomatoes_props 
        if context.area.type == 'VIEW_3D':
            if tomatoes.polycount_run == False:
                args = (self, context)
                # operator is called for the first time, start everything
                print("initialized")
                tomatoes.polycount_run = True
                context.window_manager.modal_handler_add(self)
               
                self._handle = bpy.types.SpaceView3D.draw_handler_add(draw_callback_px, args, 'WINDOW', 'POST_PIXEL')  
               
                return {'RUNNING_MODAL'}
            else:
                # operator is called again, stop displaying
                tomatoes.polycount_run = False
                print("stopped")
                return {'CANCELLED'}
        else:
            self.report({'WARNING'}, "View3D not found, can't run operator")
            return {'CANCELLED'}
 
def get_display_location(context):                
    tomatoes = context.scene.tomatoes_props 
 
    width = context.region.width
    height = context.region.height
 
    pos_x = tomatoes.polycount_pos_x
    pos_y = height - tomatoes.polycount_pos_y
 
    return(pos_x, pos_y)
 
def draw_callback_px(self, context):
    tomatoes = context.scene.tomatoes_props 
   
    if not tomatoes.polycount_run:
        return
 
    font_size  = tomatoes.polycount_font_size
    pos_x, pos_y = get_display_location(context)
     
    # draw text in the 3d-view
    # ========================
    r, g, b = tomatoes.polycount_font_color
    blf.color(0, r, g, b, 1)
    
    wdt2=0           
    if bpy.context.area.type=='VIEW_3D':
        for r in bpy.context.area.regions:
            if r.type=='TOOLS': 
                wdt2=r.width-1
                self.regionwdt=wdt2
                region_tools = 0 + r.width-1
    
    if context.object.type == 'MESH':      
        if bpy.context.object.mode == 'OBJECT':   
                                           
                #Object Name
                text = context.object.name
                text1height = blf.dimensions(0, text)[1] 
                blf.size(0, int(15*(font_size/10)) + 5, 72) #   For Title
                blf.position(0, pos_x + region_tools, pos_y - text1height, 0)
                blf.draw(0, text)
                
                blf.size(0, font_size, 72)
                        
                #Verticies Total
                verts = len(bpy.context.active_object.data.vertices)
                text = "Verts: " + (str(verts)) + "            " + all_vertices()
                text2height = blf.dimensions(0, text)[1] 
                blf.position(0, pos_x + region_tools, pos_y - text1height - text2height - 1.5 * font_size, 0)
                blf.draw(0, text)
                
                #Edge Total
                edgs = len(bpy.context.active_object.data.edges)
                text = "Edges: " + (str(edgs)) + "      " + all_edges()
                text3height = blf.dimensions(0, text)[1]
                blf.position(0, pos_x + region_tools, pos_y - text2height - text3height - 3.0 * font_size , 0)
                blf.draw(0, text)
                
                #Faces Total
                faces = len(bpy.context.active_object.data.polygons)
                text = "Faces: " + (str(faces)) + "         " +  all_faces()
                text4height = blf.dimensions(0, text)[1] 
                blf.position(0, pos_x + region_tools, pos_y - text3height - text4height - 4.6 * font_size , 0)
                blf.draw(0, text)
                               
                #Tris Total
                text = "Tris: " + trisCount()
                text5height = blf.dimensions(0, text)[1] 
                blf.position(0, pos_x + region_tools, pos_y - text4height - text5height - 6.5 * font_size , 0)
                blf.draw(0, text)
               
                #Ngons Total
                text = "Ngons: " + ngonsCount()
                text6height = blf.dimensions(0, text)[1] 
                blf.position(0, pos_x + region_tools, pos_y - text5height - text6height - 8.0 * font_size , 0)
                blf.draw(0, text)
           
        elif bpy.context.object.mode == 'EDIT':     
            ob = bpy.context.object
            me = ob.data
            bm = bmesh.from_edit_mesh(me)
            
            quads = tris = ngons = 0
            ngons_to_tris = 0             
            
            for f in bm.faces:                
                v = len(f.verts)
                if v == 3: # tris
                    tris += 1
                elif v == 4: # quads
                    quads += 1 
                elif v > 4: # ngons
                    ngons += 1            
                    V = len(f.verts) - 2 # nomber of tris in ngons
                    ngons_to_tris += V # get total tris of total ngons 
                        
            bmesh.update_edit_mesh(me)
                                          
            #Object Name
            text = context.object.name
            text1height = blf.dimensions(0, text)[1] 
            blf.size(0, int(15*(font_size/10)) + 5, 72) #   For Title
            blf.position(0, pos_x + region_tools, pos_y - text1height, 0)
            blf.draw(0, text)
            
            blf.size(0, font_size, 72)
                    
            #Verticies Total
            verts = len(bpy.context.active_object.data.vertices)
            text = "Verts: " + (str(len(bm.verts)))
            text2height = blf.dimensions(0, text)[1] 
            blf.position(0, pos_x + region_tools, pos_y - text1height - text2height - 1.5 * font_size, 0)
            blf.draw(0, text)
            
            #Edge Total
            edgs = len(bpy.context.active_object.data.edges)
            text = "Edges: " + (str(len(bm.edges)))
            text3height = blf.dimensions(0, text)[1]
            blf.position(0, pos_x + region_tools, pos_y - text2height - text3height - 3.0 * font_size , 0)
            blf.draw(0, text)
            
            #Faces Total
            faces = len(bpy.context.active_object.data.polygons)
            text = "Faces: " + (str(len(bm.faces)))
            text4height = blf.dimensions(0, text)[1] 
            blf.position(0, pos_x + region_tools, pos_y - text3height - text4height - 4.6 * font_size , 0)
            blf.draw(0, text)
           
            #Tris Total
            text = "Tris: " + (str(tris + quads*2 + ngons_to_tris))
            text5height = blf.dimensions(0, text)[1] 
            blf.position(0, pos_x + region_tools, pos_y - text4height - text5height - 6.5 * font_size , 0)
            blf.draw(0, text)
           
            #Ngons Total
            text = "Ngons: " + (str(ngons))
            text6height = blf.dimensions(0, text)[1] 
            blf.position(0, pos_x + region_tools, pos_y - text5height - text6height - 8.0 * font_size , 0)
            blf.draw(0, text)
            
    #Use Autosmooth
    text = "AutoSmooth: " + (str(bpy.context.object.data.use_auto_smooth))
    text7height = blf.dimensions(0, text)[1] 
    blf.position(0, pos_x + region_tools, pos_y - text6height - text7height - 12 * font_size , 0)
    blf.draw(0, text)

    #Autosmooth Degree
    text = "AutoSmooth: " + (str(round(math.degrees(bpy.context.object.data.auto_smooth_angle))))
    text8height = blf.dimensions(0, text)[1] 
    blf.position(0, pos_x + region_tools, pos_y - text7height - text8height - 14 * font_size , 0)
    blf.draw(0, text)


def trisCount():   
    quads = tris = ngons = 0
    ngons_to_tris = 0
    
    ob = bpy.context.active_object 
    for p in ob.data.polygons:
        count = p.loop_total
        if count == 3:
            tris += 1                    
        elif count == 4:
            quads += 1
        elif count > 4:
            ngons += 1 
            V = count - 2  
            ngons_to_tris += V 
    tris_count = str(tris + quads*2 + ngons_to_tris)    
    return tris_count

def ngonsCount():   
    ngons = 0   
    ob = bpy.context.active_object 
    for p in ob.data.polygons:
        count = p.loop_total
        if count > 4:
            ngons += 1             
    return str(ngons)

def all_vertices():   
    sumverts = []
    for element in bpy.context.scene.objects:
        if element.type !='MESH':
            continue
        me = element.data
        verts = len(me.vertices)
        sumverts.append(verts)
    all_count_vertices = ("Total: %d" % sum(sumverts))    
    return all_count_vertices

def all_edges():   
    sumedges = []
    for element in bpy.context.scene.objects:
        if element.type !='MESH':
            continue
        me = element.data
        edges = len(me.edges)
        sumedges.append(edges)
    all_count_edges = ("Total: %d" % sum(sumedges))    
    return all_count_edges

def all_faces():   
    sumfaces = []
    for element in bpy.context.scene.objects:
        if element.type !='MESH':
            continue
        me = element.data
        faces = len(me.polygons)
        sumfaces.append(faces)
    all_count_faces = ("Total: %d" % sum(sumfaces))    
    return all_count_faces
  