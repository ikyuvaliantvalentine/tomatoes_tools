import bpy, os 
from bpy.props import *
from bpy.types import PropertyGroup

def get_addon_preferences():
    addon_name = os.path.basename(os.path.dirname(os.path.abspath(__file__).split("utils")[0]))
    user_preferences = bpy.context.preferences
    addon_prefs = user_preferences.addons[addon_name].preferences     
    return addon_prefs

def dpifac():
    prefs = bpy.context.preferences.system
    # python access to this was only added recently, assume non-retina display is used if using older blender
    if hasattr(prefs, 'pixel_size'):
        retinafac = bpy.context.preferences.system.pixel_size
    else:
        retinafac = 1
    return bpy.context.preferences.system.dpi / (72 / retinafac)

# ------------------------------------------------------------------------              
#   Property Group
# ------------------------------------------------------------------------    
class SceneCheckerProperties(PropertyGroup):
    settingsFilePath : StringProperty(
            name="Settings",
            default="",
            subtype='FILE_PATH',
            description="location for the settings save/load\n")  
    
    
    save_filename : StringProperty(
            name="Filename",
            default="",
            description="Set Filename")  
            