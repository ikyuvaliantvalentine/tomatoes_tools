import bpy, os, bpy.utils.previews
from os.path import join, dirname
from bpy.props import *
from bpy.types import PropertyGroup
from bpy.utils import previews
                        
def get_addon_preferences():
    addon_name = os.path.basename(os.path.dirname(os.path.abspath(__file__).split("utils")[0]))
    user_preferences = bpy.context.preferences
    addon_prefs = user_preferences.addons[addon_name].preferences     
    return addon_prefs

def dpifac():
    prefs = bpy.context.preferences.system
    # python access to this was only added recently, assume non-retina display is used if using older blender
    if hasattr(prefs, 'pixel_size'):
        retinafac = bpy.context.preferences.system.pixel_size
    else:
        retinafac = 1
    return bpy.context.preferences.system.dpi / (72 / retinafac)

#####################################################################
# UI List World
#####################################################################
def update_world_selection(self,context):
    brandoville = context.scene.brandoville_props
    if brandoville.selected_world_index <= len(bpy.data.worlds) - 1:
        world = bpy.data.worlds[brandoville.selected_world_index]
        context.scene.world = world  
        
# ------------------------------------------------------------------------              
#   Custom Icons
# ------------------------------------------------------------------------    
ICONS = {'Label', 'prev_material', 'lighting_outliner'\
, 'delete_material', 'tools_settings', 'ngon', 'triangle', 'check_icon'\
, 'maya_combine', 'maya_separate', 'maya_polysmooth', 'maya_boolean_union'\
, 'maya_extrude_face', 'maya_bevel', 'maya_bridge', 'maya_add_divisions'\
, 'maya_multicut', 'maya_target_weld', 'maya_connect', 'maya_quad_draw' }
ICON_COLLECTION = {}

def register_icons():
    preview_coll = previews.new()
    icons_folder = join(dirname(__file__), "custom_icons")

    for icon in ICONS:
        preview_coll.load(icon, join(icons_folder, icon + ".png"), 'IMAGE')

    ICON_COLLECTION["main"] = preview_coll

def unregister_icons():
    for collection in ICON_COLLECTION.values():
        previews.remove(collection)
    ICON_COLLECTION.clear()

def get_icon(icon):
    preview_coll = ICON_COLLECTION["main"]
    return preview_coll[icon].icon_id

# Hide boolean objects
def toggle_bool(self, context):
    ao = context.view_layer.objects.active
    objs = [i.object for i in ao.modifiers if i.type == "BOOLEAN"]
    hide_state = context.scene.tomatoes_props.hide_bool_objects

    for o in objs:
        o.hide_viewport = hide_stat

# ------------------------------------------------------------------------              
#   Property Group
# ------------------------------------------------------------------------    
class TomatoesProperties(PropertyGroup):
    
    polycount_pos_x : IntProperty(
        name = "Pos X",
        default = 20,
        min = 0,
        max=2000,
        description = "Margin on the x axis")
        
    polycount_pos_y : IntProperty(
        name = "Pos Y",
        default = 100,
        min = 0,
        max=2000,
        description = "Margin on the y axis")
        
    polycount_font_size : IntProperty(
        name = "Font",
        default = 15,
        min = 10,
        max=150,
        description = "Fontsize")
        
    polycount_font_color : FloatVectorProperty(
        name="Color",
        description="Color for the text",
        default=(1.0, 1.0, 1.0),
        min=0.1,
        max=1,
        subtype='COLOR')
        
    polycount_run : BoolProperty(default=False) 
                
    FontSizeModal : IntProperty(
        name = "Font Size",
        default = 10,
        min = 10,
        max=50,
        description = "Ganti Ukuran Text")
                
    PositionXModal : IntProperty(
        name = "X Offset",
        description = "X Offset of the Viewport GUI")
        
    PositionYModal : IntProperty(
        name = "Y Offset",
        description = "Y Offset of the Viewport GUI")
                    
    Font_Space : IntProperty(
        name = "Font Space",
        default = 1,
        min = -50,
        max=50,
        description = "Font Space on the Viewport GUI")
        
    Font_Space_Y : IntProperty(
        name = "Font Space Y",
        default = 1,
        min = -50,
        max=50,
        description = "Font Space Y Offset on the Viewport GUI")
        
    showhide_flag : BoolProperty(default=False) 
    
    showhide_label = BoolProperty(default = False) 
    
    # the font size.
    important_hotkeys_font_size : IntProperty(
        name="Text Size",
        description="Text size displayed on 3D View",
        default=11, min=8, max=150)
    
    # color variables
    important_hotkeys_text_color : FloatVectorProperty(
        name="Text Color",
        description="Color for the text",
        default=(1.0, 1.0, 1.0, 1.0),
        min=0.1,
        max=1,
        subtype='COLOR',
        size=4)
            
    # ------------------------------------------------------------------------              
    #   Renamer Object
    # ------------------------------------------------------------------------                                      
    del_prefix : BoolProperty(name='del pr_', default = False, description='hapus kata depan')
          
    prefix : StringProperty(
            name="prefix",
            default="",
            description="Kata Depan")  
            
    prefix_input : StringProperty(
            name="prefix_input",
            default="_",
            description="Separator Kata Depan")  
            
    suffix_input : StringProperty(
            name="suffix_input",
            default="_",
            description="Separator Kata Belakang")  
            
    suffix : StringProperty(
            name="suffix",
            default="",
            description="Kata Belakang")
            
    hide_name: BoolProperty(
        name="Hide Name List",
        description="Hide Name List",
        default = True)
        
    regex_search_pattern: StringProperty(
        name="Search String",
        default="")
    
    regex_replacement_string: StringProperty(
        name="Replacement String",
        default="")
                                                                                    
    # ------------------------------------------------------------------------              
    #   Index UI List
    # ------------------------------------------------------------------------            
    selected_world_index : IntProperty(name="Selected World Index", default=0, update = update_world_selection) 
    selected_material_index : IntProperty(name="Selected Material Index", default=0)
    active_modifier_index : IntProperty(name="Selected Modifier Index", default=0)
       
    # ------------------------------------------------------------------------              
    #   UI Set Scene
    # ------------------------------------------------------------------------                         
    UISetScene : EnumProperty(
            name="Choose UI",
            items=(
                ("scene_unit", "Units", "Scene Units UI", 'SCENE_DATA', 1),
                ("matcap", "Matcap", "Matcap UI", 'MATSPHERE', 2),
                ("display", "Object Display", "Object Display UI", 'MESH_CUBE', 3),
                ("uv", "UV Sets", "UV Sets UI", 'UV', 4)),
            default='scene_unit',
            description = "Choose UI")    
            
    UISetViewport: BoolProperty(
        name="Set Viewport",
        description = "Open UI Set Viewport",
        default = True)  
            
    UISetUnits: BoolProperty(
        name="Set Units",
        description = "Open UI Set Units",
        default = True)                       
    # ------------------------------------------------------------------------              
    #   Modifier Stack
    # ------------------------------------------------------------------------            
    auto_cut_mirror : BoolProperty(
            name="Use Mirror",
            description = "AutoCut + Add Mirror",
            default = True)
        
    view_level : IntProperty(
            name="View",
            description="Number of subdivisions for 3D view",
            default=1,
            min=0,
            max=6)
            
    render_level : IntProperty(
            name="Render",
            description="Number of subdivisions for rendering",
            default=2,
            min=0,
            max=6)
            
    object_sel : EnumProperty(
            name="Objects",
            items=(
                ("ALL", "All Objects", "Apply settings to all mesh objects"),
                ("SEL", "Selected Objects", "Apply settings to only selected objects"),
                ("VIS", "Visible Objects", "Apply settings to only visible objects")),
            description = "Apply Subdivison Surface Modifier settings to:")
            
    tp_axis : EnumProperty(
              items = [("positiv",  "Positiv", "", 1),
                       ("negativ",  "Negativ", "", 2)], 
                       name = "Side for Remove",
                       description="side for remove")
                                   
    tp_axis_cut : EnumProperty(
              items = [("x",   "X",   "", 1),
                       ("y",   "Y",   "", 2),
                       ("z",   "Z",   "", 3), 
                       ("xy",  "XY",  "", 4), 
                       ("xz",  "XZ",  "", 5), 
                       ("yz",  "YZ",  "", 6), 
                       ("xyz", "XYZ", "", 7)], 
                       name = "Axis for Remove", 
                       description="axis for remove")  
                                               
    #------------------------------------------------------------------------              
    #   UV Editing
    # ------------------------------------------------------------------------ 
    checker_type : EnumProperty(
        name="Sort Axis",
        items=[
            ("UV_GRID", "Checker Grid", "", "", 0),
            ("COLOR_GRID", "Color Grid", "", "", 1)],
        default='UV_GRID'
        )
            
    assign_image: EnumProperty(
        items=[
            ("enable", "Enable", "", "", 0),
            ("disable", "Disable", "", "", 1)
        ],
        default="enable"
    )

    uv_sync_auto_select: EnumProperty(
        items=[
            ("enable", "Enable", "", "", 0),
            ("disable", "Disable", "", "", 1)
        ],
        default="enable"
    )

    uv_sync_selection_mode: EnumProperty(
        items=[
            ("enable", "Enable", "", "", 0),
            ("disable", "Disable", "", "", 1)
        ],
        default="enable"
    )

    boundary_loop_unwrap: EnumProperty(
        items=[
            ("enable", "Enable", "", "", 0),
            ("disable", "Disable", "", "", 1)
        ],
        default="disable"
    )

    boundary_loop_enable_uv_sync: EnumProperty(
        items=[
            ("enable", "Enable", "", "", 0),
            ("disable", "Disable", "", "", 1)
        ],
        default="disable"
    )

    boundary_loop_enable_live_unwrap: EnumProperty(
        items=[
            ("enable", "Enable", "", "", 0),
            ("disable", "Disable", "", "", 1)
        ],
        default="disable"
    )

    move_uv_type : EnumProperty(
        name="Move",
        description="Move UV Parameter",
        items=[
            ("0.5", "0.5", "", 0),
            ("1", "1", "", 1)],
        default='1'
        )
       
    checker_map_width: IntProperty(name="Width", min=0)
    checker_map_height: IntProperty(name="Height", min=0)
        
    #------------------------------------------------------------------------              
    #   FBX Settings
    # ------------------------------------------------------------------------        
#    fbx_export_mode_menu_items = (('0','1 Obj->1 FBX',''),('1','All->One FBX',''),('2','By Parent',''))
    fbx_export_mode_menu_items = (('0','1 Obj->1 FBX',''),('1','All->One FBX',''))
    fbx_export_mode: EnumProperty(name="", items = fbx_export_mode_menu_items, default='1')
    
    apply_rot: BoolProperty(
        name="Apply Rotation",
        description="Apply Rotation for Exported Models",
        default = True)
        
    apply_scale: BoolProperty(
        name="Apply Scale",
        description="Apply Scale for Exported Models",
        default = True)
        
    apply_loc: BoolProperty(
        name="Apply Location",
        description="Apply Location for Exported Models",
        default = True)
        
    set_custom_fbx_name: BoolProperty(
        name="Set Custom Name for FBX",
        description="Set Custom Name for FBX",
        default = True)
        
    custom_fbx_name: StringProperty(
        name="",
        description="Custom Name for FBX",
        default="")
    
    custom_export_path: BoolProperty(
        name="Custom Export Path",
        description="Custom Export Path",
        default = True)

    export_path: StringProperty(
        name="",
        default = "",
        description = "Path for Export FBX",
        subtype = 'DIR_PATH')
        
    delete_all_materials: BoolProperty(
        name="Delete Materials",
        description="Delete Materials before Export",
        default = False)
                    
    export_dir: StringProperty(
        name="",
        description="Export Directory",
        default="")
    # ------------------------------------------------------------------------              
    #   Hide Boolean
    # ------------------------------------------------------------------------      
    hide_bool_objects: BoolProperty(
        name="Hide Boolean",
        description = "Hide boolean objects",
        update = toggle_bool,
        default = False)
        
    # ------------------------------------------------------------------------              
    #   Camera Projection Lister
    # ------------------------------------------------------------------------   
    ui_expand_cam_settings: BoolProperty(
        name="Camera Settings",
        description="Open/Hide UI Camera Settings",
        default = False)  
    
    ui_expand_cam_bg_settings: BoolProperty(
        name="Camera Background Settings",
        description="Open/Hide UI Camera Background Settings",
        default = False)  
        
    ui_expand_cam_proj_settings: BoolProperty(
        name="Camera Projection Settings",
        description="Open/Hide UI Camera Projection Settings",
        default = False)  
        