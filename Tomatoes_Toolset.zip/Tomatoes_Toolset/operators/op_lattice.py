import bpy
from bpy.types import Operator

class AddLatice(Operator):
    "Add Lattice to selected object"
    bl_idname = "ob.add_latice"
    bl_label = "Add Lattice"

    def execute(self, context):
        obj_list = [obj for obj in bpy.context.selected_objects]
        bbox_obj = bpy.context.active_object

        #ensure origin is centered on bounding box center
        bpy.ops.object.origin_set(type='ORIGIN_GEOMETRY', center='BOUNDS')
        #create a cube for the bounding box
        location = bbox_obj.location
        bpy.ops.object.add(radius=1, type='LATTICE', location=location)
        
        #our new cube is now the active object, so we can keep track of it in a variable:
        lattice_object = bpy.context.active_object
        
        #copy transforms
        lattice_object.dimensions = bbox_obj.dimensions
        lattice_object.rotation_euler = bbox_obj.rotation_euler

        for obj in obj_list:                       
            bpy.context.view_layer.objects.active = obj
            obj.select_set(state=True)
            newMod = obj.modifiers.new(lattice_object.name, 'LATTICE')
            newMod.object = lattice_object
            
        #Make Lattice Active object        
        bpy.ops.object.select_all(action='DESELECT')
        bpy.context.view_layer.objects.active = lattice_object
        lattice_object.select_set(state=True)
        bpy.ops.object.mode_set(mode = 'EDIT')  
        return {'FINISHED'}
