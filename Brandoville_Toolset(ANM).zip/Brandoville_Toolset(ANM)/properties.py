import bpy, os
from bpy.props import *
from bpy.types import PropertyGroup

def get_addon_preferences():
    addon_name = os.path.basename(os.path.dirname(os.path.abspath(__file__).split("utils")[0]))
    user_preferences = bpy.context.preferences
    addon_prefs = user_preferences.addons[addon_name].preferences     
    return addon_prefs

def dpifac():
    prefs = bpy.context.preferences.system
    # python access to this was only added recently, assume non-retina display is used if using older blender
    if hasattr(prefs, "pixel_size"):
        retinafac = bpy.context.preferences.system.pixel_size
    else:
        retinafac = 1
    return bpy.context.preferences.system.dpi / (72 / retinafac)

types_one =  [("red_c0", "Asset/Scene Management", "Asset/Scene Management", "ASSET_MANAGER" ,0),
              ("red_c1", "Rigging Utilities", "ModellingUtilities","COLLAPSEMENU", 1), ]


# class OHA_RenderOpenGL_Settings(bpy.types.PropertyGroup):
#     space_show_only_render              : BoolProperty(default=True)
#     render_use_stamp                    : BoolProperty(default=True)
#     render_use_stamp_camera             : BoolProperty(default=False)
#     render_use_stamp_date               : BoolProperty(default=True)
#     render_use_stamp_filename           : BoolProperty(default=False)
#     render_use_stamp_frame              : BoolProperty(default=True)
#     render_use_stamp_lens               : BoolProperty(default=False)
#     render_use_stamp_marker             : BoolProperty(default=False)
#     render_use_stamp_note               : BoolProperty(default=True)
#     render_use_stamp_render_time        : BoolProperty(default=False)
#     render_use_stamp_scene              : BoolProperty(default=False)
#     render_use_stamp_sequencer_strip    : BoolProperty(default=False)
#     render_use_stamp_time               : BoolProperty(default=False)
#     render_use_simplify                 : BoolProperty(default=False)
#     render_use_antialiasing             : BoolProperty(default=False)

#     render_stamp_note_text              : StringProperty(\
#         name='Stamp',
#         description="Template for stamp note, %(user)s substituted to user name,"\
#             +" %(path)s to blendfile's name",
#         default='%(user)s | %(path)s')
#     render_filepath                     : StringProperty(\
#         name='Folder',
#         description="Folder name to substitute for blendfile's folder.",
#         default='opengl_render')
#     image_file_format                   : StringProperty(default='H264')
#     ffmpeg_format                       : StringProperty(default='QUICKTIME')
#     ffmpeg_codec                        : StringProperty(default='H264')
#     ffmpeg_audio_codec                  : StringProperty(default='MP3')

#     render_stamp_font_size              : IntProperty(default=20)
#     render_resolution_percentage        : IntProperty(default=100)
#     render_resolution_x                 : IntProperty()
#     render_resolution_y                 : IntProperty()
#     ffmpeg_video_bitrate                : IntProperty(default=6000)

#     render_stamp_background             : FloatVectorProperty(subtype='COLOR', size=4,
#                                                               default=(0,0,0,.5))


# class OHA_RenderOpenGL_Props(bpy.types.PropertyGroup):
#     restored : BoolProperty(default=True)

#     temp : PointerProperty(type = OHA_RenderOpenGL_Settings)
#     load : PointerProperty(type = OHA_RenderOpenGL_Settings)

# ------------------------------------------------------------------------              
#   Property Group
# ------------------------------------------------------------------------    
class Dropdown_RedProject_Props(PropertyGroup):
    red_create : EnumProperty(name = "Choose UI", default = "red_c0", items = types_one)
    
    # ------------------------------------------------------------------------              
    #   Asset Saver
    # ------------------------------------------------------------------------   

    asset_type: EnumProperty(
        items=[
            ('CHAR', 'Char', 'Character'),
            ('PROP', 'Props', 'Props'),
            ('SET', 'Sets', 'Sets')
        ],
        default='CHAR'
    )    
    
    asset_jobtype: EnumProperty(
        items=[
            ('Proxy', 'Proxy', 'Proxy'),
            ('Model', 'Model', 'Model'),
            ('Rig', 'Rig', 'Rig')
        ],
        default='Rig'
    )   
    
    save_filename : StringProperty(
            name="Filename",
            default="",
            description="Set Filename")  
    

    # ------------------------------------------------------------------------              
    #  Camera UI
    # ------------------------------------------------------------------------ 

    cam_composition_ui_is_visible : BoolProperty(
        name = "Use Camera Composition",
        description = "Show/hide the Use Camera Composition UI.",
        default = False)
    
    # opengl_props : PointerProperty(
    #     type = OHA_RenderOpenGL_Props,
    #     options = {'HIDDEN', 'SKIP_SAVE'})
    
    # temp : PointerProperty(type = OHA_RenderOpenGL_Settings)
    # load : PointerProperty(type = OHA_RenderOpenGL_Settings)
    
