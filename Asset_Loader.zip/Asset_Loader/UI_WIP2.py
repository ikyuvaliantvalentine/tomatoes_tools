import os
import bpy
from PySide2.QtWidgets import *
from PySide2.QtCore import Qt

class BlendFileSelector(QWidget):
    def __init__(self, base_directory):
        super().__init__()

        self.base_directory = base_directory

        self.initUI()

    def initUI(self):
        self.setWindowTitle("Blend File Selector")
        self.setGeometry(100, 100, 800, 300)

        layout = QVBoxLayout()

        # Add a base directory selection dropdown
        category_layout = QHBoxLayout()

        category_label = QLabel("Category:")
        self.base_directory_combo = QComboBox()
        self.base_directory_combo.currentIndexChanged.connect(self.populate_assets)

        category_layout.addWidget(category_label)
        category_layout.addWidget(self.base_directory_combo)

        category_layout.setSpacing(10)
        category_layout.setAlignment(Qt.AlignLeft)

        self.base_directory_combo.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)

        layout.addLayout(category_layout)

        # Left Column Layout
        left_column_layout = QVBoxLayout()
        
        spacer_item = QSpacerItem(20, 25)

        self.search_input = QLineEdit()
        self.search_input.setPlaceholderText("Search...")
        self.search_input.setFixedHeight(25)

        asset_name_label = QLabel("Asset Name:")
        asset_name_label.setAlignment(Qt.AlignLeft)

        self.asset_list = QListWidget()
        self.asset_list.itemClicked.connect(self.update_blend_files)

        left_column_layout.addItem(spacer_item)
        left_column_layout.addWidget(self.search_input)
        left_column_layout.addWidget(asset_name_label)
        left_column_layout.addWidget(self.asset_list)

        # Right Column Layout
        right_column_layout = QVBoxLayout()

        stage_groupbox = QGroupBox("Stage")
        stage_groupbox.setAlignment(Qt.AlignLeft)

        stage_layout = QHBoxLayout()

        self.wip_radio = QRadioButton("Wip")
        self.published_radio = QRadioButton("Published")
        self.approved_radio = QRadioButton("Approved")

        stage_layout.addWidget(self.wip_radio)
        stage_layout.addWidget(self.published_radio)
        stage_layout.addWidget(self.approved_radio)

        stage_groupbox.setLayout(stage_layout)

        blend_list_label = QLabel("Versions:")
        blend_list_label.setAlignment(Qt.AlignLeft)

        self.blend_list = QListWidget()

        right_column_layout.addWidget(stage_groupbox)
        right_column_layout.addWidget(blend_list_label)
        right_column_layout.addWidget(self.blend_list)

        # Combine Left and Right Columns in Main Layout
        main_layout = QHBoxLayout()
        main_layout.addLayout(left_column_layout)
        main_layout.addLayout(right_column_layout)

        layout.addLayout(category_layout)
        layout.addLayout(main_layout)

        # Add a link/append option checkbox
        option_layout = QHBoxLayout()
        self.link_option = QRadioButton("Link")
        self.append_option = QRadioButton("Append")
        option_layout.addWidget(self.link_option)
        option_layout.addWidget(self.append_option)

        # Add the "Open Blend File" button
        self.open_button = QPushButton("Open Blend File", clicked=self.open_blend_file)
        spacer = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)
        option_layout.addItem(spacer)
        option_layout.addWidget(self.open_button)

        layout.addLayout(option_layout)

        self.setLayout(layout)

        self.populate_base_directories()
        self.populate_assets()


    def populate_base_directories(self):
        base_directories = os.listdir(self.base_directory)
        self.base_directory_combo.addItems(base_directories)

    def populate_assets(self):
        selected_folder = self.base_directory_combo.currentText()
        assets = os.listdir(os.path.join(self.base_directory, selected_folder))
        self.asset_list.clear()
        self.asset_list.addItems(assets)

    def update_blend_files(self):
        self.blend_list.clear()
        selected_asset = self.asset_list.currentItem()
        if selected_asset is not None:
            base_dir = os.path.join(self.base_directory, self.base_directory_combo.currentText())
            asset_path = os.path.join(base_dir, selected_asset.text())
            publish_path = os.path.join(asset_path, "Publish")
            if os.path.exists(publish_path):
                blend_files = [f for f in os.listdir(publish_path) if f.endswith(".blend")]
                self.blend_list.addItems(blend_files)
            else:
                print(f"No 'Publish' folder found in {asset_path}")
    
    def dummy_refresh(self):
        print("Refresh Button Clicked")

    def dummy_load(self):
        print("Load Button Clicked")
    
    def open_blend_file(self):
        selected_blend = self.blend_list.currentItem()
        if selected_blend is not None:
            selected_asset = self.asset_list.currentItem().text()
            base_dir = os.path.join(self.base_directory, self.base_directory_combo.currentText())
            asset_path = os.path.join(base_dir, selected_asset)
            publish_path = os.path.join(asset_path, "Publish", selected_blend.text())

            print(f"Selected Asset: {selected_asset}")
            print(f"Base Directory: {base_dir}")
            print(f"Asset Path: {asset_path}")
            print(f"Publish Path: {publish_path}")

            bpy.ops.wm.open_mainfile(filepath=publish_path)

if __name__ == "__main__":
    app = QApplication.instance()
    if not app:
        app = QApplication([])
    selector = BlendFileSelector(r'E:/02_PIPELINE/NAME_PROJECTS/02_Maya/')
    selector.show()
#    app.exec_()