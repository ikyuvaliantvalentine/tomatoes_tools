import bpy
from bpy.types import Operator

##########################
# Add Weignted Normal
#########################        
class Red_addWeightedNRM(Operator):
    """Add Weighted Normal To Selected Object"""
    bl_label = "Add Weighted Normal"
    bl_idname = "op.weightednormal"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        if not context.selected_objects and not context.active_object:
            self.report({'ERROR'}, "Nothing is selected & there is no Active Object")
            return{'FINISHED'}

        if context.active_object:
            activeCallback = context.view_layer.objects.active
            modeCallback = context.object.mode
            bpy.ops.object.mode_set(mode='OBJECT')

        for ob in context.selected_objects:
            if ob.type == 'MESH':
                context.view_layer.objects.active = ob

                bpy.ops.object.shade_smooth()
                ob.data.use_auto_smooth = True
                ob.data.auto_smooth_angle = 0.523599

                for mod in ob.modifiers:
                    if mod.type == 'WEIGHTED_NORMAL':
                        break
                else:
                    ob.modifiers.new('Weighted Normal', 'WEIGHTED_NORMAL')
                    ob.modifiers["Weighted Normal"].weight = 100
                    ob.modifiers["Weighted Normal"].keep_sharp  = True
                    ob.modifiers["Weighted Normal"].use_face_influence =  False

        if 'activeCallback' in locals():
            context.view_layer.objects.active = activeCallback
            bpy.ops.object.mode_set(mode = modeCallback)

        self.report({'INFO'}, "Automatically Face Weighted selection")
        return{'FINISHED'}

#Apply Weighted Normals Modifier
class Red_apply_wnrm_modifier(Operator):
    bl_idname = "op.apply_weighted_normals_modifier"
    bl_label = "Apply Weighted Normals Modifier"
    bl_description = "Apply Weighted Normals on selected objects"
    bl_options = {"REGISTER","UNDO"}

    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        obj = context.active_object
        obj_list = [obj for obj in context.selected_objects]
        
        bpy.ops.object.mode_set(mode = 'OBJECT')
        bpy.ops.object.select_all(action='DESELECT')
        for obj in obj_list:
            obj.select_set(state=True)
            context.view_layer.objects.active = obj
            
            wnrm = False
            for mod in obj.modifiers:
                if mod.type == "WEIGHTED_NORMAL":
                    wnrm = True
            if wnrm:
                if bpy.app.version >= (2, 90, 0):
                    bpy.ops.object.modifier_apply(modifier=mod.name)
                else:
                    bpy.ops.object.modifier_apply(apply_as='DATA', modifier=mod.name)
        
        del(obj_list[:])    
        self.report({'INFO'}, 'Weighted Normals Modifier was applied')
        return {"FINISHED"}

#Remove Weighted Normals Modifier
class Red_remove_wnrm_modifier(Operator):
    bl_idname = "op.remove_weighted_normals_modifier"
    bl_label = "Remove Weighted Normals Modifier"
    bl_description = "Remove Weighted Normals from selected objects"
    bl_options = {"REGISTER","UNDO"}

    def execute(self, context):
        obj = context.active_object
        obj_list = [obj for obj in context.selected_objects]
        
        bpy.ops.object.mode_set(mode = 'OBJECT')
        bpy.ops.object.select_all(action='DESELECT')
        for obj in obj_list:
            obj.select_set(state=True)
            context.view_layer.objects.active = obj
            
            wnrm = False
            for mod in obj.modifiers:
                if mod.type == "WEIGHTED_NORMAL":
                    wnrm = True
            if wnrm:
                bpy.ops.object.modifier_remove(modifier=mod.name)
            
        del(obj_list[:])    
        self.report({'INFO'}, 'Weighted Normals Modifier was removed')
        return {"FINISHED"}