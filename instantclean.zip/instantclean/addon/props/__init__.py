# This file is part of Instant Clean
# Copyright (C) 2023  Ruben Messerschmidt

from .states_pg import BC_PG_States
from .misc_pg import BC_PG_Misc
from .repair_pg import BC_PG_Repair_Settings
from .limdiss_pg import BC_PG_Limdiss_Settings
from .topology_pg import BC_PG_Topology_Settings
from .normals_pg import BC_PG_Normals_Settings
from .objectdata_pg import BC_PG_Objectdata_Settings


pgs_classes = {
    'bc_states': BC_PG_States,
    'bc_misc': BC_PG_Misc,
    'bc_repair': BC_PG_Repair_Settings,
    'bc_limdiss': BC_PG_Limdiss_Settings,
    'bc_topology': BC_PG_Topology_Settings,
    'bc_normals': BC_PG_Normals_Settings,
    'bc_objectdata': BC_PG_Objectdata_Settings
}

import bpy


def register():
    for pg, cls in pgs_classes.items():
        bpy.utils.register_class(cls)
        setattr(bpy.types.Scene, pg, bpy.props.PointerProperty(type=cls))
        

def unregister():
    for pg, cls in pgs_classes.items():
        delattr(bpy.types.Scene, pg)
        bpy.utils.unregister_class(cls)
