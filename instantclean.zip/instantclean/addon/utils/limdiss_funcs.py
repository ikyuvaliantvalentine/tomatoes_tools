# This file is part of Instant Clean
# Copyright (C) 2023  Ruben Messerschmidt

import bmesh


def limited_dissolve(bm, verts, edges, ang, boundaries, delimiter: set):
    bmesh.ops.dissolve_limit(bm, angle_limit=ang, use_dissolve_boundaries=boundaries, verts=verts, edges=edges, delimit=delimiter)