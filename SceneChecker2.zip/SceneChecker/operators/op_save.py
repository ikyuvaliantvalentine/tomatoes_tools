import bpy, os, re
from bpy.types import Operator
 
class FileIncrementalSave(bpy.types.Operator):
    bl_idname = "file.save_incremental_backup"
    bl_label = "Save Incremental"
   
    def execute(self, context):        
        # Get the current scene file name
        file_name = bpy.data.filepath

        # Check if the file has been saved
        if not file_name:
            raise ValueError("The current scene has not been saved.")

        # Extract the version number from the file name
        match = re.search(r"_v\d\d\d", file_name)
        if not match:
            raise ValueError("The file name does not contain a version number.")

        # Increment the version number
        version = int(match.group()[2:]) + 1
        new_suffix = "_v{:03d}".format(version)

        # Replace the old suffix with the new suffix
        new_file_name = file_name.replace(match.group(), new_suffix)

        # Save the file with the new name
        bpy.ops.wm.save_as_mainfile(filepath=new_file_name, relative_remap=True, compress=True, check_existing=True)

        # Show a dialog box indicating that the file was saved successfully
        self.report({'INFO'}, "Successfully created increment save at " + new_file_name)
        return {'FINISHED'}
    
class WIPSaveBlend(Operator):
    """Saving Blend File For WIP Version"""
    bl_idname = "op.save_wip"
    bl_label = "Initial Save"

    def execute(self, context):               
        scenechk = context.scene.scenechk_props
        my_dir = scenechk.settingsFilePath
        savename = scenechk.save_filename

        wip_folder = f"{my_dir}/{savename}/WIP"
        if not os.path.exists(wip_folder):
            os.makedirs(wip_folder)
            
        # Set the version number to 1
        version = 1
        
        prefix = "ALM_"
        type = "_MOD"
        jobtype = "_WIP"
        
        file_exists = True
        while file_exists:
            # Generate the filename with the current version number
            filename = f"{my_dir}/{savename}/WIP/{prefix}{savename}{type}{jobtype}_v{version:03d}.blend"

            # Check if the file already exists
            if os.path.exists(filename):
                version += 1
            else:
                file_exists = False
                
        bpy.ops.wm.save_as_mainfile(filepath=f"{my_dir}/{savename}/WIP/{prefix}{savename}{type}{jobtype}_v{version:03d}.blend", \
            relative_remap=True, compress=True, check_existing=True)

        self.report({"INFO"}, "File Saved")

        return {'FINISHED'}
    
class PublishSaveBlend(Operator):
    """Saving Blend File For Final Version"""
    bl_idname = "op.save_publish"
    bl_label = "Publish"

    def execute(self, context):    
        if bpy.data.is_saved:
            # Get the current scene name
            scene_name = bpy.path.basename(bpy.data.filepath)
            current_file = bpy.data.filepath

            # Set the default file name to the scene name
            file_name = scene_name

            # Remove any existing version suffix and job type from the file name
            # Split the string by the "_" character
            split_name = file_name.split("_")
            # Extract the second element of the split list
            object_name = split_name[1]

            directory = os.path.dirname(os.path.dirname(current_file))
            # Create the Publish folder if it does not already exist
            publish_folder = os.path.join(directory, "Publish")
            if not os.path.exists(publish_folder):
                os.makedirs(publish_folder)

            # Set the version number to 1
            version = 1

            prefix = "ALM_"
            type = "_MOD"
            jobtype = "_Publish"

            # Check if the file already exists
            while os.path.exists(os.path.join(publish_folder, f"{prefix}{object_name}{type}{jobtype}_v{version:03d}.blend")):
                # If the file exists, increment the version number and check again
                version += 1

            # Save the file with the incrementing version number in the Publish folder
            publish_file_path = os.path.join(publish_folder, f"{prefix}{object_name}{type}{jobtype}_v{version:03d}.blend")
            bpy.ops.wm.save_as_mainfile(filepath=publish_file_path, relative_remap=True, compress=True, check_existing=True)



            #################################################################
            #   AUTOMATIC EXPORT FBX
            #################################################################
            # Get the current blend file name
            blend_file_name = bpy.path.basename(bpy.context.blend_data.filepath)

            # Remove the file extension from the blend file name
            blend_file_name = os.path.splitext(blend_file_name)[0]

            # Set the base output directory
            base_output_dir = "E:/02_PIPELINE/NAME_PROJECTS/03_FinalAssets"

            # Create the base output directory if it doesn't exist
            if not os.path.exists(base_output_dir):
                os.makedirs(base_output_dir)

            # Remove "_LIT" and the existing version number from the base name
            base_name = re.sub(r'_MOD_Publish_v\d+', '', blend_file_name)

            # Find the latest version number
            latest_version = 0
            sub_dir = os.path.join(base_output_dir, base_name)
            if os.path.exists(sub_dir):
                for folder_name in os.listdir(sub_dir):
                    match = re.search(rf"v(\d+)", folder_name)
                    if match:
                        version = int(match.group(1))
                        latest_version = max(latest_version, version)

            # Increment the latest version number
            new_version = latest_version + 1

            # Format the new version number with leading zeros
            version_string = f"v{str(new_version).zfill(3)}"

            # Create the versioned output directory
            output_dir = os.path.join(sub_dir, version_string)

            # Create the output directory if it doesn't exist
            if not os.path.exists(output_dir):
                os.makedirs(output_dir)

            # Get all mesh objects in the scene
            mesh_objects = [obj for obj in bpy.context.scene.objects if obj.type == 'MESH']

            # Export each mesh object as a separate FBX file
            for obj in mesh_objects:
                # Select the current object
                bpy.context.view_layer.objects.active = obj
                obj.select_set(True)

                # Set the output file path
                output_file = os.path.join(output_dir, obj.name + ".fbx")

                # Export the selected object as FBX
                bpy.ops.export_scene.fbx(
                    filepath=output_file,
                    use_selection=True,
                    object_types={'MESH'},
                    bake_space_transform=True
                )

                # Deselect the object
                obj.select_set(False)

        
            # Show a dialog box indicating that the file was saved successfully
            self.report({'INFO'}, "The file was published successfully")
        else:
            self.report({'ERROR'}, "Anak Goblok Kerja Belum Kelar Udah Publish Aja!!!!")
        return {'FINISHED'}
    