import bpy
from bpy.types import Panel
from .. ui.ui_assetmanagement import *
from .. properties import *

class VIEW3D_PT_RIG_Brandoville_Project(Panel):
    bl_label = "(RIG) Brandoville Tools"
    bl_idname = "VIEW3D_PT_RIG_Brandoville_Project"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Brandoville"

    def draw(self, context):
        layout = self.layout    
        draw_assetmanagement_ui(self, context, layout)


