# This file is part of Instant Clean
# Copyright (C) 2023  Ruben Messerschmidt

import bpy
bc_states = bpy.context.scene.bc_states
bc_repair = bpy.context.scene.bc_repair
bc_limdiss = bpy.context.scene.bc_limdiss
bc_topology = bpy.context.scene.bc_topology
bc_normals = bpy.context.scene.bc_normals
bc_objectdata = bpy.context.scene.bc_objectdata

bc_states.repair = True
bc_repair.loose = True
bc_repair.loose_verts = True
bc_repair.loose_edges = True
bc_repair.loose_faces = True
bc_repair.doubles = True
bc_repair.doubles_dst = 9.999999747378752e-05
bc_repair.zero_faces = True
bc_repair.zero_faces_area = 9.999999747378752e-05
bc_repair.dispensables = True
bc_repair.dispensables_ang = 0.08749999850988388
bc_repair.interiors = True
bc_states.limdiss = False
bc_limdiss.max_angle = 0.08749999850988388
bc_limdiss.boundaries = False
bc_limdiss.protect_sharp = True
bc_limdiss.protect_seam = True
bc_limdiss.protect_uv = True
bc_limdiss.protect_materials = True
bc_states.topology = False
bc_topology.type = 'TRIS'
bc_topology.quad_method = 'BEAUTY'
bc_topology.ngon_method = 'BEAUTY'
bc_topology.compare_sharp = True
bc_topology.compare_seam = True
bc_topology.compare_vcol = True
bc_topology.compare_uv = True
bc_topology.compare_material = True
bc_states.normals = True
bc_normals.recalculate = True
bc_normals.recalculate_orientation = 'OUTSIDE'
bc_normals.auto_smooth = False
bc_normals.auto_smooth_ang = 0.785398006439209
bc_normals.weighted_normals = False
bc_normals.clear_custom_split_normals = False
bc_normals.clear_sharp_edges = False
bc_states.objectdata = True
bc_objectdata.unused_material_slots = True
bc_objectdata.empty_vertex_groups = True
