import bpy
from bpy.types import Operator

bl_info = {
    "name": "Jin Kepepet Presets",
    "description": "Tools Cepat Setup Composiotr",
    "author": "Valiant Valentine",
    "version": (0, 0, 1),
    "blender": (2, 80, 0),
    "location": "3D View > Properties > Jin Kepepet",
    "warning": "",
    "category": "NodeEditor"}
    
class ComposBG(Operator):
    "Simple Setup Background Compositor"
    bl_idname = "op.nodebg"
    bl_label = "Background Preset"

    def execute(self, context):
        bpy.context.scene.render.use_simplify = True
        bpy.context.scene.render.simplify_subdivision = 0
        bpy.context.scene.render.simplify_subdivision_render = 6
        
        try:
            file = bpy.path.basename(bpy.data.filepath).split('_')
            sc_no = file[0]
            sh_no = file[1]
            sh_ext = file[2]
        except:
            file =''
            sc_no = 'SC_'
            sh_no = 'SH_'
            sh_ext = 'SH_ext'

        if sh_ext.startswith('SH'):
            scsh = '%s_%s_%s' % (sc_no, sh_no, sh_ext)
        else:
            scsh = '%s_%s' % (sc_no, sh_no)

        try:
            base_path = tree.nodes["File Output"].base_path
        except:
            base_path = "X:\Jin_Kepepet/"
                
        # switch on nodes and get reference
        bpy.context.scene.render.image_settings.file_format = 'PNG'
        bpy.context.scene.render.image_settings.color_mode = 'RGBA'
        bpy.context.scene.eevee.use_gtao = True
        bpy.context.scene.view_layers["View Layer"].use_pass_ambient_occlusion = True
        bpy.context.scene.use_nodes = True
        tree = bpy.context.scene.node_tree
        links = tree.links

        prev = bpy.context.area.type
        bpy.context.area.type = 'NODE_EDITOR'

        area = bpy.context.area      

        # clear default nodes
        for n in tree.nodes:
            tree.nodes.remove(n)

        # create input
        rl = tree.nodes.new('CompositorNodeRLayers')
        rl.location = 0,200
            
        map = tree.nodes.new('CompositorNodeMapValue')
        map.name = 'Map Value'
        map.location = 500,200
        tree.nodes["Map Value"].offset[0] = -2.5
        tree.nodes["Map Value"].size[0] = 0.025
        links.new(rl.outputs[2],map.inputs[0])

        set = tree.nodes.new('CompositorNodeSetAlpha')
        set.name = 'SetAlpha'
        set.location = 500,-100
        links.new(rl.outputs['AO'],set.inputs[0])
        links.new(rl.outputs[1], set.inputs[1])

        fout = tree.nodes.new('CompositorNodeOutputFile')
        fout.name = 'File Output'
        fout.width = 300
        fout.location = 800,100
        fout.format.color_mode = 'RGBA'
        fout.format.compression = 100
        fout.base_path = base_path

        fout.outputs.data.file_slots['Image'].path = 'BG\%s_BG_ ' % scsh
        fout.outputs.data.file_slots.new('BG_AO\%s_BG_AO_' % scsh)
        bg_z = fout.outputs.data.file_slots.new('BG_Z\%s_BG_Z_' % scsh)
        fout.outputs.data.file_slots[bg_z.name].use_node_format = False
        fout.outputs.data.file_slots[bg_z.name].format.color_mode = 'RGB'

        links.new(rl.outputs[0],fout.inputs[0])
        links.new(set.outputs[0],fout.inputs[1])
        links.new(map.outputs[0],fout.inputs[2])
                
        bpy.context.area.type = prev
        return {'FINISHED'}

class ComposCHAR(Operator):
    "Simple Setup Character Compositor"
    bl_idname = "op.nodechar"
    bl_label = "Character Preset"

    def execute(self, context):
        bpy.context.scene.render.use_simplify = True
        bpy.context.scene.render.simplify_subdivision = 0
        bpy.context.scene.render.simplify_subdivision_render = 6
        
        try:
            file = bpy.path.basename(bpy.data.filepath).split('_')
            sc_no = file[0]
            sh_no = file[1]
            sh_ext = file[2]
        except:
            file =''
            sc_no = 'SC_'
            sh_no = 'SH_'
            sh_ext = 'SH_ext'

        if sh_ext.startswith('SH'):
            scsh = '%s_%s_%s' % (sc_no, sh_no, sh_ext)
        else:
            scsh = '%s_%s' % (sc_no, sh_no)

        try:
            base_path = tree.nodes["File Output"].base_path
        except:
            base_path = "X:\Jin_Kepepet/"
                
        # switch on nodes and get reference
        bpy.context.scene.render.image_settings.file_format = 'PNG'
        bpy.context.scene.render.image_settings.color_mode = 'RGBA'
        bpy.context.scene.eevee.use_gtao = True
        bpy.context.scene.view_layers["View Layer"].use_pass_ambient_occlusion = True
        bpy.context.scene.use_nodes = True
        tree = bpy.context.scene.node_tree
        links = tree.links

        prev = bpy.context.area.type
        bpy.context.area.type = 'NODE_EDITOR'

        area = bpy.context.area      

        # clear default nodes
        for n in tree.nodes:
            tree.nodes.remove(n)

        # create input
        rl = tree.nodes.new('CompositorNodeRLayers')
        rl.location = 0,200
    
        set = tree.nodes.new('CompositorNodeSetAlpha')
        set.name = 'SetAlpha'
        set.location = 500,-100
        links.new(rl.outputs['AO'],set.inputs[0])
        links.new(rl.outputs[1], set.inputs[1])

        fout = tree.nodes.new('CompositorNodeOutputFile')
        fout.name = 'File Output'
        fout.width = 300
        fout.location = 800,100
        fout.format.color_mode = 'RGBA'
        fout.format.compression = 100
        fout.base_path = base_path

        fout.outputs.data.file_slots['Image'].path = 'CHAR\%s_CH_' %scsh
        fout.outputs.data.file_slots.new('CHAR_AO\%s_CHAR_AO_' % scsh)
        links.new(rl.outputs[0],fout.inputs[0])
        links.new(set.outputs[0],fout.inputs[1])
   
        bpy.context.area.type = prev
        return {'FINISHED'}

class ShdCHAR(Operator):
    "Simple Setup For Render Only Shadow"
    bl_idname = "op.nodeshdchar"
    bl_label = "Shadow Preset"

    def execute(self, context):
        bpy.context.scene.render.use_simplify = True
        bpy.context.scene.render.simplify_subdivision = 0
        bpy.context.scene.render.simplify_subdivision_render = 6
        
        try:
            file = bpy.path.basename(bpy.data.filepath).split('_')
            sc_no = file[0]
            sh_no = file[1]
            sh_ext = file[2]
        except:
            file =''
            sc_no = 'SC_'
            sh_no = 'SH_'
            sh_ext = 'SH_ext'

        if sh_ext.startswith('SH'):
            scsh = '%s_%s_%s' % (sc_no, sh_no, sh_ext)
        else:
            scsh = '%s_%s' % (sc_no, sh_no)

        try:
            base_path = tree.nodes["File Output"].base_path
        except:
            base_path = "X:\Jin_Kepepet/"
                
        # switch on nodes and get reference
        bpy.context.scene.render.image_settings.file_format = 'PNG'
        bpy.context.scene.render.image_settings.color_mode = 'RGBA'
        bpy.context.scene.eevee.use_gtao = True
        bpy.context.scene.view_layers["View Layer"].use_pass_ambient_occlusion = True
        bpy.context.scene.use_nodes = True
        tree = bpy.context.scene.node_tree
        links = tree.links

        prev = bpy.context.area.type
        bpy.context.area.type = 'NODE_EDITOR'

        area = bpy.context.area      

        # clear default nodes
        for n in tree.nodes:
            tree.nodes.remove(n)

        # create input
        rl = tree.nodes.new('CompositorNodeRLayers')
        rl.location = 0,200
    
        fout = tree.nodes.new('CompositorNodeOutputFile')
        fout.name = 'File Output'
        fout.width = 300
        fout.location = 800,100
        fout.format.color_mode = 'RGBA'
        fout.format.compression = 100
        fout.base_path = base_path

        fout.outputs.data.file_slots['Image'].path = 'CHAR_SHD\%s_CH_SHD_' %scsh
        links.new(rl.outputs[0],fout.inputs[0])
   
        bpy.context.area.type = prev
        return {'FINISHED'}
           
class JinKepepetPanel(bpy.types.Panel):
    bl_label = "Jin Kepepet Presets"
    bl_idname = "JK_PT_tools"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Jin Kepepet"

    def draw(self, context):
        layout = self.layout
        layout.operator("op.nodebg")
        layout.operator("op.nodechar")
        layout.operator("op.nodeshdchar")


def register():
    bpy.utils.register_class(JinKepepetPanel)
    bpy.utils.register_class(ComposBG)
    bpy.utils.register_class(ComposCHAR)
    bpy.utils.register_class(ShdCHAR)
    
def unregister():
    bpy.utils.unregister_class(JinKepepetPanel)
    bpy.utils.unregister_class(ComposBG)
    bpy.utils.unregister_class(ComposCHAR)
    bpy.utils.unregister_class(ShdCHAR)


if __name__ == "__main__":
    register()
