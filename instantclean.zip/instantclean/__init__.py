# This file is part of Instant Clean
# Copyright (C) 2023  Ruben Messerschmidt

bl_info = {
    "name": "Instant Clean",
    "description": "Clean Mesh in one Click",
    "blender": (2, 93, 0),
    'version': (1, 2, 0),
    "category": "Mesh",
    "author": "Ruben Messerschmidt",
    "location": "View3D > Sidebar > Instant Clean",
    'doc_url': 'https://instant-clean.readthedocs.io/en/latest/',
}

import bpy
import addon_utils
import sys
import os
import shutil
import importlib
import pkgutil
from pathlib import Path
from bpy.types import AddonPreferences, Operator


##### Load Modules #####


def get_all_submodules(directory):
    return list(iter_submodules(directory, directory.name))


def iter_submodules(path, package_name):
    for name in sorted(iter_submodule_names(path)):
        mod = importlib.import_module("." + name, package_name)
        yield mod


def iter_submodule_names(path, root=""):
    for _, module_name, is_package in pkgutil.iter_modules([str(path)]):
        if is_package:
            if module_name == 'standard_presets':
                continue
            sub_path = path / module_name
            sub_root = root + module_name + "."
            yield from iter_submodule_names(sub_path, sub_root)
        else:
            yield root + module_name


def reload_modules():
    for name in reload_list:
        importlib.reload(sys.modules[name])


def get_loaded_modules():
    prefix = __name__ + "."
    return [name for name in sys.modules if name.startswith(prefix)]


if "reload_list" in locals():
    reload_modules()
else:
    modules = get_all_submodules(Path(__file__).parent)
    reload_list = get_loaded_modules()

    from .addon import *


##### Addon Prefs #####


class BC_Addon_Preferences(AddonPreferences):
    bl_idname=__package__

    def draw(self, context):
        layout = self.layout
        layout.operator('bc.reinstall_presets')


##### Registration #####


def register():
    if bpy.app.version < (2, 93, 0):
        print('Instant Clean is not compatible with your current Blender version!')
        print('Upgrade to Blender 2.93.0 or later.')
        return

    bpy.utils.register_class(BC_Addon_Preferences)
    addon.register()

    filepath: str
    for mod in addon_utils.modules():
        if mod.bl_info['name'] == "Instant Clean":
            filepath = mod.__file__


    presets_path = os.path.join(bpy.utils.user_resource('SCRIPTS', path='presets', create=True), 'Instant Clean')
    if not os.path.isdir(presets_path):
        standard_presets = filepath.replace('__init__.py', 'standard_presets')
        files = os.listdir(standard_presets)

        os.makedirs(presets_path)
        [shutil.copy2(os.path.join(standard_presets, f), presets_path) for f in files]


def unregister():
    bpy.utils.unregister_class(BC_Addon_Preferences)
    addon.unregister()


if __name__ == "__main__":
    register()