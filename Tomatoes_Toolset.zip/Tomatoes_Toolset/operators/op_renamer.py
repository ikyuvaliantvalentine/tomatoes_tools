import bpy, re
from bpy.props import *
from bpy.types import Operator

#-------------------------------------------------------        
#Check String is a Number
def StrIsInt(s):
    try: 
        int(s)
        return True
    except ValueError:
        return False
    
#Numbering
class Numbering(Operator):
    """Numbering of Objects"""
    bl_idname = "object.remove_replace_numbering"
    bl_label = "Numbering of Objects"

    def execute(self, context):        
        selected_obj = bpy.context.selected_objects 
        objects_list = []

        for x in selected_obj:
            #List of Objects
            object_class = [x.name, x.location.x]
            
            objects_list.append(object_class)
        
        #Preprocess Delete Blender Numbers and add new numbers
        for y in range(len(objects_list)):
            current_obj = bpy.data.objects[objects_list[y][0]]
            
            #Delete Blender Numbers
            ob_name = current_obj.name
            if StrIsInt(ob_name[-3:]):
                dot_pos = len(ob_name) - 4
                if ob_name[dot_pos] == '.':
                    ob_name = ob_name[:-4]
                        
            #Delete Previous Numbers
            if StrIsInt(ob_name[-1:]):
                unds_pos = len(ob_name) - 2
                if ob_name[unds_pos] == '_':
                    ob_name = ob_name[:-2]
                    
            if StrIsInt(ob_name[-2:]):
                unds_pos = len(ob_name) - 3
                if ob_name[unds_pos] == '_':
                    ob_name = ob_name[:-3]
                    
            if StrIsInt(ob_name[-3:]):
                unds_pos = len(ob_name) - 4
                if ob_name[unds_pos] == '_':
                    ob_name = ob_name[:-4]
                        
            #Format for Numbers
            num_str = ''
            if (y <= 8):
                num_str = '00' + str(y+1)
            elif (y >= 9) and (y <= 98):
                num_str = '0' + str(y+1)
            else:
                num_str = str(y+1)
            bpy.data.objects[objects_list[y][0]].name = ob_name + '_' + num_str;
        return {'FINISHED'}

class Replacedot(Operator):
    bl_idname = "rename.replace_dot"
    bl_label = "Replace Dot"
    def execute(self, context):
        for obj in bpy.context.selected_objects:
            if "." in obj.name[-5:]:
                obj.name = obj.name.replace(".", "_")
        return {'FINISHED'}


class AddSuffixName(Operator):
    bl_idname = "object.addsuffix"
    bl_label = "Add Suffix"

    type_suffix: EnumProperty(
        items=(('low', "low", ""),
               ('high', "high", ""),
               ('geo', "geo", "")),
        default='low'
    )

    def execute(self, context):
        if self.type_suffix == 'low':
            for obj in bpy.context.selected_objects:
                newName = (obj.name + "_low")
                obj.name = newName

        if self.type_suffix == 'high':
            for obj in bpy.context.selected_objects:
                newName = (obj.name + "_high")
                obj.name = newName

        if self.type_suffix == 'geo':
            for obj in bpy.context.selected_objects:
                newName = (obj.name + "_geo")
                obj.name = newName

        return {'FINISHED'}

######################
#  VIEW SELECTED 
######################    
class selectRenameOB(Operator):
    bl_idname = "object.renamer_select"
    bl_label = "select"
    bl_options = {'REGISTER','UNDO'}
    ob : StringProperty()
    type : StringProperty()
    
    def execute(self, context):
        try:
            if self.type=='obj':                    
                bpy.ops.object.select_all(action='DESELECT')
                bpy.data.objects[self.ob].select_set(True)
                bpy.ops.view3d.view_selected(use_all_regions=1)
        except:
            self.report({'ERROR'}, 'ngga ada di viewport')            
        return {'FINISHED'}

######################################
#  Make Selected Object Name Lowecase
######################################    
class selectobnametolower(Operator):
    "Make All Selected Object Name To Lowercase"
    bl_idname = "object.set_to_lowercase"
    bl_label = "Set Object Name TO LoweCase"
    bl_options = {'REGISTER','UNDO'}
    
    def execute(self, context):
        for obj in bpy.context.selected_objects:
            newname = obj.name.lower()
            obj.name = newname
            obj.data.name = newname     
        return {'FINISHED'}

