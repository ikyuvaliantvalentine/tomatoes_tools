import os
import re
import bpy
from PySide6.QtWidgets import *
from PySide6.QtCore import Qt, QSettings
from PySide6.QtGui  import QIcon
from PySide6 import QtWidgets, QtCore, QtGui
from os.path import join, dirname, normpath

class AssetLoader(QWidget):
    @staticmethod
    def show_message_box(message):
        msg = QtWidgets.QMessageBox()
        msg.setWindowFlags(QtCore.Qt.WindowStaysOnTopHint)
        msg.setWindowTitle("Info Popup")
        msg.setIcon(QtWidgets.QMessageBox.Warning)
        msg.setText(message)
        msg.setStandardButtons(QtWidgets.QMessageBox.Ok)
        msg.setStyleSheet("background-color: #5d5d5d; color: white;")
        msg.exec_()

    @staticmethod
    def show_info_message_box(message):
        msg = QtWidgets.QMessageBox()
        msg.setWindowFlags(QtCore.Qt.WindowStaysOnTopHint)
        msg.setWindowTitle("Info Popup")
        msg.setIcon(QtWidgets.QMessageBox.Information)
        msg.setText(message)
        msg.setStandardButtons(QtWidgets.QMessageBox.Ok)
        msg.setStyleSheet("background-color: #5d5d5d; color: white;")
        msg.exec_()

    def __init__(self, base_directory):
        super().__init__()

        self.base_directory = base_directory

        # Initialize QSettings
        self.settings = QSettings("YourCompanyName", "AssetLoader")

        self.initUI()
        self.restore_settings()
        
    def initUI(self):

        # Set the background color
        self.setStyleSheet("background-color: #494949;")

        self.setWindowTitle("Asset Loader v01")
        self.setGeometry(100, 100, 800, 300)
        self.setWindowFlags(self.windowFlags() | Qt.WindowStaysOnTopHint)

        layout = QVBoxLayout()

        # Add a base directory selection dropdown
        category_layout = QHBoxLayout()

        category_label = QLabel("Category:")
        category_label.setStyleSheet("color: white;")

        self.base_directory_combo = QComboBox()
        self.base_directory_combo.setStyleSheet("color: white;")
        self.base_directory_combo.currentIndexChanged.connect(self.populate_assets)

        category_layout.addWidget(category_label)
        category_layout.addWidget(self.base_directory_combo)

        category_layout.setSpacing(10)
        category_layout.setAlignment(Qt.AlignLeft)

        self.base_directory_combo.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)

        layout.addLayout(category_layout)

        # Add the new Alphabet dropdown
        alphabet_layout = QHBoxLayout()

        alphabet_label = QLabel("Alphabet:")
        alphabet_label.setStyleSheet("color: white;")

        self.alphabet_combo = QComboBox()
        self.alphabet_combo.setStyleSheet("color: white;")
        self.alphabet_combo.currentIndexChanged.connect(self.filter_assets_by_alphabet)

        alphabet_layout.addWidget(alphabet_label)
        alphabet_layout.addWidget(self.alphabet_combo)

        alphabet_layout.setSpacing(10)
        alphabet_layout.setAlignment(Qt.AlignLeft)

        self.alphabet_combo.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)

        layout.addLayout(alphabet_layout)

        # Left Column Layout
        left_column_layout = QVBoxLayout()
        
        spacer_item = QSpacerItem(20, 25)

        self.search_input = QLineEdit()
        self.search_input.setPlaceholderText("Search Asset Name...")
        self.search_input.setStyleSheet("color: white;")
        self.search_input.textChanged.connect(self.search_assets)
        self.search_input.setFixedHeight(25)

        # Connect both signals to populate assets and update search filter
        self.base_directory_combo.currentIndexChanged.connect(self.populate_assets)
        self.base_directory_combo.currentIndexChanged.connect(self.search_assets)

        asset_name_label = QLabel("Asset Name:")
        asset_name_label.setStyleSheet("color: white;")
        asset_name_label.setAlignment(Qt.AlignLeft)

        self.asset_list = QListWidget()

        self.asset_list.setStyleSheet('''
            QWidget {
                background-color: #2b2b2b;
                color: white;
            }
            QListWidget::item:selected {
                background: rgb(128,128,255);
            }
        ''')

        # Asset List List Need Update for Subfolder List
        self.asset_list.itemClicked.connect(self.populate_subfolders)

        left_column_layout.addItem(spacer_item)
        left_column_layout.addWidget(self.search_input)
        left_column_layout.addWidget(asset_name_label)
        left_column_layout.addWidget(self.asset_list)
        
        
        # Add a list widget for listing subfolders
        subfolder_list_label = QLabel("Subfolders:")
        subfolder_list_label.setStyleSheet("color: white;")
        subfolder_list_label.setAlignment(Qt.AlignLeft)

        self.subfolder_list = QListWidget()

        self.subfolder_list.setStyleSheet('''
            QWidget {
                background-color: #2b2b2b;
                color: white;
            }
            QListWidget::item:selected {
                background: rgb(128,128,255);
            }
        ''')

        left_column_layout.addWidget(subfolder_list_label)
        left_column_layout.addWidget(self.subfolder_list)
        
        # Subfolder List Need Update the Blend_List
        self.subfolder_list.itemClicked.connect(self.update_blend_files)
    

        # Right Column Layout
        right_column_layout = QVBoxLayout()

        stage_groupbox = QGroupBox("Stage")
        stage_groupbox.setStyleSheet("color: white;")
        stage_groupbox.setAlignment(Qt.AlignLeft)

        stage_layout = QHBoxLayout()

        self.wip_radio = QRadioButton("Wip")
        self.wip_radio.setStyleSheet("color: white;")
        self.published_radio = QRadioButton("Published")
        self.published_radio.setStyleSheet("color: white;")

        self.wip_radio.toggled.connect(self.update_blend_files)
        self.published_radio.toggled.connect(self.update_blend_files)

        stage_layout.addWidget(self.wip_radio)
        stage_layout.addWidget(self.published_radio)

        stage_groupbox.setLayout(stage_layout)

        blend_list_label = QLabel("Versions:")
        blend_list_label.setStyleSheet("color: white;")
        blend_list_label.setAlignment(Qt.AlignLeft)

        self.blend_list = QListWidget()
        
        self.blend_list.setStyleSheet('''
            QWidget {
                background-color: #2b2b2b;
                color: white;
            }
            QListWidget::item:selected {
                background: rgb(128,128,255);
            }
        ''')

        right_column_layout.addWidget(stage_groupbox)
        right_column_layout.addWidget(blend_list_label)
        right_column_layout.addWidget(self.blend_list)

        # Combine Left and Right Columns in Main Layout
        main_layout = QHBoxLayout()
        main_layout.addLayout(left_column_layout)
        main_layout.addLayout(right_column_layout)

        layout.addLayout(main_layout)

        # Add a link/append option checkbox
        option_layout = QHBoxLayout()

        self.button_group = QButtonGroup()  # Create a button group

        self.open_option = QRadioButton("Open")
        self.link_option = QRadioButton("Link")
        self.append_option = QRadioButton("Append")

        self.open_option.setStyleSheet("color: white;")
        self.link_option.setStyleSheet("color: white;")
        self.append_option.setStyleSheet("color: white;")

        self.button_group.addButton(self.open_option)  # Add buttons to the group
        self.button_group.addButton(self.link_option)
        self.button_group.addButton(self.append_option)

        self.open_option.setChecked(True)  # Set the default option to "Open"

        option_layout.addWidget(self.open_option)
        option_layout.addWidget(self.link_option)
        option_layout.addWidget(self.append_option)

        # Add the "Open Blend File" button
        self.refresh_assets_button = QPushButton("Refresh", clicked=self.refresh_assets)
        self.open_button = QPushButton("Open Blend File", clicked=self.open_blend_file)
        self.link_button = QPushButton("Link Blend File", clicked=self.link_blend_collection)
        self.append_button = QPushButton("Append Blend", clicked=self.append_blend_collection)

        self.refresh_assets_button.setStyleSheet("background-color: #5d5d5d; color: white;")
        self.open_button.setStyleSheet("background-color: #5d5d5d; color: white;")
        self.link_button.setStyleSheet("background-color: #5d5d5d; color: white;")
        self.append_button.setStyleSheet("background-color: #5d5d5d; color: white;")

        self.open_button.setVisible(True)  # Initially hide the buttons
        self.link_button.setVisible(False)
        self.append_button.setVisible(False)

        # Set the fixed size for the button (adjust the values as needed)
        self.refresh_assets_button.setFixedSize(70, 30)
        self.open_button.setFixedSize(150, 30)
        self.link_button.setFixedSize(150, 30)
        self.append_button.setFixedSize(150, 30)

        # Set the icon for the "Refresh" button
        icons_folder = join(dirname(__file__), "custom_icons")
        icon_path = join(icons_folder, "refresh.png")
        icon_path = icon_path.replace("\\", "/")
        icon_path = icon_path.replace("/ui/", "/") # Modify the path to change "ui/custom_icons" to "custom_icons"
        self.refresh_assets_button.setIcon(QIcon(icon_path))

        # Add a vertical separator
        separator = QFrame()
        separator.setFrameShape(QFrame.VLine)
        separator.setFrameShadow(QFrame.Sunken)

        spacer = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)
        option_layout.addItem(spacer)
        option_layout.addWidget(self.refresh_assets_button)

        option_layout.addWidget(separator)

        option_layout.addWidget(self.open_button)
        option_layout.addWidget(self.link_button)
        option_layout.addWidget(self.append_button)

        layout.addLayout(option_layout)

        self.setLayout(layout)

        # Connect radio button toggled signals to functions
        self.open_option.toggled.connect(self.update_buttons_visibility)
        self.link_option.toggled.connect(self.update_buttons_visibility)
        self.append_option.toggled.connect(self.update_buttons_visibility)

        self.populate_base_directories()
        self.populate_assets()
        
    def update_buttons_visibility(self):
        self.open_button.setVisible(self.open_option.isChecked())
        self.link_button.setVisible(self.link_option.isChecked())
        self.append_button.setVisible(self.append_option.isChecked())

    def populate_base_directories(self):
        base_directories = os.listdir(self.base_directory)
        self.base_directory_combo.addItems(base_directories)

    def populate_alphabet_combo(self):
        # Get the selected category folder from the combo
        selected_folder = self.base_directory_combo.currentText()

        # Get the full path to the selected folder
        asset_path = os.path.join(self.base_directory, selected_folder)

        # Get all subfolders
        subfolders = [f for f in os.listdir(asset_path) if os.path.isdir(os.path.join(asset_path, f))]

        # Create a set of letters to avoid duplicates
        alphabet_set = set()

        # Loop through each subfolder and get the first letter
        for subfolder in subfolders:
            if subfolder:  # Ignore empty folder names
                first_letter = subfolder[0].upper()  # Take the first letter, uppercase
                alphabet_set.add(first_letter)

        # Sort the letters and update the alphabet combo box
        alphabet_list = sorted(list(alphabet_set))
        self.alphabet_combo.clear()  # Clear any existing items
        self.alphabet_combo.addItems(alphabet_list)  # Add the letters to the combo box

    def filter_assets_by_alphabet(self):
        selected_letter = self.alphabet_combo.currentText()
        base_dir = os.path.join(self.base_directory, self.base_directory_combo.currentText())

        # Get the subfolders in the base directory that start with the selected letter
        filtered_assets = []
        for subfolder in os.listdir(base_dir):
            subfolder_path = os.path.join(base_dir, subfolder)
            
            # If it's a directory, check its contents
            if os.path.isdir(subfolder_path):
                for asset in os.listdir(subfolder_path):
                    asset_path = os.path.join(subfolder_path, asset)
                    
                    # If the asset starts with the selected letter and is a directory, add it to the list
                    if os.path.isdir(asset_path) and asset.lower().startswith(selected_letter.lower()):
                        filtered_assets.append(asset)

        # # If no assets are found starting with the selected letter
        # if not filtered_assets:
        #     print(f"No assets found starting with {selected_letter} in {base_dir}")

        # Clear and add filtered assets to the asset list
        self.asset_list.clear()
        self.asset_list.addItems(filtered_assets)

    def populate_assets(self):
        selected_folder = self.base_directory_combo.currentText()
        assets = os.listdir(os.path.join(self.base_directory, selected_folder))
        self.asset_list.clear()
        self.asset_list.addItems(assets)
        
        # Populate subfolders
        self.populate_subfolders()

        # Automatically filter alphabet options based on subfolder names
        self.populate_alphabet_combo()
        
        # Update blend files
        self.update_blend_files()
        
    def populate_subfolders(self):
        selected_asset = self.asset_list.currentItem()
        self.subfolder_list.clear()

        if selected_asset is not None:
            # Retrieve the additional path from the alphabet combo
            alphabet_path = self.alphabet_combo.currentText()

            base_dir = os.path.join(self.base_directory, self.base_directory_combo.currentText(), alphabet_path)
            asset_path = os.path.join(base_dir, selected_asset.text())

            subfolders = [f for f in os.listdir(asset_path) if os.path.isdir(os.path.join(asset_path, f))]
            self.subfolder_list.addItems(subfolders)
        
        # Update blend files
        self.update_blend_files()
    
    def update_blend_files(self):
        self.blend_list.clear()
        selected_asset = self.asset_list.currentItem()
        selected_subfolder = self.subfolder_list.currentItem()
        alphabet_path = self.alphabet_combo.currentText()
        
        if selected_asset is not None and selected_subfolder is not None:
            base_dir = os.path.join(self.base_directory, self.base_directory_combo.currentText(), alphabet_path)
            asset_path = os.path.join(base_dir, selected_asset.text())
            
            # Determine the stage folder based on radio button selection
            stage_folder = "WIP" if self.wip_radio.isChecked() else "Published"
            
            # Update the stage_folder attribute
            self.stage_folder = stage_folder
        
            subfolder = selected_subfolder.text()
            stage_path = os.path.join(asset_path, subfolder, stage_folder)
            
            if os.path.exists(stage_path):
                blend_files = [os.path.splitext(f)[0] for f in os.listdir(stage_path) if f.endswith(".blend")]
                self.blend_list.addItems(blend_files)
            else:
                print(f"No '{stage_folder}' folder found in {asset_path}")


    def search_assets(self):
        search_text = self.search_input.text().lower()
        items = self.asset_list.findItems("", Qt.MatchContains)

        for item in items:
            if search_text in item.text().lower():
                item.setHidden(False)
            else:
                item.setHidden(True)
                
    def refresh_assets(self):
        # Store the currently selected items' text
        selected_asset_text = None
        current_asset_item = self.asset_list.currentItem()
        if current_asset_item:
            selected_asset_text = current_asset_item.text()

        selected_subfolder_text = None
        current_subfolder_item = self.subfolder_list.currentItem()
        if current_subfolder_item:
            selected_subfolder_text = current_subfolder_item.text()

        selected_blend_text = None
        current_blend_item = self.blend_list.currentItem()
        if current_blend_item:
            selected_blend_text = current_blend_item.text()

        # Clear existing items in subfolder_list and blend_list
        self.subfolder_list.clear()
        self.blend_list.clear()

        # Repopulate subfolders
        self.populate_subfolders()

        # Attempt to select the previously selected items
        if selected_asset_text:
            items = self.asset_list.findItems(selected_asset_text, Qt.MatchExactly)
            if items:
                self.asset_list.setCurrentItem(items[0])

        if selected_subfolder_text:
            items = self.subfolder_list.findItems(selected_subfolder_text, Qt.MatchExactly)
            if items:
                self.subfolder_list.setCurrentItem(items[0])

        # Update blend files after subfolders are populated
        self.update_blend_files()

        if selected_blend_text:
            items = self.blend_list.findItems(selected_blend_text, Qt.MatchExactly)
            if items:
                self.blend_list.setCurrentItem(items[0])
        
    def open_blend_file(self):
        selected_blend = self.blend_list.currentItem()
        selected_asset = self.asset_list.currentItem()
        alphabet_path = self.alphabet_combo.currentText()
        if selected_blend is not None and selected_asset is not None:
            base_dir = os.path.join(self.base_directory, self.base_directory_combo.currentText(), alphabet_path)
            asset_path = os.path.join(base_dir, selected_asset.text())

            # Determine the stage folder based on radio button selection
            stage_folder = "WIP" if self.wip_radio.isChecked() else "Published"
            
            subfolder = self.subfolder_list.currentItem().text()
            publish_path = os.path.join(asset_path, subfolder, stage_folder, selected_blend.text() + ".blend")
            bpy.ops.wm.open_mainfile(filepath=publish_path)

    def append_blend_collection(self):
        job_types = ['_MOD', '_RIG', '_LGT']
        status_types = ['_WIP', '_Published', '_Approved']

        # Get the selected blend file from the blend_list widget
        selected_blend = self.blend_list.currentItem()
        if selected_blend is not None:
            blend_name = os.path.splitext(selected_blend.text())[0]

            # Construct the regular expression pattern dynamically
            job_pattern  = '|'.join(job_types) 
            status_pattern = '|'.join(status_types) 
            get_collection_name = re.sub(r'KUR_|' + job_pattern + r'|' + status_pattern + r'|_v\d{3}|.blend', '', blend_name)
            
            # Determine the stage folder based on radio button selection
            stage_folder = "WIP" if self.wip_radio.isChecked() else "Published"

            alphabet_path = self.alphabet_combo.currentText()

            blend_file_path = os.path.join(
                self.base_directory, 
                self.base_directory_combo.currentText(), 
                alphabet_path,
                self.asset_list.currentItem().text(),
                self.subfolder_list.currentItem().text(),
                stage_folder,
                f"{blend_name}.blend"
            )

            collection_name = get_collection_name
            
            # Link the collection with relative paths unchecked
            with bpy.data.libraries.load(blend_file_path, link=False) as (data_from, data_to):
                data_to.collections = [name for name in data_from.collections if name == collection_name]

            if not data_to.collections:
                self.show_message_box(f"Warning: Collection '{collection_name}' from '{blend_file_path}' is empty.")
                return

            # Link the appended collection to the current scene
            appended_collection = None
            for collection in data_to.collections:
                bpy.context.scene.collection.children.link(collection)
                appended_collection = collection

            # Ensure a collection was appended
            if appended_collection is None:
                self.show_message_box(f"Error: Failed to append collection '{collection_name}' from '{blend_file_path}'.")
                return
            
            # Deselect all previously selected objects
            for obj in bpy.context.view_layer.objects:
                obj.select_set(False)

            # Select objects in the appended collection
            for obj in appended_collection.objects:
                obj.select_set(True)

            # Set the active object for better context
            if appended_collection.objects:
                bpy.context.view_layer.objects.active = appended_collection.objects[0]
            
            self.show_info_message_box(f"Success Append collection '{collection_name}")
     
    def link_blend_collection(self):
        job_types = ['_MOD', '_RIG', '_LGT']
        status_types = ['_WIP', '_Published', '_Approved']
        
        # Get the selected blend file from the blend_list widget
        selected_blend = self.blend_list.currentItem()
        if selected_blend is not None:
            blend_name = os.path.splitext(selected_blend.text())[0]
            
            # Construct the regular expression pattern dynamically
            job_pattern  = '|'.join(job_types) 
            status_pattern = '|'.join(status_types) 
            
            get_collection_name = re.sub(r'KUR_|' + job_pattern + r'|' + status_pattern + r'|_v\d{3}|.blend', '', blend_name)

            # Determine the stage folder based on radio button selection
            stage_folder = "WIP" if self.wip_radio.isChecked() else "Published"

            alphabet_path = self.alphabet_combo.currentText()

            blend_file_path = os.path.join(
                self.base_directory, 
                self.base_directory_combo.currentText(), 
                alphabet_path,
                self.asset_list.currentItem().text(),
                self.subfolder_list.currentItem().text(),
                stage_folder,
                f"{blend_name}.blend"
            )

            collection_name = get_collection_name
            
            # Link the collection with relative paths unchecked
            with bpy.data.libraries.load(blend_file_path, link=True, relative=False) as (data_from, data_to):
                data_to.collections = [name for name in data_from.collections if name == collection_name]

            if not data_to.collections:
                self.show_message_box(f"Warning: Collection '{collection_name}' from '{blend_file_path}' is empty.")
                return
            
            for coll in data_to.collections:
                bpy.context.scene.collection.children.link(coll)


            # Select objects in the linked collection
            linked_collection = bpy.data.collections.get(collection_name)
            if linked_collection:
                bpy.ops.object.select_all(action='DESELECT')  # Deselect all objects

                # Loop through objects in the linked collection
                for obj in linked_collection.objects:
                    if obj.name not in bpy.context.scene.objects:
                        bpy.context.scene.collection.objects.link(obj)  # Link object to the active scene
                    obj.select_set(True)  # Select the object
                    bpy.context.view_layer.objects.active = obj  # Set it as active object

            self.show_info_message_box(f"Success Linked collection '{collection_name}")
        else:
            self.show_message_box("No blend file selected.")

    def save_settings(self):
        self.settings.setValue("base_directory", self.base_directory_combo.currentText())
        self.settings.setValue("alphabet", self.alphabet_combo.currentText())
        self.settings.setValue("search_input", self.search_input.text())
        self.settings.setValue("selected_asset", self.asset_list.currentRow())
        self.settings.setValue("selected_subfolder", self.subfolder_list.currentRow())
        self.settings.setValue("selected_stage", "wip" if self.wip_radio.isChecked() else "published")
        self.settings.setValue("operation_mode", self.button_group.checkedButton().text())

    def closeEvent(self, event):
        self.save_settings()
        super().closeEvent(event)

    def restore_settings(self):
        base_directory = self.settings.value("base_directory", "")
        if base_directory in [self.base_directory_combo.itemText(i) for i in range(self.base_directory_combo.count())]:
            self.base_directory_combo.setCurrentText(base_directory)

        self.populate_assets()
        
        alphabet = self.settings.value("alphabet", "")
        if alphabet in [self.alphabet_combo.itemText(i) for i in range(self.alphabet_combo.count())]:
            self.alphabet_combo.setCurrentText(alphabet)
        
        self.search_input.setText(self.settings.value("search_input", ""))
        
        selected_asset = int(self.settings.value("selected_asset", -1))
        if selected_asset >= 0 and selected_asset < self.asset_list.count():
            self.asset_list.setCurrentRow(selected_asset)
            self.populate_subfolders() 
        
        selected_subfolder = int(self.settings.value("selected_subfolder", -1))
        if selected_subfolder >= 0 and selected_subfolder < self.subfolder_list.count():
            self.subfolder_list.setCurrentRow(selected_subfolder)
            self.update_blend_files()

        stage = self.settings.value("selected_stage", "wip")
        if stage == "wip":
            self.wip_radio.setChecked(True)
        elif stage == "published":
            self.published_radio.setChecked(True)
        
        operation_mode = self.settings.value("operation_mode", "Open")
        for button in self.button_group.buttons():
            if button.text() == operation_mode:
                button.setChecked(True)
                break