bl_info = {
    "name": "Scene Checker",
    "description": "Check Scene To Find Problem",
    "author": "IkyuValiantValentine",
    "version": (0, 1),
    "blender": (2, 93, 0),
    "location": "View3dPanel > Scene Checker",
    "category": "Tomatoes"}


###################################################
# Reference
# https://github.com/Weisl/Random-Blender-Scripts/blob/a2b53a95f7b6059b7719b06d6c9975422bc3de97/materials/material_delete_empty_slots.py
# https://github.com/MikeFesta/3xr/blob/67579ef88d3a6f5694aba030961089bfbf862dc1/blender-add-on/xrs/validate.py

import bpy
# load and reload submodules
##################################

import importlib
from . import developer_utils
from . import auto_load

from bpy.types import (
        Operator,
        Panel,
        PropertyGroup,
        )
        
from bpy.props import (StringProperty,
                       BoolProperty,
                       FloatVectorProperty,
                       FloatProperty,
                       EnumProperty,
                       IntProperty,
                       PointerProperty)
from bpy.app.handlers import persistent
from . properties import *

importlib.reload(developer_utils)
modules = developer_utils.setup_addon_modules(__path__, __name__, "bpy" in locals())     
                                     
class Scene_Checker_Preferences(bpy.types.AddonPreferences):
    bl_idname = __name__
    
    scale : FloatProperty(
            name="",
            description="Dialog Box Scale",
            default=0.2,
            min=0.1, max=1
            )    

    WorkflowOptions : EnumProperty(
            name="Preferences Scene Checker",
            items=(
                ("game_flow", "Game", "Game Scene Checker Workflow UI", 1),
                ("animation_flow", "Animation", "Animation Scene Checker Workflow UI", 2)),
            default='game_flow',
            description = "Choose UI") 

    SoftwareWorkflowOptions : EnumProperty(
            name="Preferences Scene Checker",
            items=(
                ("blender", "Blender", "Workflow For Blender", 1),
                ("maya", "Maya", "Workflow For Maya", 2)),
            default='blender',
            description = "Choose UI") 

    default_prefix_name: StringProperty(default="")
    default_suffix_name: StringProperty(default="")
                
    def draw(self, context):
        layout = self.layout 
        box = layout.box()     
        
        box.prop(self, "scale", text="Dialog Box Scale")

        box.prop(self, "default_prefix_name", text="Prefix")      
        box.prop(self, "default_suffix_name", text="Suffix")     

        box = layout.box()
        row = box.row()
        row.label(text="Workflow:")
        row.prop(self, "WorkflowOptions", expand=True)   

        box = layout.box()
        row = box.row()
        row.label(text="Set Software Option:")
        row.prop(self, "SoftwareWorkflowOptions", expand=True)   
      
##################################
# register
##################################
addon_keymaps = []
auto_load.init()
        
def register():            
    auto_load.register()
    bpy.utils.register_class(Scene_Checker_Preferences)
    bpy.types.Scene.scenechk_props = PointerProperty(type=SceneCheckerProperties)   
    
def unregister():
    auto_load.unregister()
    bpy.utils.unregister_class(Scene_Checker_Preferences)    
    del bpy.types.Scene.scenechk_props  


