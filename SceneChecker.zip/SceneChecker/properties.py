import bpy
from bpy.props import *
from bpy.types import PropertyGroup

# ------------------------------------------------------------------------              
#   Property Group
# ------------------------------------------------------------------------    
class SceneCheckerProperties(PropertyGroup):
    settingsFilePath : StringProperty(
            name="Settings",
            default="",
            subtype='FILE_PATH',
            description="location for the settings save/load\n")  
            