import bpy, os
from bpy.types import Operator
from .. properties import *

class ComposBG(Operator):
    "Simple Setup Background Compositor"
    bl_idname = "op.nodebg"
    bl_label = "Background Preset"

    def execute(self, context):
        bpy.context.scene.render.use_simplify = True
        bpy.context.scene.render.simplify_subdivision = 0
        bpy.context.scene.render.simplify_subdivision_render = 6
        
        try:
            file = bpy.path.basename(bpy.data.filepath).split('_')
            sc_no = file[0]
            sh_no = file[1]
            sh_ext = file[2]
        except:
            file =''
            sc_no = 'SC_'
            sh_no = 'SH_'
            sh_ext = 'SH_ext'

        if sh_ext.startswith('SH'):
            scsh = '%s_%s_%s' % (sc_no, sh_no, sh_ext)
        else:
            scsh = '%s_%s' % (sc_no, sh_no)

        try:
            base_path = tree.nodes["File Output"].base_path
        except:
            base_path = "X:\Jin_Kepepet/"
                
        # switch on nodes and get reference
        bpy.context.scene.render.image_settings.file_format = 'PNG'
        bpy.context.scene.render.image_settings.color_mode = 'RGBA'
        bpy.context.scene.render.image_settings.compression = 0
        bpy.context.scene.eevee.use_gtao = True
        bpy.context.scene.view_layers["View Layer"].use_pass_ambient_occlusion = True
        bpy.context.scene.use_nodes = True
        tree = bpy.context.scene.node_tree
        links = tree.links

        prev = bpy.context.area.type
        bpy.context.area.type = 'NODE_EDITOR'

        area = bpy.context.area      

        # clear default nodes
        for n in tree.nodes:
            tree.nodes.remove(n)

        # create input
        rl = tree.nodes.new('CompositorNodeRLayers')
        rl.location = 0,200
            
        map = tree.nodes.new('CompositorNodeMapValue')
        map.name = 'Map Value'
        map.location = 500,200
        tree.nodes["Map Value"].offset[0] = -2.5
        tree.nodes["Map Value"].size[0] = 0.025
        links.new(rl.outputs[2],map.inputs[0])

        set = tree.nodes.new('CompositorNodeSetAlpha')
        set.name = 'SetAlpha'
        set.location = 500,-100
        links.new(rl.outputs['AO'],set.inputs[0])
        links.new(rl.outputs[1], set.inputs[1])

        fout = tree.nodes.new('CompositorNodeOutputFile')
        fout.name = 'File Output'
        fout.width = 300
        fout.location = 800,100
        fout.format.color_mode = 'RGBA'
        fout.format.compression = 100
        fout.base_path = base_path

        fout.outputs.data.file_slots['Image'].path = 'BG\%s_BG_ ' % scsh
        fout.outputs.data.file_slots.new('BG_AO\%s_BG_AO_' % scsh)
        bg_z = fout.outputs.data.file_slots.new('BG_Z\%s_BG_Z_' % scsh)
        fout.outputs.data.file_slots[bg_z.name].use_node_format = False
        fout.outputs.data.file_slots[bg_z.name].format.color_mode = 'RGB'

        links.new(rl.outputs[0],fout.inputs[0])
        links.new(set.outputs[0],fout.inputs[1])
        links.new(map.outputs[0],fout.inputs[2])
                
        bpy.context.area.type = prev
        return {'FINISHED'}

class ComposCHAR(Operator):
    "Simple Setup Character Compositor"
    bl_idname = "op.nodechar"
    bl_label = "Character Preset"

    def execute(self, context):
        bpy.context.scene.render.use_simplify = True
        bpy.context.scene.render.simplify_subdivision = 0
        bpy.context.scene.render.simplify_subdivision_render = 6
        
        try:
            file = bpy.path.basename(bpy.data.filepath).split('_')
            sc_no = file[0]
            sh_no = file[1]
            sh_ext = file[2]
        except:
            file =''
            sc_no = 'SC_'
            sh_no = 'SH_'
            sh_ext = 'SH_ext'

        if sh_ext.startswith('SH'):
            scsh = '%s_%s_%s' % (sc_no, sh_no, sh_ext)
        else:
            scsh = '%s_%s' % (sc_no, sh_no)

        try:
            base_path = tree.nodes["File Output"].base_path
        except:
            base_path = "X:\Jin_Kepepet/"
                
        # switch on nodes and get reference
        bpy.context.scene.render.image_settings.file_format = 'PNG'
        bpy.context.scene.render.image_settings.color_mode = 'RGBA'
        bpy.context.scene.render.image_settings.compression = 0
        bpy.context.scene.eevee.use_gtao = True
        bpy.context.scene.view_layers["View Layer"].use_pass_ambient_occlusion = True
        bpy.context.scene.use_nodes = True
        tree = bpy.context.scene.node_tree
        links = tree.links

        prev = bpy.context.area.type
        bpy.context.area.type = 'NODE_EDITOR'

        area = bpy.context.area      

        # clear default nodes
        for n in tree.nodes:
            tree.nodes.remove(n)

        # create input
        rl = tree.nodes.new('CompositorNodeRLayers')
        rl.location = 0,200
    
        set = tree.nodes.new('CompositorNodeSetAlpha')
        set.name = 'SetAlpha'
        set.location = 500,-100
        links.new(rl.outputs['AO'],set.inputs[0])
        links.new(rl.outputs[1], set.inputs[1])

        fout = tree.nodes.new('CompositorNodeOutputFile')
        fout.name = 'File Output'
        fout.width = 300
        fout.location = 800,100
        fout.format.color_mode = 'RGBA'
        fout.format.compression = 100
        fout.base_path = base_path

        fout.outputs.data.file_slots['Image'].path = 'CHAR\%s_CH_' %scsh
        fout.outputs.data.file_slots.new('CHAR_AO\%s_CHAR_AO_' % scsh)
        links.new(rl.outputs[0],fout.inputs[0])
        links.new(set.outputs[0],fout.inputs[1])
   
        bpy.context.area.type = prev
        return {'FINISHED'}

class ShdCHAR(Operator):
    "Simple Setup For Render Only Shadow"
    bl_idname = "op.nodeshdchar"
    bl_label = "Shadow Preset"

    def execute(self, context):
        bpy.context.scene.render.use_simplify = True
        bpy.context.scene.render.simplify_subdivision = 0
        bpy.context.scene.render.simplify_subdivision_render = 6
        
        try:
            file = bpy.path.basename(bpy.data.filepath).split('_')
            sc_no = file[0]
            sh_no = file[1]
            sh_ext = file[2]
        except:
            file =''
            sc_no = 'SC_'
            sh_no = 'SH_'
            sh_ext = 'SH_ext'

        if sh_ext.startswith('SH'):
            scsh = '%s_%s_%s' % (sc_no, sh_no, sh_ext)
        else:
            scsh = '%s_%s' % (sc_no, sh_no)

        try:
            base_path = tree.nodes["File Output"].base_path
        except:
            base_path = "X:\Jin_Kepepet/"
                
        # switch on nodes and get reference
        bpy.context.scene.render.image_settings.file_format = 'PNG'
        bpy.context.scene.render.image_settings.color_mode = 'RGBA'
        bpy.context.scene.eevee.use_gtao = True
        bpy.context.scene.view_layers["View Layer"].use_pass_ambient_occlusion = True
        bpy.context.scene.use_nodes = True
        tree = bpy.context.scene.node_tree
        links = tree.links

        prev = bpy.context.area.type
        bpy.context.area.type = 'NODE_EDITOR'

        area = bpy.context.area      

        # clear default nodes
        for n in tree.nodes:
            tree.nodes.remove(n)

        # create input
        rl = tree.nodes.new('CompositorNodeRLayers')
        rl.location = 0,200
    
        fout = tree.nodes.new('CompositorNodeOutputFile')
        fout.name = 'File Output'
        fout.width = 300
        fout.location = 800,100
        fout.format.color_mode = 'RGBA'
        fout.format.compression = 100
        fout.base_path = base_path

        fout.outputs.data.file_slots['Image'].path = 'CHAR_SHD\%s_CH_SHD_' %scsh
        links.new(rl.outputs[0],fout.inputs[0])
   
        bpy.context.area.type = prev
        return {'FINISHED'}
    

class file_final_save_settings(Operator):
    bl_idname = "test.save_jinkepepet"
    bl_label = "Replace Name & Save"
   
    def execute(self, context,):
        tomatoes = context.scene.tomatoes_props
        if tomatoes.apply_file_rev == True:
            outname = bpy.path.basename(bpy.data.filepath).replace(tomatoes.str_default + tomatoes.file_rev , tomatoes.final_str)
        else:
            outname = bpy.path.basename(bpy.data.filepath).replace(tomatoes.str_default , tomatoes.final_str)
        outpath = os.path.dirname(bpy.path.abspath(bpy.data.filepath))
        self.report({'INFO'}, (os.path.join("File : " + outname, " Created at: " + outpath)))
        return bpy.ops.wm.save_mainfile(filepath=os.path.join(outpath, outname),
                    check_existing=True)

class OpenDirectorySave(Operator):
    """Open Export Directory in OS"""
    bl_idname = "file.open_save_directory"
    bl_label = "Open Save File Directory in OS"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        outpath = os.path.dirname(bpy.path.abspath(bpy.data.filepath))
        if len(outpath) > 0:
            try:
                os.startfile(outpath)
            except:
                subprocess.Popen(['xdg-open', outpath])
        else:
            self.report({'INFO'}, 'Save File Before')
            return {'FINISHED'}

        return {'FINISHED'}