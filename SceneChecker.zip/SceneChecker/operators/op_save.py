import bpy, os
from bpy.types import Operator
import glob 
from bpy.props import *
import shutil

def getVersion(p_fileName):
    
    version = ""
    separator = False
    nameLeng = len(p_fileName)
    cont = nameLeng - 1
    isNumber = p_fileName[cont].isdigit()
    
    while cont >= 0 and isNumber:
        
        version = p_fileName[cont] + version
        cont = cont - 1
        if p_fileName[cont] == "_":
            separator = True
            break
        else:
            isNumber = p_fileName[cont].isdigit()
    
    if version == "" or separator == False:
        version = "NONE"
        
    return version

def incrementVersion(p_version):
    
    version = ""
    nameLeng = len(p_version)
    cont = nameLeng - 1
    sum = 0
    add = 0
    
    nVersion = int(p_version)
    nVersion += 1
    version = str(nVersion)
    
    while len(version) < len(p_version):
        version = "0" + version
        
    return version
    

def hasVersion(p_fileName):
    
    cont = len(p_fileName) - 1
    isNumber = p_fileName[cont].isdigit()
    
    return isNumber

def getVersionPosition(p_fileName):
    
    i = len(p_fileName) - 1
    while p_fileName[i] != "_":
        i = i - 1
    i += 1
    
    
    return i 
    
def getIncrementedFile(p_file="", p_inIncFolder = True):
    
    incrementedFile = ""
    file = p_file
    baseName= os.path.basename(file)
    folder = os.path.dirname(file)
    fileName = os.path.splitext(baseName)[0]
    versionFolderName = ""
    type = os.path.splitext(baseName)[1]
    version = getVersion(fileName)
    newVersion = ""
    
    #if there is not a first version file, create the new one
    if version == "NONE":
        versionFolderName = "versions_" + fileName
        version = "000"
        fileName = fileName + "_000" 
        
    newVersion = incrementVersion(version) 
    numVersions = fileName.count(version)
    if numVersions >= 1:
        posVersion = getVersionPosition(fileName)
        print("ver: ", posVersion)
        fileName = fileName[:posVersion]
        newFileName = fileName + newVersion
    else:
        newFileName = fileName.replace(version,newVersion)
        
        
    newFullFileName = newFileName + type
    
    
    if p_inIncFolder:
        
        versionFolder = os.path.join(folder,versionFolderName)
        incrementedFile = os.path.join(versionFolder, newFullFileName)
        
    else:
        incrementedFile = os.path.join(folder, newFullFileName)
    
    return incrementedFile 

def getLastVersionFile(p_file = ""):
    
    #look into the version folder for the last one
    #if there is not anything, return an empty string
    
    lastFile = ""
    file = p_file
    baseName= os.path.basename(file)
    folder = os.path.dirname(file)
    fileName = os.path.splitext(baseName)[0]
    versionFolderName = "versions_" + fileName    
    versionFolder = os.path.join(folder,versionFolderName)

    if os.path.exists(versionFolder):
        filesToSearch = os.path.join(versionFolder, "*.blend")
        if len(filesToSearch) > 0:
            blendFiles = sorted(glob.glob(filesToSearch))
            lastFile = blendFiles[len(blendFiles)-1]
    else:
        os.makedirs(versionFolder)
          
    return lastFile
    
    
def saveIncremental():
    
    # check if it has version, 
    # if it has a version in the name save in the same folder with a version up number,
    # if not, save a new version within the version folder.
    
    currentFile = bpy.data.filepath
    baseName= os.path.basename(currentFile)
    currentFileName= os.path.splitext(baseName)[0]
    newFile = ""
        
    hasVersion = getVersion(currentFileName)

    if hasVersion == "NONE":
        
        # save in the version folder
        lastFile = getLastVersionFile(p_file = currentFile)
        if lastFile == "":
            lastFile = currentFile
        
        newFile = getIncrementedFile(p_file = lastFile, p_inIncFolder = True)
        """
        bpy.ops.wm.save_as_mainfile(filepath=currentFile, copy=False)
        bpy.ops.wm.save_as_mainfile(filepath=newFile, copy=True)
        """
        
        #SAVE MASTER
        bpy.ops.wm.save_as_mainfile(filepath=currentFile, copy=True)
        
        #COPY MASTER FILE AND SAVE AS INCREMENTAL
        shutil.copyfile(currentFile, newFile)
        
    else:
        
        # save a new version in file current
        newFile = getIncrementedFile(p_file = currentFile, p_inIncFolder = False)
        bpy.ops.wm.save_as_mainfile(filepath=newFile)
     
    return os.path.basename(newFile)
    

class ExportSomeData(Operator):
    """This appears in the tooltip of the operator and in the generated docs"""
    bl_idname = "ob.save"
    bl_label = "Initial Save"

    def execute(self, context):
        scenechk = context.scene.scenechk_props
        my_dir = scenechk.settingsFilePath
        savename = scenechk.save_filename

        wipFolder = os.path.join(my_dir, "WIP")
        if os.path.exists(wipFolder):
            print ("OK")
        else:
            os.makedirs(wipFolder)
            print ("Create WIP")

        for root, dirs, files in os.walk(wipFolder, topdown='true'):
            print (os.path.relpath(root, wipFolder))
            # print("root %s dirs %s files %s" %(root, dirs, files))
            for file in files:
                ext = os.path.splitext(file)[-1].lower()
                if (ext == '.blend'):
                    print(file)

        bpy.ops.wm.save_as_mainfile(filepath=wipFolder + "\\" + savename + "_WIP" + ".blend", \
            relative_remap=True, compress=True, check_existing=True)

        self.report({"INFO"}, "File Saved")

        return {'FINISHED'}

class PublishSaveBlend(Operator):
    """Saving Blend File For Final Version"""
    bl_idname = "op.save_publish"
    bl_label = "Publish"

    def execute(self, context):
        scenechk = context.scene.scenechk_props
        my_dir = scenechk.settingsFilePath
        savename = scenechk.save_filename

        bpy.ops.wm.save_as_mainfile(filepath=my_dir + "\\" + savename +"_MOD" + ".blend", check_existing=True)

        self.report({"INFO"}, "File Saved")

        return {'FINISHED'}