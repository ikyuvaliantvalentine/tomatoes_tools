import bpy
from mathutils import Vector, Euler
from . properties import *

###########################################
#   for ob in context.scene.objects:
#   for ob in bpy.context.view_layer.objects # Change To This To Avoid Error Object Not Visible In ViewLayer Because Collection is Hide
###########################################

def scene_materials(self, context):
    mat_list_per_object = []
    for ob in bpy.context.view_layer.objects:
        if ob.type == "MESH":
            if ob.data.materials:
                mat_list_per_object.append(ob.data.materials.items())
    # Flatten the list and return a set (unique)
    return set([i[0] for i in sum(mat_list_per_object, [])]) 

def object_multiuser(self, context):
    multi_user_object = []
    for ob in bpy.context.view_layer.objects:
        if ob.type == "MESH":
            if ob.data.users > 1:
                multi_user_object.append(ob)
    return multi_user_object
    
def object_location(self, context):
    loc_list_per_object = []
    for ob in bpy.context.visible_objects:
        if ob.type == "MESH":
            if ob.location != Vector((0,0,0)):
                loc_list_per_object.append(ob)
    return loc_list_per_object

def object_scale(self, context):
    scale_list_per_object = []
    for ob in bpy.context.visible_objects:
        if ob.type == "MESH":
            if ob.scale != Vector((1.0,1.0,1.0)):
                scale_list_per_object.append(ob)
    return scale_list_per_object

def object_rotation(self, context):
    rot_list_per_object = []
    for ob in bpy.context.visible_objects:
        if ob.type == "MESH":
            if ob.rotation_euler != Euler((0,0,0), 'XYZ'):
                rot_list_per_object.append(ob)
    return rot_list_per_object

def uv_object_more_than_one(self, context):
    uv_list_per_object = []
    for ob in bpy.context.visible_objects:
        if ob.type == "MESH":
            if(len(ob.data.uv_layers)) > 1:
                uv_list_per_object.append(ob)
    return uv_list_per_object

def uv_object_empty(self, context):
    empty_uv_list_per_object = []
    for ob in bpy.context.visible_objects:
        if ob.type == "MESH":
            if(len(ob.data.uv_layers)) < 1:
                empty_uv_list_per_object.append(ob)
    return empty_uv_list_per_object

def uv_object_name(self, context):
    addon_preferences = get_addon_preferences()
    softwareworkflow = addon_preferences.SoftwareWorkflowOptions
    
    uv_name_list_per_object = []
    
    for ob in bpy.context.visible_objects:
        if ob.type == "MESH":
            for uvmap in  ob.data.uv_layers :
                if softwareworkflow == "maya":
                    if uvmap.name != "map1":
                        uv_name_list_per_object.append(ob)
                        
                elif softwareworkflow == "blender":
                    if uvmap.name != "UVMap":
                        uv_name_list_per_object.append(ob)
                    
    return uv_name_list_per_object

def valid_uv_name(self, context):
    valid_uv_name = []
    
    for ob in bpy.context.visible_objects:
        if ob.type == "MESH":
            for uvmap in  ob.data.uv_layers :
                name = uvmap.name
                check = name.isalnum()
                if not check:
                    valid_uv_name.append(check)
    return valid_uv_name


def object_vertex_color(self, context):
    ob_vcol = []
    
    for ob in bpy.context.visible_objects:
        if ob.type == "MESH":
            for vcol in ob.data.vertex_colors :
                ob_vcol.append(ob)
    return ob_vcol

def tris_meshcalc(self, context):
    ob_tris = []
    
    for ob in bpy.context.visible_objects:
        if ob.type == "MESH":
            trisCount = 0
            for p in ob.data.polygons:
                if len(ob.data.vertices) < 2000:
                    if len(p.vertices) == 3:
                        trisCount += 1
                        ob_tris.append(ob)
                else:
                    break
    return ob_tris

def ngon_meshcalc(self, context):
    ob_ngon = []
    
    for ob in bpy.context.visible_objects:
        if ob.type == "MESH":
            ngonCount = 0
            for p in ob.data.polygons:
                count = p.loop_total
                if count > 4:
                    ngonCount += 1 
                    ob_ngon.append(ob)
    return ob_ngon

def prefix_check_count(self, context):
    # Store Name To Preferences
    addon_prefs = context.preferences.addons["SceneChecker"].preferences
    prefix_check = []

    for obj in bpy.context.visible_objects:
        if obj.type == "MESH":
            if not obj.name.startswith((addon_prefs.default_prefix_name)):
                prefix_check.append(obj)

    return prefix_check

#mod_data = [tuple(["actions"]*3),
#            tuple(["armatures"]*3),
#            tuple(["brushes"]*3),
#            tuple(["cameras"]*3),
#            tuple(["curves"]*3),
#            tuple(["fonts"]*3),
#            tuple(["grease_pencil"]*3),
#            tuple(["groups"]*3),
#            tuple(["images"]*3),
#            tuple(["lamps"]*3),
#            tuple(["lattices"]*3),
#            tuple(["libraries"]*3),
#            tuple(["linestyles"]*3),
#            tuple(["materials"]*3),
#            tuple(["masks"]*3),
#            tuple(["meshes"]*3),
#            tuple(["metaballs"]*3),
#            tuple(["movieclips"]*3),
#            tuple(["node_groups"]*3),
#            tuple(["objects"]*3),
#            tuple(["particles"]*3),
#            tuple(["sounds"]*3),
#            tuple(["scenes"]*3),
#            tuple(["speakers"]*3),
#            tuple(["texts"]*3),
#            tuple(["textures"]*3),
#            tuple(["worlds"]*3),
#            tuple(["everything"]*3),
#]

#def check_packed_image(self, context):
#    check_packed_image_count = []
#    
#    target = bpy.context.view_layer.objects    
#    
#    every_block_name = [list(x)[0] for x in bpy.types.Scene.mod_list[1]["items"] 
#                        if list(x)[0] != "everything"]

#    for image in every_block_name:
#        target_coll = eval("bpy.data.{}".format(block_name))
#        check_packed_image_count.append(target_coll)
#        # i.name, i.packed_file

#    return check_packed_image_count

def check_suffix_geo(self, context):
    suffix_geo = []

    for obj in bpy.context.visible_objects:
        if obj.type == "MESH":
            if not obj.name.endswith("_geo"):
                object_name = obj.name
                suffix_geo.append(object_name)
    return suffix_geo

def calculate_blend_size():
    # returns the size of the current Blender file as a string

    filepath = bpy.data.filepath
    size_bytes = os.stat(filepath).st_size if filepath != '' else -1

    kilobyte = 1024  # bytes
    megabyte = 1048576  # bytes
    gigabyte = 1073741824  # bytes

    if 0 <= size_bytes < kilobyte:
        size_scaled = "{:.1f} B".format(size_bytes)
    elif kilobyte <= size_bytes < megabyte:
        size_scaled = "{:.1f} KB".format(size_bytes / kilobyte)
    elif megabyte <= size_bytes < gigabyte:
        size_scaled = "{:.1f} MB".format(size_bytes / megabyte)
    elif size_bytes >= gigabyte:
        size_scaled = "{:.1f} GB".format(size_bytes / gigabyte)
    else:
        size_scaled = "No Data!"

    return size_scaled
