import bpy, re
from .. properties import *
from bpy.types import Operator
from . invoke_draw import *
#########################################
#   List Material
#########################################     
class ListMat(Operator):
    bl_label = "List Material"
    bl_idname = "quick.listmaterial"
    bl_description = "List Data Material"
    dialog_width =  500
              
    def draw(self, context):
        UI_List_Mat(self, context)
             
    def check(self, context):
        return True            
    def execute(self, context):
        return {'FINISHED'}    
    def invoke(self, context, event):
        wm = context.window_manager
        self.scale = get_addon_preferences().scale
        window_size = (context.window.width/250)/dpifac()
        wm.invoke_props_dialog(self, width = self.dialog_width * window_size * self.scale)
        return {'RUNNING_MODAL'} 
    
#########################################
#   World
#########################################                
class WorldToolbox(Operator):
    bl_label = "World Settings Toolbox"
    bl_idname = "quick.worldtool"
    bl_description = "World Settings UI"
    dialog_width =  300                        
    
    def draw(self, context):
        UIWorld(self, context)
                                                
    def check(self, context):
        return True        
    def execute(self, context):
        return {'FINISHED'}    
    def invoke(self, context, event):
        wm = context.window_manager
        self.scale = get_addon_preferences().scale
        window_size = (context.window.width/250)/dpifac()
        return wm.invoke_popup(self, width = self.dialog_width * window_size * self.scale)

#########################################
#   Autocut
#########################################
class AutoCutUI(Operator):
    bl_label = "Auto Cut"
    bl_idname = "auto.cuts"
    dialog_width =  250 
    
    def draw(self, context):
        layout = self.layout
        Autocut_UI(context, layout) 
    
    def check(self, context):
        return True        
    def execute(self, context):
        return {'FINISHED'}    
    def invoke(self, context, event):
        wm = context.window_manager
        self.scale = get_addon_preferences().scale
        window_size = (context.window.width/250)/dpifac()
        wm.invoke_props_dialog(self, width = self.dialog_width * window_size * self.scale)
        return {'RUNNING_MODAL'} 
    
#########################################
#   Global Subsurf Control
#########################################
class GlobalSubsurf(Operator):
    "Global Subsurf Control"
    bl_label = "Global Subsurf"
    bl_idname = "glob.sub"
    dialog_width =  250 
    
    def draw(self, context):
        layout = self.layout
        glob_subsurf_UI(context, layout) 
        
    def check(self, context):
        return True        
    def execute(self, context):
        obj = bpy.data.objects
        tomatoes = context.scene.tomatoes_props    
       
        mesh_obj = [] # define mesh_obj list - a list of all mesh objects
        view_levels = tomatoes.view_level # define view levels for subsurf - from UI
        render_levels = tomatoes.render_level # define render levels for subsurf - from UI
        select = tomatoes.object_sel # define select - from UI
        # this is what objects will be worked on. ALL, SEL, or VIS
       
        # loop thru all objects, adding only mesh objects to mesh_obj list
        for index in obj:
           
            if index.type == 'MESH':
               
                # object is mesh object, now check to see if it should be
                # added to mesh_obj based on UI
                if select == 'ALL':
                    mesh_obj.append(index)
                elif select == 'SEL' and index in bpy.context.selected_objects:
                    mesh_obj.append(index)
                elif select == 'VIS' and index.is_visible(bpy.context.scene):
                    mesh_obj.append(index)      
       
        for index in mesh_obj:
            obj_modifiers = index.modifiers
           
            for i in obj_modifiers:
                if i.type == "SUBSURF":                    
                    i.levels = view_levels
                    i.render_levels = render_levels                    
        return {'FINISHED'}  
      
    def invoke(self, context, event):
        wm = context.window_manager
        self.scale = get_addon_preferences().scale
        window_size = (context.window.width/250)/dpifac()
        wm.invoke_props_dialog(self, width = self.dialog_width * window_size * self.scale)
        return {'RUNNING_MODAL'} 

#########################################
#   Cycles SpeedUP
#########################################
class CyclesTools(Operator):
    bl_label = "Cycles Tools"
    bl_idname = "quick.cycles_tools"
    dialog_width =  250
              
    def draw(self, context):
        UICyclesTools(self, context)  
             
    def check(self, context):
        return True            
    def execute(self, context):
        return {'FINISHED'}    
    def invoke(self, context, event):
        wm = context.window_manager
        self.scale = get_addon_preferences().scale
        window_size = (context.window.width/250)/dpifac()
        return wm.invoke_popup(self, width = self.dialog_width * window_size * self.scale)
            
#########################################
#   Lamp Settings
#########################################    
class LampSettingsToolbox(Operator):
    bl_label = "Quick Lamp Settings"
    bl_idname = "quick.lamptool"
    dialog_width =  250
        
    def draw(self, context):
        layout = self.layout        
        if context.active_object.type == 'LIGHT':  
            if context.scene.render.engine == 'BLENDER_EEVEE':  
                UILamp_Eevee(context, layout)
            elif context.scene.render.engine == 'CYCLES':  
                UILamp_Cycles(context, layout)
        elif context.active_object.type in {'MESH', 'CURVE'}: 
            UILamp_Cycles_Mesh(context, layout)
        else:
            self.layout.label(text="Need Selected Mesh, Curve or Lamp", icon='ERROR')
        
    def check(self, context):
        return True        
    def execute(self, context):
        return {'FINISHED'}    
    def invoke(self, context, event):
        wm = context.window_manager
        self.scale = get_addon_preferences().scale
        window_size = (context.window.width/250)/dpifac()
        wm.invoke_props_dialog(self, width = self.dialog_width * window_size * self.scale)
        return {'RUNNING_MODAL'}

############################################
# Camera & Curve & Lattice Parameter
############################################
class HandleParameter(Operator):
    bl_label = "Handle Parameter"
    bl_idname = "quick.handle"
    dialog_width =  350

    def draw(self, context):
        layout = self.layout
        if context.active_object.type == 'CURVE':  
            UICurve(context, layout)
        elif context.active_object.type == 'LATTICE':  
            UILattice(context, layout)
        elif context.active_object.type == 'EMPTY':  
            UIEmpty(context, layout)
             
    def check(self, context):
        return True            
    def execute(self, context):
        return {'FINISHED'}    
    def invoke(self, context, event):
        wm = context.window_manager
        self.scale = get_addon_preferences().scale
        window_size = (context.window.width/250)/dpifac()
        return wm.invoke_popup(self, width = self.dialog_width * window_size * self.scale)
        
############################################
# Renamer Tools
############################################            
class AddCustomName(Operator):
    bl_label = "Numbering & Custom Prefix/Suffix"
    bl_idname = "rename.more_naming"
    dialog_width = 280

    def draw(self, context):
        layout = self.layout
        UIRenamerPlus(context, layout)
        
    def check(self, context):
        return True        
    def execute(self, context):
        return {'FINISHED'}    
    def invoke(self, context, event):
        wm = context.window_manager
        self.scale = get_addon_preferences().scale
        window_size = (context.window.width/250)/dpifac()
        return wm.invoke_popup(self, width=self.dialog_width * window_size * self.scale)
            
class Renamertools(Operator):
    bl_label = "Rename Object"
    bl_idname = "rename.tools"
    dialog_width = 350
    
    @classmethod
    def poll(cls, context):
        return context.active_object and bpy.context.object.mode == "OBJECT"

    def draw(self, context):
        layout = self.layout
        UIRenamer(context, layout)
            
    def check(self, context):
        return True

    def execute(self, context):
        tomatoes = context.scene.tomatoes_props
        aob = context.active_object
        if aob.type not in {'EMPTY'} and aob.mode == 'OBJECT':

            for ob in context.selected_editable_objects:
                if tomatoes.prefix != '' or tomatoes.suffix != '':
                    if ob.name.startswith(tomatoes.prefix):
                        ob.name = ob.name
                    else:
                        ob.name = tomatoes.prefix + tomatoes.prefix_input + ob.name

                    if ob.name.startswith(tomatoes.suffix):
                        ob.name = ob.name
                    else:
                        ob.name = ob.name + tomatoes.suffix_input + tomatoes.suffix

                    if tomatoes.del_prefix:
                        ob.name = ob.name.replace(tomatoes.prefix, '')
                ob.data.name = ob.name   
        return {'FINISHED'}

    def invoke(self, context, event):
        wm = context.window_manager
        self.scale = get_addon_preferences().scale
        window_size = (context.window.width / 250) / dpifac()
        wm.invoke_props_dialog(self, width=self.dialog_width * window_size * self.scale)
        return {'RUNNING_MODAL'}

class RenameRegextools(Operator):
    bl_label = "Rename Regex"
    bl_idname = "rename_regex.tools"
    dialog_width = 350
    
    @classmethod
    def poll(cls, context):
        return context.active_object and bpy.context.object.mode == "OBJECT"
        
    # @classmethod
    # def poll(cls, context):
    #     return context.selected_objects != []

    def draw(self, context):
        layout = self.layout
        UIRenameRegex(context, layout)
            
    def check(self, context):
        return True

    def execute(self, context):
        tomatoes = context.scene.tomatoes_props
        search_str = tomatoes.regex_search_pattern
        replacement_str = tomatoes.regex_replacement_string
        substring_re = re.compile(search_str)
        if context.mode == 'OBJECT':
            item_list = context.selected_objects
        elif context.mode == 'POSE':
            item_list = context.selected_pose_bones
        elif context.mode == 'EDIT_ARMATURE':
            item_list = context.selected_bones
        else:
            return {'CANCELLED'}

        for item in item_list:
            item.name = substring_re.sub(replacement_str, item.name)

        # In pose mode, operator's result won't show immediately. This
        # solves it somehow: only the View3D area will refresh
        # promptly.
        if context.mode == 'POSE':
            context.area.tag_redraw()
        
        # Rename Object Data   
        aob = context.active_object
        if aob.type not in {'EMPTY'} and aob.mode == 'OBJECT':
            for ob in context.selected_editable_objects:
                if replacement_str != '':
                    if ob.name.startswith(replacement_str):
                        ob.name = ob.name
                    else:
                        ob.name = replacement_str + ob.name
                ob.data.name = ob.name
            
        return {'FINISHED'}

    def invoke(self, context, event):
        wm = context.window_manager
        self.scale = get_addon_preferences().scale
        window_size = (context.window.width / 250) / dpifac()
        wm.invoke_props_dialog(self, width=self.dialog_width * window_size * self.scale)
        return {'RUNNING_MODAL'}
    
#########################################
#   Set Scene
#########################################     
class SetScene(Operator):
    bl_label = "Set Scene"
    bl_idname = "quick.viewsetscene"
    bl_description = "Set Scene"
    dialog_width =  300
              
    def draw(self, context):
        layout = self.layout
        UISetScene(context, layout)
             
    def check(self, context):
        return True            
    def execute(self, context):
        return {'FINISHED'}    
    def invoke(self, context, event):
        wm = context.window_manager
        self.scale = get_addon_preferences().scale
        window_size = (context.window.width/250)/dpifac()
        wm.invoke_props_dialog(self, width = self.dialog_width * window_size * self.scale)
        return {'RUNNING_MODAL'} 
    

#########################################
#   Camera Projection List
#########################################     
class CamProjList(Operator):
    bl_label = "Camera Projection"
    bl_idname = "quick.cam_proj"
    bl_description = "Camera Projection UI"
    dialog_width =  300
              
    def draw(self, context):
        layout = self.layout
        cam_proj_list(context, layout)
             
    def check(self, context):
        return True            
    def execute(self, context):
        return {'FINISHED'}    
    def invoke(self, context, event):
        wm = context.window_manager
        self.scale = get_addon_preferences().scale
        window_size = (context.window.width/250)/dpifac()
        wm.invoke_props_dialog(self, width = self.dialog_width * window_size * self.scale)
        return {'RUNNING_MODAL'} 
    
class CamProjListRename(Operator):
    bl_label = "Camera Renamer"
    bl_idname = "quick.rename_cam_proj"
    bl_description = "Camera Projection Renamer UI"
    dialog_width =  300
                  
    def draw(self, context):
        layout = self.layout
        rename_camera_list(context, layout)
             
    def check(self, context):
        return True            
    def execute(self, context):
        for ob in context.selected_editable_objects:
            ob.data.name = ob.name
        return {'FINISHED'}    
    def invoke(self, context, event):
        wm = context.window_manager
        self.scale = get_addon_preferences().scale
        window_size = (context.window.width/250)/dpifac()
        wm.invoke_props_dialog(self, width = self.dialog_width * window_size * self.scale)
        return {'RUNNING_MODAL'} 
    