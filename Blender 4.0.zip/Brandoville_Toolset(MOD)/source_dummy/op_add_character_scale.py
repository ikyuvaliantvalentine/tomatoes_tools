import bpy
import os
from bpy.types import Operator

class Add_Character_Scale(Operator):
    " Add Unreal Mannequin for Scale"
    bl_idname = "op.add_character_scale"
    bl_label = "Add Character Scale"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        script_file = os.path.realpath(__file__)
        dir = os.path.dirname(script_file)         
        filepath = os.path.join(dir, "SK_Mannequin.blend")

        with bpy.data.libraries.load(filepath, link=False) as (data_from, data_to):
            data_to.collections = ["SK_Mannequin"]

        for collection in data_to.collections:
            bpy.context.scene.collection.children.link(collection)
            appended_collection = bpy.data.collections.get(collection.name)

            bpy.ops.object.mode_set(mode='OBJECT') 
            bpy.ops.object.select_all(action='DESELECT')
            for obj in appended_collection.objects:
                obj.select_set(True)
            
        return {'FINISHED'}