import bpy, math
from bpy.types import Operator
from bpy.props import *    

########################################################
#   Autosmooth Selectedf Object
########################################################
class Red_OT_AutoSmooth(Operator):
    bl_label = "Automatically smooth hard edges"
    bl_description = "Smooth hard edges based on an angle value"
    bl_idname = "mesh.be_auto_smooth"
    bl_options = {'REGISTER', 'UNDO'}

    angle: FloatProperty(name="Angle", default=math.radians(45), min=math.radians(1), max=math.radians(180), subtype="ANGLE")

    @classmethod
    def poll(cls, context):
        if context.object is None:
            return False
        return True
        
    def execute(self, context):
        bpy.ops.object.mode_set(mode = 'OBJECT')
        for obj in bpy.context.selected_objects:
            if obj.type == "MESH":
                bpy.context.view_layer.objects.active = obj
                if obj.data.use_auto_smooth == False:
                    obj.data.use_auto_smooth = True
                obj.data.auto_smooth_angle = self.angle
        bpy.ops.object.shade_smooth() 
        return {'FINISHED'}

#################################
#    Custom AutoSmooth
#################################  
class Red_AutoSmoothOption(Operator):
    """ Apply Custom AutoSmooth To Selected Objects"""
    bl_idname = "op.custom_autosmooth"
    bl_label = "Auto Smooth"
    
    type_smooth : EnumProperty(
        items = (('30', "30", ""),
                 ('60', "60", ""),
                 ('90', "90", ""),
                 ('180', "180", "")),
                 default = '30'
                 )

    @classmethod
    def poll(cls, context):
        return context.active_object is not None
        
    def execute(self, context):
        for obj in bpy.context.selected_objects:
            if obj.type == "MESH":
                bpy.context.view_layer.objects.active = obj
                if obj.data.use_auto_smooth == False:
                    obj.data.use_auto_smooth = True
                if self.type_smooth == '30':   
                    obj.data.auto_smooth_angle = 0.523599
                if self.type_smooth == '60':                     
                    obj.data.auto_smooth_angle = 1.0472
                if self.type_smooth == '90':                     
                    obj.data.auto_smooth_angle = 1.5708
                if self.type_smooth == '180':                     
                    obj.data.auto_smooth_angle = 3.14159
        bpy.ops.object.shade_smooth() 
        return {'FINISHED'}

#################################
#    Select Ngons & Tris
#################################      
class Red_OP_facetype_select(Operator):
    """Select all faces of a certain type"""
    bl_idname = "op.facetype_select"
    bl_label = "Select by face type"
    face_type : EnumProperty(
        name="Select faces:",
        items = (("3","Triangles","Faces made up of 3 vertices"),
                 ("5","Ngons","Faces made up of 5 and more vertices")),
        default = "5")
        
    @classmethod
    def poll(cls, context):
        return context.object is not None and context.object.type == 'MESH'

    def execute(self, context):
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.mesh.select_mode(use_extend=False, use_expand=False, type='FACE')
        bpy.ops.mesh.select_all(action='DESELECT')
        if self.face_type == "3":
            bpy.ops.mesh.select_face_by_sides(number=3, type='EQUAL')
        else:
            bpy.ops.mesh.select_face_by_sides(number=4, type='GREATER')     
        return {'FINISHED'}

#####################################
#Clear Custom Split Normals
#####################################
class Red_ClearNormals(Operator):
    """Clear Custom Split Normals On Selected Objects"""
    bl_idname = "op.clear_normals"
    bl_label = "Clear Custom Split Normals"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        selected_obj = bpy.context.selected_objects
        active_obj = bpy.context.active_object
        
        for x in selected_obj:
            bpy.ops.object.select_all(action='DESELECT')
            x.select_set(True)
            if x.type == 'MESH':
                bpy.context.view_layer.objects.active = x
                bpy.ops.mesh.customdata_custom_splitnormals_clear()
                bpy.context.object.data.auto_smooth_angle = 3.14159
                
        # Select again objects
        for j in selected_obj:
            j.select_set(True)
        
        bpy.context.view_layer.objects.active = active_obj                  
        return {'FINISHED'}     