import bpy
from .. properties import *

def draw_assetmanagement_ui(self, context, layout):
    red = context.scene.red_props
    addon_preferences = get_addon_preferences()

    box_prefix = layout.box()
    box_prefix.scale_x = 1.3
    box_prefix.scale_y = 1.3
    row1 = box_prefix.row()
    row1.enabled = False
    row1.prop(addon_preferences, "set_prefix", text="Prefix Name")
    row2 = box_prefix.row()
    row2.operator("op.open_addon_pref")

    box_assetsaver = layout.box()
    box_assetsaver.scale_x = 1.3
    box_assetsaver.scale_y = 1.3

    box_assetsaver.prop(addon_preferences, "settingsFilePath")

    layout.separator()
    layout.separator()
    layout.separator()

    box_shotloader = layout.box()
    box_shotloader.scale_x = 1.8
    box_shotloader.scale_y = 1.8
    box_shotloader.operator("op.shot_loader", icon="ASSET_MANAGER")
    box_shotloader.operator("op.anim_asset_loader", icon="SNAP_VOLUME")
    
    box_shotloader.separator()
    box_shotloader.separator()
   
    box_shotloader.operator("op.local_playblast")
    box_shotloader.operator("wm.publish_shot")