import bpy
from .. properties import *

#############################################
#   Camera Projection    
############################################# 
def ui_cam_list(context,layout):
    red = context.scene.red_props
    
    cam_list=[cam.name for cam in context.scene.objects if cam.type=="CAMERA"]
    cam_list.sort(key=str.lower)

    col = layout.column(align=True)
    
    if not red.display_camera: 
        box = col.box().column(align=True)
        row = box.row(align=True)   
        row.prop(red, "display_camera", text="", icon="TRIA_RIGHT", toggle = True)                
        row.label(text="Camera Settings")   

    else:
        box = col.box().column(align=True)
        row = box.row(align=True)   
        row.prop(red, "display_camera", text="", icon="TRIA_DOWN", toggle = True)                
        row.label(text="Camera Settings")  

        col = box.column()
        split = col.split()
        col = split.column()
        col.separator()
        
        for cam in cam_list:     
            row = col.row(align=True) 
            row.operator("op.cameras_set_view", text=cam, emboss=True).camera=cam
            row.separator()
            row.operator("op.cameras_delete", text="", icon="PANEL_CLOSE").camera=cam

        col = split.column()
        col.scale_x = 1.2
        col.scale_y = 1.2
        col.separator()
        col.operator("op.cameras_new_from_view", text="New Camera from View", icon="ADD")
        
        scene = bpy.context.scene
        rd = scene.render
        
        box = layout.box()
        split = box.split()
        col = split.column()
        sub = col.column(align=True)
            
        sub.label(text="Resolution:")
        sub.prop(rd, "resolution_x", text="X")
        sub.prop(rd, "resolution_y", text="Y")
        sub.prop(rd, "resolution_percentage", text="")
        
        sub.separator()
        sub.prop(rd, "use_border")

        switchresbutton = box.column()
        switchresbutton.scale_x = 1.4
        switchresbutton.scale_y = 1.4
        switchresbutton.operator("op.swithrestoggle", icon="FILE_REFRESH")
        rend_percent = rd.resolution_percentage * 0.01
        x = (str(rd.resolution_x * rend_percent).split("."))[0]
        y = (str(rd.resolution_y * rend_percent).split("."))[0]
        box.label(text="Resolution: " + x + " x " + y)

        cam_objects = [ob for ob in scene.objects if ob.type == "CAMERA"]
        if len(cam_objects) == 0:
            return False
        else:
            cam = context.scene.camera.data
            if context.object.type == "CAMERA":
                col = split.column()
                sub = col.column(align=True)
                sub.label(text="Clipping")
                sub.prop(cam, "clip_start", text="Start")
                sub.prop(cam, "clip_end", text="End")        

                sub = col.column() 
                sub.separator()
                sub.prop(cam, "show_passepartout") 
                sub.prop(cam, "passepartout_alpha")  
                if bpy.context.scene.render.engine == "CYCLES":
                    sub.prop(bpy.context.scene.cycles,"film_transparent",text="Transparent Film")

                col = box.column()
                row = col.row()
                row.prop(cam, "type", expand=True)
                
                split = box.split()
                col = split.column()
                if cam.type == "PERSP":
                    row = col.row()
                    if cam.lens_unit == "MILLIMETERS":
                        row.prop(cam, "lens")
                    elif cam.lens_unit == "FOV":
                        row.prop(cam, "angle")
                    row.prop(cam, "lens_unit", text="")

                if cam.type == "ORTHO":
                    col.prop(cam, "ortho_scale")

                if cam.type == "PANO":
                    engine = bpy.context.scene.render.engine
                    row = col.row()
                    row.prop(cam, "lens")
                    if engine == "CYCLES":
                        ccam = cam.cycles
                        col.prop(ccam, "panorama_type", text="Panorama Type")
                        if ccam.panorama_type == "FISHEYE_EQUIDISTANT":
                            col.prop(ccam, "fisheye_fov")
                        elif ccam.panorama_type == "FISHEYE_EQUISOLID":
                            row = col.row()
                            row.prop(ccam, "fisheye_lens", text="Lens")
                            row.prop(ccam, "fisheye_fov")

                col.separator()
                sub = col.column(align=True)
                sub.prop(cam, "clip_start", text="Clip Start")
                sub.prop(cam, "clip_end", text="End")
                        
                split = box.split()
                col = split.column()

                box.prop(cam.dof, "use_dof", text="Depth of Field")
                row = box.row(align=True)
                row.active = cam.dof.use_dof
                row.prop(cam.dof, "focus_object", text="")
                col = row.column()
                sub = col.row()
                sub.active = cam.dof.focus_object is None
                sub.prop(cam.dof, "focus_distance", text="Distance")

                col = layout.column(align=True)
                if not red.cam_composition_ui_is_visible:
                    box = col.box().column(align=True)
                    row = box.row(align=True)   
                    row.prop(red, "cam_composition_ui_is_visible", text="", icon="TRIA_RIGHT", toggle = True)  
                    row.label(text="Use Composition Camera")   
                else:
                    box = col.box().column(align=True)
                    row = box.row(align=True)  
                    row.prop(red, "cam_composition_ui_is_visible", text="", icon="TRIA_DOWN", toggle = True)      
                    row.label(text="Use Composition Camera")   

                    row = box.row()
                    col = row.column(align=True)
                    col.label(text="Use")
                    col.separator()
                    col.prop(cam, "show_composition_thirds")

                    col = row.column(align=True)
                    col.label(text="Center")
                    col.separator()
                    col.prop(cam, "show_composition_center")
                    col.prop(cam, "show_composition_center_diagonal", text="Diagonal")

                    col = row.column(align=True)
                    col.label(text="Golden")
                    col.separator()
                    col.prop(cam, "show_composition_golden", text="Ratio")
                    col.prop(cam, "show_composition_golden_tria_a", text="Triangle A")
                    col.prop(cam, "show_composition_golden_tria_b", text="Triangle B")

                    col = row.column(align=True)
                    col.label(text="Harmony")
                    col.separator()
                    col.prop(cam, "show_composition_harmony_tri_a", text="Triangle A")
                    col.prop(cam, "show_composition_harmony_tri_b", text="Triangle B")
            