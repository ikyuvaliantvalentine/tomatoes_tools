import bpy, bgl, blf
from bpy.types import Operator
from .. properties import *

#######################
#Modifier Modal
#######################
#Subsurf
def draw_subsurf(self, context):
    font_id = 0
    region = context.region
       
    addon_preferences = get_addon_preferences()
    size = addon_preferences.FontSizeModal
    xmod = addon_preferences.PositionXModal
    ymod = addon_preferences.PositionYModal
    space = addon_preferences.Font_Space
    space_y = addon_preferences.Font_Space_Y

    font_color_r, font_color_g, font_color_b, font_color_alpha = addon_preferences.base_color
    font_bool_color_r, font_bool_color_g, font_bool_color_b, font_bool_color_alpha = addon_preferences.bool_color

    wdt2 = 0
    multsp = space / 10

    wdt2 = 0
    if bpy.context.area.type == 'VIEW_3D':
        for r in bpy.context.area.regions:
            if r.type == 'TOOLS':
                wdt2 = r.width - 1
                self.regionwdt = wdt2
                xmod = addon_preferences.PositionXModal + r.width - 1
    
    for obj in context.selected_objects:
        context.view_layer.objects.active = obj
    for mod in obj.modifiers:
        if mod.type == 'SUBSURF':    
            cobj = context.active_object
            subd_levl = cobj.modifiers[mod.name].levels
            rend_levl = cobj.modifiers[mod.name].render_levels
            ce = cobj.modifiers[mod.name].show_only_control_edges
            ty = cobj.modifiers[mod.name].subdivision_type   
                         
            #Title
            blf.color(font_id, font_color_r, font_color_g, font_color_b, font_color_alpha)
            blf.position(font_id, 450 + xmod, 260 + ymod, 0)
            blf.size(font_id, int(15*(size/10)) + 5, 72)
            blf.draw(font_id, mod.name )
            
            blf.color(font_id, font_color_r, font_color_g, font_color_b, font_color_alpha)
            blf.position(font_id, 450 + xmod, 250 + ymod, 0)
            blf.size(font_id, int(15 * (size / 10)) + 5, 72)
            blf.draw(font_id, "__________")

            #Level
            blf.color(font_id, font_color_r, font_color_g, font_color_b, font_color_alpha)
            blf.position(font_id, 450 + xmod, 220 + ymod + space_y, 0)
            blf.size(font_id, int(15*(size/10)), 72)
            blf.draw(font_id, "Subsurf Level" )
                    
            blf.color(font_id, font_bool_color_r, font_bool_color_g, font_bool_color_b, font_bool_color_alpha)
            blf.position(font_id, 600 + xmod + 20*multsp , 220 + ymod + space_y, 0)
            blf.size(font_id, int(15*(size/10)), 72)
            blf.draw(font_id, "(MM) " + str(subd_levl))
            
            blf.color(font_id, font_color_r, font_color_g, font_color_b, font_color_alpha)
            blf.position(font_id, 450 + xmod, 190 + ymod + space_y, 0)
            blf.size(font_id, int(15*(size/10)), 72)
            blf.draw(font_id, "Render Level" )
            
            blf.color(font_id, font_bool_color_r, font_bool_color_g, font_bool_color_b, font_bool_color_alpha)
            blf.position(font_id, 600 + xmod + 20*multsp , 190 + ymod + space_y, 0)
            blf.size(font_id, int(15*(size/10)), 72)
            blf.draw(font_id, "(MM + Shift) " + str(rend_levl))
            
            #Optimal
            blf.color(font_id, font_color_r, font_color_g, font_color_b, font_color_alpha)
            blf.position(font_id, 450 + xmod, 160 + ymod + space_y, 0)
            blf.size(font_id, int(15*(size/10)), 72)
            blf.draw(font_id, "Optimal Display"  ) 
               
            blf.color(font_id, font_bool_color_r, font_bool_color_g, font_bool_color_b, font_bool_color_alpha)
            blf.position(font_id, 600 + xmod + 20*multsp , 160 + ymod + space_y, 0)
            blf.size(font_id, int(15*(size/10)), 72)
            blf.draw(font_id, "(Z) " + str(ce))
            
            #Switch
            blf.color(font_id, font_color_r, font_color_g, font_color_b, font_color_alpha)
            blf.position(font_id, 450 + xmod, 130 + ymod + space_y, 0)
            blf.size(font_id, int(15*(size/10)), 72)
            blf.draw(font_id, "Type"  ) 
                    
            blf.color(font_id, font_bool_color_r, font_bool_color_g, font_bool_color_b, font_bool_color_alpha)
            blf.position(font_id, 600 + xmod + 20*multsp , 130 + ymod + space_y, 0)
            blf.size(font_id, int(15*(size/10)), 72)
            if self._mode == 0:
                mode = bpy.context.object.modifiers[mod.name].subdivision_type = 'CATMULL_CLARK'
            elif self._mode == 1:
                mode = bpy.context.object.modifiers[mod.name].subdivision_type = 'SIMPLE'        
            type_subidv = "(Q) {0}".format(mode)
            blf.draw(font_id, type_subidv)
                            
            #Keys
            blf.color(font_id, font_color_r, font_color_g, font_color_b, font_color_alpha)
            blf.position(font_id, 450 + xmod, 50, 0)
            blf.size(font_id, int(15*(size/10)), 72)
            blf.draw(font_id, "Exit"  ) 
            
            blf.color(font_id, font_bool_color_r, font_bool_color_g, font_bool_color_b, font_bool_color_alpha)
            blf.position(font_id, 600 + xmod + 20*multsp, 50, 0)
            blf.size(font_id, int(15*(size/10)), 72)
            blf.draw(font_id, "RMB/ESC"  ) 
            
            blf.color(font_id, font_color_r, font_color_g, font_color_b, font_color_alpha)
            blf.position(font_id, 450 + xmod, 30, 0)
            blf.size(font_id, int(15*(size/10)), 72)
            blf.draw(font_id, "Turn Off"  ) 
            
            blf.color(font_id, font_bool_color_r, font_bool_color_g, font_bool_color_b, font_bool_color_alpha)
            blf.position(font_id, 600 + xmod + 20*multsp, 30, 0)
            blf.size(font_id, int(15*(size/10)), 72)
            blf.draw(font_id, "(+ SHIFT)"  ) 
        
class Subsurf_Modal(Operator):
    'Add Subsurf With Modal Operator'
    bl_idname = "object.subsurf_modal"
    bl_label = "Subsurf Modal"
        
    first_mouse_x : IntProperty()
    first_value : FloatProperty()
     
    def modal(self, context, event):  
        delta = self.first_mouse_x - event.mouse_x
                
        for obj in context.selected_objects:
            context.view_layer.objects.active=obj
            for mod in [m for m in obj.modifiers if m.type == 'SUBSURF']:
                if mod :                                       
                    if event.type in {'MIDDLEMOUSE', 'WHEELUPMOUSE', 'WHEELDOWNMOUSE'}:
                        return {'PASS_THROUGH'}
                                                  
                    if event.type == 'MOUSEMOVE':
                        bpy.context.area.tag_redraw()
                        if event.shift:
                            mod.render_levels = self.first_value + delta *  -0.01 
                        else:
                            mod.levels = self.first_value + delta *  -0.01 
                                                        
                    elif event.type == 'Z' and event.value == 'PRESS':
                        mod.show_only_control_edges = True
                        if event.shift:
                            mod.show_only_control_edges = False
                                                            
                    elif event.type == 'Q' and event.value == 'PRESS':
                        self._mode = (self._mode + 1)  % 2 
                        
                    elif event.type == 'A' and event.value == 'PRESS':
                        for ob in bpy.context.selected_objects:
                            bpy.context.view_layer.objects.active = ob
                            for mod in [m for m in ob.modifiers if m.type == 'SUBSURF']:
                                bpy.ops.object.modifier_apply( modifier = mod.name )
                                return {'CANCELLED'}   
                    
                    elif event.type == 'LEFTMOUSE':
                        bpy.types.SpaceView3D.draw_handler_remove(self._handle, 'WINDOW')
                        return {'FINISHED'}
                    
                    elif event.type in {'RIGHTMOUSE', 'ESC'}:
                        context.object.location.x = self.first_value
                        bpy.types.SpaceView3D.draw_handler_remove(self._handle, 'WINDOW')
                        return {'CANCELLED'}                        
                    return {'RUNNING_MODAL'}
     
    def invoke(self, context, event):                                 
        if context.object:
            is_solid = False
            for mod in bpy.context.object.modifiers :
                if mod.type == 'SUBSURF' :
                    is_solid = True
                    
            if not is_solid:
                for obj in context.selected_objects:
                    bpy.ops.object.subsurf()
                for mod in obj.modifiers:
                    if mod.type == 'SUBSURF':
                        mod.show_only_control_edges = True
                        mod.show_on_cage = False
                        mod.levels = 2 
                    
            self._mode = 0
            self.first_mouse_x = event.mouse_x
            for obj in context.selected_objects:
                context.view_layer.objects.active = obj
            for mod in obj.modifiers:
                if mod.type == 'SUBSURF':
                    self.first_value = bpy.context.object.modifiers[mod.name].levels

            # Draw Text
            args = (self, context)
            self._handle = bpy.types.SpaceView3D.draw_handler_add(draw_subsurf, args, 'WINDOW', 'POST_PIXEL')            
            context.window_manager.modal_handler_add(self)
            return {'RUNNING_MODAL'}
        else:
            self.report({'WARNING'}, "Must Use In a 3D Region")
            return {'CANCELLED'}
        

#Bevel
def draw_bevel(self, context):
    font_id = 0
    region = context.region
       
    addon_preferences = get_addon_preferences()
    size = addon_preferences.FontSizeModal
    xmod = addon_preferences.PositionXModal
    ymod = addon_preferences.PositionYModal
    space = addon_preferences.Font_Space
    space_y = addon_preferences.Font_Space_Y

    font_color_r, font_color_g, font_color_b, font_color_alpha = addon_preferences.base_color
    font_bool_color_r, font_bool_color_g, font_bool_color_b, font_bool_color_alpha = addon_preferences.bool_color

    wdt2 = 0
    multsp = space / 10

    wdt2 = 0
    if bpy.context.area.type == 'VIEW_3D':
        for r in bpy.context.area.regions:
            if r.type == 'TOOLS':
                wdt2 = r.width - 1
                self.regionwdt = wdt2
                xmod = addon_preferences.PositionXModal + r.width - 1
    
    for obj in context.selected_objects:
        context.view_layer.objects.active = obj
    for mod in obj.modifiers:
        if mod.type == 'BEVEL':    
            cobj = context.active_object
            wdth_levl = cobj.modifiers[mod.name].width
            segm_levl = cobj.modifiers[mod.name].segments
            lm = cobj.modifiers[mod.name].limit_method
            wm = cobj.modifiers[mod.name].offset_type
                         
            #Title
            blf.color(font_id, font_color_r, font_color_g, font_color_b, font_color_alpha)
            blf.position(font_id, 450 + xmod, 260 + ymod, 0)
            blf.size(font_id, int(15*(size/10)) + 5, 72)
            blf.draw(font_id, mod.name )
            
            blf.color(font_id, font_color_r, font_color_g, font_color_b, font_color_alpha)
            blf.position(font_id, 450 + xmod, 250 + ymod, 0)
            blf.size(font_id, int(15 * (size / 10)) + 5, 72)
            blf.draw(font_id, "__________")

            #Level
            blf.color(font_id, font_color_r, font_color_g, font_color_b, font_color_alpha)
            blf.position(font_id, 450 + xmod, 220 + ymod + space_y, 0)
            blf.size(font_id, int(15*(size/10)), 72)
            blf.draw(font_id, "Width" )
                    
            blf.color(font_id, font_bool_color_r, font_bool_color_g, font_bool_color_b, font_bool_color_alpha)
            blf.position(font_id, 600 + xmod + 20*multsp , 220 + ymod + space_y, 0)
            blf.size(font_id, int(15*(size/10)), 72)
            blf.draw(font_id, "(MM) " + str(wdth_levl))
            
            blf.color(font_id, font_color_r, font_color_g, font_color_b, font_color_alpha)
            blf.position(font_id, 450 + xmod, 190 + ymod + space_y, 0)
            blf.size(font_id, int(15*(size/10)), 72)
            blf.draw(font_id, "Segments" )
            
            blf.color(font_id, font_bool_color_r, font_bool_color_g, font_bool_color_b, font_bool_color_alpha)
            blf.position(font_id, 600 + xmod + 20*multsp , 190 + ymod + space_y, 0)
            blf.size(font_id, int(15*(size/10)), 72)
            blf.draw(font_id, "(MM + Shift) " + str(segm_levl))
            
            #Limit Method
            blf.color(font_id, font_color_r, font_color_g, font_color_b, font_color_alpha)
            blf.position(font_id, 450 + xmod, 160 + ymod + space_y, 0)
            blf.size(font_id, int(15*(size/10)), 72)
            blf.draw(font_id, "Limit Method"  ) 
               
            blf.color(font_id, font_bool_color_r, font_bool_color_g, font_bool_color_b, font_bool_color_alpha)
            blf.position(font_id, 600 + xmod + 20*multsp , 160 + ymod + space_y, 0)
            blf.size(font_id, int(15*(size/10)), 72)
            if self._mode == 0:
                mode = bpy.context.object.modifiers[mod.name].limit_method = 'NONE'
            elif self._mode == 1:
                mode = bpy.context.object.modifiers[mod.name].limit_method = 'ANGLE'   
            elif self._mode == 2:
                mode = bpy.context.object.modifiers[mod.name].limit_method = 'WEIGHT'   
            elif self._mode == 3:
                mode = bpy.context.object.modifiers[mod.name].limit_method = 'VGROUP'        
            type_limit = "(Q) {0}".format(mode)
            blf.draw(font_id, type_limit)
            
            #Width Method
            blf.color(font_id, font_color_r, font_color_g, font_color_b, font_color_alpha)
            blf.position(font_id, 450 + xmod, 130 + ymod + space_y, 0)
            blf.size(font_id, int(15*(size/10)), 72)
            blf.draw(font_id, "Width Method"  ) 
                    
            blf.color(font_id, font_bool_color_r, font_bool_color_g, font_bool_color_b, font_bool_color_alpha)
            blf.position(font_id, 600 + xmod + 20*multsp , 130 + ymod + space_y, 0)
            blf.size(font_id, int(15*(size/10)), 72)
            if self._mode == 0:
                mode1 = bpy.context.object.modifiers[mod.name].offset_type = 'OFFSET'
            elif self._mode == 1:
                mode1 = bpy.context.object.modifiers[mod.name].offset_type = 'WIDTH'   
            elif self._mode == 2:
                mode1 = bpy.context.object.modifiers[mod.name].offset_type = 'DEPTH'   
            elif self._mode == 3:
                mode1 = bpy.context.object.modifiers[mod.name].offset_type = 'PERCENT'        
            width_met = "(Z) {0}".format(mode1)
            blf.draw(font_id, width_met)
                            
            #Keys
            blf.color(font_id, font_color_r, font_color_g, font_color_b, font_color_alpha)
            blf.position(font_id, 450 + xmod, 50, 0)
            blf.size(font_id, int(15*(size/10)), 72)
            blf.draw(font_id, "Exit"  ) 
            
            blf.color(font_id, font_bool_color_r, font_bool_color_g, font_bool_color_b, font_bool_color_alpha)
            blf.position(font_id, 600 + xmod + 20*multsp, 50, 0)
            blf.size(font_id, int(15*(size/10)), 72)
            blf.draw(font_id, "RMB/ESC"  ) 
            
            blf.color(font_id, font_color_r, font_color_g, font_color_b, font_color_alpha)
            blf.position(font_id, 450 + xmod, 30, 0)
            blf.size(font_id, int(15*(size/10)), 72)
            blf.draw(font_id, "Turn Off"  ) 
            
            blf.color(font_id, font_bool_color_r, font_bool_color_g, font_bool_color_b, font_bool_color_alpha)
            blf.position(font_id, 600 + xmod + 20*multsp, 30, 0)
            blf.size(font_id, int(15*(size/10)), 72)
            blf.draw(font_id, "(+ SHIFT)"  ) 
        
class Bevel_Modal(Operator):
    'Add Subsurf With Modal Operator'
    bl_idname = "object.bevel_modal"
    bl_label = "Bevel Modal"
        
    first_mouse_x : IntProperty()
    first_value : FloatProperty()
     
    def modal(self, context, event):  
        delta = self.first_mouse_x - event.mouse_x
                
        for obj in context.selected_objects:
            context.view_layer.objects.active=obj
            for mod in [m for m in obj.modifiers if m.type == 'BEVEL']:
                if mod :                                       
                    if event.type in {'MIDDLEMOUSE'}:
                        return {'PASS_THROUGH'}
                                                  
                    if event.type == 'MOUSEMOVE':
                        bpy.context.area.tag_redraw()
                        if event.shift:
                            mod.segments = self.first_value + delta *  -0.01 
                        else:
                            mod.width = self.first_value + delta *  -0.01 
                                                            
                    elif event.type == 'WHEELUPMOUSE':
                        self._mode = (self._mode + 1)  % 4
                        return {'RUNNING_MODAL'}
                        
                    elif event.type == 'Z' and event.value == 'PRESS':
                        self._mode = (self._mode + 1)  % 4
                        
                    elif event.type == 'A' and event.value == 'PRESS':
                        for ob in bpy.context.selected_objects:
                            bpy.context.view_layer.objects.active = ob
                            for mod in [m for m in ob.modifiers if m.type == 'BEVEL']:
                                bpy.ops.object.modifier_apply( modifier = mod.name )
                                return {'CANCELLED'}   
                    
                    elif event.type == 'LEFTMOUSE':
                        bpy.types.SpaceView3D.draw_handler_remove(self._handle, 'WINDOW')
                        return {'FINISHED'}
                    
                    elif event.type in {'RIGHTMOUSE', 'ESC'}:
                        context.object.location.x = self.first_value
                        bpy.types.SpaceView3D.draw_handler_remove(self._handle, 'WINDOW')
                        return {'CANCELLED'}                        
                    return {'RUNNING_MODAL'}
     
    def invoke(self, context, event):                                 
        if context.object:
            is_solid = False
            for mod in bpy.context.object.modifiers :
                if mod.type == 'BEVEL' :
                    is_solid = True
                    
            if not is_solid:
                for obj in context.selected_objects:
                    bpy.ops.object.bevel()
                for mod in obj.modifiers:
                    if mod.type == 'BEVEL':
                        mod.use_clamp_overlap = True
                        mod.loop_slide = False
                        mod.width = 0.3 
                        mod.segments = 1
                    
            self._mode = 0
            self.first_mouse_x = event.mouse_x
            for obj in context.selected_objects:
                context.view_layer.objects.active = obj
            for mod in obj.modifiers:
                if mod.type == 'BEVEL':
                    self.first_value = bpy.context.object.modifiers[mod.name].width

            # Draw Text
            args = (self, context)
            self._handle = bpy.types.SpaceView3D.draw_handler_add(draw_bevel, args, 'WINDOW', 'POST_PIXEL')            
            context.window_manager.modal_handler_add(self)
            return {'RUNNING_MODAL'}
        else:
            self.report({'WARNING'}, "Must Use In a 3D Region")
            return {'CANCELLED'}

C = bpy.context
class OBJECT_OT_make_proxy(bpy.types.Operator):
    """Saves the world from war and hunger"""
    bl_idname = "object.make_proxy"
    bl_label = "mProxy"
    bl_options = {'REGISTER', 'UNDO'}

    ratio: bpy.props.FloatProperty( name = "Decimate Ratio",
                                    description = "Does something",
                                    default = 0.25,
                                    min = 0, max = 1    
                                  )
    @classmethod
    def poll(cls, context):    
        return context.object is not None
    def execute(self, context): #This is apparently needed for the history panel to work
        if "mProxyDecimate" not in C.object.modifiers:
            bpy.ops.object.modifier_add(type='DECIMATE')
            C.object.modifiers[len(C.object.modifiers)-1].name = 'mProxyDecimate'
        C.object.modifiers["mProxyDecimate"].ratio = self.ratio
        return {'FINISHED'}

    def modal(self, context, event):

        if event.type == 'WHEELUPMOUSE':
            self.ratio += 0.02
            C.object.modifiers["mProxyDecimate"].ratio = self.ratio
        elif event.type == 'WHEELDOWNMOUSE':
            self.ratio -= 0.02
            C.object.modifiers["mProxyDecimate"].ratio = self.ratio
        elif event.type == 'LEFTMOUSE': #You need to be able to confirm it
            return {'FINISHED'}
        elif event.type in {'RIGHTMOUSE', 'ESC'}: #..and also to get out of it
            bpy.ops.object.modifier_remove(modifier="mProxyDecimate")
            return {'CANCELLED'}

        return {'RUNNING_MODAL'}

    def invoke(self, context, event):
        if context.object:
            if "mProxyDecimate" not in C.object.modifiers:
                bpy.ops.object.modifier_add(type='DECIMATE')
                C.object.modifiers[len(C.object.modifiers)-1].name = 'mProxyDecimate'
            C.object.modifiers["mProxyDecimate"].ratio = self.ratio
            context.window_manager.modal_handler_add(self)
            return {'RUNNING_MODAL'}
        else:
            self.report({'WARNING'}, "No active object, could not finish")
            return {'CANCELLED'}

                            
##Mirror
#def draw_mirror(self, context):

#    font_id = 0
#    region = context.region
#       
#    addon_preferences = get_addon_preferences()
#    size = addon_preferences.FontSizeModal
#    xmod = addon_preferences.PositionXModal
#    ymod = addon_preferences.PositionYModal
#    space = addon_preferences.Font_Space
#    space_y = addon_preferences.Font_Space_Y

#    font_color_r, font_color_g, font_color_b, font_color_alpha = addon_preferences.base_color
#    font_bool_color_r, font_bool_color_g, font_bool_color_b, font_bool_color_alpha = addon_preferences.bool_color

#    wdt2 = 0
#    multsp = space / 10

#    wdt2 = 0
#    if bpy.context.area.type == 'VIEW_3D':
#        for r in bpy.context.area.regions:
#            if r.type == 'TOOLS':
#                wdt2 = r.width - 1
#                self.regionwdt = wdt2
#                xmod = addon_preferences.PositionXModal + r.width - 1
#    
#    for obj in context.selected_objects:
#        context.view_layer.objects.active = obj
#    for mod in obj.modifiers:
#        if mod.type == 'MIRROR':    
#            cobj = context.active_object
#            merge = cobj.modifiers[mod.name].merge_threshold
#            a = cobj.modifiers[mod.name].use_x
#            b = cobj.modifiers[mod.name].use_y
#            c = cobj.modifiers[mod.name].use_z
#            cl = cobj.modifiers[mod.name].use_clip
#            #Title
#            blf.color(font_id, font_color_r, font_color_g, font_color_b, font_color_alpha)
#            blf.position(font_id, 450 + xmod, 150 + ymod, 0)
#            blf.size(font_id, int(15*(size/10)) + 5, 72)
#            blf.draw(font_id, mod.name )
#            
#            blf.color(font_id, font_color_r, font_color_g, font_color_b, font_color_alpha)
#            blf.position(font_id, 450 + xmod, 250 + ymod, 0)
#            blf.size(font_id, int(15 * (size / 10)) + 5, 72)
#            blf.draw(font_id, "__________")

#            #Axis
#            blf.color(font_id, font_color_r, font_color_g, font_color_b, font_color_alpha)
#            blf.position(font_id, 450 + xmod, 120 + ymod + space_y, 0)
#            blf.size(font_id, int(15*(size/10)), 72)
#            blf.draw(font_id, "Mirror Axis" )
#                
#            blf.color(font_id, font_bool_color_r, font_bool_color_g, font_bool_color_b, font_bool_color_alpha)
#            blf.position(font_id, 550 + xmod + 20*multsp , 120 + ymod + space_y, 0)
#            blf.size(font_id, int(15*(size/10)), 72)
#            blf.draw(font_id, "(X, Y, Z)"  ) 
#            
#            blf.color(font_id, font_color_r, font_color_g, font_color_b, font_color_alpha)
#            blf.position(font_id, 450 + xmod, 100 + ymod + space_y, 0)
#            blf.size(font_id, int(15*(size/10)), 72)
#            blf.draw(font_id, "X"  ) 
#            
#            blf.color(font_id, font_bool_color_r, font_bool_color_g, font_bool_color_b, font_bool_color_alpha)
#            blf.position(font_id, 480 + xmod + 20*multsp , 100 + ymod + space_y, 0)
#            blf.size(font_id, int(15*(size/10)), 72)
#            blf.draw(font_id, str(a))
#            
#            blf.color(font_id, font_color_r, font_color_g, font_color_b, font_color_alpha)
#            blf.position(font_id, 550 + xmod, 100 + ymod + space_y, 0)
#            blf.size(font_id, int(15*(size/10)), 72)
#            blf.draw(font_id, "Y"  ) 
#            
#            blf.color(font_id, font_bool_color_r, font_bool_color_g, font_bool_color_b, font_bool_color_alpha)
#            blf.position(font_id, 580 + xmod + 20*multsp , 100 + ymod + space_y, 0)
#            blf.size(font_id, int(15*(size/10)), 72)
#            blf.draw(font_id, str(b))
#            
#            blf.color(font_id, font_color_r, font_color_g, font_color_b, font_color_alpha)
#            blf.position(font_id, 630 + xmod, 100 + ymod + space_y, 0)
#            blf.size(font_id, int(15*(size/10)), 72)
#            blf.draw(font_id, "Z"  ) 
#            
#            blf.color(font_id, font_bool_color_r, font_bool_color_g, font_bool_color_b, font_bool_color_alpha)
#            blf.position(font_id, 660 + xmod + 20*multsp , 100 + ymod + space_y, 0)
#            blf.size(font_id, int(15*(size/10)), 72)
#            blf.draw(font_id, str(c))
#            
#            #Clipping
#            blf.color(font_id, font_color_r, font_color_g, font_color_b, font_color_alpha)
#            blf.position(font_id, 450 + xmod, 80 + ymod + space_y, 0)
#            blf.size(font_id, int(15*(size/10)), 72)
#            blf.draw(font_id, "Clipping"  ) 
#            
#            blf.color(font_id, font_bool_color_r, font_bool_color_g, font_bool_color_b, font_bool_color_alpha)
#            blf.position(font_id, 550 + xmod + 20*multsp , 80 + ymod + space_y, 0)
#            blf.size(font_id, int(15*(size/10)), 72)
#            blf.draw(font_id, "(C) " + str(cl))  
#                                                               
#            #Keys    
#            blf.color(font_id, font_color_r, font_color_g, font_color_b, font_color_alpha)
#            blf.position(font_id, 450 + xmod, 50, 0)
#            blf.size(font_id, int(15*(size/10)), 72)
#            blf.draw(font_id, "Exit"  ) 
#            
#            blf.color(font_id, font_bool_color_r, font_bool_color_g, font_bool_color_b, font_bool_color_alpha)
#            blf.position(font_id, 500 + xmod + 20*multsp, 50, 0)
#            blf.size(font_id, int(15*(size/10)), 72)
#            blf.draw(font_id, "ESC/RMB"  ) 
#            
#            blf.color(font_id, font_color_r, font_color_g, font_color_b, font_color_alpha)
#            blf.position(font_id, 450 + xmod, 30, 0)
#            blf.size(font_id, int(15*(size/10)), 72)
#            blf.draw(font_id, "Turn Off Value") 
#            
#            blf.color(font_id, font_bool_color_r, font_bool_color_g, font_bool_color_b, font_bool_color_alpha)
#            blf.position(font_id, 550 + xmod + 20*multsp, 30, 0)
#            blf.size(font_id, int(15*(size/10)), 72)
#            blf.draw(font_id, "(+ SHIFT)"  ) 
#                
#class Mirror_Modal(Operator):
#    'Add Mirror With Modal Operator'
#    bl_idname = "object.mirror_modal"
#    bl_label = "Mirror Modal"
#    bl_options = {'REGISTER', 'UNDO'}
#    
#    @classmethod
#    def poll(cls, context):
#        obj = context.active_object
#        if len([obj for obj in context.selected_objects if context.object is not None if obj.type in ['MESH','TEXT','CURVE'] ]) >= 1:
#            return True
#     
#    def modal(self, context, event):                  
#        for obj in context.selected_objects:
#            context.view_layer.objects.active=obj
#            for mod in [m for m in obj.modifiers if m.type == 'MIRROR']:
#                
#                bpy.ops.object.mode_set(mode="EDIT")
#                                        
#                if event.type == 'X' and event.value == 'PRESS':
#                    mod.use_x = True
#                    if event.ctrl:
#                        bpy.ops.tp_ops.mods_negativ_x_cut_obm()
#                    if event.alt:
#                        bpy.ops.tp_ops.mods_positiv_x_cut_obm()
#                    if event.shift:
#                        mod.use_x = False
#                        
#                elif event.type == 'Y' and event.value == 'PRESS':
#                    mod.use_y = True
#                    if event.shift:
#                        mod.use_y = False
#                    
#                elif event.type == 'Z' and event.value == 'PRESS':
#                    mod.use_z = True
#                    if event.shift:
#                        mod.use_z = False
#                        
#                elif event.type == 'C' and event.value == 'PRESS':
#                    mod.use_clip = True
#                    if event.shift:
#                        mod.use_clip = False
#                                                
#                elif event.type == 'A' and event.value == 'PRESS':
#                    for ob in bpy.context.selected_objects:
#                        bpy.context.scene.objects.active = ob
#                        for mod in [m for m in ob.modifiers if m.type == 'MIRROR']:
#                            bpy.ops.object.modifier_apply( modifier = mod.name )
#                            return {'CANCELLED'}  
#                                                        
#                elif event.type == 'LEFTMOUSE':
#                    bpy.types.SpaceView3D.draw_handler_remove(self._handle, 'WINDOW')
#                    return {'FINISHED'}
#                                    
#                elif event.type in {'RIGHTMOUSE', 'ESC'}:
#                    bpy.types.SpaceView3D.draw_handler_remove(self._handle, 'WINDOW')
#                    return {'CANCELLED'}        
#                return {'RUNNING_MODAL'}
#               
#    def invoke(self, context, event):
#        if context.object:
#            is_solid = False
#            for mod in bpy.context.object.modifiers :
#                if mod.type == 'MIRROR' :
#                    is_solid = True
#            if not is_solid:
#                bpy.ops.object.modifier_add(type='MIRROR')
#                bpy.context.object.modifiers["Mirror"].use_clip = True
#                
#            for obj in context.selected_objects:
#                for i, mod in enumerate(obj.modifiers):
#                    if mod.type == 'MIRROR':
#                        context.view_layer.objects.active=obj
#                        for x in range(0, i):
#                            bpy.ops.object.modifier_move_up(modifier=mod.name)
#                            self.report({'INFO'}, "Move Up Mirror modifier to first") 
#            
#            #Text in BGL
#            args = (self, context)
#            self._handle = bpy.types.SpaceView3D.draw_handler_add(draw_mirror, args, 'WINDOW', 'POST_PIXEL')                     
#            context.window_manager.modal_handler_add(self)
#            return {'RUNNING_MODAL'}
#        else:
#            self.report({'WARNING'}, "Must Use In a 3D Region")
#            return {'CANCELLED'}    


import bpy, bmesh, math
from math import * 
import bgl
import blf
import gpu
from gpu_extras.batch import batch_for_shader

vertices = (
    (60, 150), (500, 150), # bawah
    (60, 560), (500, 560)) # atas

indices = (
    (0, 1, 2), (2, 1, 3))

shader = gpu.shader.from_builtin('2D_UNIFORM_COLOR')
batch = batch_for_shader(shader, 'TRIS', {"pos": vertices}, indices=indices)
    
def draw_bevel(self, context):

    #box
    shader.bind()
    shader.uniform_float("color", (0.3, 0.3, 0.3, 0.7))
    batch.draw(shader)

    #text
    font_id = 0  
    x_offset = 0
    y_offset = 0

    if context.active_object.type == 'LIGHT': 
        for obj in context.visible_objects:              
            if obj != context.selected_objects:  
                if obj == context.view_layer.objects.active: 
                    if obj:

                        blf.color(font_id, 1, 1, 1, 0.7)
                        blf.position(font_id, 83, 530, 0)
                        blf.size(font_id, 15, 100)
                        blf.draw(font_id, obj.name + " - " + str(bpy.context.object.data.type))
                        
                        blf.color(font_id, 1, 1, 1, 0.7)
                        blf.position(font_id, 83, 520, 0)
                        blf.size(font_id, 15, 81)
                        blf.draw(font_id, "________________________________________________" )
                        
                        blf.color(font_id, 1, 1, 1, 0.7)
                        blf.position(font_id, 83, 500, 0)
                        blf.size(font_id, 15, 81)
                        blf.draw(font_id, "Lighting Shadow Parameters..." )
                        
                        blf.color(font_id, 1, 1, 1, 0.7)
                        blf.position(font_id, 83, 480, 0)
                        blf.size(font_id, 15, 81)
                        blf.draw(font_id, "Light R" )
                        
                        blf.color(font_id, 1, 1, 1, 0.7)
                        blf.position(font_id, 83, 460, 0)
                        blf.size(font_id, 15, 81)
                        blf.draw(font_id, "Light G" )
                        
                        blf.color(font_id, 1, 1, 1, 0.7)
                        blf.position(font_id, 83, 440, 0)
                        blf.size(font_id, 15, 81)
                        blf.draw(font_id, "Light B" )
                        
                        blf.color(font_id, 1, 1, 1, 0.7)
                        blf.position(font_id, 83, 420, 0)
                        blf.size(font_id, 15, 81)
                        blf.draw(font_id, "Energy" )
                        
                        blf.color(font_id, 1, 1, 1, 0.7)
                        blf.position(font_id, 83, 400, 0)
                        blf.size(font_id, 15, 81)
                        blf.draw(font_id, "Specular" )
                        
                        if context.object.data.type in {'POINT', 'SPOT'}:
                            blf.color(font_id, 1, 1, 1, 0.7)
                            blf.position(font_id, 83, 380, 0)
                            blf.size(font_id, 15, 81)
                            blf.draw(font_id, "Radius" )
                            
                            blf.color(font_id, 0, 1, 0.232, 0.7)
                            blf.position(font_id, 400, 380, 0)
                            blf.size(font_id, 15, 81)
                            blf.draw(font_id, str(round(bpy.context.object.data.shadow_soft_size, 2)))  
                            
                            if context.object.data.type == 'SPOT':
                                
                                blf.color(font_id, 1, 1, 1, 0.7)
                                blf.position(font_id, 83, 360, 0)
                                blf.size(font_id, 15, 81)
                                blf.draw(font_id, "Spot Shape" )
                                
                                blf.color(font_id, 0, 1, 0.232, 0.7)
                                blf.position(font_id, 400, 360, 0)
                                blf.size(font_id, 15, 81)
                                blf.draw(font_id, str(round(math.degrees(bpy.context.object.data.spot_size), 1))+ "°")
                                
                                blf.color(font_id, 1, 1, 1, 0.7)
                                blf.position(font_id, 83, 340, 0)
                                blf.size(font_id, 15, 81)
                                blf.draw(font_id, "Spot Blend" )
                                
                                blf.color(font_id, 0, 1, 0.232, 0.7)
                                blf.position(font_id, 400, 340, 0)
                                blf.size(font_id, 15, 81)
                                blf.draw(font_id, str(round(bpy.context.object.data.spot_blend, 2)))  
                            
                        
                        elif context.object.data.type == 'SUN':
                            blf.color(font_id, 1, 1, 1, 0.7)
                            blf.position(font_id, 83, 380, 0)
                            blf.size(font_id, 15, 81)
                            blf.draw(font_id, "Angle" )
                            
                            blf.color(font_id, 0, 1, 0.232, 0.7)
                            blf.position(font_id, 400, 380, 0)
                            blf.size(font_id, 15, 81)
                            blf.draw(font_id, str(round(math.degrees(bpy.context.object.data.angle), 1))+ "°")
                            
                        elif context.object.data.type == 'AREA':
                            blf.color(font_id, 1, 1, 1, 0.7)
                            blf.position(font_id, 83, 380, 0)
                            blf.size(font_id, 15, 81)
                            blf.draw(font_id, "Shape" )
                            
                            blf.color(font_id, 0, 1, 0.232, 0.7)
                            blf.position(font_id, 400, 380, 0)
                            blf.size(font_id, 15, 81)
                            blf.draw(font_id, str(bpy.context.object.data.shape))
                            
                            if bpy.context.object.data.shape in {'SQUARE', 'DISK'}:
                                blf.color(font_id, 1, 1, 1, 0.7)
                                blf.position(font_id, 83, 360, 0)
                                blf.size(font_id, 15, 81)
                                blf.draw(font_id, "Size" )
                                
                                blf.color(font_id, 0, 1, 0.232, 0.7)
                                blf.position(font_id, 400, 360, 0)
                                blf.size(font_id, 15, 81)
                                blf.draw(font_id, str(round(bpy.context.object.data.size, 2)))  
                         
                            elif bpy.context.object.data.shape in {'RECTANGLE', 'ELLIPSE'}:
                                
                                blf.color(font_id, 1, 1, 1, 0.7)
                                blf.position(font_id, 83, 360, 0)
                                blf.size(font_id, 15, 81)
                                blf.draw(font_id, "Size X" )
                                
                                blf.color(font_id, 0, 1, 0.232, 0.7)
                                blf.position(font_id, 400, 360, 0)
                                blf.size(font_id, 15, 81)
                                blf.draw(font_id, str(round(bpy.context.object.data.size, 2)))  
                                
                                blf.color(font_id, 1, 1, 1, 0.7)
                                blf.position(font_id, 83, 340, 0)
                                blf.size(font_id, 15, 81)
                                blf.draw(font_id, "Size Y" )
                                
                                blf.color(font_id, 0, 1, 0.232, 0.7)
                                blf.position(font_id, 400, 340, 0)
                                blf.size(font_id, 15, 81)
                                blf.draw(font_id, str(round(bpy.context.object.data.size_y, 2)))  
                        
                        blf.color(font_id, 1, 1, 1, 0.7)
                        blf.position(font_id, 83, 330, 0)
                        blf.size(font_id, 15, 81)
                        blf.draw(font_id, "________________________________________________" )
                
                        blf.color(font_id, 1, 1, 1, 0.7)
                        blf.position(font_id, 83, 300, 0)
                        blf.size(font_id, 15, 81)
                        blf.draw(font_id, "Shadow" )  
                            
                        blf.color(font_id, 1, 1, 1, 0.7)
                        blf.position(font_id, 83, 280, 0)
                        blf.size(font_id, 15, 81)
                        blf.draw(font_id, "Clip Start" )
                        
                        blf.color(font_id, 1, 1, 1, 0.7)
                        blf.position(font_id, 83, 260, 0)
                        blf.size(font_id, 15, 81)
                        blf.draw(font_id, "Bias" )
                        
                        blf.color(font_id, 1, 1, 1, 0.7)
                        blf.position(font_id, 83, 250, 0)
                        blf.size(font_id, 15, 81)
                        blf.draw(font_id, "________________________________________________" )
                        
                        blf.color(font_id, 1, 1, 1, 0.7)
                        blf.position(font_id, 83, 220, 0)
                        blf.size(font_id, 15, 81)
                        blf.draw(font_id, "Rotation X" )
                        
                        blf.color(font_id, 1, 1, 1, 0.7)
                        blf.position(font_id, 83, 200, 0)
                        blf.size(font_id, 15, 81)
                        blf.draw(font_id, "Rotation Y" )
                        
                        blf.color(font_id, 1, 1, 1, 0.7)
                        blf.position(font_id, 83, 180, 0)
                        blf.size(font_id, 15, 81)
                        blf.draw(font_id, "Rotation Z" )
                        
                        ################################### LIGHTING VALUE #############################################

                        blf.color(font_id, 0, 1, 0.232, 0.7)
                        blf.position(font_id, 400, 480, 0)
                        blf.size(font_id, 15, 81)
                        blf.draw(font_id, str(round(bpy.context.object.data.color[0], 3)))
                        
                        blf.color(font_id, 0, 1, 0.232, 0.7)
                        blf.position(font_id, 400, 460, 0)
                        blf.size(font_id, 15, 81)
                        blf.draw(font_id, str(round(bpy.context.object.data.color[1], 3)))
                        
                        blf.color(font_id, 0, 1, 0.232, 0.7)
                        blf.position(font_id, 400, 440, 0)
                        blf.size(font_id, 15, 81)
                        blf.draw(font_id, str(round(bpy.context.object.data.color[2], 3)))
                        
                        blf.color(font_id, 0, 1, 0.232, 0.7)
                        blf.position(font_id, 400, 420, 0)
                        blf.size(font_id, 15, 81)
                        blf.draw(font_id, str(round(bpy.context.object.data.energy, 2)))   
                        
                        blf.color(font_id, 0, 1, 0.232, 0.7)
                        blf.position(font_id, 400, 400, 0)
                        blf.size(font_id, 15, 81)
                        blf.draw(font_id, str(round(bpy.context.object.data.specular_factor, 2)))  
                        
                        if bpy.context.object.data.use_shadow == True: 
                            blf.color(font_id, 0, 1, 0.232, 0.7)
                            blf.position(font_id, 400, 300, 0)
                            blf.size(font_id, 15, 81)
                            blf.draw(font_id, str(bpy.context.object.data.use_shadow))   
                        else:
                            blf.color(font_id, 1, 0.053, 0.074, 1)
                            blf.position(font_id, 400, 300, 0)
                            blf.size(font_id, 15, 81)
                            blf.draw(font_id, str(bpy.context.object.data.use_shadow)) 
                            
                        blf.color(font_id, 0, 1, 0.232, 0.7)
                        blf.position(font_id, 400, 280, 0)
                        blf.size(font_id, 15, 81)
                        blf.draw(font_id, str(round(bpy.context.object.data.shadow_buffer_clip_start, 2)))  
                        
                        blf.color(font_id, 0, 1, 0.232, 0.7)
                        blf.position(font_id, 400, 260, 0)
                        blf.size(font_id, 15, 81)
                        blf.draw(font_id, str(round(bpy.context.object.data.shadow_buffer_bias, 2)))         
                        
                        ################################### ROTATION VALUE #############################################
                        blf.color(font_id, 0, 1, 0.232, 0.7)
                        blf.position(font_id, 400, 220, 0)
                        blf.size(font_id, 15, 81)
                        rotationX = obj.rotation_euler[0]
                        blf.draw(font_id, str(round(math.degrees(rotationX) ,2)))
                        
                        blf.color(font_id, 0, 1, 0.232, 0.7)
                        blf.position(font_id, 400, 200, 0)
                        blf.size(font_id, 15, 81)
                        rotationY = obj.rotation_euler[1]
                        blf.draw(font_id, str(round(math.degrees(rotationY) ,2)))
                        
                        blf.color(font_id, 0, 1, 0.232, 0.7)
                        blf.position(font_id, 400, 180, 0)
                        blf.size(font_id, 15, 81)
                        rotationZ = obj.rotation_euler[2]
                        blf.draw(font_id, str(round(math.degrees(rotationZ) ,2)))     
                                  

class BevelSetModal(bpy.types.Operator):
    """Move an object with the mouse, example"""
    bl_idname = "bevel.set_operator"
    bl_label = "Bevel Set modal"

    first_mouse_x : IntProperty()
    first_value : FloatProperty()

    def modal(self, context, event):
        ob = context.object 
        lamp = ob.data
        if context.area and context.area.type == 'VIEW_3D':
            context.area.tag_redraw()  
            
            # if event.type == 'E':
            #     delta = event.mouse_x - self.first_mouse_x
            #     lamp.energy  = self.first_value + delta * 0.02

            if event.type in {'MOUSEMOVE', 'WHEELUPMOUSE', 'WHEELDOWNMOUSE'}:
                return {'PASS_THROUGH'}

            if event.type == "ESC":
                bpy.types.SpaceView3D.draw_handler_remove(self._handle, 'WINDOW')
                return {'CANCELLED'}            
        return {'PASS_THROUGH'} 
        
    def invoke(self, context, event):
        
        if context.area.type == 'VIEW_3D':         
            args = (self, context)            
            self._handle = bpy.types.SpaceView3D.draw_handler_add(draw_bevel, args, 'WINDOW', 'POST_PIXEL')
            self.mouse_path = []
            
        if context.object:
            self.first_mouse_x = event.mouse_x
#            ob = context.object 
#            lamp = ob.data
#            self.first_value = lamp.energy
            context.window_manager.modal_handler_add(self) 

            return {'RUNNING_MODAL'}
        else:
            self.report({'WARNING'}, "No active object, could not finish")
            return {'CANCELLED'}
        