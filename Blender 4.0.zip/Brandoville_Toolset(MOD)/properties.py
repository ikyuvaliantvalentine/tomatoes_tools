import bpy, os
from bpy.props import *
from bpy.types import PropertyGroup

def get_addon_preferences():
    addon_name = os.path.basename(os.path.dirname(os.path.abspath(__file__).split("utils")[0]))
    user_preferences = bpy.context.preferences
    addon_prefs = user_preferences.addons[addon_name].preferences     
    return addon_prefs

def dpifac():
    prefs = bpy.context.preferences.system
    # python access to this was only added recently, assume non-retina display is used if using older blender
    if hasattr(prefs, "pixel_size"):
        retinafac = bpy.context.preferences.system.pixel_size
    else:
        retinafac = 1
    return bpy.context.preferences.system.dpi / (72 / retinafac)

types_one =  [("red_c0", "Asset/Scene Management", "Asset/Scene Management", "ASSET_MANAGER" ,0),
              ("red_c1", "Modelling Utilities", "ModellingUtilities","COLLAPSEMENU", 1), 
              ("red_c2", "Shading", "Shading", "NODE_MATERIAL", 2),
              ("red_c3", "Renamer", "Renamer", "FILE_FONT", 3),
              ("red_c4", "Lookdev", "Lookdev", "OUTLINER_OB_LIGHT", 4),]

# ------------------------------------------------------------------------              
#   Property Group
# ------------------------------------------------------------------------    
class Dropdown_RedProject_Props(PropertyGroup):
    red_create : EnumProperty(name = "Choose UI", default = "red_c0", items = types_one)

    display_uv_sets : BoolProperty(name="UV Sets", description="open / close", default=False)
    display_origin : BoolProperty(name="Origin", description="open / close", default=True)
    display_relation : BoolProperty(name="Relations", description="open / close", default=False)
    display_add_modifier : BoolProperty(name="Add Modifier", description="open / close", default=False)
    display_mesh_edit : BoolProperty(name="Mesh Edit", description="open / close", default=True)
    display_camera : BoolProperty(name="Camera Settings", description="open / close", default=False)

    hide_name: BoolProperty(
        name="Hide Name List",
        description="Hide Name List",
        default = True)
    
    # ------------------------------------------------------------------------              
    #   Renamer 
    # ------------------------------------------------------------------------   
    
    regex_search_pattern: StringProperty(
        name="Search String",
        default="")
    
    regex_replacement_string: StringProperty(
        name="Replacement String",
        default="")
    
    prefix : StringProperty(name="Prefix",
                    description="Put your Prefix here",
                    default="")

    suffix : StringProperty(name="Suffix",
                    description="Put your Suffix here",
                    default="")
    
    # ------------------------------------------------------------------------              
    #   Asset Saver
    # ------------------------------------------------------------------------   

    asset_type: EnumProperty(
        items=[
            ('CHAR', 'Char', 'Character'),
            ('PROP', 'Props', 'Props'),
            ('SET', 'Sets', 'Sets')
        ],
        default='CHAR'
    )    
    
    asset_jobtype: EnumProperty(
        items=[
            ('Proxy', 'Proxy', 'Proxy'),
            ('Model', 'Model', 'Model'),
        ],
        default='Proxy'
    )   
    
    save_filename : StringProperty(
            name="Filename",
            default="",
            description="Set Filename")  
    

    # ------------------------------------------------------------------------              
    #  Camera UI
    # ------------------------------------------------------------------------ 

    cam_composition_ui_is_visible : BoolProperty(
        name = "Use Camera Composition",
        description = "Show/hide the Use Camera Composition UI.",
        default = False)