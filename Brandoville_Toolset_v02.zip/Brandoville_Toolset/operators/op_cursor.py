import bpy
import rna_keymap_ui
from bpy.types import Operator, Menu, AddonPreferences, Panel
from bpy.props import (StringProperty,
                       BoolProperty,
                       PointerProperty,
                       FloatVectorProperty,
                       FloatProperty,
                       EnumProperty,
                       IntProperty,
                       BoolVectorProperty,
                       CollectionProperty)


# MODAL
selection = list()
class SMARTCURSOR_OT_Modal(Operator):
    """    CLICK - Snap VERTEX
    SHIFT - Snap FACES
    CTRL  - Snap EDGES
    ALT    - Snap INCREMENT
    ALT + SHIFT - On Axis pressing MMB
    CTRL + ALT - MIX INCREMENT
    CTRL + SHIFT - Origin To Cursor
    """
    bl_idname = "op.smart_cursor_modal"
    bl_label = "Smart Pivot"

    first_mouse_x: IntProperty()
    count = 0

    @classmethod
    def poll(cls, context):
        if context.object is None:
            return False
        return True

    def modal(self, context, event):
        self.count += 1

        if self.count == 1:
            bpy.ops.transform.translate('INVOKE_DEFAULT')

        if event.type in {'MIDDLEMOUSE', 'WHEELUPMOUSE', 'WHEELDOWNMOUSE'}:
            return {'PASS_THROUGH'}

        # ---------------------------------------
        # Apply Cursor Location and/or Origin
        # ---------------------------------------
        if event.type == 'LEFTMOUSE':
            bpy.ops.view3d.snap_cursor_to_selected()
            bpy.ops.object.delete()

            if selection:
                for obj in selection:
                    obj.select_set(state=True)
                    bpy.ops.object.origin_set(type='ORIGIN_CURSOR')

                    context.view_layer.objects.active = self.act_obj
                    if self.edit_mode:
                        bpy.ops.object.mode_set(mode='EDIT')

            self.first_mouse_x = event.mouse_x

            del (selection[:])

            if self.wire_mode_on == False:
                context.object.show_wire = False
                context.object.show_all_edges = False

            if self.snap_active == False:
                context.scene.tool_settings.use_snap = False

            context.scene.tool_settings.snap_elements = self.snap_mode

            self.on_axis = False
            self.wire_mode_on = False
            self.edit_mode = False
            self.snap_active = False

            return {'FINISHED'}

        # ---------------------------------
        # ESCAPE
        # ---------------------------------
        if event.type in {'RIGHTMOUSE', 'ESC', 'SPACE'}:
            bpy.ops.object.delete()
            if selection:
                for obj in selection:
                    obj.select_set(state=True)
                    self.act_obj.select_set(state=True)
                    context.view_layer.objects.active = self.act_obj
                    if self.edit_mode:
                        bpy.ops.object.mode_set(mode='EDIT')

            self.first_mouse_x = event.mouse_x

            del (selection[:])

            context.scene.cursor.location[0] = self.saved_location_x
            context.scene.cursor.location[1] = self.saved_location_y
            context.scene.cursor.location[2] = self.saved_location_z

            if self.wire_mode_on == False:
                context.object.show_wire = False
                context.object.show_all_edges = False

            if self.snap_active == False:
                context.scene.tool_settings.use_snap = False

            context.scene.tool_settings.snap_elements = self.snap_mode

            self.on_axis = False
            self.wire_mode_on = False
            self.edit_mode = False
            self.snap_active = False

            return {'CANCELLED'}

        return {'RUNNING_MODAL'}

    def invoke(self, context, event):
        self.saved_location_x = context.scene.cursor.location[0]
        self.saved_location_y = context.scene.cursor.location[1]
        self.saved_location_z = context.scene.cursor.location[2]

        self.wire_mode_on = False
        self.edit_mode = False
        self.snap_active = False
        self.snap_mode = context.scene.tool_settings.snap_elements
        self.on_axis = False

        self.translation_x = event.mouse_x
        self.translation_y = event.mouse_y

        if context.scene.tool_settings.use_snap == True:
            self.snap_active = True

        if context.object is not None and context.selected_objects:
            self.act_obj = context.active_object

            if context.object.show_wire == True:
                self.wire_mode_on = True
            else:
                context.object.show_wire = True
                context.object.show_all_edges = True

            if context.object.mode == "EDIT":
                self.edit_mode = True

            bpy.ops.object.mode_set(mode='OBJECT')

            if len(context.selected_objects):
                for obj in context.selected_objects:
                    selection.append(obj)
            
            context.scene.tool_settings.snap_elements = {'VERTEX'}
            context.scene.tool_settings.snap_target = 'MEDIAN'
            context.scene.tool_settings.use_snap_align_rotation = False

            # # On Cursor
            # if event.ctrl and event.shift:
            #     bpy.ops.object.origin_set(type='ORIGIN_CURSOR')
            #     return {'FINISHED'}

            # # On Axis
            # elif event.shift and event.alt:
            #     context.scene.tool_settings.use_snap = False
            #     context.scene.tool_settings.snap_elements = {'VERTEX', 'EDGE', 'FACE'}
            #     context.scene.tool_settings.use_snap_align_rotation = False
            #     self.on_axis = True

            #     # Mix
            # elif event.alt and event.ctrl:
            #     context.scene.tool_settings.snap_elements = {'VERTEX', 'EDGE', 'FACE'}
            #     # bpy.ops.view3d.cursor3d('INVOKE_DEFAULT')

            # # Face
            # elif event.shift:
            #     context.scene.tool_settings.snap_elements = {'FACE'}
            #     context.scene.tool_settings.use_snap_align_rotation = False
            #     context.scene.tool_settings.snap_target = 'MEDIAN'

            # # Edge
            # elif event.ctrl:
            #     context.scene.tool_settings.snap_elements = {'EDGE'}
            #     context.scene.tool_settings.snap_target = 'MEDIAN'

            # # Increment
            # elif event.alt:
            #     context.scene.tool_settings.snap_elements = {'INCREMENT'}
            #     context.scene.tool_settings.use_snap_grid_absolute = True

            # # Vertex
            # else:
            #     context.scene.tool_settings.snap_elements = {'VERTEX'}
            #     context.scene.tool_settings.snap_target = 'MEDIAN'
            #     context.scene.tool_settings.use_snap_align_rotation = False

            if not self.on_axis:
                bpy.ops.view3d.cursor3d('INVOKE_DEFAULT')
                if context.scene.tool_settings.use_snap == False:
                    context.scene.tool_settings.use_snap = True

            bpy.ops.object.select_all(action='DESELECT')
            bpy.ops.object.empty_add(type='PLAIN_AXES', radius=0.2, align='WORLD', location=(
            context.scene.cursor.location[0], context.scene.cursor.location[1], context.scene.cursor.location[2]),
                                     scale=(1, 1, 1))

            context.window_manager.modal_handler_add(self)
            self.first_mouse_x = event.mouse_x

            return {'RUNNING_MODAL'}
        else:
            self.report({'WARNING'}, "No active object, could not finish")
            return {'CANCELLED'}

