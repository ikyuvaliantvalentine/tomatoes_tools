# This file is part of Instant Clean
# Copyright (C) 2023  Ruben Messerschmidt

import bpy
import addon_utils
from .super_panel import Super_Panel
from .layout_temps import sub_layout, results_layout
from ..ops.presets_op import BC_MT_Preset_Menu


class BC_PT_Main_Panel(Super_Panel):
    bl_idname='bc.main_panel'
    bl_label='Instant Clean'

    version = [addon.bl_info.get('version', (-1,-1,-1)) for addon in addon_utils.modules() if addon.bl_info['name'] == 'Instant Clean'][0]

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        pg = scene.bc_misc

        col = layout.column()
        
        col.enabled = False
        col.label(text=f'Instant Clean v{self.version[0]}.{self.version[1]}.{self.version[2]}')

        sub = sub_layout(layout, 3)

        
        col.separator()
        
        row = sub.row()
        row.scale_y = 2
        txt = 'Clean'
        op = 'bc.clean'
        if bpy.context.mode not in ('OBJECT', 'EDIT_MESH'):
            txt = 'Mode not supported'
            row.enabled = False
        elif pg.results:
            txt = 'Close Results'
            op = 'bc.close_results'
        row.operator(op, text=txt)
        row.separator(factor=1.8)

        if not pg.results:
            row = sub.row(align=True)
            row.menu(BC_MT_Preset_Menu.__name__, text=BC_MT_Preset_Menu.bl_label)
            row.operator('bc.override_preset', text='', icon='DUPLICATE')
            row.operator('bc.add_preset', text='', icon='ADD')
            row.operator('bc.add_preset', text='', icon='REMOVE').remove_active = True
            row.separator(factor=3)

        else:
            sub.separator()
            sub.label(text='Overall')
            row = sub.row()
            results_layout(row, bpy.context.scene['Stats'])
            row.separator()


