import bpy
import os
import re
from bpy.types import Operator
from .. properties import *
from .. ui.ui_pyside_assetchecker import *
from PySide2.QtWidgets import *


class WIPSaveBlend(Operator):
    bl_label = "Initial Save"
    bl_idname = "op.initial_save"
    bl_description = "Initial Save"
    dialog_width =  350
              
    def draw(self, context):
        layout = self.layout
        red = context.scene.red_props
        box_assetsaver = layout.box()
        box_assetsaver.scale_x = 1.3
        box_assetsaver.scale_y = 1.3
        box_assetsaver.label(text="Asset Category:")
        row = box_assetsaver.row()
        row.prop(red, "asset_type", expand=True)
        row = box_assetsaver.row()
        row.prop(red, "asset_jobtype", expand=True)
        box_assetsaver.prop(red, "save_filename")
             
    # def check(self, context):
    #     return True    
    
    def create_collection(self, collection_name):
        # Check if the collection already exists
        if collection_name not in bpy.data.collections:
            new_collection = bpy.data.collections.new(collection_name)
            bpy.context.scene.collection.children.link(new_collection)
        
    def execute(self, context):
        red = context.scene.red_props
        addon_preferences = get_addon_preferences()
        my_dir = addon_preferences.settingsFilePath
        savename = red.save_filename
        asset_type = red.asset_type
        asset_jobtype = red.asset_jobtype

        if not savename:
            self.report({'ERROR'}, "Please enter a valid filename.")
            return {'CANCELLED'}

        wip_folder = f"{my_dir}/{asset_type}/{savename}/{asset_jobtype}/WIP"
        if not os.path.exists(wip_folder):
            os.makedirs(wip_folder)
            
        # Set the version number to 1
        version = 1
        
        prefix = "ETY_"
        type = "_MOD"
        jobtype = "_WIP"
        
        file_exists = True
        while file_exists:
            # Generate the filename with the current version number
            filename = f"{my_dir}/{asset_type}/{savename}/{asset_jobtype}/WIP/{prefix}{savename}{type}{jobtype}_v{version:03d}.blend"

            # Check if the file already exists
            if os.path.exists(filename):
                version += 1
            else:
                file_exists = False
                
        bpy.ops.wm.save_as_mainfile(filepath=f"{my_dir}/{asset_type}/{savename}/{asset_jobtype}/WIP/{prefix}{savename}{type}{jobtype}_v{version:03d}.blend", \
            relative_remap=True, compress=True, check_existing=True)

        self.report({'INFO'}, "Successfully created file at " + filename)
        
        # Create a new collection based on savename
        collection_name = f"{savename}"
        self.create_collection(collection_name)

        return {"FINISHED"}   
     
    def invoke(self, context, event):
        wm = context.window_manager
        self.scale = get_addon_preferences().scale
        window_size = (context.window.width/250)/dpifac()
        if bpy.app.version >= (3, 0, 0):
            return wm.invoke_props_dialog(self, width = int(self.dialog_width * window_size * self.scale))
        else:
            return wm.invoke_props_dialog(self, width = self.dialog_width * window_size * self.scale)
        # return {"RUNNING_MODAL"} 
        # return context.window_manager.invoke_props_dialog(self)
    
class FileIncrementalSave(Operator):
    bl_idname = "op.assetsave_incremental_backup"
    bl_label = "Save Incremental"
   
    def execute(self, context):        
        # Get the current scene file name
        file_name = bpy.data.filepath

        # Check if the file has been saved
        if not file_name:
            raise ValueError("The current scene has not been saved.")

        # Extract the version number from the file name
        match = re.search(r"_v\d\d\d", file_name)
        if not match:
            raise ValueError("The file name does not contain a version number.")

        # Increment the version number
        version = int(match.group()[2:]) + 1
        new_suffix = "_v{:03d}".format(version)

        # Replace the old suffix with the new suffix
        new_file_name = file_name.replace(match.group(), new_suffix)

        # Save the file with the new name
        bpy.ops.wm.save_as_mainfile(filepath=new_file_name, relative_remap=True, compress=True, check_existing=True)

        # Show a dialog box indicating that the file was saved successfully
        self.report({'INFO'}, "Successfully updated version file ")
        return {'FINISHED'}
    
#class WIPSaveBlend(Operator):
#    """Saving Blend File For WIP Version"""
#    bl_idname = "op.assetsave_wip"
#    bl_label = "Initial Save"

#    def execute(self, context):               
#        red = context.scene.red_props
#        addon_preferences = get_addon_preferences()
#        my_dir = addon_preferences.settingsFilePath
#        savename = red.save_filename
#        asset_type = red.asset_type

#        if not savename:
#            self.report({'ERROR'}, "Please enter a valid filename.")
#            return {'CANCELLED'}

#        wip_folder = f"{my_dir}/{asset_type}/{savename}/WIP"
#        if not os.path.exists(wip_folder):
#            os.makedirs(wip_folder)
#            
#        # Set the version number to 1
#        version = 1
#        
#        prefix = "ALM_"
#        type = "_MOD"
#        jobtype = "_WIP"
#        
#        file_exists = True
#        while file_exists:
#            # Generate the filename with the current version number
#            filename = f"{my_dir}/{asset_type}/{savename}/WIP/{prefix}{savename}{type}{jobtype}_v{version:03d}.blend"

#            # Check if the file already exists
#            if os.path.exists(filename):
#                version += 1
#            else:
#                file_exists = False
#                
#        bpy.ops.wm.save_as_mainfile(filepath=f"{my_dir}/{asset_type}/{savename}/WIP/{prefix}{savename}{type}{jobtype}_v{version:03d}.blend", \
#            relative_remap=True, compress=True, check_existing=True)

#        self.report({'INFO'}, "Successfully created file at " + filename)

#        return {'FINISHED'}
    

class PublishSaveBlend(Operator):
    """Saving Blend File For WIP Version"""
    bl_idname = "op.assetsave_publish"
    bl_label = "Publish"

    def execute(self, context):                       
        red = context.scene.red_props
        addon_preferences = get_addon_preferences()
        my_dir = addon_preferences.settingsFilePath
        savename = red.save_filename
        asset_type = red.asset_type
        asset_jobtype = red.asset_jobtype
        
        # Validate before publishing
        # Call the Window First
        app = QApplication.instance()
        if not app:
            app = QApplication(sys.argv)

        # Validate before publishing
        validation_checker = ValidationChecker()
        validation_issues = validation_checker.validate_before_publish()

        if validation_issues:
            validation_checker.show()
            self.report({'ERROR'}, f"Validation failed. Please fix the following issues: {', '.join(validation_issues)}")
            return {'CANCELLED'}

        if bpy.data.is_saved:
            publish_folder = f"{my_dir}/{asset_type}/{savename}/{asset_jobtype}/Published"
            if not os.path.exists(publish_folder):
                os.makedirs(publish_folder)
                
            # Set the version number to 1
            version = 1
            
            prefix = "ETY_"
            type = "_MOD"
            jobtype = "_Published"
            
            file_exists = True
            while file_exists:
                # Generate the filename with the current version number
                filename = f"{my_dir}/{asset_type}/{savename}/{asset_jobtype}/Published/{prefix}{savename}{type}{jobtype}_v{version:03d}.blend"  # Change "WIP" to "Publish"

                # Check if the file already exists
                if os.path.exists(filename):
                    version += 1
                else:
                    file_exists = False
                    
            bpy.ops.wm.save_as_mainfile(filepath=f"{my_dir}/{asset_type}/{savename}/{asset_jobtype}/Published/{prefix}{savename}{type}{jobtype}_v{version:03d}.blend", \
                relative_remap=True, compress=True, check_existing=True)
            
            self.report({'INFO'}, "Successfully Published file at " + publish_folder)
            
        #     #################################################################
        #     #   AUTOMATIC EXPORT FBX
        #     #################################################################
        #     # Get the current blend file name
        #     blend_file_name = bpy.path.basename(bpy.context.blend_data.filepath)

        #     # Remove the file extension from the blend file name
        #     blend_file_name = os.path.splitext(blend_file_name)[0]

        #     # Set the base output directory
        #     base_output_dir = "E:/02_PIPELINE/NAME_PROJECTS/03_FinalAssets"

        #     # Create the base output directory if it doesn't exist
        #     if not os.path.exists(base_output_dir):
        #         os.makedirs(base_output_dir)

        #     # # Remove "_MOD" and the existing version number from the base name
        #     base_name = re.sub(r'_MOD_Publish_v\d+', '', blend_file_name)
        #     # base_name = base_name.replace("_MOD", "")

        #     # Remove the "ALM_" prefix from the base name
        #     base_name = base_name.replace("ALM_", "")

        #     # Create the new directory inside the base output directory
        #     output_dir = os.path.join(base_output_dir, base_name)

        #     # Find the latest version number
        #     latest_version = 0
        #     if os.path.exists(output_dir):
        #         for folder_name in os.listdir(output_dir):
        #             match = re.search(r"v(\d+)", folder_name)
        #             if match:
        #                 version = int(match.group(1))
        #                 latest_version = max(latest_version, version)

        #     # Increment the latest version number
        #     new_version = latest_version + 1

        #     # Format the new version number with leading zeros
        #     version_string = f"v{str(new_version).zfill(3)}"

        #     # Create the versioned output directory
        #     output_dir = os.path.join(output_dir, version_string)

        #     # Create the output directory if it doesn't exist
        #     if not os.path.exists(output_dir):
        #         os.makedirs(output_dir)

        #     # Get all mesh objects in the scene
        #     mesh_objects = [obj for obj in bpy.context.scene.objects if obj.type == 'MESH']

        #     # Export each mesh object as a separate FBX file
        #     for obj in mesh_objects:
        #         # Select the current object
        #         bpy.context.view_layer.objects.active = obj
        #         obj.select_set(True)

        #         # Set the output file path
        #         output_file = os.path.join(output_dir, obj.name + ".fbx")

        #         # Export the selected object as FBX
        #         bpy.ops.export_scene.fbx(
        #             filepath=output_file,
        #             use_selection=True,
        #             object_types={'MESH'},
        #             bake_space_transform=True
        #         )

        #         # Deselect the object
        #         obj.select_set(False)

        #     self.report({'INFO'}, "The file was published successfully")
            
        # else:
        #     self.report({'ERROR'}, "The file has not been saved yet.")
        #     return {'CANCELLED'}

        return {'FINISHED'}