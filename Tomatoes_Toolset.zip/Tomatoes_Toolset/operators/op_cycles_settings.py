import bpy, os
from bpy.types import Operator, Panel

class SetHdri(Operator):
    "Set Cycles HDRI Node"
    bl_label="Set HDRI Cycles"
    bl_idname="cycles.hdri_world"
    filepath : bpy.props.StringProperty(subtype="FILE_PATH")

    def draw(self, context):
        self.layout.operator('file.select_all_toggle')  

    def invoke(self, context, event):
        wm = context.window_manager
        wm.fileselect_add(self)
        return {'RUNNING_MODAL'}
    
    def execute(self,context):        
        scn = bpy.context.scene
        file_path, file_name = os.path.split(self.filepath)
        filename , ext = os.path.splitext(file_name)
        new_image = bpy.data.images.load(self.filepath)
        
        scn.world.use_nodes = True

        #Select World Node Tree
        wd = scn.world
        nt = bpy.data.worlds[wd.name].node_tree
        
        #clear default nodes            
        for n in nt.nodes:
            nt.nodes.remove(n)
            
        #Create New Node
        backNode = nt.nodes.new(type="ShaderNodeBackground")
        enviNode = nt.nodes.new(type="ShaderNodeTexEnvironment")
        mapNode = nt.nodes.new(type="ShaderNodeMapping")
        coordNode = nt.nodes.new(type="ShaderNodeTexCoord")
        outNode = nt.nodes.new('ShaderNodeOutputWorld')

        #Location Node    
        backNode = nt.nodes['Background']
        backNode.location = 0, 300
        enviNode.location.x = backNode.location.x-200
        enviNode.location.y = backNode.location.y
        
        outNode = nt.nodes['World Output']
        outNode.location.x = backNode.location.x+200
        outNode.location.y = backNode.location.y

        enviNode = nt.nodes['Environment Texture']
        enviNode.image = new_image
        mapNode.location.x = enviNode.location.x-350
        mapNode.location.y = enviNode.location.y

        mapNode = nt.nodes['Mapping']
        coordNode.location.x = mapNode.location.x-200
        coordNode.location.y = mapNode.location.y
        
        #Connect Background To Output
        backOut = backNode.outputs[0]
        outIn = outNode.inputs[0]
        nt.links.new(backOut, outIn)

        #Connect Environment To Background
        enviOut = enviNode.outputs[0]
        backIn = backNode.inputs[0]
        nt.links.new(enviOut, backIn)

        #Connect Mapping To Environment
        mapOut = mapNode.outputs[0]
        enviIn = enviNode.inputs[0]
        nt.links.new(mapOut, enviIn)

        #Connect Texture Coord To Mapping
        coordOut = coordNode.outputs[0]
        mapIn = mapNode.inputs[0]
        nt.links.new(coordOut, mapIn)
        return {'FINISHED'}

class SetHdri_Two(Operator):
    "Set Cycles HDRI Node type 2"
    bl_label="Set HDRI Cycles 02"
    bl_idname="cycles.hdri_world_two"
    
    filepath : bpy.props.StringProperty(subtype="FILE_PATH")

    def draw(self, context):
        self.layout.operator('file.select_all_toggle')  

    def invoke(self, context, event):
        wm = context.window_manager
        wm.fileselect_add(self)
        return {'RUNNING_MODAL'}
    
    def execute(self,context):        
        scn = bpy.context.scene
        file_path, file_name = os.path.split(self.filepath)
        filename , ext = os.path.splitext(file_name)
        new_image = bpy.data.images.load(self.filepath)
                
        scn.world.use_nodes = True

        #Select World Node Tree
        wd = scn.world
        nt = bpy.data.worlds[wd.name].node_tree
        
        #clear default nodes            
        for n in nt.nodes:
            nt.nodes.remove(n)

        #Create New Node
        back2Node = nt.nodes.new(type="ShaderNodeBackground")
        backNode = nt.nodes.new(type="ShaderNodeBackground")
        outNode = nt.nodes.new('ShaderNodeOutputWorld')
        lightpathNode = nt.nodes.new(type="ShaderNodeLightPath")
        enviNode = nt.nodes.new(type="ShaderNodeTexEnvironment")
        mixshdNode = nt.nodes.new(type="ShaderNodeMixShader")
        mapNode = nt.nodes.new(type="ShaderNodeMapping")
        coordNode = nt.nodes.new(type="ShaderNodeTexCoord")
        gamNode = nt.nodes.new(type="ShaderNodeGamma")
        gam2Node = nt.nodes.new(type="ShaderNodeGamma")

        #Location Node
        backNode = nt.nodes['Background']
        backNode.location = 0, 300
        enviNode.location.x = backNode.location.x-200
        enviNode.location.y = backNode.location.y
        
        outNode = nt.nodes['World Output']
        outNode.location.x = backNode.location.x+400
        outNode.location.y = backNode.location.y
        
        enviNode.location.x = backNode.location.x-500
        enviNode.location.y = backNode.location.y

        back2Node = nt.nodes['Background.001']
        back2Node.location.x = backNode.location.x
        back2Node.location.y = backNode.location.y -150

        lightpathNode = nt.nodes['Light Path']
        lightpathNode.location.x = backNode.location.x
        lightpathNode.location.y = backNode.location.y+400

        mixshdNode = nt.nodes['Mix Shader']
        mixshdNode.location.x = backNode.location.x+180
        mixshdNode.location.y = backNode.location.y

        gamNode = nt.nodes['Gamma']
        gamNode.location.x = backNode.location.x-250
        gamNode.location.y = backNode.location.y
        
        gam2Node = nt.nodes['Gamma.001']
        gam2Node.location.x = back2Node.location.x-250
        gam2Node.location.y = back2Node.location.y

        enviNode = nt.nodes['Environment Texture']
        enviNode.image = new_image
        mapNode.location.x = enviNode.location.x-400
        mapNode.location.y = enviNode.location.y

        mapNode = nt.nodes['Mapping']
        coordNode.location.x = mapNode.location.x-200
        coordNode.location.y = mapNode.location.y
        
        outputNode = nt.nodes['World Output']

        ##############################################       
        #Connect LightPath To Mix
        LightPathOut = lightpathNode.outputs[0]
        mixIn = mixshdNode.inputs[0]
        nt.links.new(LightPathOut, mixIn)

        #Connect Background To Mix
        backOut = backNode.outputs[0]
        mixIn = mixshdNode.inputs[1]
        nt.links.new(backOut, mixIn)

        #Connect Background 2 To Mix
        back2Out = back2Node.outputs[0]
        mixIn2 = mixshdNode.inputs[2]
        nt.links.new(back2Out, mixIn2)

        #Connect MixShader To Output
        mixOut = mixshdNode.outputs[0]
        outIn = outputNode.inputs[0]
        nt.links.new(mixOut, outIn)

        #Connect Environment To Gamma
        enviOut = enviNode.outputs[0]
        gamIn = gamNode.inputs[0]
        nt.links.new(enviOut, gamIn)

        #Connect Environment To Gamma 02
        enviOut = enviNode.outputs[0]
        gam2In = gam2Node.inputs[0]
        nt.links.new(enviOut, gam2In)

        #Connect Gamma To Background
        gamOut = gamNode.outputs[0]
        backIn = backNode.inputs[0]
        nt.links.new(gamOut, backIn)

        #Connect Gamma 02 To Background 02
        gam2Out = gam2Node.outputs[0]
        back2In = back2Node.inputs[0]
        nt.links.new(gam2Out, back2In)

        #Connect Mapping To Environment
        mapOut = mapNode.outputs[0]
        enviIn = enviNode.inputs[0]
        nt.links.new(mapOut, enviIn)

        #Connect Texture Coord To Mapping
        coordOut = coordNode.outputs[0]
        mapIn = mapNode.inputs[0]
        nt.links.new(coordOut, mapIn)
        return {'FINISHED'}

class WORLD_OT_create_sky_world(Operator):
    """Creates a New Sky World"""
    bl_idname = "world.create_sky_world"
    bl_label = "Create Sky World"

    def execute(self, context):
        world = bpy.data.worlds.new("Sky")
        world.use_nodes = True
        world.node_tree.nodes.clear()
        
        context.scene.world = world

        output = world.node_tree.nodes.new("ShaderNodeOutputWorld")
        output.location = (0,0)
        
        background = world.node_tree.nodes.new("ShaderNodeBackground")
        background.location = (-200,0)        
        
        sky = world.node_tree.nodes.new("ShaderNodeTexSky")
        sky.location = (-400,0)

        new_links = world.node_tree.links.new
        new_links(output.inputs[0], background.outputs[0])
        new_links(background.inputs[0], sky.outputs[0]) 
        return {'FINISHED'}   
    
class WORLD_OT_create_world_from_hdr(Operator):
    """Creates a New World from a HDR"""
    bl_idname = "world.create_new_world_from_hdr"
    bl_label = "Create New World From HDR"

    filepath : bpy.props.StringProperty(subtype="FILE_PATH")

    def draw(self, context):
        self.layout.operator('file.select_all_toggle')  

    def invoke(self, context, event):
        wm = context.window_manager
        wm.fileselect_add(self)
        return {'RUNNING_MODAL'}

    def execute(self, context):
        file_path, file_name = os.path.split(self.filepath)
        filename , ext = os.path.splitext(file_name)        
        
        world = bpy.data.worlds.new(filename)
        world.use_nodes = True
        world.node_tree.nodes.clear()
        
        context.scene.world = world
        new_image = bpy.data.images.load(self.filepath)

        output = world.node_tree.nodes.new("ShaderNodeOutputWorld")
        output.location = (0,0)
        
        mix_shader = world.node_tree.nodes.new("ShaderNodeMixShader")
        mix_shader.location = (-200,0)
        
        background = world.node_tree.nodes.new("ShaderNodeBackground")
        background.location = (-400,0)
        
        background_2 = world.node_tree.nodes.new("ShaderNodeBackground")
        background_2.location = (-400,-200)        
        
        light_path = world.node_tree.nodes.new("ShaderNodeLightPath")
        light_path.location = (-400,400)        
        
        #ENVIRONMENT LIGHTING
        math_add = world.node_tree.nodes.new("ShaderNodeMath")
        math_add.name = "ADD"
        math_add.operation = 'ADD'
        math_add.location = (-600,-300)
         
        #SHADOWS
        math_multiply = world.node_tree.nodes.new("ShaderNodeMath")
        math_multiply.name = "MULTIPLY"
        math_multiply.operation = 'MULTIPLY'
        math_multiply.inputs[1].default_value = 1     
        math_multiply.location = (-800,-300) 
        
        texture = world.node_tree.nodes.new("ShaderNodeTexEnvironment")
        texture.image = new_image
        texture.location = (-1000,0)

        mapping = world.node_tree.nodes.new("ShaderNodeMapping")
        mapping.location = (-1500,0)
 
        texcord = world.node_tree.nodes.new("ShaderNodeTexCoord")
        texcord.location = (-1700,0)
        
        new_links = world.node_tree.links.new
        new_links(output.inputs[0], mix_shader.outputs[0])
        new_links(mix_shader.inputs[0], light_path.outputs[0]) 
        new_links(mix_shader.inputs[2], background.outputs[0])
        new_links(mix_shader.inputs[1], background_2.outputs[0])  
        new_links(background_2.inputs[1], math_add.outputs[0])  
        new_links(math_add.inputs[0], math_multiply.outputs[0]) 
        new_links(math_multiply.inputs[0], texture.outputs[0]) 
        new_links(background_2.inputs[0], texture.outputs[0]) 
        new_links(background.inputs[0], texture.outputs[0])     
        new_links(texture.inputs[0], mapping.outputs[0])
        new_links(mapping.inputs[0], texcord.outputs[0])        
        return {'FINISHED'}
    
######################################
#   World UI List
######################################
class WORLD_OT_delete_world(Operator):
    bl_idname = "world.delete_world"
    bl_label = "Delete World"
    bl_description = "This will delete the world"

    world_name : bpy.props.StringProperty(name="World Name")

    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        if self.world_name in bpy.data.worlds:
            wrl = bpy.data.worlds[self.world_name]
            bpy.data.worlds.remove(wrl,do_unlink=True)
        return {'FINISHED'}

    def invoke(self,context,event):
        wm = context.window_manager
        return wm.invoke_props_dialog(self, width=400)

    def draw(self, context):
        layout = self.layout
        layout.label(text="Are you sure you want to delete the world?")
        layout.label(text="World Name: " + self.world_name)

######################################
#   Cycles Setings
######################################          
class SpeedUpNow(Operator):
    "Speed Up Branched Path Tracing"
    bl_idname = "object.speedupnow"
    bl_label = "Speed Up Branched Path"

    def execute(self, context):
        context.scene.render.engine = 'CYCLES'
        scene = bpy.context.scene
        scene.cycles.progressive = 'BRANCHED_PATH'
        scene.cycles.aa_samples = 1
        scene.cycles.use_square_samples = False
        scene.cycles.diffuse_samples = 1
        scene.cycles.glossy_samples = 1
        scene.cycles.transmission_samples = 1
        scene.cycles.ao_samples = 1
        scene.cycles.mesh_light_samples = 1
        scene.cycles.subsurface_samples = 1
        scene.cycles.volume_samples = 1
                
        alllamps = bpy.data.lights
        for lamp in alllamps:
            lamp.cycles.max_bounces = 3
        return {'FINISHED'}

class SpeedUpPath(Operator):
    "Speed Up Path Tracing"
    bl_idname = "object.speeduppath"
    bl_label = "Speed Up Path"

    def execute(self, context):
        context.scene.render.engine = 'CYCLES'
        scene = bpy.context.scene
        scene.cycles.progressive = 'PATH'
        scene.cycles.transparent_max_bounces = 2
        scene.cycles.transparent_min_bounces = 2
        scene.cycles.max_bounces = 2
        scene.cycles.min_bounces = 2
        scene.cycles.diffuse_bounces = 2
        scene.cycles.glossy_bounces = 2
        scene.cycles.transmission_bounces = 2
        scene.cycles.volume_bounces = 0
                        
        alllamps = bpy.data.lights
        for lamp in alllamps:
            lamp.cycles.max_bounces = 3
            
        return {'FINISHED'}

class MaxPath(Operator):
    "Max Settings Path Tracing"
    bl_idname = "object.maxpath"
    bl_label = "Max Path"

    def execute(self, context):
        context.scene.render.engine = 'CYCLES'
        scene = bpy.context.scene
        scene.cycles.progressive = 'PATH'
        scene.cycles.transparent_max_bounces = 8
        scene.cycles.transparent_min_bounces = 8
        scene.cycles.max_bounces = 12
        scene.cycles.min_bounces = 8
        scene.cycles.diffuse_bounces = 5
        scene.cycles.glossy_bounces = 5
        scene.cycles.transmission_bounces = 16
        scene.cycles.volume_bounces = 0
                    
        alllamps = bpy.data.lights
        for lamp in alllamps:
            lamp.cycles.max_bounces = 1024             
        return {'FINISHED'} 

######################################
#   Emission
######################################  
class MaterialEmissions(Operator):
    """
    CLICK - ADD EMISSION MATERIAL
    SHIFT - ADD NEW EMISSION MATERIAL
    """
    bl_idname = "object.to_emission"
    bl_label = "Add Emission"

    @classmethod                                     
    def poll(cls, context):                         
        obj = context.active_object
        if len([obj for obj in context.selected_objects if context.object is not None if obj.type in ['MESH','CURVE'] ]) >= 1:
            return True

    def invoke(self, context, event):
        ob = bpy.context.active_object
        if event.shift :
            material = bpy.data.materials.get("Emission")
            material = bpy.data.materials.new(name="Emission")
            material.use_nodes = True     
            material_output = material.node_tree.nodes.get('Material Output')
            emission = material.node_tree.nodes.new('ShaderNodeEmission')
            emission.inputs[1].default_value = 5.0
            
            # link emission shader to material
            material.node_tree.links.new(material_output.inputs[0], emission.outputs[0])  
                 
        else:
            material = bpy.data.materials.get("Emission")
            if material is None:
                material = bpy.data.materials.new(name="Emission")
                material.use_nodes = True
                
                # Remove default
                material.node_tree.nodes.remove(material.node_tree.nodes.get('Principled BSDF'))
                material_output = material.node_tree.nodes.get('Material Output')
                emission = material.node_tree.nodes.new('ShaderNodeEmission')
                emission.inputs[1].default_value = 5.0
                
                # link emission shader to material
                material.node_tree.links.new(material_output.inputs[0], emission.outputs[0])

        # Assign it to object
        if ob.data.materials:
            # assign to 1st material slot
            ob.data.materials[0] = material
        else:
            # no slots
            ob.data.materials.append(material)
        return {'FINISHED'}

class FalloffEmission(Operator):
    'Use the "light falloff" node to control the strength of the emitter'
    bl_idname = "lamp.use_falloff"
    bl_label = "Add Falloff"

    def execute(self, context):
        obj = context.active_object
        if obj.type == 'LIGHT':
            lamp = context.object.data
            add = bpy.data.lights[lamp.name].node_tree

            fallNode = add.nodes.new(type="ShaderNodeLightFalloff")
            
            #Location Node
            emiNode = add.nodes['Emission']
            fallNode.location.x = emiNode.location.x-200
            fallNode.location.y = emiNode.location.y
            
            #Connect
            fallOut = fallNode.outputs[0]
            emiIn = emiNode.inputs[1]
            add.links.new(fallOut, emiIn)
            
        elif obj.type in ['MESH', 'CURVE', 'TEXT']:
            mat = context.active_object.active_material
            add = bpy.context.active_object.data.materials[mat.name].node_tree

            fallNode = add.nodes.new(type="ShaderNodeLightFalloff")
            
            #Location Node
            emiNode = add.nodes['Emission']
            fallNode.location.x = emiNode.location.x-200
            fallNode.location.y = emiNode.location.y
            
            #Connect
            fallOut = fallNode.outputs[0]
            emiIn = emiNode.inputs[1]
            add.links.new(fallOut, emiIn)
        return {'FINISHED'}    
    
######################################
#   Base Texture
######################################  
class DiplayTextureSetup(Operator):
    """
    CLICK - ADD EMISSION MATERIAL
    """
    bl_idname = "object.display_texture"
    bl_label = "Display Texture"

    @classmethod                                     
    def poll(cls, context):                         
        obj = context.active_object
        if len([obj for obj in context.selected_objects if context.object is not None if obj.type in ['MESH','CURVE'] ]) >= 1:
            return True
        
    def execute(self, context):
        ob = bpy.context.active_object
        mat = context.active_object.active_material
        add = bpy.context.active_object.data.materials[mat.name].node_tree
            
        material = bpy.data.materials.get("Emission")
        if material is None:
            material = bpy.data.materials.new(name="Emission")
            material.use_nodes = True
    
            # Remove default
            material.node_tree.nodes.remove(material.node_tree.nodes.get('Principled BSDF'))
            material_output = material.node_tree.nodes.get('Material Output')
            
            # Add Emission
            emission = material.node_tree.nodes.new('ShaderNodeEmission')
            emission.inputs[1].default_value = 1.0
            
            emission.location.x = material_output.location.x-200
            emission.location.y = material_output.location.y
            
            # link emission shader to material
            material.node_tree.links.new(material_output.inputs[0], emission.outputs[0])
            
            # Add Image Texture
            teximage = material.node_tree.nodes.new('ShaderNodeTexImage')  
            teximage.location.x = emission.location.x-300
            teximage.location.y = emission.location.y 
                     
            # link texture to emission
            material.node_tree.links.new(emission.inputs[0], teximage.outputs[0])
            
            # Add Mapping
            map = material.node_tree.nodes.new('ShaderNodeMapping')  
            map.location.x = teximage.location.x-400
            map.location.y = teximage.location.y 
                     
            # link mapping to image texture
            material.node_tree.links.new(teximage.inputs[0], map.outputs[0])
            
            # Add Tex Coordinate
            coord = material.node_tree.nodes.new('ShaderNodeTexCoord')  
            coord.location.x = map.location.x-450
            coord.location.y = map.location.y 
                     
            # link text coord to mapping
            material.node_tree.links.new(map.inputs[0], coord.outputs[2])
            
        # Assign it to object
        if ob.data.materials:
            # assign to 1st material slot
            ob.data.materials[0] = material
        else:
            # no slots
            ob.data.materials.append(material)
        return {'FINISHED'}    
            