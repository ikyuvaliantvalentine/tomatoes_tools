# This file is part of Instant Clean
# Copyright (C) 2023  Ruben Messerschmidt

import bpy
from .super_panel import Super_Panel
from .layout_temps import sub_layout, sub_panel_header, results_layout


class BC_PT_Normals_Panel(Super_Panel):
    bl_idname='bc.normals_panel'
    bl_label=''

    @classmethod
    def poll(cls, context):
        return not context.scene.bc_misc.results or (context.scene.bc_states.normals and bpy.context.scene['Normals'] is not None and [v for k, v in bpy.context.scene['Normals'].items() if type(v) != type(False)])

    def draw_header(self, context):
        sub_panel_header(self.layout, 'normals', context.scene.bc_misc.results, 'Normals')

    def draw(self, context):
        layout = self.layout
        layout.enabled = context.scene.bc_states.normals
        pg = context.scene.bc_normals

        sub = sub_layout(layout, 3)

        if not context.scene.bc_misc.results:
            sub.prop(pg, 'recalculate')
            col = sub.column()
            col.prop(pg, 'recalculate_orientation', text='')
            col.enabled = pg.recalculate

            sub.separator()

            sub.prop(pg, 'auto_smooth')
            col = sub.column()
            col.prop(pg, 'auto_smooth_ang')
            col.enabled = pg.auto_smooth

            sub.separator()
            sub.prop(pg, 'weighted_normals')

            sub.separator()
            sub.label(text='Clear Data')
            box = sub.box()
            col = box.column()
            col.prop(pg, 'clear_custom_split_normals')
            col.prop(pg, 'clear_sharp_edges')
        
        else:
            results_layout(sub, bpy.context.scene['Normals'])
        