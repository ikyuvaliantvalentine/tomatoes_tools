import bpy, os
from bpy_extras.io_utils import ImportHelper
from bpy.types import Operator, Menu, Panel
from bpy.props import *

############################
# TOGGLE VIEW NAME DATA CAMERA
############################
class ToggleShowDataCamName(Operator):
    """
    CLICK - Show / Unshow data camera name
    SHIFT - Refresh Camera Data
    """
    bl_idname = 'cameras.toggle_name'
    bl_label = 'Show / Unshow data camera name'

    def invoke(self, context, event):
        if event.shift:
            for cam in bpy.data.cameras:
                if cam.show_name == False:
                    cam.show_name = True  
                self.report({'INFO'}, "Refresh camera in the scene")
        else:
            for cam in bpy.data.cameras:
                cam.show_name = not cam.show_name
        return {"FINISHED"}

############################
# NEW CAMERA FROM VIEW
############################
class NewCameraFromView(Operator):
    bl_idname = 'cameras.new_from_view'
    bl_label = 'New Camera From View'
    bl_description = "Create a new camera from view"
    bl_options = {'UNDO'}

    def execute(self,context):
        if context.area.spaces[0].region_3d.view_perspective == 'CAMERA':
            context.area.spaces[0].region_3d.view_perspective='PERSP'
        bpy.ops.object.camera_add()
        context = bpy.context
        scene = context.scene
        currentCameraObj = bpy.data.objects[bpy.context.active_object.name]
        scene.camera = currentCameraObj
        bpy.ops.view3d.camera_to_view()
        return{'FINISHED'}

############################
# SET CAMERA VIEW
############################
class SetCameraView(Operator):
    bl_idname = 'cameras.set_view'
    bl_label = 'Set Camera View'
    bl_description = "Set View to this Camera"
    bl_options = {'UNDO'}

    camera: bpy.props.StringProperty()

    def execute(self,context):
        if context.object:
            if context.object.select_get():
                context.object.select_set(state=False)
        cam=bpy.data.objects[self.camera]
        cam.select_set(state=True)
        context.view_layer.objects.active = cam
        context.scene.camera=cam
        
        bpy.ops.view3d.object_as_camera()
        
        # Refresh Resolution
        for c in cam.data.background_images:
            context.scene.render.resolution_x  = c.image.size[0]
            context.scene.render.resolution_y  = c.image.size[1]
            print(c.image.name)

        return{'FINISHED'}

############################
# DELETE CAMERA
############################
class DeleteCamera(Operator):
    bl_idname = 'cameras.delete'
    bl_label = 'Delete Camera'
    bl_description = "Delete camera"
    bl_options = {'UNDO'}

    camera: StringProperty()

    def execute(self,context):
        cam=bpy.data.objects[self.camera]
        bpy.data.objects.remove(cam)        
        
        data = bpy.data
        for m in data.cameras:
            if m.users == 0:                    
                data.cameras.remove(m)    
        return{'FINISHED'}
    

############################
#  Create Background Image
############################  
class Add_Image_To_Cam(Operator, ImportHelper):
    bl_idname = "add.image_to_camera"
    bl_label = "Add Image "
    bl_description = "Add New Background Image To Camera"
    bl_options = {"REGISTER", "UNDO"}
    
    camera: StringProperty()
    index : IntProperty(default=1)
    filepath : StringProperty(subtype="FILE_PATH")
                
    filter_glob: StringProperty(
        default="*.png;*.jpg;*.jpeg",
        options={'HIDDEN'})
    
    def draw(self, context):
        self.layout.operator('file.select_all_toggle')  

    def invoke(self, context, event):
        wm = context.window_manager
        wm.fileselect_add(self)
        return {'RUNNING_MODAL'}
 
    def execute(self, context):
        cam=bpy.data.objects[self.camera]    
        context.view_layer.objects.active = cam
        context.scene.camera=cam
          
        file_path, file_name = os.path.split(self.filepath)
        filename , ext = os.path.splitext(file_name)
        new_image = bpy.data.images.load(self.filepath)
        
        cam.data.show_background_images = True
        bg = cam.data.background_images.new()
        bg.image = new_image  
        
        #Make Resolution Same As Image Reference
        context.scene.render.resolution_x  = bg.image.size[0]
        context.scene.render.resolution_y  = bg.image.size[1]
        
        # Make Limit
        for i, bg in enumerate(cam.data.background_images):
            if i == self.index:
                cam.data.background_images.remove(bg)   
                self.report({'ERROR'}, "Only One Image Data!!!")
    
        return {'FINISHED'}    
        
############################
#  Remove Background Image
############################
class cam_background_image_remove(Operator):
    bl_idname = "cameras.background_image_remove"
    bl_label = "Remove Background Image"
    bl_description = "Remove a Background Image from the camera"
    bl_options = {'UNDO'}

    index: IntProperty()
    camera: StringProperty()
        
    def execute(self, context):
        obj = context.active_object
        cam = context.active_object.data
        if obj.type == "CAMERA":
            for i, bg in enumerate(cam.background_images):
                if i == self.index:
                    bg.show_background_image = False
                    cam.background_images.remove(bg)    
                 
        count_clear_img = 0        
        for image in bpy.data.images:
            if not image.users:
                count_clear_img+=1
                image.user_clear()
                bpy.data.images.remove(image)
      
        for img in bpy.data.images:
            self.report({'INFO'}, "Check Console" + img.name + " From" + img.filepath)
#            self.report({'INFO'}, "name=%s, filepath=%s" % (img.name, img.filepath))
                     
        return {'FINISHED'}