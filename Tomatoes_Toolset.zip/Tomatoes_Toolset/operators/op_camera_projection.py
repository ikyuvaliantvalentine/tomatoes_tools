import bpy, os
from bpy_extras.io_utils import ImportHelper
from bpy.types import Operator, Menu, Panel
from bpy.props import *

############################
# NEW CAMERA FROM VIEW
############################
class NewCameraFromView(Operator):
    bl_idname = 'cameras.new_from_view'
    bl_label = 'New Camera From View'
    bl_description = "Create a new camera from view"
    bl_options = {'UNDO'}

    def execute(self,context):
        if context.area.spaces[0].region_3d.view_perspective == 'CAMERA':
            context.area.spaces[0].region_3d.view_perspective='PERSP'
        bpy.ops.object.camera_add()
        context = bpy.context
        scene = context.scene
        currentCameraObj = bpy.data.objects[bpy.context.active_object.name]
        scene.camera = currentCameraObj
        bpy.ops.view3d.camera_to_view()
        return{'FINISHED'}

############################
# SET CAMERA VIEW
############################
class SetCameraView(Operator):
    bl_idname = 'cameras.set_view'
    bl_label = 'Set Camera View'
    bl_description = "Set View to this Camera"
    bl_options = {'UNDO'}

    camera: bpy.props.StringProperty()

    def execute(self,context):
        if context.object:
            if context.object.select_get():
                context.object.select_set(state=False)
        cam=bpy.data.objects[self.camera]
        cam.select_set(state=True)
        context.view_layer.objects.active = cam
        context.scene.camera=cam
        
        bpy.ops.view3d.object_as_camera()
        
        # Refresh Resolution
        for c in cam.data.background_images:
            context.scene.render.resolution_x  = c.image.size[0]
            context.scene.render.resolution_y  = c.image.size[1]
            print(c.image.name)

        return{'FINISHED'}

############################
# DELETE CAMERA
############################
class DeleteCamera(Operator):
    bl_idname = 'cameras.delete'
    bl_label = 'Delete Camera'
    bl_description = "Delete camera"
    bl_options = {'UNDO'}

    camera: StringProperty()

    def execute(self,context):
        cam=bpy.data.objects[self.camera]
        bpy.data.objects.remove(cam)        
        
        data = bpy.data
        for m in data.cameras:
            if m.users == 0:                    
                data.cameras.remove(m)    
        return{'FINISHED'}
    

############################
#  Create Background Image
############################  
class Add_Image_To_Cam(Operator, ImportHelper):
    bl_idname = "add.image_to_camera"
    bl_label = "Add Image "
    bl_description = "Add New Background Image To Camera"
    bl_options = {"REGISTER", "UNDO"}
    
    camera: StringProperty()
    filepath : StringProperty(subtype="FILE_PATH")
                
    filter_glob: StringProperty(
        default="*.png;*.jpg;*.jpeg",
        options={'HIDDEN'})
    
    update_existing_camera : BoolProperty(
        name="Update existing import (if any)",
        description=(
            "If a camera and background image matching "
            "the project file name already exist, update "
            "them instead of creating new objects"
        ),
        default=True
    )
    
    # def draw(self, context):
    #     self.layout.operator('file.select_all_toggle')  

    def invoke(self, context, event):
        wm = context.window_manager
        wm.fileselect_add(self)
        return {'RUNNING_MODAL'}
 
    def execute(self, context):
        cam=bpy.data.objects[self.camera]   
        context.view_layer.objects.active = cam
          
        file_path, file_name = os.path.split(self.filepath)
        filename , ext = os.path.splitext(file_name)
        new_image = bpy.data.images.load(self.filepath)

        # Just only need one data images, so remove the first data after create the new one
        for i, bg in enumerate(cam.data.background_images):
            if i == 0:
                cam.data.background_images.remove(bg)   
                break
        
        bg = None
        if not bg:
            # No existin background image slot. Create one
            bg = cam.data.background_images.new()
            cam.data.show_background_images = True
            bg.image = new_image  
            context.scene.render.resolution_x  = bg.image.size[0]
            context.scene.render.resolution_y  = bg.image.size[1]
        return {'FINISHED'}    