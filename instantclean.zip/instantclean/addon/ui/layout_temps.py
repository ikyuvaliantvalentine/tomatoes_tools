# This file is part of Instant Clean
# Copyright (C) 2023  Ruben Messerschmidt

import bpy


def sub_layout(layout: bpy.types.UILayout, space: float):
    row = layout.row(align=True)
    row.separator(factor=space)
    return row.column()


def sub_panel_header(layout: bpy.types.UILayout, header, text_only: bool, text: str):
        split = layout.split(align=True)
        col = split.column()
        row = col.row(align=True)
        row.ui_units_x = 6
        row.separator()
        if text_only:
            row.label(text=text)
        else:
            row.prop(bpy.context.scene.bc_states, header, toggle=True)
            row.operator('bc.' + header, text='', icon='TRIA_RIGHT')

def results_layout(layout: bpy.types.UILayout, stats):
    box = layout.box()
    split = box.split()
    col = split.column()
    col.enabled = False
    vals = split.column()
    for name, value in stats.items():
        if type(value) == type(False):
            continue
        col.label(text=name)
        row = vals.row()
        row.alignment = 'CENTER'
        row.separator(factor=1)
        row.label(text=str(value))

def popup_results(layout: bpy.types.UILayout, stats):
    sub = sub_layout(layout, 2)
    split = sub.split()
    col = split.column()
    col.enabled = False
    vals = split.column()
    for name, value in stats.items():
        if type(value) == type(False):
            continue
        col.label(text=name)
        row = vals.row()
        row.alignment = 'CENTER'
        row.separator(factor=1)
        row.label(text=str(value))
