import bpy
from bpy.types import Operator

class Optimize_Viewport(Operator):
    "Optimize Clip Start & Clip End"
    bl_idname = "scene.optimize_viewport"
    bl_label = "Optimize Viewport"
    
    def execute(self, context):
        for a in bpy.context.screen.areas:
            if a.type == 'VIEW_3D':
                for s in a.spaces:
                    if s.type == 'VIEW_3D':
                        s.clip_start = 0.01
                        s.clip_end = 10000
        return {'FINISHED'}

class Set_Unit_Centimeter(Operator):
    "Set Unit Scale Centimeter"
    bl_idname = "scene.set_centimeter"
    bl_label = "Unit Centimeter"
    def execute(self, context):
        bpy.context.scene.unit_settings.system = 'METRIC'
        bpy.context.scene.unit_settings.scale_length = 0.01
        bpy.context.scene.unit_settings.length_unit = 'CENTIMETERS'
        return {'FINISHED'}

class Set_Unit_Default(Operator):
    "Set Unit Scale Default"
    bl_idname = "scene.set_default"
    bl_label = "Unit Default"
    def execute(self, context):
        bpy.context.scene.unit_settings.system = 'METRIC'
        bpy.context.scene.unit_settings.scale_length = 1
        bpy.context.scene.unit_settings.length_unit = 'METERS'
        return {'FINISHED'}