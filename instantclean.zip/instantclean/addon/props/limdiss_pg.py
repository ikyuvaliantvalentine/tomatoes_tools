# This file is part of Instant Clean
# Copyright (C) 2023  Ruben Messerschmidt

import bpy
from bpy.props import (BoolProperty, IntProperty, FloatProperty, EnumProperty)


class BC_PG_Limdiss_Settings(bpy.types.PropertyGroup):
    max_angle: FloatProperty(
        name='Max Angle',
        default=0.0875,
        subtype='ANGLE',
        description='Maximal angle at which geometry will be dissolved'
    )

    boundaries: BoolProperty(
        name='Boundaries',
        description='Edges which are connected to one face only'
    )

    protect_sharp : BoolProperty(
        name='Sharp',
        default=True,
        description='Excludes edges marked as sharp from the dissolve'
    )

    protect_seam : BoolProperty(
        name='Seam',
        default=True,
        description='Excludes edges marked as seam from the dissolve'
    )

    protect_uv : BoolProperty(
        name='UV',
        default=True,
        description='Excludes edges which are boundary of UV islands from the dissolve'
    )

    protect_materials : BoolProperty(
        name='Materials',
        default=True,
        description='Excludes edges which delimit two different assigned materials from the dissolve'
    )