import bpy
from bpy.types import Operator
from mathutils import Vector
from bpy.props import *


from ..utils.utils import del_duplicate, cursorPivot, co_elements
from .. properties import *


class Pivot_To_Bottom(Operator):             
    bl_idname = "op.pivot_to_bottom"
    bl_label = "Pivot To Bottom"
    bl_description = "Pivot To Bottom Select Object"
    bl_options = {'REGISTER', 'UNDO', 'INTERNAL'}

    drop_to_z: BoolProperty(name="Drop To Z", default=False)

    @classmethod
    def poll(cls, context):
        if context.object is None:
            return False
        return True

    # @classmethod
    # def poll(self, context):
    #     return context.object.type in {'MESH', 'ARMATURE', 'CURVE', 'SURFACE', 'META', 'LATTICE'}


    def execute(self, context):
        addon_preferences = get_addon_preferences()

        edit = False
        if context.object.mode == 'EDIT':
            bpy.ops.object.mode_set(mode = 'OBJECT')
            edit = True
        else:
            edit = False



        activeObj = context.active_object
        selObject = context.selected_objects

        for obj in selObject:
            obj.select_set(state=True)

            depsgraph = context.evaluated_depsgraph_get()
            object_eval = obj.evaluated_get(depsgraph)

            co = co_elements(object_eval, edit=edit)

            # --- Set Pivot
            if co:
                x = (min([v.x for v in co]) + max([v.x for v in co])) / 2
                y = (min([v.y for v in co]) + max([v.y for v in co])) / 2
                z = min([v.z for v in co])
                global_origin = Vector((x, y, z))

                cursorPivot(global_origin)
                obj.select_set(state=False)



        # --- Restore
        for obj in selObject:
            obj.select_set(state=True)

            if self.drop_to_z:
                obj.location[2] = 0.0

        context.view_layer.objects.active = activeObj
                
        return {'FINISHED'}

    def draw(self, context):
        layout = self.layout
        
        row = layout.row(align=True)
        row.label(text="Drop To") 
        row.prop(self, 'drop_to_z', text='Z', toggle=True)



class CenterPivot(Operator):
    bl_label = "Pivot to Center Object"
    bl_description = "Move the pivot point to the center of the object."
    bl_idname = "op.center_pivot"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        if context.object is None:
            return False
        return True

    def execute(self, context):
        bpy.ops.object.mode_set(mode='OBJECT')
        bpy.ops.object.origin_set(type='ORIGIN_CENTER_OF_MASS', center='MEDIAN')
        return {'FINISHED'}

class Pivot2Cursor(Operator):
    bl_label = "Pivot to 3D Cursor"
    bl_description = "Move the pivot point to the 3D cursor"
    bl_idname = "op.pivot2cursor"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        if context.object is None:
            return False
        return True
        
    def execute(self, context):
        bpy.ops.object.mode_set(mode='OBJECT')
        bpy.ops.object.origin_set(type='ORIGIN_CURSOR', center='MEDIAN')
        return {'FINISHED'}