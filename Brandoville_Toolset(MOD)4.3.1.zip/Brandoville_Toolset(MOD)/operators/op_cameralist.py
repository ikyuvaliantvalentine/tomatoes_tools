import bpy, os
from bpy.types import Operator
from bpy.props import *

############################
# NEW CAMERA FROM VIEW
############################
class NewCameraFromView(Operator):
    bl_idname = 'op.cameras_new_from_view'
    bl_label = 'New Camera From View'
    bl_description = "Create a new camera from view"
    bl_options = {'UNDO'}

    def execute(self,context):
        if context.area.spaces[0].region_3d.view_perspective == 'CAMERA':
            context.area.spaces[0].region_3d.view_perspective='PERSP'
        bpy.ops.object.camera_add()
        context = bpy.context
        scene = context.scene
        currentCameraObj = bpy.data.objects[bpy.context.active_object.name]
        scene.camera = currentCameraObj
        bpy.ops.view3d.camera_to_view()
        return{'FINISHED'}

############################
# SET CAMERA VIEW
############################
class SetCameraView(Operator):
    bl_idname = 'op.cameras_set_view'
    bl_label = 'Set Camera View'
    bl_description = "Set View to this Camera"
    bl_options = {'UNDO'}

    camera: bpy.props.StringProperty()

    def execute(self,context):
        if context.object:
            if context.object.select_get():
                context.object.select_set(state=False)
        cam=bpy.data.objects[self.camera]
        cam.select_set(state=True)
        context.view_layer.objects.active = cam
        context.scene.camera=cam
        
        bpy.ops.view3d.object_as_camera()
        
        # Refresh Resolution
        for c in cam.data.background_images:
            context.scene.render.resolution_x  = c.image.size[0]
            context.scene.render.resolution_y  = c.image.size[1]
            print(c.image.name)

        return{'FINISHED'}

############################
# DELETE CAMERA
############################
class DeleteCamera(Operator):
    bl_idname = 'op.cameras_delete'
    bl_label = 'Delete Camera'
    bl_description = "Delete camera"
    bl_options = {'UNDO'}

    camera: StringProperty()

    def execute(self,context):
        cam=bpy.data.objects[self.camera]
        bpy.data.objects.remove(cam)        
        
        data = bpy.data
        for m in data.cameras:
            if m.users == 0:                    
                data.cameras.remove(m)    
        return{'FINISHED'}
    
######################
#  Switch Cam Resolution
######################      
class SwitchRenderResolution(Operator):
    "Switch Resolution"
    bl_idname="op.swithrestoggle"
    bl_label="Switch Resolution"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self,context):
        rd = context.scene.render
        rs_x = rd.resolution_x
        rs_y = rd.resolution_y

        if rd.resolution_x == rs_x:
            rd.resolution_x = rs_y
            rd.resolution_y = rs_x
        else:
            rd.resolution_x = rs_x
            rd.resolution_y = rs_y
        return {"FINISHED"}
    
