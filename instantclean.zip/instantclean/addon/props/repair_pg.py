# This file is part of Instant Clean
# Copyright (C) 2023  Ruben Messerschmidt

import bpy
from bpy.props import (BoolProperty, IntProperty, FloatProperty, EnumProperty)


class BC_PG_Repair_Settings(bpy.types.PropertyGroup):
    loose: BoolProperty(
        name='Loose',
        default=True,
        description='Unconnected Geometry'
    )

    loose_verts: BoolProperty(
        name='Loose Verts',
        default=True,
        description='Vertices which are not part of an edge'
    )

    loose_edges: BoolProperty(
        name='Loose Edges',
        default=True,
        description='Edges which are not part of an face'
    )

    loose_faces: BoolProperty(
        name='Loose Faces',
        default=True,
        description='Faces which are not connected to other faces'
    )

    doubles: BoolProperty(
        name='Doubles',
        default=True,
        description='Vertices with the same position'
    )

    doubles_dst: FloatProperty(
        name='Max Distance',
        default=0.0001,
        subtype='DISTANCE',
        description='Maximal Distance between positions to be considered as same'
    )

    zero_faces: BoolProperty(
        name='Zero Faces',
        default=True,
        description='Faces with an area of zero'
    )

    zero_faces_area: FloatProperty(
        name='Max Area',
        default=0.0001,
        subtype='DISTANCE',
        description='Maximal area of an face to be considered as zero'
    )

    dispensables: BoolProperty(
        name='Dispensables',
        default=True,
        description='Vertices which are connecting two edges by an angle of zero'
    )

    dispensables_ang: FloatProperty(
        name='Max Angle',
        default=0.0875,
        subtype='ANGLE',
        description='Maximal angle between two edges to be considered as zero'
    )

    interiors: BoolProperty(
        name='Interiors',
        default=True,
        description='Faces which are inside the mesh'
    )