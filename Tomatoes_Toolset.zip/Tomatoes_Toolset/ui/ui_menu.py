import bpy
from bpy.types import Menu
from .. properties import *
###################################
#Class Menu For Invoke
###################################
class VIEW3D_MT_menu_add_mod(Menu):
    bl_label = "Add Modifier"
    bl_description = "Add Modifier Menu"

    def draw(self, context):
        layout = self.layout
        layout.operator("object.subsurf", text= "Subsurf", icon="MOD_SUBSURF") 
        layout.operator("object.mirror", text= "Mirror", icon="MOD_MIRROR")
        layout.operator("object.solidify", text= "Solidify", icon="MOD_SOLIDIFY")
        layout.operator("object.array", text= "Array", icon="MOD_ARRAY")
        layout.operator("object.bevel", text= "Bevel", icon="MOD_BEVEL")
        layout.operator("object.lattice", text= "Lattice", icon="MOD_LATTICE")
        layout.operator("object.shrinkwrap", text= "Shrinkwrap", icon="MOD_SHRINKWRAP")
        layout.operator("object.weightednormal", text= "Weighted Normal", icon="MOD_NORMALEDIT")

class VIEW3D_MT_menu_control_mod(Menu):
    bl_label = "Apply Modifier"
    bl_description = "Control Modifier Menu"

    def draw(self, context):
        layout = self.layout
        layout.operator("object.apply_subsurf", icon="FILE_TICK")
        layout.operator("object.apply_mirror", icon="FILE_TICK")
        layout.operator("object.apply_array", icon="FILE_TICK")
        layout.operator("object.apply_solidify", icon="FILE_TICK") 
        layout.operator("object.apply_bevel", icon="FILE_TICK") 
        
class VIEW3D_MT_menu_other(Menu):
    bl_label = "Other"
    bl_description = "Other Menu"

    def draw(self, context):
        layout = self.layout
        layout.operator("auto.cuts", text= "Auto Cut", icon="SNAP_EDGE")          
        layout.operator("glob.sub", icon="MOD_SUBSURF")
        layout.operator("copy.modifier", icon="COPYDOWN")
        layout.operator("object.modifier_remove_all", icon="CANCEL") 
        layout.operator("object.modifier_apply_all", icon_value=get_icon("check_icon"))
        layout.operator("op.particlehideall")
        
########################
#Quick Add Objects Menu
########################
class VIEW3D_MT_quick_add_objects(Menu):
    bl_label = "Quick Add Object"
    bl_idname = "VIEW3D_MT_quick_add_objects"
       
    def draw(self, context):
        layout = self.layout
        
        layout.operator("view3d.addprim", icon="VERTEXSEL", text="6").type = "Vertex"        
        layout.operator("view3d.addprim", icon="OUTLINER_OB_CURVE", text="6").type = "Draw_Curve"
        layout.separator()        
        layout.operator("view3d.addprim", icon="MESH_CYLINDER", text="6").type = "Cylinder_6"
        layout.operator("view3d.addprim", icon="MESH_CYLINDER", text="8").type = "Cylinder_8"
        layout.operator("view3d.addprim", icon="MESH_CYLINDER", text="12").type = "Cylinder_12"
        layout.operator("view3d.addprim", icon="MESH_CYLINDER", text="16").type = "Cylinder_16"
        layout.operator("view3d.addprim", icon="MESH_CYLINDER", text="24").type = "Cylinder_24"
        layout.operator("view3d.addprim", icon="MESH_CYLINDER", text="32").type = "Cylinder_32"
        layout.operator("view3d.addprim", icon="MESH_CYLINDER", text="64").type = "Cylinder_64"
        layout.operator("view3d.addprim", icon="MESH_CYLINDER", text="128").type = "Cylinder_128"  
        layout.separator()       
        layout.operator("view3d.addprim", icon="MESH_CIRCLE", text="6").type = "Circle_6"
        layout.operator("view3d.addprim", icon="MESH_CIRCLE", text="8").type = "Circle_8"
        layout.operator("view3d.addprim", icon="MESH_CIRCLE", text="12").type = "Circle_12"
        layout.operator("view3d.addprim", icon="MESH_CIRCLE", text="16").type = "Circle_16"
        layout.operator("view3d.addprim", icon="MESH_CIRCLE", text="24").type = "Circle_24"
        layout.operator("view3d.addprim", icon="MESH_CIRCLE", text="32").type = "Circle_32"  
        layout.separator()     
        layout.operator("view3d.addprim", icon="MESH_UVSPHERE", text="8").type = "Sphere_8"
        layout.operator("view3d.addprim", icon="MESH_UVSPHERE", text="12").type = "Sphere_12"
        layout.operator("view3d.addprim", icon="MESH_UVSPHERE", text="16").type = "Sphere_16"
        layout.operator("view3d.addprim", icon="MESH_UVSPHERE", text="24").type = "Sphere_24"
        layout.operator("view3d.addprim", icon="MESH_UVSPHERE", text="32").type = "Sphere_32"

########################
# Toggle Edit Menu
########################         
class VIEW3D_MT_Toggle_Edit_Mode(Menu):
    bl_label = "Toggle Edit Mode"
    bl_description = "Toggle Edit Mode Menu"

    @classmethod                                     
    def poll(cls, context):                         
        obj = context.active_object
        return obj is not None and obj.type == "MESH" and bpy.context.mode == "EDIT_MESH"

    def draw(self, context):
        layout = self.layout
        layout.operator("uv.unwrap", text="Unwrap")
        layout.separator()   
        layout.operator("object.toggle_mark", text="Bevel").type_toggle = "bevel"
        layout.operator("object.toggle_mark", text="Crease").type_toggle = "crease"
        layout.operator("object.toggle_mark", text="Sharp").type_toggle = "sharp" 
        layout.operator("object.toggle_mark", text="Seam").type_toggle = "seam" 

        layout.operator("mesh.vert_connect_path", text="Connect")
        layout.separator()        

        
        if tuple (bpy.context.tool_settings.mesh_select_mode) == (True, False, False) :
            layout.operator("object.toggle_merge", text="At First").type_merge = "first" 
            layout.operator("object.toggle_merge", text="At last").type_merge = "last" 
            layout.operator("object.toggle_merge", text="At center").type_merge = "center" 
        else:
            layout.operator("object.toggle_merge", text="At center").type_merge = "center" 
            layout.operator("object.toggle_merge", text="At Cursor").type_merge = "cursor" 
            layout.operator("object.toggle_merge", text="Collapse").type_merge = "collapse" 

###################################
#Special Menu
###################################
class VIEW3D_MT_Light_SpecialMenu(Menu):
    bl_label = "Quick Menu"
    bl_description = "Quick Menu"
    
    @classmethod                                     
    def poll(cls, context):                         
        obj = context.active_object
        if len([obj for obj in context.selected_objects if context.object is not None if obj.type == "LIGHT"]) == 1:
            return True
                           
    def draw(self, context):
        layout = self.layout
        layout.operator("op.hide_view_set_light")
        layout.operator("op.show_view_set_light")
        layout.operator("op.aim_light")
        layout.operator("op.light_show_name")
        layout.separator()
        layout.operator("object.isolate_type_render")
        layout.operator("object.hide_render_clear_all")

###################################
#Create Iso Cam
###################################
class VIEW3D_MT_create_isocam(Menu):
    bl_label = "Add Iso Cam"
    bl_description = "Create Iso Cam Menu"

    def draw(self, context):
        layout = self.layout
        layout.operator("scene.create_trueisocam")
        layout.operator("scene.create_gameisocam")
        layout.operator("scene.create_gameisocam4to3")

###################################
# Extra Object
###################################
class VIEW3D_MT_extra_object(Menu):
    bl_label = "Add Extra Object"
    bl_description = "Add Extra Object Menu"

    def draw(self, context):
        layout = self.layout
        layout.operator("op.new_smoke", icon = "OUTLINER_OB_VOLUME")
        layout.operator("op.exterior_light")
        layout.operator("op.threepointlights")

###################################
# VFX Tools
###################################
class VIEW3D_MT_vfx_menu(Menu):
    bl_label = "Add VFX"
    bl_description = "Quick Create VFX"

    def draw(self, context):
        layout = self.layout
        layout.label(text= "Rain Creator")
        layout.operator("add.new_emit_operator", text= "New Add Emitter")         
        layout.operator("add.collision_operator", text= "Make Collide")
        layout.separator()
        layout.label(text= "Add Ground")
        layout.operator("add.groundwater_operator", text= "Water")
        layout.separator()
        layout.label(text= "Add Field")
        layout.operator("add.wind_operator", text= "Wind")
        layout.operator("add.turbulance_operator", text= "Turbulance")
        layout.separator()
        layout.label(text= "Add Rigid body")
        layout.operator("add.rigidbody_operator", text="Active").type_rigid="active"
        layout.operator("add.rigidbody_operator", text="Passive").type_rigid="passive"
        layout.operator("apply.rigidbody_operator", text="Apply")

###################################
# Origin Menu
###################################
class VIEW3D_MT_custom_object_origin(Menu):
    bl_label = "Custom Set Origin"
    bl_description = "Custom Set Origin Menu"

    def draw(self, context):
        layout = self.layout
        layout.operator("object.origin_set", text="Geo To Origin").type = "GEOMETRY_ORIGIN"
        layout.operator("object.origin_set", text="Origin To Geometry").type = "ORIGIN_GEOMETRY"
        layout.operator("object.origin_set", text="Origin To 3DCursor").type = "ORIGIN_CURSOR"
        layout.operator("object.origin_set", text="Orig To Center Of Mass(Surface)").type = "ORIGIN_CENTER_OF_MASS"
        layout.operator("object.origin_set", text="Orig To Center Of Mass(Volume)").type = "ORIGIN_CENTER_OF_VOLUME"
        layout.separator()
        layout.operator("ob.pivotobottom")
        layout.operator("test.edit_origin")
###################################
#  Quick Tools 
###################################
class VIEW3D_MT_quick_tools(Menu):
    bl_label = "Quick Tools"
    bl_description = "Quick Tools Menu"

    def draw(self, context):
        layout = self.layout
        layout.menu("VIEW3D_MT_quick_add_objects")
        layout.menu("VIEW3D_MT_extra_object")
        layout.menu("VIEW3D_MT_vfx_menu")
        layout.separator()
        layout.menu("VIEW3D_MT_custom_object_origin")


