import bpy, os 
from bpy.props import *
from bpy.types import PropertyGroup

def get_addon_preferences():
    addon_name = os.path.basename(os.path.dirname(os.path.abspath(__file__).split("utils")[0]))
    user_preferences = bpy.context.preferences
    addon_prefs = user_preferences.addons[addon_name].preferences     
    return addon_prefs

# ------------------------------------------------------------------------              
#   Property Group
# ------------------------------------------------------------------------    
class SceneCheckerProperties(PropertyGroup):
    settingsFilePath : StringProperty(
            name="Settings",
            default="",
            subtype='FILE_PATH',
            description="location for the settings save/load\n")  

    save_filename : StringProperty(
            name="Filename",
            default="",
            description="Set Filename")  
            