import bpy
from .. properties import *

def draw_add_modifier_ui(self, context, layout):
    red = context.scene.red_props
    obj = context.active_object

    col = layout.column(align=True)

    if not red.display_add_modifier: 
          
        box = col.box().column(align=True)
        
        row = box.row(align=True)   
        row.prop(red, "display_add_modifier", text="", icon="TRIA_RIGHT", toggle = True)                
        row.label(text="Add Modifier")     

    else:
        
        box = col.box().column(align=True)
        row = box.row(align=True)  
        row.prop(red, "display_add_modifier", text="", icon="TRIA_DOWN", toggle = True)            
        row.label(text="Add Modifier") 

        
        
        if len([obj for obj in context.selected_objects if context.object is not None if obj.type in ['MESH', 'LATTICE'] ]) >= 1:
            
            if context.object is not None and obj.type == 'MESH' :
                lattice = False
                for mod in obj.modifiers:
                    if mod.type == "LATTICE":
                        lattice = True

                if not lattice:
                    box = col.box().column(align=True)                         
                    row = box.row(align=True) 
                    row.scale_x = 1.2
                    row.scale_y = 1.2
                    row.operator("op.lattice_create")
                    
                else :
                    box = col.box().column(align=True)                         
                    row = box.row(align=True)  
                    sub = row.row(align=True) 
                    sub.scale_x = 1.2
                    sub.scale_y = 1.2
                    sub.operator("op.apply_lattice_modifier", icon="CHECKMARK")
                    sub.operator("op.remove_lattice_modifier", text="", icon="X")

        if len([obj for obj in context.selected_objects if obj.type == 'LATTICE' ]) == 1:                      
            row = box.row(align=True)  
            sub = row.row(align=True) 
            sub.scale_x = 1.2
            sub.scale_y = 1.2
            sub.operator("op.lattice_apply", icon="CHECKMARK")
            sub.operator("op.lattice_remove", text="", icon="X")

            box.label(text="Lattice Parameter", icon='OUTLINER_OB_LATTICE')
            split = box.split()
            col = split.column(align=True)
            row = col.row(align=True)
            row.scale_y = 1.2
            row = col.row(align=True)
            row.separator()
            row = col.row(align=True)
            row.prop(context.object.data, "points_u")
            row = col.row(align=True)
            row.prop(context.object.data, "points_v")
            row = col.row(align=True)
            row.prop(context.object.data, "points_w")

        if context.object is not None and obj.type == 'MESH' :
            col_wnrm = layout.column(align=True)
            box1 = col_wnrm.box().column(align=True)                         
            col = box1.column(align=True)   
            row = col.row(align=True)
            row.scale_x = 1.2
            row.scale_y = 1.2

            wnrm = False
            for mod in obj.modifiers:
                if mod.type == "WEIGHTED_NORMAL":
                    wnrm = True

            if not wnrm:
                row.operator("op.weightednormal")
            else:
                row.operator("op.apply_weighted_normals_modifier")
                row.operator("op.remove_weighted_normals_modifier", text="", icon="X")

            col_array = layout.column(align=True)
            box1 = col_array.box().column(align=True)                         
            col = box1.column(align=True)   
            row = col.row(align=True)
            row.scale_x = 1.2
            row.scale_y = 1.2

            row.operator("op.array_modwall", icon="MOD_BUILD")