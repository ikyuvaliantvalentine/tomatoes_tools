# This file is part of Instant Clean
# Copyright (C) 2023  Ruben Messerschmidt

import bpy
from bpy.props import (BoolProperty, IntProperty, FloatProperty, EnumProperty)


class BC_PG_Misc(bpy.types.PropertyGroup):
    results: BoolProperty(
        name=''
    )