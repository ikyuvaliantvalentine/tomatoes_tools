import bpy
import getpass
import os
import string
import shelve
import threading
from mathutils import Matrix, Vector
from bpy.app.handlers import persistent
from bl_operators.presets import AddPresetBase, ExecutePreset
from bpy.props import BoolProperty, IntProperty, PointerProperty,\
    StringProperty, FloatVectorProperty, EnumProperty, CollectionProperty
from .. properties import *

space_settings_keys = [
    'show_only_render']
render_settings_keys = frozenset([
    'use_stamp', 'use_stamp_camera', 'use_stamp_date', 'use_stamp_filename',
    'use_stamp_frame', 'use_stamp_lens', 'use_stamp_marker',
    'use_stamp_note', 'use_stamp_render_time', 'use_stamp_scene',
    'use_stamp_sequencer_strip', 'use_stamp_time', 'use_simplify',
    'stamp_note_text', 'stamp_background', 'stamp_font_size',
    'resolution_percentage', 'resolution_x', 'resolution_y',
    'use_antialiasing', 'filepath'])
render_static_keys = render_settings_keys\
    - set(['filepath', 'stamp_note_text',
           'resolution_x', 'resolution_y'])
image_settings_keys = [
    'file_format']
ffmpeg_settings_keys = [
    'format', 'codec', 'audio_codec', 'video_bitrate']

class RENDER_OT_oha_render_opengl_animation(bpy.types.Operator):
    """OpenGL render active viewport."""
    bl_idname = 'render.oha_opengl'
    bl_label = 'OHA OpenGL Render Animation'
    bl_options = {'REGISTER'}

    _timer = None

    # Fungsi modifikasi setting render.
    def temp_settings(self, context):
        space = context.space_data
        scene = context.scene
        render = scene.render
        image = render.image_settings
        ffmpeg = render.ffmpeg
        load = context.scene.red_props.load

        # Setting render dan FFMPEG menggunakan nilai default yang
        # ditentukan dalam kelas OHA_RenderOpenGL_Props, kecuali yang
        # diatur manual dalam kode setelah ini.
        # for key in render_static_keys:
        #     setattr(render, key, getattr(load, 'render_'+key))
        # for key in ffmpeg_settings_keys:
        #     setattr(ffmpeg, key, getattr(load, 'ffmpeg_'+key))

        # Nama folder output didapat dengan mengganti folder file
        # .blend terbuka dengan apapun yang ditentukan pengguna. Nama
        # file output didapat dengan menghapus ekstensi file .blend
        # terbuka.
        blendpath = context.blend_data.filepath
        safechars = '_-.()' + string.digits + string.ascii_letters
#        base_folder = ''.join(c for c in load.render_filepath if c in safechars)
        base_folder = "D:\Playblast\ASJ"
        if blendpath:
            blenddir, blendfile = os.path.split(blendpath)
            blenddir0, blenddir1 = os.path.split(blenddir)
            if blenddir1:
                format_ext_dict = { "MPEG1" : '.mpg',
                                    "MPEG2" : '.mp2',
                                    "MPEG4" : '.mp4',
                                    "AVI" : '.avi',
                                    "QUICKTIME" : '.mov',
                                    "DV" : '.dv',
                                    "H264" : '.mp4',
                                    "XVID" : '.avi',
                                    "OGG" : '.ogg',
                                    "MKV" : '.mkv',
                                    "FLASH" : '.flv',
                                    "WAV" : '.wav',
                                    "MP3" : '.mp3'}
                renderfile = os.path.splitext(blendfile)[0] + format_ext_dict.get(ffmpeg.format)
                render.filepath = os.path.join(blenddir0, base_folder,
                                               renderfile)
        render.stamp_note_text = load.render_stamp_note_text\
            % dict(user=getpass.getuser(),
                   path=bpy.path.basename(blendpath) if blendpath\
                       else "*unsaved*")

        # Only Render hanya berlaku jika area jendela di mana operator
        # ini dijalankan adalah 3D View.
        if space.type == 'VIEW_3D':
            space.overlay.show_overlays = load.space_show_only_render
        # Tentukan format video, agar setting FFMPEG terpakai.
        image.file_format = load.image_file_format
        # Codec H.264 hanya dapat memproses video dengan resolusi
        # kelipatan dua.
        for key in ['resolution_x', 'resolution_y']:
            res = getattr(render, key)
            if res % 2 != 0:
                setattr(render, key, res + 1)

    # def _check_render_thread(self, context):
    #     bpy.ops.render.oha_opengl_settings(save=False)

    #     return {'FINISHED'}

    def cancel(self, context):
        context.window_manager.event_timer_remove(self._timer)
        
        return {'CANCELLED'}

    # def modal(self, context, event):
    #     if event.type == 'TIMER':
    #         return self.check_render_thread(context)

    #     return {'PASS_THROUGH'}

    def execute(self, context):
        wm = context.window_manager

        # bpy.ops.render.oha_opengl_settings(save=True)
        # self.temp_settings(context)

        bpy.ops.render.opengl('INVOKE_DEFAULT', animation=True, view_context=True)

        return {'FINISHED'}

    def invoke(self, context, event):
        return self.execute(context)
    

class RENDER_OT_oha_render_opengl_animation_settings(bpy.types.Operator):
    """Return to previous render settings."""
    bl_idname = 'render.oha_opengl_settings'
    bl_label = 'Restore Render Settings'
    bl_options = {'REGISTER'}

    save : BoolProperty(options={'HIDDEN', 'SKIP_SAVE'})

    def save_settings(self, context):
        scene = context.scene
        space = context.space_data

        temp = context.scene.red_props.temp

        if not props.restored:
            return {'CANCELLED'}

        if space.type == 'VIEW_3D':
            for key in space_settings_keys:
                setattr(temp, 'space_'+key, getattr(space, key))
        for key in render_settings_keys:
            setattr(temp, 'render_'+key, getattr(scene.render, key))
        for key in image_settings_keys:
            setattr(temp, 'image_'+key, getattr(scene.render.image_settings, key))
        for key in ffmpeg_settings_keys:
            setattr(temp, 'ffmpeg_'+key, getattr(scene.render.ffmpeg, key))

        props.restored = False

        return {'FINISHED'}

    def restore_settings(self, context):
        scene = context.scene
        space = context.space_data
        props = context.scene.oha.opengl_props
        temp = props.temp

        if props.restored:
            return {'CANCELLED'}

        if space.type == 'VIEW_3D':
            for key in space_settings_keys:
                setattr(space, key, getattr(temp, 'space_'+key))
        for key in render_settings_keys:
            setattr(scene.render, key, getattr(temp, 'render_'+key))
        for key in image_settings_keys:
            setattr(scene.render.image_settings, key, getattr(temp, 'image_'+key))
        for key in ffmpeg_settings_keys:
            setattr(scene.render.ffmpeg, key, getattr(temp, 'ffmpeg_'+key))

        props.restored = True

        return {'FINISHED'}

    def execute(self, context):
        if self.save:
            return self.save_settings(context)
        else:
            return self.restore_settings(context)
        

class Playblast(bpy.types.Operator):

	'''Render Animation Preview'''
	bl_idname = "scene.playblast"
	bl_label = "Playblast"
	
	def execute(self, context):
            if context.scene.enable_overlays:
                overlays = context.scene.hide_overlays
            
            previous = bpy.context.scene.render.image_settings.file_format
            bpy.context.scene.render.use_stamp = True
            bpy.context.scene.render.use_stamp_frame = True
            bpy.context.space_data.overlay.show_overlays = False
                
            if(previous != "FFMPEG"):
                rd = bpy.context.scene.render
                rd.image_settings.file_format = "FFMPEG"
                rd.ffmpeg.format = "MPEG4"
                rd.ffmpeg.codec = "H264"

            try:
                bpy.ops.render.opengl(animation=True)
                bpy.ops.render.play_rendered_anim()
                
            except:
                self.report({'ERROR'}, "Scene has to be saved first!")
                
            if(previous != "FFMPEG"):
                bpy.context.scene.render.image_settings.file_format = previous

            return {'FINISHED'}