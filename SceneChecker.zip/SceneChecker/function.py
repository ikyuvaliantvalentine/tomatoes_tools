import bpy
from mathutils import Vector, Euler
from . properties import *
        
###########################################
#   for ob in context.scene.objects:
#   for ob in bpy.context.view_layer.objects # Change To This To Avoid Error Object Not Visible In ViewLayer Because Collection is Hide
###########################################
def scene_materials(self, context):
    mat_list_per_object = []
    for ob in bpy.context.view_layer.objects:
        if ob.type == "MESH":
            if ob.data.materials:
                mat_list_per_object.append(ob.data.materials.items())
    # Flatten the list and return a set (unique)
    return set([i[0] for i in sum(mat_list_per_object, [])]) 

def object_multiuser(self, context):
    multi_user_object = []
    for ob in bpy.context.view_layer.objects:
        if ob.type == "MESH":
            if ob.data.users > 1:
                multi_user_object.append(ob)
    return set(multi_user_object)
    

def object_location(self, context):
    loc_list_per_object = []
    for ob in bpy.context.visible_objects:
        if ob.type == "MESH":
            if ob.data.users > 1:
                continue        
            if ob.location != Vector((0,0,0)):       
                loc_list_per_object.append(ob)     
    return set(loc_list_per_object)

def object_scale(self, context):
    scale_list_per_object = []
    for ob in bpy.context.visible_objects:
        if ob.type == "MESH":
            if ob.data.users > 1:
                continue   
            if ob.scale != Vector((1.0,1.0,1.0)):
                scale_list_per_object.append(ob)
    return set(scale_list_per_object)

def object_rotation(self, context):
    rot_list_per_object = []
    for ob in bpy.context.visible_objects:
        if ob.type == "MESH":
            if ob.data.users > 1:
                continue   
            if ob.rotation_euler != Euler((0,0,0), 'XYZ'):
                rot_list_per_object.append(ob)
    return set(rot_list_per_object)

def uv_object_more_than_one(self, context):
    uv_list_per_object = []
    for ob in bpy.context.visible_objects:
        if ob.type == "MESH":
            if ob.data.users > 1:
                continue   
            if(len(ob.data.uv_layers)) > 1:
                uv_list_per_object.append(ob)
    return set(uv_list_per_object)

def uv_object_empty(self, context):
    empty_uv_list_per_object = []
    for ob in bpy.context.visible_objects:
        if ob.type == "MESH":
            if ob.data.users > 1:
                continue   
            if(len(ob.data.uv_layers)) < 1:
                empty_uv_list_per_object.append(ob)
    return set(empty_uv_list_per_object)

def uv_object_name(self, context):
    addon_preferences = get_addon_preferences()
    softwareworkflow = addon_preferences.SoftwareWorkflowOptions
    defaultuvname = addon_preferences.default_uv_name
    
    uv_name_list_per_object = []
    
    for ob in bpy.context.visible_objects:
        if ob.type == "MESH":
            if ob.data.users > 1:
                continue   
            for uvmap in  ob.data.uv_layers :
                if uvmap.name != defaultuvname:
                    uv_name_list_per_object.append(ob)
                # if softwareworkflow == "maya":
                #     if uvmap.name != "map1":
                #         uv_name_list_per_object.append(ob)
                        
                # elif softwareworkflow == "blender":
                #     if uvmap.name != "UVMap":
                #         uv_name_list_per_object.append(ob)
                    
    return set(uv_name_list_per_object)

def valid_uv_name(self, context):
    valid_uv_name = []
    
    for ob in bpy.context.visible_objects:
        if ob.type == "MESH":
            if ob.data.users > 1:
                continue   
            for uvmap in  ob.data.uv_layers :
                name = uvmap.name
                check = name.isalnum()
                if not check:
                    valid_uv_name.append(check)
    return set(valid_uv_name)


def object_vertex_color(self, context):
    ob_vcol = []
    
    for ob in bpy.context.visible_objects:
        if ob.type == "MESH":
            if ob.data.users > 1:
                continue   
            for vcol in ob.data.vertex_colors :
                ob_vcol.append(ob)
    return set(ob_vcol)

def tris_meshcalc(self, context):
    ob_tris = []
    
    for ob in bpy.context.visible_objects:
        if ob.type == "MESH":
            if ob.data.users > 1:
                continue   
            trisCount = 0
            for p in ob.data.polygons:
                if len(ob.data.vertices) < 2000:
                    if len(p.vertices) == 3:
                        trisCount += 1
                        ob_tris.append(ob)
                else:
                    break
    return set(ob_tris)

def ngon_meshcalc(self, context):
    ob_ngon = []
    
    for ob in bpy.context.visible_objects:
        if ob.type == "MESH":
            if ob.data.users > 1:
                continue   
            ngonCount = 0
            for p in ob.data.polygons:
                count = p.loop_total
                if count > 4:
                    ngonCount += 1 
                    ob_ngon.append(ob)
    return set(ob_ngon)

def need_apply_mod(self, context):
    need_apply_mod = []
    
    for ob in bpy.context.visible_objects:
        if ob.type == "MESH":
            if ob.data.users > 1:
                continue   
            if (len(ob.modifiers) > 0):
                need_apply_mod.append(ob)
    return set(need_apply_mod)

def need_remove_mod_subsurf(self, context):
    need_remove_mod_subsurf = []
    
    for ob in bpy.context.visible_objects:
        if ob.type == "MESH":
            if ob.data.users > 1:
                continue   
            for m in ob.modifiers:
                if m.type == 'SUBSURF':
                    need_remove_mod_subsurf.append(ob)
    return set(need_remove_mod_subsurf)

def naming_prefix_check(self, context):
    addon_preferences = get_addon_preferences()
    prefix = addon_preferences.default_prefix_name
    prefix_check = []

    for ob in bpy.context.visible_objects:
        if ob.type == "MESH":
            if ob.data.users > 1:
                continue   
            if not ob.name.startswith((prefix)):
                prefix_check.append(ob)
    return set(prefix_check)

def naming_suffix_check(self, context):
    addon_preferences = get_addon_preferences()
    suffix = addon_preferences.default_suffix_name
    suffix_check = []

    for ob in bpy.context.visible_objects:
        if ob.type == "MESH":
            if ob.data.users > 1:
                continue   
            if not ob.name.endswith((suffix)):
                suffix_check.append(ob)
    return set(suffix_check)

def calculate_blend_size():
    # returns the size of the current Blender file as a string

    filepath = bpy.data.filepath
    size_bytes = os.stat(filepath).st_size if filepath != '' else -1

    kilobyte = 1024  # bytes
    megabyte = 1048576  # bytes
    gigabyte = 1073741824  # bytes

    if 0 <= size_bytes < kilobyte:
        size_scaled = "{:.1f} B".format(size_bytes)
    elif kilobyte <= size_bytes < megabyte:
        size_scaled = "{:.1f} KB".format(size_bytes / kilobyte)
    elif megabyte <= size_bytes < gigabyte:
        size_scaled = "{:.1f} MB".format(size_bytes / megabyte)
    elif size_bytes >= gigabyte:
        size_scaled = "{:.1f} GB".format(size_bytes / gigabyte)
    else:
        size_scaled = "No Data!"

    return size_scaled

def check_non_manifold_edges(self, context):
    non_manifold_edges = []

    for ob in bpy.context.visible_objects:
        if ob.type == "MESH":
            if ob.data.users > 1:
                continue   
            mc = dict([(ed.key, 0) for ed in ob.data.edges])
            for p in ob.data.polygons:
                for ek in p.edge_keys:
                    mc[ek] += 1
                    if mc[ek] > 2:
                        non_manifold_edges.append(ek)
    return set(non_manifold_edges)

def check_empty_mat_slot(self, context):
    empty_mat_slot = []

    for ob in bpy.context.visible_objects:
        if ob.type == "MESH":
            if ob.data.users > 1:
                continue   
            for slot in ob.material_slots:
                mat = slot.material
                if (mat is None):
                    empty_mat_slot.append(mat)
    return set(empty_mat_slot)
