import bpy, bmesh, traceback
from bpy.types import Operator        
#####################################
#Clear Custom Split Normals
#####################################
class ClearNormals(Operator):
    """Clear Custom Split Normals"""
    bl_idname = "object.clear_normals"
    bl_label = "Clear Custom Split Normals"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        selected_obj = bpy.context.selected_objects
        active_obj = bpy.context.active_object
        
        for x in selected_obj:
            bpy.ops.object.select_all(action='DESELECT')
            x.select_set(True)
            if x.type == 'MESH':
                bpy.context.view_layer.objects.active = x
                bpy.ops.mesh.customdata_custom_splitnormals_clear()
                bpy.context.object.data.auto_smooth_angle = 3.14159
                
        # Select again objects
        for j in selected_obj:
            j.select_set(True)
        
        bpy.context.view_layer.objects.active = active_obj                  
        return {'FINISHED'}     
    
####################################
# Split Concave Faces
####################################
class ResolveConcaveFaces(Operator):
    "CLICK - Split Concave Faces of all selected objects"
    bl_idname = "objects.concave_faces"
    bl_label = "Resolve Concave"
    bl_options = {'REGISTER', 'UNDO'}
    
    @classmethod
    def poll(cls, context):
        return bpy.context.mode == 'OBJECT' and bpy.context.selected_objects
    
    def execute(self, context):
        objs = context.selected_objects
        for obj in objs:
            if obj.type == 'MESH':
                context.view_layer.objects.active = obj
                bpy.ops.object.editmode_toggle()
                bpy.ops.mesh.select_all(action='SELECT')
                bpy.ops.mesh.vert_connect_concave()
                self.report({'INFO'}, "Split Concave Faces of " + obj.name)
        return {'FINISHED'}

#####################################
# Select NonManifold
#####################################    
class SelNonManifoldObjects(Operator):
    "CLICK - Select Non Manifold Vertices On Selected Object"
    bl_idname = "objects.nonmanifold_mesh"
    bl_label = "Check NonManifold"
    bl_options = {'REGISTER', 'UNDO'}
    
    @classmethod
    def poll(cls, context):
        return bpy.context.mode == 'OBJECT' and bpy.context.selected_objects
    
    def execute(self, context):
        is_editmode = (context.mode == 'EDIT_MESH')
        if is_editmode:
            obList = context.objects_in_mode_unique_data
        else:
            obList = [
                ob for ob in context.selected_editable_objects
                if ob.type == 'MESH' and ob.data.library is None
            ]
            
        if(context.mode == 'OBJECT'):
            bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.mesh.select_all(action='DESELECT')
        context.tool_settings.mesh_select_mode = (True, False, False)
        bpy.ops.object.mode_set(mode='OBJECT')
            
        for obj in obList:
            context.view_layer.objects.active = obj
            bpy.ops.object.editmode_toggle()
            bpy.ops.mesh.select_non_manifold(extend=False, use_wire=False, use_boundary=False, \
            use_multi_face=False, use_non_contiguous=False, use_verts=True)
            self.report({'INFO'}, "Select NonManifold of " + obj.name)
        return {'FINISHED'}
    
####################################
# Get Object have more than one uv map
####################################
class Get_Object(Operator):
    "CLICK - Select all objects That Have More Than One UVMap "
    bl_idname = "uv.get_object"
    bl_label = "Check Object >1 UV Map "
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):               
        for ob in bpy.context.visible_objects:
            if ob.type == 'MESH':
                if(len(ob.data.uv_layers)) > 1:
                    ob.select_set(state=True)                
        return {'FINISHED'}
    
####################################
# Delete Unused UVMap
####################################
class Clear_UVMAP_except_active_one(Operator):
    "CLICK - Delete Unused UVMaps On Selected Objects"
    bl_idname = "uv.del_unused_uvmap"
    bl_label = "Delete Unused UVMap"
    bl_options = {'REGISTER', 'UNDO'}
    
    @classmethod
    def poll(cls, context):
        return bpy.context.mode == 'OBJECT' and bpy.context.selected_objects
    
    def execute(self, context):    
        selected = bpy.context.selected_objects
        for me in selected:
            uvs = [uv for uv in me.data.uv_layers 
                    if uv !=  me.data.uv_layers.active]
            while uvs:
                me.data.uv_layers.remove(uvs.pop())
        return {'FINISHED'}

####################################
# Rename UV to map1
####################################
class Rename_UV_Map(Operator):
    "CLICK - Rename All UV Map to map1"
    bl_idname = "uv.rename_all"
    bl_label = "Rename to map1 "
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):    
        for obj in bpy.context.selected_objects :
            for uvmap in  obj.data.uv_layers :
                uvmap.name = 'map1'
        return {'FINISHED'}
                                
####################################
# Remove All UV Map
####################################
class UVremove(Operator):
    """Remove UV layer"""
    bl_idname = "object.uv_remove"
    bl_label = "Remove UV layer"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        selected_obj = bpy.context.selected_objects
        active_obj = bpy.context.active_object
        for x in selected_obj:
            bpy.ops.object.select_all(action='DESELECT')
            x.select_set(True)
            bpy.context.view_layer.objects.active = x
            if x.type == 'MESH':
                for a in range(len(x.data.uv_layers)):
                    bpy.ops.mesh.uv_texture_remove()			
        
        # Select again objects
        for j in selected_obj:
            j.select_set(True)
            
        bpy.context.view_layer.objects.active = active_obj

        return {'FINISHED'}
            