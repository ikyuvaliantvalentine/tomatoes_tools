import bpy, os
from bpy.types import Operator

class QuickSettingsEevee(Operator):
    """
    Turn On AO, Volumetric Shadows, Reflections
    Eevee Sample set : 64

    On Indirect Lighting
    Cube Map set : 512
    Diffuse Bounces set : 3
    Diffuse Occlusion set : 3
    Irradiances Smooth set : 0.20
    """
    bl_idname = "op.quicksettingseevee"
    bl_label = "Quick Eevee Settings"

    def execute(self, context):
        eevee = bpy.context.scene.eevee

        bpy.context.scene.render.engine = 'BLENDER_EEVEE'
        eevee.taa_samples = 16
        eevee.taa_render_samples = 64
        eevee.use_taa_reprojection = True

        eevee.shadow_cube_size = '4096'
        eevee.shadow_cascade_size = '4096'
        eevee.use_soft_shadows = True
        eevee.use_shadow_high_bitdepth = True

        eevee.use_ssr = True
        eevee.use_ssr_refraction = True
        eevee.use_ssr_halfres = False
        eevee.ssr_quality = 0.7

        eevee.use_gtao = True
        eevee.gtao_distance = 1

        eevee.use_volumetric_lights = True
        eevee.use_volumetric_shadows = True
        eevee.volumetric_tile_size = '2'

        eevee.gi_diffuse_bounces = 3
        eevee.gi_cubemap_resolution = '512'
        eevee.gi_visibility_resolution = '32'
        eevee.gi_irradiance_smoothing = 0.2
        return {'FINISHED'}

class SpeedupViewportEevee(Operator):
    """
    Eevee Samples : 16
    Turn off AO
    Turn off SSR
    Turn off Volumetric Shadow & Light
    Shadow Cube Size : 64
    Shadow Cascade Size : 64
    Turn off Soft Shadow
    Turn off High BitDepth
    """
    bl_idname = "op.speedupeevee"
    bl_label = "Speedup Eevee"

    def execute(self, context):
        eevee = bpy.context.scene.eevee

        eevee.taa_samples = 16
        eevee.taa_render_samples = 16
        eevee.use_taa_reprojection = True

        eevee.use_gtao = False
        eevee.use_ssr = False
        eevee.use_volumetric_lights = False
        eevee.use_volumetric_shadows = False

        eevee.shadow_cube_size = '64'
        eevee.shadow_cascade_size = '64'
        eevee.use_soft_shadows = False
        eevee.use_shadow_high_bitdepth = False

        return {'FINISHED'}

class QuickAddIrradianceVolume(Operator):
    "Add irradiance volume by selected objects & dimension"
    bl_idname = "op.quickaddirradiancevolume"
    bl_label = "Add Irradiance Volume"

    def execute(self, context):
        for obj in bpy.context.selected_objects:
            bpy.context.view_layer.objects.active = obj
            bpy.ops.object.origin_set(type='ORIGIN_GEOMETRY', center='BOUNDS')
            
            bpy.ops.object.lightprobe_add(type='GRID', enter_editmode=False, align='WORLD', \
            location=(obj.location))
            
            bpy.ops.transform.resize(value=(obj.dimensions/2))


        return {'FINISHED'}