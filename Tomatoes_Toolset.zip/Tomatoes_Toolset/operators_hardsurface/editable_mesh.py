import bpy
from bpy.types import Operator


class MeshEditable_Cylinder(bpy.types.Operator):
    bl_idname = "mesh.editable_cylinder"
    bl_label = "Editable Cyclinder"
    bl_description = "Make Editable Cyclinder"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        mesh_name = "Editable_Cylinder"
        # Create vertex
        bpy.ops.mesh.primitive_plane_add(size=2, enter_editmode=False)
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.mesh.select_mode(use_extend=False, use_expand=False, type='VERT')
        bpy.ops.mesh.merge(type='CENTER')
        new_prim = bpy.context.active_object
        new_prim.name = mesh_name
        new_prim.data.name = mesh_name

        bpy.ops.mesh.extrude_region_move(MESH_OT_extrude_region={"use_normal_flip": False, "mirror": False},
                                         TRANSFORM_OT_translate={"value": (0, 0, 0), "orient_type": 'GLOBAL',
                                                                 "orient_matrix": ((1, 0, 0), (0, 1, 0), (0, 0, 1)),
                                                                 "orient_matrix_type": 'GLOBAL',
                                                                 "constraint_axis": (True, False, False),
                                                                 "mirror": False, "use_proportional_edit": False,
                                                                 "proportional_edit_falloff": 'SMOOTH',
                                                                 "proportional_size": 1,
                                                                 "use_proportional_connected": False,
                                                                 "use_proportional_projected": False, "snap": False,
                                                                 "snap_target": 'CLOSEST', "snap_point": (0, 0, 0),
                                                                 "snap_align": False, "snap_normal": (0, 0, 0),
                                                                 "gpencil_strokes": False, "cursor_transform": False,
                                                                 "texture_space": False, "remove_on_cancel": False,
                                                                 "release_confirm": False, "use_accurate": False})

        # Add Vgroup
        bpy.ops.object.vertex_group_add()
        bpy.context.scene.tool_settings.vertex_group_weight = 1
        bpy.ops.object.vertex_group_assign()
        vgroups = new_prim.vertex_groups

        bpy.ops.object.mode_set(mode='OBJECT')

        # Add Displace Modifier
        disp_modifier = new_prim.modifiers.new("Displace", 'DISPLACE')
        disp_modifier.direction = 'X'
        disp_modifier.name = "Displace - %s" % (disp_modifier.direction)
        disp_modifier.strength = 1
        disp_modifier.mid_level = 0
        disp_modifier.vertex_group = vgroups.active.name
        disp_modifier.show_on_cage = True
        disp_modifier.show_in_editmode = True

        # Add Screw Modifier Z
        screw_modifier = new_prim.modifiers.new("Screw", 'SCREW')
        screw_modifier.axis = 'Z'
        screw_modifier.name = "Screw - %s" % (screw_modifier.axis)
        screw_modifier.angle = 6.28319
        screw_modifier.use_normal_calculate = True
        screw_modifier.use_normal_flip = True
        screw_modifier.use_merge_vertices = True
        screw_modifier.render_steps = 32
        screw_modifier.steps = 32

        # Add Solidify
        solidify_modifier = new_prim.modifiers.new("Solidify", 'SOLIDIFY')
        solidify_modifier.thickness = 2
        solidify_modifier.use_even_offset = True
        solidify_modifier.use_quality_normals = True
        solidify_modifier.offset = 0
        
        bpy.context.object.data.use_auto_smooth = True
        bpy.context.object.data.auto_smooth_angle = 0.523599
        bpy.ops.object.shade_smooth()
        return {'FINISHED'}
