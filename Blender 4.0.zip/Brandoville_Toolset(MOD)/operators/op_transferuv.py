import bpy
from bpy.types import Operator
import numpy as np

class Red_OT_TransferUVs(Operator):
    bl_idname = "mesh.transfer_multiple_uvs"
    bl_label = "Transfer UV"
    bl_description = "Transfer UVs to multiple objects"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        from bpy import context as C

        selected_objects = C.selected_objects
        if len(selected_objects) <= 1:
            self.report({'ERROR'}, "Please select more than one object for UV transfer.")
            return {'CANCELLED'}
        
        source = C.active_object
        targets = (o for o in C.selected_objects if o is not source)
        uvs = np.empty((2 * len(source.data.uv_layers[0].data), 1), "f")
        for o in targets:
            target_layers = o.data.uv_layers
            while target_layers:
                o.data.uv_layers.remove(o.data.uv_layers[0])
            for l in source.data.uv_layers:
                l.data.foreach_get('uv', uvs)
                target_layer = target_layers.new(name=l.name, do_init=False)
                target_layer.data.foreach_set('uv', uvs)
                target_layer.active_clone = l.active_clone
                target_layer.active_render = l.active_render
                target_layer.active = l.active

        self.report({'INFO'}, "UV transfer successful.")
        return {"FINISHED"}