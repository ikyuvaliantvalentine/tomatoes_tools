import bpy, os
from bpy.props import *
from bpy.types import PropertyGroup

def get_addon_preferences():
    addon_name = os.path.basename(os.path.dirname(os.path.abspath(__file__).split("utils")[0]))
    user_preferences = bpy.context.preferences
    addon_prefs = user_preferences.addons[addon_name].preferences     
    return addon_prefs

def dpifac():
    prefs = bpy.context.preferences.system
    # python access to this was only added recently, assume non-retina display is used if using older blender
    if hasattr(prefs, "pixel_size"):
        retinafac = bpy.context.preferences.system.pixel_size
    else:
        retinafac = 1
    return bpy.context.preferences.system.dpi / (72 / retinafac)

types_one =  [("red_c0", "Asset/Scene Management", "Asset/Scene Management", "ASSET_MANAGER" ,0),
              ("red_c1", "Tools", "AnimUtilities","COLLAPSEMENU", 1), ]

# ------------------------------------------------------------------------              
#   Property Group
# ------------------------------------------------------------------------    
class Dropdown_RedProject_Props(PropertyGroup):
    red_create : EnumProperty(name = "Choose UI", default = "red_c0", items = types_one)
    
    # ------------------------------------------------------------------------              
    #   Asset Saver
    # ------------------------------------------------------------------------   

    asset_type: EnumProperty(
        items=[
            ('CHAR', 'Char', 'Character'),
            ('PROP', 'Props', 'Props'),
            ('SET', 'Sets', 'Sets')
        ],
        default='CHAR'
    )    
    
    asset_jobtype: EnumProperty(
        items=[
            ('Proxy', 'Proxy', 'Proxy'),
            ('Model', 'Model', 'Model'),
            ('Rig', 'Rig', 'Rig')
        ],
        default='Rig'
    )   
    
    save_filename : StringProperty(
            name="Filename",
            default="",
            description="Set Filename")  
    

    # ------------------------------------------------------------------------              
    #  Camera UI
    # ------------------------------------------------------------------------ 

    cam_composition_ui_is_visible : BoolProperty(
        name = "Use Camera Composition",
        description = "Show/hide the Use Camera Composition UI.",
        default = False)
    
    
