import bpy
from bpy.types import Operator

# =============================================================================
# Automatic Turntable Operator
# =============================================================================
class SetupTurntableOperator(Operator):
    bl_idname = "op.setup_turntable_operator"
    bl_label = "Set up Turntable"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        self.setup_turntable()
        return {'FINISHED'}

    def apply_material_to_object(self, material, obj):
        if obj.data.materials:
            obj.data.materials[0] = material
        else:
            obj.data.materials.append(material)

    def setup_turntable(self):
        import math
        from mathutils import Vector

        if bpy.context.selected_objects == []:
            self.report({'ERROR'}, "No object selected. Please select a 3D model to proceed.")
            return

        active_object = bpy.context.active_object

        # Camera setup
        bpy.ops.object.camera_add(location=(active_object.location.x + 10, active_object.location.y, active_object.location.z))
        camera = bpy.context.object
        camera.name = "Turntable_Camera"
        
        direction = active_object.location - camera.location
        rot_quat = direction.to_track_quat('Z', 'Y')
        camera.rotation_euler = rot_quat.to_euler()
        camera.rotation_euler.z += math.pi
        bpy.context.scene.camera = camera

        # Add empty and set its name
        bpy.ops.object.empty_add(location=active_object.location)
        empty = bpy.context.object
        empty.name = "Turntable_Empty"

        # Parenting and constraints setup
        camera.parent = empty
        camera.location.z = 0

        track_to = camera.constraints.new(type='TRACK_TO')
        track_to.target = active_object
        track_to.track_axis = 'TRACK_NEGATIVE_Z'
        track_to.up_axis = 'UP_Y'
        
        # Add shader balls and parent to camera
        for loc, is_metallic in [((0.18, -0.13, -1), False), ((0.3, -0.13, -1), True)]:
            bpy.ops.mesh.primitive_uv_sphere_add(radius=0.5, location=(0, 0, 0))
            shader_ball = bpy.context.object
            shader_ball.parent = camera
            shader_ball.location = loc
            shader_ball.scale = (0.1, 0.1, 0.1)
            
            # Smooth shading and subdivision modifier
            bpy.ops.object.shade_smooth()
            bpy.ops.object.modifier_add(type='SUBSURF')
            shader_ball.modifiers["Subdivision"].levels = 2
            shader_ball.modifiers["Subdivision"].render_levels = 2
            
            # Create and assign material
            mat = bpy.data.materials.new(name="ShaderBallMaterial")
            mat.use_nodes = True
            nodes = mat.node_tree.nodes
            shader = nodes.get('Principled BSDF')
            if is_metallic:
                shader.inputs['Metallic'].default_value = 1.0
                shader.inputs['Roughness'].default_value = 0.0
            else:
                shader.inputs['Base Color'].default_value = (0.18, 0.18, 0.18, 1)
                shader.inputs['Roughness'].default_value = 0.5
            self.apply_material_to_object(mat, shader_ball)

        # Animation setup
        start_frame = 0
        end_frame = 250

        bpy.context.scene.frame_start = start_frame
        bpy.context.scene.frame_end = end_frame

        empty.rotation_euler.z = -math.pi / 2
        empty.keyframe_insert(data_path="rotation_euler", frame=start_frame)

        empty.rotation_euler.z = 2 * math.pi
        empty.keyframe_insert(data_path="rotation_euler", frame=end_frame)

        empty.rotation_euler.z = 3 * math.pi / 2
        empty.keyframe_insert(data_path="rotation_euler", frame=end_frame)

        for fcurve in empty.animation_data.action.fcurves:
            for kf in fcurve.keyframe_points:
                kf.interpolation = 'LINEAR'

        # Cleanup and final constraints
        if "Track To" in camera.constraints:
            camera.constraints.remove(camera.constraints["Track To"])

        track_to = camera.constraints.new(type='TRACK_TO')
        track_to.target = empty
        track_to.track_axis = 'TRACK_NEGATIVE_Z'
        track_to.up_axis = 'UP_Y'

        camera.data.lens = 50

        self.report({'INFO'}, "Turntable setup complete with shader balls.")