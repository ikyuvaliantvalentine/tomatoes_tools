import bpy
from bpy.types import Operator


class VIEW3D_OT_Snap_To_Grid(Operator):
    """CLICK - SNAP TO GRID"""
    bl_idname = "object.snap_to_grid"
    bl_label = "Snap To Grid"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):       
        bpy.context.scene.tool_settings.use_snap = True  #Use Snap           
        bpy.context.scene.tool_settings.transform_pivot_point = 'BOUNDING_BOX_CENTER' #Pivot
        bpy.context.scene.tool_settings.use_transform_pivot_point_align = False #Pivot Only Origins
        bpy.context.scene.tool_settings.snap_elements = {'INCREMENT'} #Snapping element type
        bpy.context.scene.tool_settings.snap_target = 'ACTIVE' #Snapping Element Target
        bpy.context.scene.tool_settings.use_snap_grid_absolute = True # Snapping Increment Option For grid
        bpy.context.scene.tool_settings.use_snap_translate = True #Snapping Effect Move
        bpy.context.scene.tool_settings.use_snap_rotate = False #Snapping Effect Rotate
        bpy.context.scene.tool_settings.use_snap_scale = False #Snapping Effect Scale
        bpy.context.scene.tool_settings.use_snap_align_rotation = False  #For Align Rotation
        bpy.context.scene.tool_settings.use_snap_project = False #Project Individual Elements
        bpy.context.scene.tool_settings.use_snap_peel_object = False # Snapping Volume Option
        return {'FINISHED'}
    
class VIEW3D_OT_Snap_To_Vertex(Operator):
    """CLICK - SNAP TO CLOSEST POINT"""
    bl_idname = "object.snap_to_vertex"
    bl_label = "Snap To Vertex"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):            
        bpy.context.scene.tool_settings.use_snap = True  #Use Snap           
        bpy.context.scene.tool_settings.transform_pivot_point = 'MEDIAN_POINT' #Pivot
        bpy.context.scene.tool_settings.use_transform_pivot_point_align = False #Pivot Only Origins
        bpy.context.scene.tool_settings.snap_elements = {'VERTEX'} #Snapping element type
        bpy.context.scene.tool_settings.snap_target = 'CLOSEST' #Snapping Element Target
        bpy.context.scene.tool_settings.use_snap_self = True #Snap Onto Itself (EDIT MODE)
        bpy.context.scene.tool_settings.use_snap_grid_absolute = False # Snapping Increment Option For grid
        bpy.context.scene.tool_settings.use_snap_translate = True #Snapping Effect Move
        bpy.context.scene.tool_settings.use_snap_rotate = False #Snapping Effect Rotate
        bpy.context.scene.tool_settings.use_snap_scale = False #Snapping Effect Scale
        bpy.context.scene.tool_settings.use_snap_align_rotation = False  #For Align Rotation
        bpy.context.scene.tool_settings.use_snap_project = False #Project Individual Elements
        bpy.context.scene.tool_settings.use_snap_peel_object = False # Snapping Volume Option 
        return {'FINISHED'}