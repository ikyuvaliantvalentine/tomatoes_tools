import bpy

def re_cyl(verts):

    for i in bpy.context.selected_objects: 
        r=i.dimensions[1]/2
        h=i.dimensions[2]
        loc=i.location
        rot=i.rotation_euler
        for collection in bpy.data.collections:
            bpy.data.collections[collection.name].objects.unlink(i)
            bpy.data.objects.remove(i)
            bpy.ops.mesh.primitive_cylinder_add(vertices=verts, radius=r, depth=h, enter_editmode=False, location=loc, rotation=rot)
    return



from bpy.props import IntProperty




class re_cylinder(bpy.types.Operator):
    """Add a simple box mesh"""
    bl_idname = "mesh.re_cylinder"
    bl_label = "Recreate Cylinder"
    bl_options = {'REGISTER', 'UNDO'}


    vertices : IntProperty(
            name="Vertices",
            description="Vertices",
            min=3, max=128,
            default=16,
            )


    def execute(self, context):
        re_cyl(self.vertices)
        return {'FINISHED'}

