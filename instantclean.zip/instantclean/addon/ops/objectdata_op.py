# This file is part of Instant Clean
# Copyright (C) 2023  Ruben Messerschmidt

import bpy
from ..utils.common_funcs import (
    update_bmeshs,
    get_bmeshs,
    get_objects
)

from ..utils.objectdata_funcs import *
from ..ui.layout_temps import popup_results


class BC_OT_Objectdata(bpy.types.Operator):
    bl_idname='bc.objectdata'
    bl_label='Objectdata'
    bl_description='Execute Objectdata operations only'
    bl_options={'UNDO', 'REGISTER'}

    stats = {}

    def execute(self, context):
        if not bpy.context.selected_objects and not bpy.context.objects_in_mode:
            return {'CANCELLED'}


        if bpy.context.active_object not in bpy.context.selected_objects:
            if bpy.context.selected_objects:
                bpy.context.view_layer.objects.active = bpy.context.selected_objects[0]
            else:
                bpy.context.view_layer.objects.active = bpy.context.objects_in_mode[0]

        current_mode = bpy.context.mode
        current_active = bpy.context.active_object
        bpy.ops.object.mode_set(mode='EDIT')
        objects = get_objects()
        bmeshs = get_bmeshs(objects)
        self.stats = objectdata(objects, bmeshs)
        update_bmeshs(objects)

        if current_mode == 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
        bpy.context.view_layer.objects.active = current_active

        return {'FINISHED'}

    def draw(self, context):
        popup_results(self.layout, self.stats)


def objectdata(objs, bms):
    stats = {
        'Material Slots': False,
        'Vertex Groups': False
    }

    pg = bpy.context.scene.bc_objectdata
    if pg.empty_vertex_groups:
        for obj, bm in zip(objs, bms):
            stats['Vertex Groups'] += empty_vertex_groups(obj, bm)

    if pg.unused_material_slots:       
        bpy.ops.object.mode_set(mode='OBJECT')
        for obj in objs:
            stats['Material Slots'] += len(obj.material_slots)

        for obj, bm in zip(objs, bms):
            unused_material_slots(obj)

        for obj in objs:
            stats['Material Slots'] -= len(obj.material_slots)
        
        bpy.ops.object.mode_set(mode='EDIT')

    return stats

