import bpy
from .. properties import *

class CustomSizesCheckerMap(bpy.types.Operator):
    bl_idname = "uv.toolkit_custom_sizes_checker_map"
    bl_label = "Create Checker Map"
    bl_description = "Create checker map"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        tomatoes = context.scene.tomatoes_props
        bpy.ops.uv.toolkit_create_checker_map(width=tomatoes.checker_map_width,
                                              height=tomatoes.checker_map_height)
        return {'FINISHED'}
