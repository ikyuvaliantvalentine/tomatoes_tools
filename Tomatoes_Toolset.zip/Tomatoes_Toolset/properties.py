import bpy, os, bpy.utils.previews
from os.path import join, dirname
from bpy.props import *
from bpy.types import PropertyGroup
from bpy.utils import previews
                        
def get_addon_preferences():
    addon_name = os.path.basename(os.path.dirname(os.path.abspath(__file__).split("utils")[0]))
    user_preferences = bpy.context.preferences
    addon_prefs = user_preferences.addons[addon_name].preferences     
    return addon_prefs

def dpifac():
    prefs = bpy.context.preferences.system
    # python access to this was only added recently, assume non-retina display is used if using older blender
    if hasattr(prefs, 'pixel_size'):
        retinafac = bpy.context.preferences.system.pixel_size
    else:
        retinafac = 1
    return bpy.context.preferences.system.dpi / (72 / retinafac)

#####################################################################
# UI List World
#####################################################################
def update_world_selection(self,context):
    tomatoes = context.scene.tomatoes_props
    if tomatoes.selected_world_index <= len(bpy.data.worlds) - 1:
        world = bpy.data.worlds[tomatoes.selected_world_index]
        context.scene.world = world  
        
# ------------------------------------------------------------------------              
#   Custom Icons
# ------------------------------------------------------------------------    
ICONS = {'Label', 'prev_material', 'lighting_outliner'\
, 'delete_material', 'tools_settings', 'ngon', 'triangle', 'check_icon'\
, 'maya_combine', 'maya_separate', 'maya_polysmooth', 'maya_boolean_union'\
, 'maya_extrude_face', 'maya_bevel', 'maya_bridge', 'maya_add_divisions'\
, 'maya_multicut', 'maya_target_weld', 'maya_connect', 'maya_quad_draw' }
ICON_COLLECTION = {}

def register_icons():
    preview_coll = previews.new()
    icons_folder = join(dirname(__file__), "custom_icons")

    for icon in ICONS:
        preview_coll.load(icon, join(icons_folder, icon + ".png"), 'IMAGE')

    ICON_COLLECTION["main"] = preview_coll

def unregister_icons():
    for collection in ICON_COLLECTION.values():
        previews.remove(collection)
    ICON_COLLECTION.clear()

def get_icon(icon):
    preview_coll = ICON_COLLECTION["main"]
    return preview_coll[icon].icon_id
# ------------------------------------------------------------------------              
#   Property Group
# ------------------------------------------------------------------------    
class TomatoesProperties(PropertyGroup):
    
    polycount_pos_x : IntProperty(
        name = "Pos X",
        default = 20,
        min = 0,
        max=2000,
        description = "Margin on the x axis")
        
    polycount_pos_y : IntProperty(
        name = "Pos Y",
        default = 100,
        min = 0,
        max=2000,
        description = "Margin on the y axis")
        
    polycount_font_size : IntProperty(
        name = "Font",
        default = 15,
        min = 10,
        max=150,
        description = "Fontsize")
        
    polycount_font_color : FloatVectorProperty(
        name="Color",
        description="Color for the text",
        default=(1.0, 1.0, 1.0),
        min=0.1,
        max=1,
        subtype='COLOR')
        
    polycount_run : BoolProperty(default=False) 
                
    FontSizeModal : IntProperty(
        name = "Font Size",
        default = 10,
        min = 10,
        max=50,
        description = "Ganti Ukuran Text")
                
    PositionXModal : IntProperty(
        name = "X Offset",
        description = "X Offset of the Viewport GUI")
        
    PositionYModal : IntProperty(
        name = "Y Offset",
        description = "Y Offset of the Viewport GUI")
                    
    Font_Space : IntProperty(
        name = "Font Space",
        default = 1,
        min = -50,
        max=50,
        description = "Font Space on the Viewport GUI")
        
    Font_Space_Y : IntProperty(
        name = "Font Space Y",
        default = 1,
        min = -50,
        max=50,
        description = "Font Space Y Offset on the Viewport GUI")
        
    showhide_flag : BoolProperty(default=False) 
    
    showhide_cam_info: BoolProperty(default=False) 
    
    showhide_label = BoolProperty(default = False) 
    
    # the font size.
    important_hotkeys_font_size : IntProperty(
        name="Text Size",
        description="Text size displayed on 3D View",
        default=11, min=8, max=150)
    
    # color variables
    important_hotkeys_text_color : FloatVectorProperty(
        name="Text Color",
        description="Color for the text",
        default=(1.0, 1.0, 1.0, 1.0),
        min=0.1,
        max=1,
        subtype='COLOR',
        size=4)
            
    # ------------------------------------------------------------------------              
    #   Renamer Object
    # ------------------------------------------------------------------------                                      
    del_prefix : BoolProperty(name='del pr_', default = False, description='hapus kata depan')
          
    prefix : StringProperty(
            name="prefix",
            default="",
            description="Kata Depan")  
            
    prefix_input : StringProperty(
            name="prefix_input",
            default="_",
            description="Separator Kata Depan")  
            
    suffix_input : StringProperty(
            name="suffix_input",
            default="_",
            description="Separator Kata Belakang")  
            
    suffix : StringProperty(
            name="suffix",
            default="",
            description="Kata Belakang")
            
    hide_name: BoolProperty(
        name="Hide Name List",
        description="Hide Name List",
        default = True)
        
    regex_search_pattern: StringProperty(
        name="Search String",
        default="")
    
    regex_replacement_string: StringProperty(
        name="Replacement String",
        default="")
                                                                                    
    # ------------------------------------------------------------------------              
    #   Index UI List
    # ------------------------------------------------------------------------            
    selected_world_index : IntProperty(name="Selected World Index", default=0, update = update_world_selection) 
    selected_material_index : IntProperty(name="Selected Material Index", default=-1)
    active_modifier_index : IntProperty(name="Selected Modifier Index", default=0)
       
    # ------------------------------------------------------------------------              
    #   UI Set Scene
    # ------------------------------------------------------------------------                         
    UISetScene : EnumProperty(
            name="Choose UI",
            items=(
                ("scene_unit", "Units", "Scene Units UI", 'SCENE_DATA', 1),
                ("matcap", "Matcap", "Matcap UI", 'MATSPHERE', 2),
                ("uv", "UV Sets", "UV Sets UI", 'UV', 3)),
            default='scene_unit',
            description = "Choose UI") 
                           
    # ------------------------------------------------------------------------              
    #   Modifier Stack
    # ------------------------------------------------------------------------            
    auto_cut_mirror : BoolProperty(
            name="Use Mirror",
            description = "AutoCut + Add Mirror",
            default = True)
        
    view_level : IntProperty(
            name="View",
            description="Number of subdivisions for 3D view",
            default=1,
            min=0,
            max=6)
            
    render_level : IntProperty(
            name="Render",
            description="Number of subdivisions for rendering",
            default=2,
            min=0,
            max=6)
            
    object_sel : EnumProperty(
            name="Objects",
            items=(
                ("ALL", "All Objects", "Apply settings to all mesh objects"),
                ("SEL", "Selected Objects", "Apply settings to only selected objects"),
                ("VIS", "Visible Objects", "Apply settings to only visible objects")),
            description = "Apply Subdivison Surface Modifier settings to:")
            
    tp_axis : EnumProperty(
              items = [("positiv",  "Positiv", "", 1),
                       ("negativ",  "Negativ", "", 2)], 
                       name = "Side for Remove",
                       description="side for remove")
                                   
    tp_axis_cut : EnumProperty(
              items = [("x",   "X",   "", 1),
                       ("y",   "Y",   "", 2),
                       ("z",   "Z",   "", 3), 
                       ("xy",  "XY",  "", 4), 
                       ("xz",  "XZ",  "", 5), 
                       ("yz",  "YZ",  "", 6), 
                       ("xyz", "XYZ", "", 7)], 
                       name = "Axis for Remove", 
                       description="axis for remove")  
                                               
    #------------------------------------------------------------------------              
    #   UV Editing
    # ------------------------------------------------------------------------ 
    checker_type : EnumProperty(
        name="Sort Axis",
        items=[
            ("UV_GRID", "Checker Grid", "", "", 0),
            ("COLOR_GRID", "Color Grid", "", "", 1)],
        default='UV_GRID'
        )
            
    assign_image: EnumProperty(
        items=[
            ("enable", "Enable", "", "", 0),
            ("disable", "Disable", "", "", 1)
        ],
        default="enable"
    )

    uv_sync_auto_select: EnumProperty(
        items=[
            ("enable", "Enable", "", "", 0),
            ("disable", "Disable", "", "", 1)
        ],
        default="enable"
    )

    uv_sync_selection_mode: EnumProperty(
        items=[
            ("enable", "Enable", "", "", 0),
            ("disable", "Disable", "", "", 1)
        ],
        default="enable"
    )

    boundary_loop_unwrap: EnumProperty(
        items=[
            ("enable", "Enable", "", "", 0),
            ("disable", "Disable", "", "", 1)
        ],
        default="disable"
    )

    boundary_loop_enable_uv_sync: EnumProperty(
        items=[
            ("enable", "Enable", "", "", 0),
            ("disable", "Disable", "", "", 1)
        ],
        default="disable"
    )

    boundary_loop_enable_live_unwrap: EnumProperty(
        items=[
            ("enable", "Enable", "", "", 0),
            ("disable", "Disable", "", "", 1)
        ],
        default="disable"
    )

    move_uv_type : EnumProperty(
        name="Move",
        description="Move UV Parameter",
        items=[
            ("0.5", "0.5", "", 0),
            ("1", "1", "", 1)],
        default='1'
        )
       
    checker_map_width: IntProperty(name="Width", min=0)
    checker_map_height: IntProperty(name="Height", min=0)

    # ------------------------------------------------------------------------              
    #   Object Data Info
    # ------------------------------------------------------------------------   
    object_list_by : EnumProperty(
        name="Filter by",
        items=(
            ("SCENE", "Scene", "List all objects in the scene"),
            ("SELECTED", "Selected", "List all objects in the scene by selected")),
        default="SELECTED",
        description = "Filter list object")
        
    # ------------------------------------------------------------------------              
    #   Camera Projection Lister
    # ------------------------------------------------------------------------   
    UICam : EnumProperty(
            name="Choose UI",
            items=(
                ("ui_expand_cam_settings", "Cam Settings", "Cam Settings UI", 1),
                ("ui_expand_cam_bg_settings", "BG Settings", "Cam Background Settings UI", 2),
                ("ui_expand_cam_proj_settings", "Projection Settings", "Camera Projection Settings", 3)),
            default='ui_expand_cam_settings',
            description = "Choose UI")         

    # ------------------------------------------------------------------------              
    #   Jin Kepepet Property
    # ------------------------------------------------------------------------   
    str_default : StringProperty(
            name="default string",
            default="ANM",
            description="Kata Depan")  
                        
    final_str : StringProperty(
            name="final_string_output",
            default="BG",
            description="Separator Kata Depan") 
            
    apply_file_rev: BoolProperty(
        name="Use file REV",
        description="",
        default = False)
            
    file_rev: EnumProperty(
        items=[
            ("_REV01", "_REV01", "", "", 0),
            ("_REV02", "_REV02", "", "", 1),
            ("_REV03", "_REV03", "", "", 2),
            ("_REV04", "_REV04", "", "", 3),
            ("_REV04", "_REV05", "", "", 4),
        ],
        default="_REV01"
    )