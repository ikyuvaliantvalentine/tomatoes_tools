import bpy
from .. properties import *

def topbar_info(self, context):    
    addon_preferences = get_addon_preferences()
    use_app_handler = addon_preferences.use_app_handler
    if use_app_handler == True:
        layout = self.layout
        layout.scale_x = 1.2
        layout.scale_y = 1.2
        layout.separator()
        layout.prop(context.space_data.overlay, "show_face_orientation", toggle=True)

        addon_preferences = get_addon_preferences()
        row = layout.row()
        row.prop(addon_preferences, "RedSoftwareWorkflowOptions", expand = True)