import bpy
import os
import shutil
from bpy.types import Operator 

class Playblast(Operator):
    "Render Animation Preview"
    bl_idname = "op.scene_playblast"
    bl_label = "Playblast"
    
    def get_parent_directory(self, path):
        path_components = os.path.normpath(path).split(os.path.sep)
        parent_path = os.path.sep.join(path_components[:-1])
        return parent_path
    
    def execute(self, context):
        current_file = bpy.data.filepath
        file_name_with_version = os.path.splitext(os.path.basename(current_file))[0]
        
        src_folder = os.path.dirname(os.path.dirname(current_file))
        archive_folder = os.path.join(src_folder, "archive")
        
        # Extract file name and version number
        file_name, version_str = file_name_with_version.rsplit("_v", 1)
        version = int(version_str) if version_str.isdigit() else 1

#         # Find the highest existing version number
# #        existing_versions = [f for f in os.listdir(src_folder) if f.startswith(f"{file_name}_v") and f.endswith(".mp4")]
#         existing_versions = [f for f in os.listdir(src_folder) if f.startswith(f"{file_name}_v") and f.endswith(".mov")]
#         if existing_versions:
#             existing_versions = [int(v.split("_v")[1].split(".mov")[0]) for v in existing_versions]
# #            existing_versions = [int(v.split("_v")[1].split(".mp4")[0]) for v in existing_versions]
#             version = max(existing_versions) + 1
#         else:
#             version = 1

        # # Find the highest existing version number
        # existing_versions = [f for f in os.listdir(src_folder) if f.startswith(f"{file_name}_v") and f.endswith(".mov")]
        # if existing_versions:
        #     existing_versions = [int(v.split("_v")[1].split(".mov")[0]) for v in existing_versions if v.split("_v")[1].split(".mov")[0].isdigit()]
        #     if existing_versions:
        #         version = max(existing_versions) + 1
        #     else:
        #         version += 1
        # else:
        #     version = 1

        # Find the highest existing version number
        existing_versions = [f for f in os.listdir(src_folder) if f.startswith(f"{file_name}_v") and f.endswith(".mov")]
        existing_version_numbers = []
        for v in existing_versions:
            try:
                v_number = int(v.split("_v")[1].split(".mov")[0])
                existing_version_numbers.append(v_number)
            except ValueError:
                pass
        
        if existing_version_numbers:
            version = max(existing_version_numbers) + 1

        # Create a new versioned filepath
        new_filepath = f"{src_folder}/{file_name}_v{version:04d}.mov"
        new_filepath = bpy.path.native_pathsep(new_filepath)
        bpy.context.scene.render.filepath = new_filepath

        # Check if archive folder exists, if not, create it
        if not os.path.exists(archive_folder):
            os.makedirs(archive_folder)

        # Move old version to the archive folder
        old_version = version - 1
        old_file = f"{src_folder}/{file_name}_v{old_version:04d}.mov"
        if os.path.exists(old_file):
            shutil.move(old_file, f"{archive_folder}/{os.path.basename(old_file)}")


        bpy.context.space_data.overlay.show_overlays = False
        bpy.context.scene.render.use_stamp = True
        bpy.context.scene.render.use_stamp_frame = True

        previous = bpy.context.scene.render.image_settings.file_format
        if(previous != "FFMPEG"):
            rd = bpy.context.scene.render
            rd.image_settings.file_format = "FFMPEG"
            rd.ffmpeg.format = "QUICKTIME"
            rd.ffmpeg.codec = "H264"

        try:
            bpy.ops.render.opengl(animation=True)
            bpy.ops.render.play_rendered_anim()
            
        except:
            self.report({'ERROR'}, "Scene has to be saved first!")
                    
        if(previous != "FFMPEG"):
            bpy.context.scene.render.image_settings.file_format = previous

        return {'FINISHED'}


class Local_Playblast(Operator):
    "Render Animation Preview"
    bl_idname = "op.local_playblast"
    bl_label = "Local Playblast"

    def execute(self, context):
        lpb_dir = os.path.join(os.path.expanduser("~"), "Documents", "local_playblasts")
        if not os.path.exists(lpb_dir):
            os.makedirs(lpb_dir)

        # Get the current blend file name
        shn = bpy.path.basename(bpy.data.filepath)
        shn_filename = os.path.splitext(shn)[0]
        pb_file = shn_filename + ".mov"
        pb_path = os.path.join(lpb_dir, pb_file)

        overlays_enabled = bpy.context.space_data.overlay.show_overlays

        bpy.context.space_data.overlay.show_overlays = False
        bpy.context.scene.render.use_stamp = True
        bpy.context.scene.render.use_stamp_frame = True

        # Set the output file path
        bpy.context.scene.render.filepath = pb_path
        previous = bpy.context.scene.render.image_settings.file_format
        if previous != "FFMPEG":
            rd = bpy.context.scene.render
            rd.image_settings.file_format = "FFMPEG"
            rd.ffmpeg.format = "QUICKTIME"
            rd.ffmpeg.codec = "H264"

        # Perform the playblast (render animation)
        try:
            bpy.ops.render.opengl(animation=True)
            bpy.ops.render.play_rendered_anim()
            self.report({'INFO'}, "Success: Playblast generated at {0}".format(pb_path))
        except Exception as e:
            self.report({'ERROR'}, "Error: {0}".format(str(e)))

        bpy.context.space_data.overlay.show_overlays = overlays_enabled

        return {'FINISHED'}



class PublishShotOperator(bpy.types.Operator):
    bl_idname = "wm.publish_shot"
    bl_label = "Publish Shot"

    @staticmethod
    def publish_playblast(base_dir):
        # Get the current Blender file name
        shn = bpy.path.basename(bpy.data.filepath)
        shn_filename = os.path.splitext(shn)[0]
        pb_file = shn_filename + ".mov"
        split_shot_code = shn_filename.split("_")

        if len(split_shot_code) < 5:
            print("Error: Invalid shot name.")
            return None, "Invalid shot name."

        path = bpy.data.filepath
        folder_name = os.path.basename(os.path.dirname(path))
        # published_pb_dir = os.path.join(base_dir, "Publish", split_shot_code[4], "Playblast")
        published_pb_dir = os.path.join(base_dir, "Publish", folder_name, "Playblast")


        if not os.path.exists(published_pb_dir):
            os.makedirs(published_pb_dir)

        pb_path_published = os.path.join(published_pb_dir, pb_file)

        overlays_enabled = bpy.context.space_data.overlay.show_overlays
        bpy.context.space_data.overlay.show_overlays = False
        bpy.context.scene.render.use_stamp = True
        bpy.context.scene.render.use_stamp_frame = True

        # Set the output file path for the playblast
        bpy.context.scene.render.filepath = pb_path_published
        previous = bpy.context.scene.render.image_settings.file_format
        if previous != "FFMPEG":
            rd = bpy.context.scene.render
            rd.image_settings.file_format = "FFMPEG"
            rd.ffmpeg.format = "QUICKTIME"
            rd.ffmpeg.codec = "H264"

        # Perform the playblast (render animation)
        try:
            bpy.ops.render.opengl(animation=True)
            bpy.ops.render.play_rendered_anim()
            print("Success: Playblast generated at {0}".format(pb_path_published))
        except Exception as e:
            print("Error: {0}".format(str(e)))
            return None, str(e)

        bpy.context.space_data.overlay.show_overlays = overlays_enabled

        return pb_path_published, None

    def execute(self, context):
        shn = bpy.path.basename(bpy.data.filepath)
        sn = bpy.data.filepath

        # Extract base directory up to the shot code level
        # Example: 'E:/ANIM_DELETE/S_02/01/01_001/WIP/Layout' -> 'E:/ANIM_DELETE/S_02/01/01_001'
        base_dir = os.path.dirname(os.path.dirname(os.path.dirname(sn)))
        base_dir_compiled = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(sn))))

        if shn:
            long_shot_name = os.path.splitext(shn)[0]
            file_ext = os.path.splitext(shn)[1][1:]
            split_shot_code = long_shot_name.split("_")

            if len(split_shot_code) < 5:
                self.report({'ERROR'}, "Invalid shot format.")
                return {'CANCELLED'}

            pb_path, pb_err = self.publish_playblast(base_dir)

            if pb_path:
                short_shot_name = "_".join(split_shot_code[:4])
                compiled_pb_dir = os.path.join(base_dir_compiled, "_compiled", "Playblast")

                if not os.path.exists(compiled_pb_dir):
                    os.makedirs(compiled_pb_dir)

                compiled_pb = os.path.join(compiled_pb_dir, short_shot_name + ".mov")
                shutil.copy2(pb_path, compiled_pb)

                # Save Blender file to compiled
                compiled_scene_dir = os.path.join(base_dir_compiled, "_compiled", "Blender")

                if not os.path.exists(compiled_scene_dir):
                    os.makedirs(compiled_scene_dir)

                compiled_scene = os.path.join(compiled_scene_dir, short_shot_name + "." + file_ext)
                bpy.ops.wm.save_as_mainfile(filepath=compiled_scene)

                # Save Blender file to publish
                published_scene_dir = os.path.join(base_dir, "Publish", split_shot_code[4], "Blender")

                if not os.path.exists(published_scene_dir):
                    os.makedirs(published_scene_dir)

                published_scene = os.path.join(published_scene_dir, shn)
                bpy.ops.wm.save_as_mainfile(filepath=published_scene)

                # Reopen original file
                bpy.ops.wm.open_mainfile(filepath=sn)

                self.report({'INFO'}, "Shot published successfully.")
                return {'FINISHED'}
            else:
                self.report({'ERROR'}, pb_err)
                return {'CANCELLED'}

        self.report({'ERROR'}, "Shot not found.")
        return {'CANCELLED'}
    

# class PublishShotOperator(bpy.types.Operator):
#     bl_idname = "wm.publish_shot"
#     bl_label = "Publish Shot"

#     @staticmethod
#     def create_dummy_playblast(pb_path):
#         # Create a dummy file to simulate a playblast
#         with open(pb_path, 'w') as f:
#             f.write("This is a dummy playblast file.")

#     @staticmethod
#     def publish_playblast(base_dir):
#         # Get the current Blender file name
#         shn = bpy.path.basename(bpy.data.filepath)
#         shn_filename = os.path.splitext(shn)[0]
#         pb_file = shn_filename + ".mov"
#         split_shot_code = shn_filename.split("_")

#         if len(split_shot_code) < 5:
#             print("Error: Invalid shot name.")
#             return None, "Invalid shot name."

#         published_pb_dir = os.path.join(base_dir, "Publish", split_shot_code[4], "Playblast")

#         if not os.path.exists(published_pb_dir):
#             os.makedirs(published_pb_dir)

#         pb_path = os.path.join(published_pb_dir, pb_file)

#         # Create a dummy playblast
#         PublishShotOperator.create_dummy_playblast(pb_path)

#         return pb_path, None

#     def execute(self, context):
#         shn = bpy.path.basename(bpy.data.filepath)
#         sn = bpy.data.filepath

#         # Extract base directory up to the shot code level
#         # Example: 'E:/ANIM_DELETE/S_02/01/01_001/WIP/Layout' -> 'E:/ANIM_DELETE/S_02/01/01_001'
#         base_dir = os.path.dirname(os.path.dirname(os.path.dirname(sn)))
#         base_dir_compiled = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(sn))))

#         if shn:
#             long_shot_name = os.path.splitext(shn)[0]
#             file_ext = os.path.splitext(shn)[1][1:]
#             split_shot_code = long_shot_name.split("_")

#             if len(split_shot_code) < 5:
#                 self.report({'ERROR'}, "Invalid shot format.")
#                 return {'CANCELLED'}

#             pb_path, pb_err = self.publish_playblast(base_dir)

#             if pb_path:
#                 short_shot_name = "_".join(split_shot_code[:4])
#                 compiled_pb_dir = os.path.join(base_dir_compiled, "_compiled", "Playblast")

#                 if not os.path.exists(compiled_pb_dir):
#                     os.makedirs(compiled_pb_dir)

#                 compiled_pb = os.path.join(compiled_pb_dir, short_shot_name + ".mov")
#                 shutil.copy2(pb_path, compiled_pb)

#                 # Save Blender file to compiled
#                 compiled_scene_dir = os.path.join(base_dir_compiled, "_compiled", "Blender")

#                 if not os.path.exists(compiled_scene_dir):
#                     os.makedirs(compiled_scene_dir)

#                 compiled_scene = os.path.join(compiled_scene_dir, short_shot_name + "." + file_ext)
#                 bpy.ops.wm.save_as_mainfile(filepath=compiled_scene)

#                 # Save Blender file to publish
#                 published_scene_dir = os.path.join(base_dir, "Publish", split_shot_code[4], "Blender")

#                 if not os.path.exists(published_scene_dir):
#                     os.makedirs(published_scene_dir)

#                 published_scene = os.path.join(published_scene_dir, shn)
#                 bpy.ops.wm.save_as_mainfile(filepath=published_scene)

#                 # Reopen original file
#                 bpy.ops.wm.open_mainfile(filepath=sn)

#                 self.report({'INFO'}, "Shot published successfully.")
#                 return {'FINISHED'}
#             else:
#                 self.report({'ERROR'}, pb_err)
#                 return {'CANCELLED'}

#         self.report({'ERROR'}, "Shot not found.")
#         return {'CANCELLED'}