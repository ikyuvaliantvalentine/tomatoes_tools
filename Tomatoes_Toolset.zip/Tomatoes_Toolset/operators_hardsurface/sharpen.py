import bpy
from bpy.props import *
from math import *

class csharpenOperator(bpy.types.Operator):
    '''Sharpen With Modifiers and Bevelling'''
    bl_idname = "csharpen.objects"
    bl_label = "CSharpen"
    bl_options = {'REGISTER', 'UNDO'} 

    items = [(x.identifier, x.name, x.description, x.icon) 
             for x in bpy.types.Modifier.bl_rna.properties['type'].enum_items]

    modtypes : EnumProperty(name="Modifier Types",
                           items=[(id, name, desc, icon, 2**i) for i, (id, name, desc, icon) in enumerate(items)
                                   if id in ['BOOLEAN', 'MIRROR', 'BEVEL', 'SOLIDIFY']],
                           description="Don't apply these",
                           default={'BEVEL'},
                           options={'ENUM_FLAG'})

    angle : FloatProperty(name="AutoSmooth Angle",
                          description="Set AutoSmooth angle",
                          default= radians(60.0),
                          min = 0.0,
                          max = radians(180.0),
                          subtype='ANGLE')

    bevelwidth : FloatProperty(name="Bevel Width Amount",
                               description="Set Bevel Width",
                               default=0.0200,
                               min =
                               0.002,
                               max =0.25)

    apply_all : BoolProperty(default = True)

    original_bevel : FloatProperty()

    @classmethod
    def poll(cls, context):
        ob = context.object
        if ob is None:
            return False
        return (ob.type == 'MESH')

        #F6 MENU
    def draw(self, context):
        layout = self.layout
        box = layout.box()
        # DRAW YOUR PROPERTIES IN A BOX
        #box.prop( self, 'ssharpangle', text = "SsharpAngle")
        col = box.column()
        col.prop(self, "modtypes", expand=True)
        box.prop( self, 'angle', text = "SmoothingAngle" )
        box.prop( self, 'bevelwidth', text = "BevelWidth")
        box.prop( self, 'apply_all', text = "ApplyAll")

    def execute(self, context):
        scene = context.scene
        ob = context.object  # soapbox call don't use bpy.context as context is passed
        obs = context.selected_objects
        angle = self.angle
        original_bevel = self.original_bevel
        bevelwidth = self.bevelwidth
        
        #If bevel modifier unavaible on active object
        if "Bevel" in context.active_object.modifiers:
            bpy.ops.object.modifier_add(type='BEVEL')
        else:
            bpy.ops.object.modifier_add(type='BEVEL')  

        #Sets Original Bevel To Initial Value
        #original_bevel = 0.2
        original_bevel = bpy.context.object.modifiers["Bevel"].width

        #Just Trying To Make It Work
        bpy.ops.object.modifier_remove(modifier="Bevel")
        bpy.ops.object.modifier_remove(modifier="Solidify")
        #so that the csharp doesnt mesh up the object

        #keep the old here for now
        bpy.ops.object.modifier_add(type='BEVEL')
        bpy.context.object.modifiers["Bevel"].use_clamp_overlap = False
        bpy.context.object.modifiers["Bevel"].show_in_editmode = False
        bpy.context.object.modifiers["Bevel"].width = bevelwidth
        bpy.context.object.modifiers["Bevel"].segments = 3
        bpy.context.object.modifiers["Bevel"].profile = 0.70
        bpy.context.object.modifiers["Bevel"].limit_method = 'WEIGHT'

        mod_dic = {}
        if self.apply_all:
            #remove modifiers no one would want applied in this instance

            #bpy.ops.object.modifier_remove(modifier="Bevel")
            #bpy.ops.object.modifier_remove(modifier="Solidify")
            # replace with       
            mods = [m for m in ob.modifiers if m.type in self.modtypes]
            for mod in mods:

                mod_dic[mod.name] = {k:getattr(mod, k) for k in mod.bl_rna.properties.keys()
                                     if k not in ["rna_type"]}
                print(mod_dic)
                ob.modifiers.remove(mod)

            #convert to mesh for sanity
            #bpy.ops.object.convert(target='MESH')            
            #Object.to_mesh(scene, apply_modifiers, settings, calc_tessface=True, calc_undeformed=False)

            mesh_name = ob.data.name
            ob.data.name = 'XXXX'
            # remove the old mesh
            if not ob.data.users:
                bpy.data.meshes.remove(ob.data)      
                
            #PATCH PART 2.8
            dg = bpy.context.evaluated_depsgraph_get()
            mesh = bpy.data.meshes.new_from_object(ob.evaluated_get(dg), preserve_all_data_layers=True, depsgraph=dg)                    
            
            ob.modifiers.clear()
            mesh.name = ob.data.name
            ob.data = mesh

            for name, settings in mod_dic.items():
                m = ob.modifiers.new(name, settings["type"])
                for s, v in settings.items():
                    if s == "type":
                        continue
                    setattr(m, s, v)

        return {'FINISHED'}