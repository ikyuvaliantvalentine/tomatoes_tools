# This file is part of Instant Clean
# Copyright (C) 2023  Ruben Messerschmidt

import bpy
import bmesh
from mathutils import Vector
from .common_funcs import select_geo, deselect_all_geo


def recalculate(bm, faces, inside):
    count = 0
    compare = {}
    for f in faces:
        compare[f.index] = Vector(f.normal)

    select_geo(faces)
    bpy.ops.mesh.normals_make_consistent(inside=inside)
    deselect_all_geo(bm)

    for f in faces:
        try:
            if (f.normal - compare[f.index]).length > 0.0001:
                count += 1
        except:
            continue

    return count


def auto_smooth(obj, bm, angle):
    for f in bm.faces:
        f.smooth = True
    bpy.context.view_layer.objects.active = obj
    bpy.context.object.data.use_auto_smooth = True
    bpy.context.object.data.auto_smooth_angle = angle


def weighted_normals(obj: bpy.types.Object):
    for m in obj.modifiers.values():
        if m.type == 'WEIGHTED_NORMAL':
            return

    mod = obj.modifiers.new(name='Weighted Normals', type='WEIGHTED_NORMAL')
    mod.keep_sharp = True


def clear_custom_split_normals():
    bpy.ops.mesh.customdata_custom_splitnormals_clear()


def clear_sharp_edges(bm: bmesh.types.BMesh):
    count = 0
    for e in [e for e in bm.edges if not e.smooth]:
        e.smooth = True
        count += 1

    return count



