import bpy
                
class ApplyAll_OT_ModB(bpy.types.Operator):
    bl_idname = "applyallmodifiers.func_2"
    bl_label = "ApplyAllModifiers"
    def execute(self,context):

        CollectonAvaible = False
        for cl in bpy.data.collections:
            print(cl.name)
            if cl.name == "BackupCollection":
                CollectonAvaible = True
                break

        if CollectonAvaible == False:
            bpy.ops.object.mode_set(mode = 'OBJECT')
            bpy.ops.object.select_all(action='DESELECT')
            bpy.ops.collection.create(name="BackupCollection")
            BackupCollection = bpy.data.collections['BackupCollection']
            C = bpy.context
            C.scene.collection.children.link(BackupCollection)
    
        def ShowMessageBox(message = "", title = "Message Box", icon = 'INFO'):

            def draw(self, context):
                self.layout.label(text=message)

            bpy.context.window_manager.popup_menu(draw, title = title, icon = icon)
            

        src_obj = bpy.context.active_object

        new_obj = src_obj.copy()
        new_obj.data = src_obj.data.copy()
        new_obj.animation_data_clear()
        bpy.data.collections['BackupCollection'].objects.link(new_obj)
        for ob in bpy.data.collections['BackupCollection'].objects:
            ob.hide_viewport = True
            print(ob)
        
        try:
            if len(bpy.context.object.modifiers.items())>0:
                itemEN = ""
                for item in bpy.context.object.modifiers.items():
                    print("type: ",type(item[0]),"name: ",item[0])
                    itemEN = item[0]
                    bpy.ops.object.modifier_apply(modifier=item[0])
                ShowMessageBox("applied.")

            else:
                ShowMessageBox("No modifier available.")
        except RuntimeError as ex:
            ShowMessageBox(itemEN +" modifier settings are not complete.", "Error", 'ERROR')
            print(itemEN)
            
        objects = bpy.context.scene.objects
        
        return {'FINISHED'}

class RemoveAll_OT_ModB(bpy.types.Operator):
    bl_idname = "removeallmodifiers.func_2"
    bl_label = "RemoveAllModifiers"
    
    def execute(self,context):
        bpy.ops.object.mode_set(mode = 'OBJECT')
        def ShowMessageBox(message = "", title = "Message Box", icon = 'INFO'):

            def draw(self, context):
                self.layout.label(text=message)

            bpy.context.window_manager.popup_menu(draw, title = title, icon = icon)
            
        try:
            if len(bpy.context.object.modifiers.items())>0:
                itemEN = ""
                for item in bpy.context.object.modifiers.items():
                    print("type: ",type(item[0]),"name: ",item[0])
                    itemEN = item[0]
                    bpy.ops.object.modifier_remove(modifier=item[0])
                ShowMessageBox("Removed.")
            else:
                ShowMessageBox("No modifier available.")
        except RuntimeError as ex:
            ShowMessageBox(itemEN +" modifier settings are not complete.", "Error", 'ERROR')
            print(itemEN)
        
        return {'FINISHED'}