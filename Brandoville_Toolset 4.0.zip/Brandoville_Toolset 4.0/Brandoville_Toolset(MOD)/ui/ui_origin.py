import bpy
from .. ui.ui_mesh import *
from .. properties import *

def draw_pivot_and_cursor_ui(self, context, layout):
    red = context.scene.red_props
    addon_preferences = get_addon_preferences()

    col = layout.column(align=True)

    if not red.display_origin: 
          
        box = col.box().column(align=True)
        
        row = box.row(align=True)   
        row.prop(red, "display_origin", text="", icon="TRIA_RIGHT", toggle = True)                
        row.label(text="Pivot & 3D Cursor")     

    else:
        
        box = col.box().column(align=True)
        row = box.row(align=True)  
        row.prop(red, "display_origin", text="", icon="TRIA_DOWN", toggle = True)            
        row.label(text="Pivot & 3D Cursor")   

        col = box.column(align=True)
        col.scale_x = 1.2
        col.scale_y = 1.2

        col.operator("op.center_pivot")
        col.operator("op.pivot2cursor")
        col.operator("op.pivot_to_bottom")
        col.separator()
        col.operator("op.smart_cursor_modal")

        col = box.column(align=True)
        col.label(text="3D Cursor")

        col.operator("view3d.snap_cursor_to_selected")
        col.operator("view3d.snap_cursor_to_center")


