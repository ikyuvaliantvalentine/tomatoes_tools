import bpy
from bpy.types import Operator
from bpy.props import *    
from .. properties import *

####################################
# Get Object have more than one uv map
####################################
class Red_Get_Object(Operator):
    "CLICK - Select all objects That Have More Than One UVMap "
    bl_idname = "op.get_object_more_than_one_map"
    bl_label = "Check Object >1 UV Map "
    bl_options = {'REGISTER', 'UNDO'}
    
    @classmethod
    def poll(cls, context):
        if context.object is None:
            return False
        return True

    def execute(self, context):               
        for ob in context.scene.objects:
            ob.select_set(False)

            # Abort, if the current object is not a mesh.
            if not ob.type == "MESH":
                continue
            
            if ob.type == 'MESH':
                if(len(ob.data.uv_layers)) > 1:
                    # if not ob.data.users > 1:
                    ob.select_set(state=True)                
        return {'FINISHED'}

####################################
# Delete Unused UVMap
####################################
class Clear_UVMAP_except_active_one(Operator):
    "CLICK - Delete Unused UVMaps On Selected Objects"
    bl_idname = "reduv.del_unused_uvmap"
    bl_label = "Delete Unused UVMap On Selected Objects"
    bl_options = {'REGISTER', 'UNDO'}
    
    @classmethod
    def poll(cls, context):
        return bpy.context.mode == 'OBJECT' and bpy.context.selected_objects
    
    def execute(self, context):    
        selected = bpy.context.selected_objects
        for me in selected:
            uvs = [uv for uv in me.data.uv_layers 
                    if uv !=  me.data.uv_layers.active]
            while uvs:
                me.data.uv_layers.remove(uvs.pop())
        return {'FINISHED'}

####################################
# Rename UV to map1
####################################
class Rename_UV_Map(Operator):
    "CLICK - Rename All UV Map"
    bl_idname = "redop.uv_rename_all"
    bl_label = "Rename to Custom UV Name"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):    
        addon_preferences = get_addon_preferences()
        uvname = addon_preferences.custom_uvname 
        for obj in bpy.context.selected_objects :
            for uvmap in  obj.data.uv_layers :
                uvmap.name = uvname
        return {'FINISHED'}
    