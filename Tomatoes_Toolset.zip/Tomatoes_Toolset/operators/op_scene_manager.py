import bpy
from bpy.types import Operator

##############################################################
#    Handles moving all empty's
##############################################################
class SetEmptyCollection(Operator):
    bl_idname = "op.scene_empty_coll"
    bl_description = "Move all empties to Empty Collection"
    bl_label = "Group All Empties"

    def execute(self, context):
        collectionFound = False
        empty_collection_name = "Empty"
        old_obj = bpy.context.selected_objects
        scene = bpy.context.scene.objects
        empties = []

        bpy.ops.object.select_all(action='DESELECT')
        for myCol in bpy.data.collections:
            if myCol.name == empty_collection_name:
                collectionFound = True
                break
        for obj in scene:
            if obj.type == "EMPTY":
                empties.append(obj)

        if collectionFound == False and not len(empties) == 0:
            empty_collection = bpy.data.collections.new(empty_collection_name)
            bpy.context.scene.collection.children.link(empty_collection)
            bpy.data.collections[empty_collection_name].color_tag = 'COLOR_01'
            self.report({'INFO'}, "Moved all empties")
        else:
            self.report({'WARNING'}, "No empties in scene to sort")
        
        for obj in empties:
            for coll in obj.users_collection:
                coll.objects.unlink(obj)
            bpy.data.collections[empty_collection_name].objects.link(obj)
      
        bpy.ops.object.select_all(action='DESELECT')

        for x in old_obj:     
            x.select_set(state=True)

        return {'FINISHED'}

##############################################################
#    Handles moving all lattice's
##############################################################
class SetLatticeCollection(Operator):
    bl_idname = "op.scene_lattice_coll"
    bl_description = "Move all Lattices to Light Collection"
    bl_label = "Group All Lattices"

    def execute(self, context):
        collectionFound = False
        lattice_collection_name = "Lattice"
        old_obj = bpy.context.selected_objects
        scene = bpy.context.scene.objects
        lattice = []

        bpy.ops.object.select_all(action='DESELECT')
        for myCol in bpy.data.collections:
            if myCol.name == lattice_collection_name:
                collectionFound = True
                break
        for obj in scene:
            if obj.type == "LATTICE":
                lattice.append(obj)

        if collectionFound == False and not len(lattice) == 0:
            latticecollection = bpy.data.collections.new(lattice_collection_name)
            bpy.context.scene.collection.children.link(latticecollection)
            bpy.data.collections[lattice_collection_name].color_tag = 'COLOR_03'
            self.report({'INFO'}, "Moved all Lattices")
        else:
            self.report({'WARNING'}, "No lattices in scene to sort")
        
        for obj in lattice:
            for coll in obj.users_collection:
                coll.objects.unlink(obj)
            bpy.data.collections[lattice_collection_name].objects.link(obj)
      
        bpy.ops.object.select_all(action='DESELECT')

        for x in old_obj:     
            x.select_set(state=True)

        return {'FINISHED'}

##############################################################
#    Handles moving all light's
##############################################################
class SetLightCollection(Operator):
    bl_idname = "op.scene_light_coll"
    bl_description = "Move all Lights to Light Collection"
    bl_label = "Group All Lights"

    def execute(self, context):
        collectionFound = False
        light_collection_name = "Light"
        old_obj = bpy.context.selected_objects
        scene = bpy.context.scene.objects
        lights = []

        bpy.ops.object.select_all(action='DESELECT')
        for myCol in bpy.data.collections:
            if myCol.name == light_collection_name:
                collectionFound = True
                break
        for obj in scene:
            if obj.type == "LIGHT":
                lights.append(obj)

        if collectionFound == False and not len(lights) == 0:
            lightcollection = bpy.data.collections.new(light_collection_name)
            bpy.context.scene.collection.children.link(lightcollection)
            bpy.data.collections[light_collection_name].color_tag = 'COLOR_02'
            self.report({'INFO'}, "Moved all Lights")
        else:
            self.report({'WARNING'}, "No lights in scene to sort")
        
        for obj in lights:
            for coll in obj.users_collection:
                coll.objects.unlink(obj)
            bpy.data.collections[light_collection_name].objects.link(obj)
      
        bpy.ops.object.select_all(action='DESELECT')

        for x in old_obj:     
            x.select_set(state=True)

        return {'FINISHED'}
