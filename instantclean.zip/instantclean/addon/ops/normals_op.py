# This file is part of Instant Clean
# Copyright (C) 2023  Ruben Messerschmidt

import bpy
from ..utils.common_funcs import (
    visible_faces,
    update_bmeshs,
    get_bmeshs,
    get_objects
)

from ..utils.normals_funcs import *
from ..ui.layout_temps import popup_results


class BC_OT_Normals(bpy.types.Operator):
    bl_idname='bc.normals'
    bl_label='Normals'
    bl_description='Execute Normals operations only'
    bl_options={'UNDO', 'REGISTER'}

    stats = {}

    def execute(self, context):
        if not bpy.context.selected_objects and not bpy.context.objects_in_mode:
            return {'CANCELLED'}

        current_mode = bpy.context.mode
        current_active = bpy.context.active_object
        bpy.ops.object.mode_set(mode='EDIT')
        objects = get_objects()
        bmeshs = get_bmeshs(objects)
        self.stats = normals(bmeshs, objects)
        update_bmeshs(objects)

        if current_mode == 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
        bpy.context.view_layer.objects.active = current_active

        return {'FINISHED'}

    def draw(self, context):
        popup_results(self.layout, self.stats)


def normals(bms, objs):
    stats = {
        'Flipped': False,
        'Sharp Edges': False,
    }

    pg = bpy.context.scene.bc_normals
    
    if pg.recalculate:
        for bm in bms:
            stats['Flipped'] += recalculate(bm, visible_faces(bm), pg.recalculate_orientation == 'INSIDE')

    if pg.auto_smooth:
        for obj, bm in zip(objs, bms):
            auto_smooth(obj, bm, pg.auto_smooth_ang)

    if pg.weighted_normals:
        for obj in objs:
            weighted_normals(obj)
    
    if pg.clear_custom_split_normals:
        active = bpy.context.view_layer.objects.active
        for obj in objs:
            bpy.context.view_layer.objects.active = obj
            clear_custom_split_normals()

        bpy.context.view_layer.objects.active = active

    if pg.clear_sharp_edges:
        for bm in bms:
            stats['Sharp Edges'] += clear_sharp_edges(bm)

    return stats