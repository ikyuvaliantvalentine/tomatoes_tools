# This file is part of Instant Clean
# Copyright (C) 2023  Ruben Messerschmidt

from .results_op import BC_OT_Close_Results
from .presets_op import BC_MT_Preset_Menu, BC_OT_Add_Preset, BC_OT_Override_Preset
from .prefs_op import BC_OT_Reinstall_Presets
from .clean_op import BC_OT_Clean
from .repair_op import BC_OT_Repair
from .limdiss_op import BC_OT_Limdiss
from .topology_op import BC_OT_Topology
from .normals_op import BC_OT_Normals
from .objectdata_op import BC_OT_Objectdata


classes = [
    BC_OT_Close_Results,
    BC_MT_Preset_Menu,
    BC_OT_Add_Preset,
    BC_OT_Override_Preset,
    BC_OT_Reinstall_Presets,
    BC_OT_Clean,
    BC_OT_Repair,
    BC_OT_Limdiss,
    BC_OT_Topology,
    BC_OT_Normals,
    BC_OT_Objectdata
]

import bpy

def register():
    for cls in classes:
        bpy.utils.register_class(cls)

def unregister():
    for cls in classes:
        bpy.utils.unregister_class(cls)