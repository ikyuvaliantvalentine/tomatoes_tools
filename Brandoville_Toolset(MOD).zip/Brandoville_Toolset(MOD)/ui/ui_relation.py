import bpy
from .. properties import *

def draw_relation_ui(self, context, layout):
    red = context.scene.red_props
    col = layout.column(align=True)

    if not red.display_relation: 
          
        box = col.box().column(align=True)
        
        row = box.row(align=True)   
        row.prop(red, "display_relation", text="", icon="TRIA_RIGHT", toggle = True)                
        row.label(text="Relations")     

    else:
        
        box = col.box().column(align=True)
        row = box.row(align=True)  
        row.prop(red, "display_relation", text="", icon="TRIA_DOWN", toggle = True)            
        row.label(text="Relations")

        box = col.box().column(align=True)                         
        row = box.column(align=True)
        row.scale_x = 1.2
        row.scale_y = 1.2

        row.menu("VIEW3D_MT_make_links", text="Make Links", icon="LINKED")
        row.separator()
        row.menu("VIEW3D_MT_make_single_user", icon="UNLINKED")