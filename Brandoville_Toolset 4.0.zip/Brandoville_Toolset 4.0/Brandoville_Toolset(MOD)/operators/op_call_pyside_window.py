import bpy
from bpy.props import *
from bpy.types import Operator
from .. ui.ui_pyside_assetchecker import *
from .. ui.ui_pyside_assetloader import *
from .. properties import *
from PySide6.QtWidgets import *

class Open_Asset_Checker_Popup(Operator):
    '''Open Asset Checker Popup '''
    bl_idname = "op.asset_checker"
    bl_label = "Open Asset Checker"
    bl_options = {'REGISTER'}

    def execute(self, context):
        app = QApplication.instance()
        if not app:
            app = QApplication(sys.argv)
            
        validation_checker = ValidationChecker()
        validation_checker.show()    
        return {'RUNNING_MODAL'}
    

class Open_Asset_Loader_Popup(Operator):
    '''Open Asset Loader popup '''
    bl_idname = "op.asset_loader"
    bl_label = "Open Asset Loader"
    bl_options = {'REGISTER'}

    def execute(self, context):
        app = QApplication.instance()
        if not app:
            app = QApplication(sys.argv)

        addon_preferences = get_addon_preferences()
        my_dir = addon_preferences.settingsFilePath
        
        # base_directory = r'E:/02_PIPELINE/NAME_PROJECTS/02_Maya/'
        base_directory = my_dir
        
        if not os.path.exists(base_directory):
            self.report({'ERROR'}, f"Base directory not found: {base_directory}")
            return {'CANCELLED'}
        
        self.widget = BlendFileSelector(base_directory)
        self.widget.show()
        return {'RUNNING_MODAL'}