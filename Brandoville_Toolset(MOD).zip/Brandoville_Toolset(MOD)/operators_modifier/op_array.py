import bpy
from bpy.types import Operator

# Custom MODULAR WALL operator
class Red_ModWallOpe(Operator):
    """Visualizes selected object in a modular wall"""
    bl_label = "Create Modular Wall"
    bl_idname = "op.array_modwall"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        if not context.selected_objects and not context.active_object:
            self.report({'ERROR'}, "Nothing is selected & there is no Active Object")
            return{'FINISHED'}

        if context.active_object:
            activeCallback = context.view_layer.objects.active
            modeCallback = context.object.mode
            bpy.ops.object.mode_set(mode='OBJECT')
        
        for ob in context.selected_objects:
            if ob.type == 'MESH':
                context.view_layer.objects.active = ob
            
            for mod in ob.modifiers:
                if mod.type == 'ARRAY':
                    break
            else:
                ob.modifiers.new('Array_X', 'ARRAY')
                ob.modifiers["Array_X"].count = 5
                ob.modifiers["Array_X"].relative_offset_displace[0] = 1
                ob.modifiers["Array_X"].show_expanded = False

                ob.modifiers.new('Array_Y', 'ARRAY')
                ob.modifiers["Array_Y"].count = 4
                ob.modifiers["Array_Y"].relative_offset_displace[0] = 0
                ob.modifiers["Array_Y"].relative_offset_displace[1] = 1
                ob.modifiers["Array_Y"].show_expanded = False

        if 'activeCallback' in locals():
            context.view_layer.objects.active = activeCallback
            bpy.ops.object.mode_set(mode = modeCallback)
                
        self.report({'INFO'}, 'Modular Wall Finished!')
        return {'FINISHED'}
