import bpy, os, sys
from bpy.types import Operator
from bpy.props import *
import platform
import subprocess
    
def abspath(path):
    return os.path.abspath(bpy.path.abspath(path))

def open_folder(path):

    if platform.system() == "Windows":
        os.startfile(path)

class Open(Operator):
    bl_idname = "op.filebrowser_open"
    bl_label = "Open in System's filebrowser"
    bl_description = "Open the current location in the System's own filebrowser"

    path: StringProperty(name="Path")

    @classmethod
    def poll(cls, context):
        return context.area.type == 'FILE_BROWSER'

    def execute(self, context):
        params = context.space_data.params
        directory = abspath(params.directory.decode())
        open_folder(directory)
        return {'FINISHED'}

class ToggleDisplay(Operator):
    bl_idname = "op.filebrowser_open"
    bl_label = "Open in System's filebrowser"
    bl_description = "Open the current location in the System's own filebrowser"

    toggle_browser_type : EnumProperty(
        items=(('world_pagi', "Pagi", "Pagi"),
               ('world_sore', "Sore", "Sore"),
               ('world_malam', "Malam", "Malam"),
               ('world_fajar', "Fajar", "Fajar"),
               ('world_terbenam', "Terbenam", "Terbenam"),
               ('world_mendung', "Mendung", "Mendung"),
               ),
        default='world_pagi'
    )

    @classmethod
    def poll(cls, context):
        return context.area.type == 'FILE_BROWSER'

    def execute(self, context):
        params = context.space_data.params
        directory = abspath(params.directory.decode())
        open_folder(directory)
        return {'FINISHED'}