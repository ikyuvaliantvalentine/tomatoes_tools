# This file is part of Instant Clean
# Copyright (C) 2023  Ruben Messerschmidt

import bpy
import bmesh
from .common_funcs import select_geo, deselect_all_geo


def triangulate(bm, faces, quad_method, ngon_method):
    select_geo(faces)
    bpy.ops.mesh.quads_convert_to_tris(quad_method=quad_method, ngon_method=ngon_method)
    deselect_all_geo(bm)

def tris_to_quads(bm, faces, sharp, seam, uv, material, vcol):
    select_geo(faces)
    bpy.ops.mesh.tris_convert_to_quads(uvs=uv, vcols=vcol, seam=seam, sharp=sharp, materials=material)
    deselect_all_geo(bm)


