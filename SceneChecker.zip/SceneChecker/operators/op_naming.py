import bpy
from bpy.types import Operator
from .. properties import *

###########################################
#   GET OBJECTS UNMATCH WITH PREFIX NAME
###########################################
class Get_Unmatch_Prefix(Operator):
    "CLICK - Select all objects that dont have the same name prefix "
    bl_idname = "ob.get_obj_prefix"
    bl_label = "Select Unmatch Prefix"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):        
        addon_preferences = get_addon_preferences()
        prefix = addon_preferences.default_prefix_name
        for obj in bpy.context.visible_objects:
            if obj.type == "MESH":
                if not obj.name.startswith((prefix)):
                    obj.select_set(state=True) 
        return {'FINISHED'}

###########################################
#   GET OBJECTS UNMATCH WITH SUFFIX NAME
###########################################
class Get_Unmatch_Suffix(Operator):
    "CLICK - Select all objects that dont have the same name suffix "
    bl_idname = "ob.get_obj_suffix"
    bl_label = "Select Unmatch Suffix"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):        
        addon_preferences = get_addon_preferences()
        suffix = addon_preferences.default_suffix_name
        for obj in bpy.context.visible_objects:
            if obj.type == "MESH":
                if not obj.name.endswith((suffix)):
                    obj.select_set(state=True) 
        return {'FINISHED'}