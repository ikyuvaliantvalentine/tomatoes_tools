import bpy
from bpy.types import UIList
from .. properties import *

class VIEW3D_UL_ListMaterials(UIList):    
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        col = layout.column()
        layout.label(text=item.name, icon_value=icon)                
        layout.operator('material.delete_material',icon='X',text="",emboss=False).material_name = item.name
                                
def UI_List_Mat(self, context):   
    layout = self.layout
    scene = context.scene
    rd = scene.render
    tomatoes = context.scene.tomatoes_props
    
    box = layout.box()
    col = box.column()
    split = col.split()
    col = split.column()

    if len(bpy.data.materials) > 0:
        col.template_list("VIEW3D_UL_ListMaterials", "", bpy.data, "materials", tomatoes, "selected_material_index", rows=4)
        mat = bpy.data.materials[tomatoes.selected_material_index]
        col.prop(mat,'name')
        col.operator("tomatoes.apply_material")
        col.operator("material.delete_all_material")
        col.operator("object.colorize_from_mat")
        col.separator()
        col.operator("material.create_new_material")
        col.operator("material.rename_material")
    
        if tomatoes.selected_material_index <= len(bpy.data.materials):

            mat = bpy.data.materials[tomatoes.selected_material_index]
            split = split.column()

            if rd.engine == 'BLENDER_EEVEE':
                box = split.box()
                box.label(text="Solid View Settings")
                row = box.row()
                row.label(text="Color")
                row.prop(mat, "diffuse_color", text="")
                row = box.row()
                row.label(text="Metallic")            
                row.prop(mat, "metallic",text="")
                row = box.row()
                row.label(text="Roughness")            
                row.prop(mat, "roughness",text="")

                box = split.box()
                row = box.row()
                row.label(text="Shadow and Transparency Options", icon="HANDLETYPE_AUTO_CLAMP_VEC")   
                row = box.row()
                row.label(text="Blend Mode")               
                row = box.row(align=True)
                row.prop_enum(mat, "blend_method", 'OPAQUE', text="Opaque") 
                row.prop_enum(mat, "blend_method", 'CLIP', text="Alpha Clip") 
                row.prop_enum(mat, "blend_method", 'HASHED', text="Alpha Hashed") 
                row.prop_enum(mat, "blend_method", 'BLEND', text="Alpha Blend")    

                if mat.blend_method not in {'OPAQUE', 'CLIP', 'HASHED'}:
                    box.prop(mat, "show_transparent_back")

                row = split.row()
                row.active = ((mat.blend_method == 'CLIP') or (mat.shadow_method == 'CLIP'))
                row.prop(mat, "alpha_threshold")

                box.prop(mat, "use_backface_culling") 

                box = split.box()
                box.label(text="Reflection/Refraction Settings")
                row = box.row()
                row.prop(mat, "use_screen_refraction")
                if mat.use_screen_refraction:
                    row.prop(mat, "refraction_depth")
                box.prop(mat, "use_sss_translucency")
                
                box = split.box()
                box.prop(mat, "pass_index")    

            if rd.engine == 'CYCLES':
                box = split.box()
                box.label(text="Surface")
                box.prop(mat.cycles, "sample_as_light", text="Multiple Importance")
                box.prop(mat.cycles, "use_transparent_shadow")
                row = box.row()
                row.label(text="Displacement Method")
                row.prop(mat.cycles, "displacement_method", text="Displacement",expand=True)

                box = split.box()
                box.label(text="Volume")
                row = box.row()
                row.label(text="Sampling Type")
                row.prop(mat.cycles, "volume_sampling", text="",expand=True)
                row = box.row()
                row.label(text="Interpolation Method")
                row.prop(mat.cycles, "volume_interpolation", text="Interpolation",expand=True)
                box.prop(mat.cycles, "homogeneous_volume", text="Homogeneous")
    
    else:
        col.operator("material.create_new_material")
    

#############################################
#   Autocut 
#############################################  
def Autocut_UI(context, layout):
    obj = context.object
    tomatoes = context.scene.tomatoes_props
    layout.prop(tomatoes, "auto_cut_mirror", toggle=True)
    if obj:
        if obj.type in {'MESH'}:
            col = layout.column(align=True)
            row = col.row(align=True) 
            
            col = row.column(align=True)
            col.label(text="Axis:" , icon='AXIS_SIDE')  
            col.separator()
            col.prop(tomatoes, "tp_axis", expand=True)
            
            col = row.column(align=True)
            col.label(text="Axis Cut:" , icon='UV_SYNC_SELECT')
            col.separator()
            col.prop(tomatoes, "tp_axis_cut", expand=True)
            
            col = layout.column(align=True)
            col.operator("tp_ops.mods_autocut_obm", text="Execute")                                  
        else:
            box = layout.box().column(1)            
            row = box.row(1)                   
            row.label("nothing selected", icon ="INFO")  

#############################################
#   Global Subsurf 
#############################################  
def glob_subsurf_UI(context, layout):
    tomatoes = context.scene.tomatoes_props

    box1 = layout.box()
    col = box1.column(align=True)
    row = col.row(align=True)
    row.operator("ob.subsurfhidesel", icon="MOD_SOLIDIFY", text="Hide Selected").show=False
    row.operator("ob.subsurfhidesel", icon="MOD_SUBSURF", text="Show Selected").show=True
    row = col.row(align=True)            
    row.operator("subsurf.hideall", icon="MOD_SUBSURF", text="Show All").show=True
    row.operator("subsurf.hideall", icon="MOD_SUBSURF", text="Hide All").show=False
    row = col.row(align=True)
    row.operator("remove.all_subsurfs", icon="PANEL_CLOSE")
    
    box = layout.box()
    box.label(text="Global Subdivisons:")
    box.prop(tomatoes, 'view_level')
    box.prop(tomatoes, 'render_level')
    box.prop(tomatoes, 'object_sel')
                    
#############################################
#   Renamer 
#############################################  
def UIRenamerPlus(context, layout):
    box = layout.box()
    col = box.column()
    row = col.row(align=True)

    col.operator("object.remove_replace_numbering")
    col.operator("rename.replace_dot")
    col.operator("object.set_to_lowercase")

    col.label(text="Tambah Kata Belakang:")
    row = col.row(align=True)
    row.operator("object.addsuffix", text="_low").type_suffix='low'
    row.operator("object.addsuffix", text="_high").type_suffix='high'
    row = col.row(align=True)
    row.operator("object.addsuffix", text="_geo").type_suffix = 'geo'
      
def UIRenamer(context, layout):
    tomatoes = context.scene.tomatoes_props
    col = layout.column()
    col.operator("rename_regex.tools")
    row = col.row()
    if context.active_object.mode == 'OBJECT':
        row = col.row()
        row.label(text='Custom Prefix:')
        row.label(text='Custom Suffix:')
        row = col.row(align=1)
        row.prop(tomatoes, 'prefix', text='')
        row.prop(tomatoes, 'prefix_input', text='')
        row.separator()
        row.prop(tomatoes, 'suffix_input', text='')
        row.prop(tomatoes, 'suffix', text='')
        
        col.separator()
        col.operator("rename.more_naming", icon ="ADD")

        col.separator()

        box2 = layout.box()
        col1 = box2.column(align=True)
        col = col1.column(align=True)
        if tomatoes.hide_name == True:
            col.prop(tomatoes, 'hide_name', text='Close List Object', icon="DISCLOSURE_TRI_DOWN")
        else:
            col.prop(tomatoes, 'hide_name', text='Open List Object', icon="TRIA_RIGHT")

        if tomatoes.hide_name == True:
            for obj in context.selected_objects:
                row = col.row(align=1)
                sel = row.operator("object.renamer_select", text='', icon='BORDERMOVE')
                sel.ob = obj.name
                sel.type = 'obj'
                row.prop(obj, 'name', text='', icon='OBJECT_DATA')

def UIRenameRegex(context, layout):
    tomatoes = context.scene.tomatoes_props
    layout.prop(tomatoes, "regex_search_pattern")
    layout.prop(tomatoes, "regex_replacement_string")

#############################################
#   Set Scene 
#############################################    
def UISetScene(context, layout):
    tomatoes = context.scene.tomatoes_props
    layout.scale_x = 1.2
    layout.scale_y = 1.2

    row = layout.row()
    col = row.column()
    col.prop(tomatoes, "UISetScene", text="", expand=True)
 
    if tomatoes.UISetScene == 'scene_unit':   
        col = row.column()
        split = col.split()
        pre = split.column()
        sub = pre.column(align=True)   

        sub.label(text="Viewport Display:" , icon='SCENE_DATA')
        sub.operator("view3d.display_viewport", text="Toggle Normal Face", icon='FACESEL').type_view = 'show_face_normal'
        sub.operator("view3d.display_viewport", text="Toggle Only Render", icon='OVERLAY').type_view = 'show_only_render'
        sub.operator("view3d.display_viewport", text="Toggle Xray", icon='XRAY').type_view = 'show_xray'
        sub.operator("view3d.display_viewport", text="Toggle Wireframe", icon='MOD_WIREFRAME').type_view = 'show_wireframe'
        sub.operator("view3d.display_viewport", text="Toggle Backface Culling", icon='XRAY').type_view = 'show_backface'
        sub.operator("view3d.display_viewport", text="Toggle Cavity", icon='CUBE').type_view = 'show_cavity'
        sub.separator()
        sub.operator("object.hide_empty", icon ='OUTLINER_OB_EMPTY')
        sub.operator("boundstextured.toggle", text ="Switch Draw",icon ="OBJECT_DATA")  
        
        pre = split.column()
        sub = pre.column(align=True) 
        sub.label(text="Presets:" , icon='RENDER_STILL')
        sub.operator("scene.optimize_viewport")
        sub.operator("scene.set_to_maya")
        sub.operator("scene.blender_default")
        sub.separator()
        sub.operator("scene.toggle_grid_floor")

        pre = split.column()
        sub = pre.column(align=True) 
        sub.label(text="Group All:" , icon='OUTLINER_COLLECTION')
        sub.operator("op.scene_mesh_coll", text = "Mesh")
        sub.operator("op.scene_curve_coll", text = "Curve")
        sub.operator("op.scene_camera_coll", text = "Camera")
        sub.operator("op.scene_light_coll", text = "Light")  
        sub.operator("op.scene_empty_coll", text = "Empty/Reference")      
        sub.operator("op.scene_lattice_coll", text = "Lattice")  



            
    elif tomatoes.UISetScene == 'matcap':  
        cscene = context.scene.render
        rd = context.scene.render

        col = row.column()
        split = col.split()
        pre = split.column()
        sub = pre.column()   
        
        sub.prop(rd, "engine")

        box = sub.box()

        row = box.row()
        col = row.column(align=True)
        col.label(text="Scenes:" , icon='SCENE_DATA')
        col.separator()
        col.operator("world.create_gradient_sky", text ="Pagi").world_type ='world_pagi'
        col.operator("world.create_gradient_sky", text ="Sore").world_type ='world_sore'
        col.operator("world.create_gradient_sky", text ="Malam").world_type ='world_malam'
        col.operator("world.create_gradient_sky", text ="Fajar").world_type ='world_fajar'
        col.operator("world.create_gradient_sky", text ="Terbenam").world_type ='world_terbenam'
        col.operator("world.create_gradient_sky", text ="Mendung").world_type ='world_mendung'

        col = row.column(align=True)
        col.label(text="Presets:" , icon='NODE_COMPOSITING')
        col.separator()
        col.operator("op.jkbasicbg")
        col.operator("op.jkbasicchar")
        col.operator("op.jktest")
        col.operator("node.compose_image")
        col.operator("op.shadowjinkepepet")

        col = row.column(align=True)
        col.label(text="Final Preset:" , icon='NODE_COMPOSITING')
        col.separator()
        col.operator("op.nodebg", text ="Background")
        col.operator("op.nodechar", text ="Character")
        col.operator("op.nodeshdchar", text ="Shadow")

        if context.scene.render.engine == 'CYCLES':   
            sub.label(text="Speed Up Setting:" , icon='IPO_CONSTANT')    
            sub.operator("object.speeduppath")
            sub.operator("object.maxpath")
            
            sub = pre.column(align=True)      
            sub.label(text="For Object:" , icon='CUBE')      
            sub.operator("object.display_texture")    
            
        elif context.scene.render.engine == 'BLENDER_EEVEE':  
            sub.label(text="Speed Up Setting:" , icon='IPO_CONSTANT')    
            sub.operator("op.quicksettingseevee")
            sub.operator("op.speedupeevee")
            
        sub.label(text="Use:")    
        sub.prop(cscene, "film_transparent", toggle=True)
        
 




    elif tomatoes.UISetScene == 'uv': 
        me = context.object.data 
        col = row.column()
        col.template_list("MESH_UL_uvmaps", "uvmaps", me, "uv_layers", me.uv_layers, "active_index", rows=1)
        c = row.column()
        c.operator("mesh.uv_texture_add", icon='ADD', text="")
        c.operator("mesh.uv_texture_remove", icon='REMOVE', text="")  
        
        box = layout.box()
        col1 = col.box()
        if context.object is not None:  
            col1.label(text="Check UV Sets:", icon='MOD_UVPROJECT')
            col1.operator("uv.get_object", text="Check Objects")
            col1.label(text="Clear UV Set & Geometry Data")
            col1.operator("uv.clear_except_uvmapone", text="Clear All Except UV MAP")
            col1.operator("object.uv_remove", text="Clear All UV MAP")      
            col1.operator("object.clear_normals")   
            col1.label(text="Rename UV Sets")
            col1.operator("uv.rename_all")   
        else:
            col1.label(text="Select Object First!!!", icon='ERROR')  
                                                                    
#############################################
#   Custom Save UI
############################################# 
def custom_save_ui(context,layout):
    tomatoes = context.scene.tomatoes_props

    box = layout.box()
    box.label(text="Auto Replace & Save File Name", icon="FILE_TICK")  
    box.prop(tomatoes, "apply_file_rev")
    box.label(text="Default String:")     
    row = box.row(align=True)          
    row.prop(tomatoes, "str_default", text="")
    if tomatoes.apply_file_rev == True:
        row.active = tomatoes.apply_file_rev
        row.prop(tomatoes, "file_rev", text="")     
    col = box.column()  
    col.label(text="Replace String:") 
    col.prop(tomatoes, "final_str", text ="")
    col.separator()
    col1 = box.column()   
    col1.scale_x = 1.5
    col1.scale_y = 1.5
    col1.operator("test.save_jinkepepet")
    col1.operator("file.open_save_directory")

#########################################
#   Lamp Settings
#########################################    
def UILamp_Cycles_Mesh(context, layout):
    col= layout.column()        
    row = col.row(align=True)
    row.operator("object.to_emission",icon="HANDLETYPE_AUTO_CLAMP_VEC")
        
    mat = context.active_object.active_material
    emission_material = []
    for material in bpy.context.active_object.data.materials:
        if material.use_nodes:
            node_tree = material.node_tree
            for node in node_tree.nodes:
                if node.type == 'EMISSION':
                    emission_material.append(material)
                    break

    # display in tool shelf
    for material in emission_material:
        col = layout.column(align=True)
        row = col.row(align=True)
        row.label(text=material.name, icon='MATERIAL')
        
        node_tree = material.node_tree
        for node in node_tree.nodes:
            if node.type == 'EMISSION':
                row = col.row(align=True)
                
                ### COLOR ###
                if not node.inputs[0].is_linked:
                    row.prop(node.inputs[0],'default_value', text='')
                else:
                    row.label(text='Connected')
                    
                ### STRENGHT ###
                if not node.inputs[1].is_linked:
                    row.prop(node.inputs[1], 'default_value', text='')
                    row.operator("lamp.use_falloff", text="", icon='HANDLETYPE_AUTO_CLAMP_VEC')
                    
            elif node.type == 'LIGHT_FALLOFF':  
                if not node.inputs[0].is_linked and node.outputs[0].is_linked :
                    row = col.row() 
                    row.prop(node.inputs[0], 'default_value', text='Strength')
                    row.prop(node.inputs[1], 'default_value', text='Smooth')        
                    
        if context.active_object.type == 'MESH':
            split = layout.split()
            col = split.column()
            sub = col.column(align=True)
            sub.label(text="Viewport Color:")
            sub.prop(mat, "diffuse_color", text="")
                
            col = split.column()
            sub = col.column(align=True)
            sub.label(text="Visibility:")
            sub.prop(context.object.cycles_visibility, "camera", text='Cam', toggle=True)
            sub.prop(context.object.cycles_visibility, "diffuse", text='Diff', toggle=True)
            sub.prop(context.object.cycles_visibility, "glossy", text='Spec', toggle=True)

def UILamp_Eevee(context, layout):
    light = context.object.data

    box = layout.box()

    row = box.row()
    row.prop(light, "type",expand=True)
    row = box.row()
    row.label(text="Color")
    row.prop(light, "color",text="")
    row = box.row()
    row.label(text="Energy")
    row.prop(light, "energy",text="")
            
    row = box.row()
    row.label(text="Specular")
    row.prop(light, "specular_factor", text="")

    row = box.row()
    row.prop(light, "use_custom_distance", text="Use Custom Distance")

    if light.use_custom_distance:
        row.prop(light,"cutoff_distance",text="Distance")
    row = box.row()

    if light.type in {'POINT', 'SPOT'}:
        row.label(text="Radius:")
        row.prop(light, "shadow_soft_size", text="")
    elif light.type == 'SUN':
        row.label(text="Angle:")
        row.prop(light, "angle")
    elif light.type == 'AREA':
        box = layout.box()
        row = box.row()
        row.label(text="Shape:")
        row.prop(light, "shape",expand=True)

        sub = box.column(align=True)

        if light.shape in {'SQUARE', 'DISK'}:
            row = sub.row(align=True)
            row.label(text="Size:")     
            row.prop(light, "size",text="")
        elif light.shape in {'RECTANGLE', 'ELLIPSE'}:
            row = sub.row(align=True)
            row.label(text="Size:")

            row.prop(light, "size", text="X")
            row.prop(light, "size_y", text="Y")
    
    if light.type == 'SPOT':
        box = layout.box()
        row = box.row()        
        row.label(text="Spot Size:")    
        row.prop(light, "spot_size", text="")
        row = box.row()        
        row.label(text="Spot Blend:")                
        row.prop(light, "spot_blend", text="", slider=True)

        box.prop(light, "show_cone")            

    box = layout.box()
    box.prop(light, "use_shadow", text="Use Shadows")
    box.active = light.use_shadow

    col = box.column()
    row = col.row(align=True)
    if light.type != 'SUN':
        row.label(text="Clip:")
        row.prop(light, "shadow_buffer_clip_start", text="")

    col.separator()

    row = col.row(align=True)
    row.label(text="Bias:")
    row.prop(light, "shadow_buffer_bias", text="")          

    col.separator()

    col.prop(light, "use_contact_shadow", text="Use Contact Shadows")
    if light.use_shadow and light.use_contact_shadow:
        col = box.column()
        row = col.row(align=True)
        row.label(text="Distance:")  
        row.prop(light, "contact_shadow_distance", text="")
        row = col.row(align=True)
        row.label(text="Bias:")          
        row.prop(light, "contact_shadow_bias", text="")
        row = col.row(align=True)
        row.label(text="Thickness:")          
        row.prop(light, "contact_shadow_thickness", text="")

    if light.type == 'SUN' and light.use_shadow:
        box = layout.box()
        box.label(text="Sun Shadow Settings")
        row = box.row(align=True)
        row.label(text="Cascade Count:")                
        row.prop(light, "shadow_cascade_count", text="")
        row = box.row(align=True)
        row.label(text="Fade:")                 
        row.prop(light, "shadow_cascade_fade", text="")

        row = box.row(align=True)
        row.label(text="Max Distance:")      
        row.prop(light, "shadow_cascade_max_distance", text="")
        row = box.row(align=True)
        row.label(text="Distribution:")                  
        row.prop(light, "shadow_cascade_exponent", text="")

def UILamp_Cycles(context, layout):
    light = context.object.data

    box = layout.box()

    row = box.row()
    row.prop(light, "type",expand=True)
    row = box.row()

    col = box.column()

    col.prop(light, "color", text="")
    col.prop(light, "energy")
    col.separator()

    if light.type in {'POINT', 'SPOT'}:
        col.prop(light, "shadow_soft_size", text="Radius")
    elif light.type == 'SUN':
        col.prop(light, "angle")
    elif light.type == 'AREA':
        col.prop(light, "shape", text="Shape")
        sub = col.column(align=True)

        if light.shape in {'SQUARE', 'DISK'}:
            sub.prop(light, "size")
        elif light.shape in {'RECTANGLE', 'ELLIPSE'}:
            sub.prop(light, "size", text="Size X")
            sub.prop(light, "size_y", text="Y")

    if not (light.type == 'AREA' and light.cycles.is_portal):
        sub = col.column()
        sub.prop(light.cycles, "max_bounces")

    sub = col.column(align=True)
    sub.active = not (light.type == 'AREA' and light.cycles.is_portal)
    sub.prop(light.cycles, "cast_shadow")
    sub.prop(light.cycles, "use_multiple_importance_sampling", text="Multiple Importance")

    if light.type == 'AREA':
        col.prop(light.cycles, "is_portal", text="Portal")
    
    box1 = layout.box()
    col = box1.column()
    row = col.row(align=True)
    col.label(text="Nodes:")
    if light.use_nodes:
        for node in light.node_tree.nodes:
            if node.type == 'EMISSION':   
                row = col.row(align=True)     
                         
                ### COLOR ###
                if not node.inputs[0].is_linked:
                    row.prop(node.inputs[0], 'default_value', text='')
                else:
                    row.label(text='Connected')
                    
                ### STRENGHT ###
                if not node.inputs[1].is_linked:
                    row.prop(node.inputs[1], 'default_value', text='')
                    row.operator("lamp.use_falloff", text="", icon='VIEW_ZOOM')
                         
            elif node.type == 'LIGHT_FALLOFF':  
                if not node.inputs[0].is_linked and node.outputs[0].is_linked :
                    row = col.row() 
                    row.prop(node.inputs[0], 'default_value', text='Strength')
                    row.prop(node.inputs[1], 'default_value', text='Smooth') 
                    
    else:
        col.prop(light, 'use_nodes', toggle=True)
    
    if light.type == 'SPOT':    
        split = layout.split()

        col = split.column()
        sub = col.column()
        sub.prop(light, "spot_size", text="Size")
        sub.prop(light, "spot_blend", text="Blend", slider=True)

        col = split.column()
        col.prop(light, "show_cone")
    
    if context.active_object.type == 'LIGHT':
        box2 = layout.box()
        col = box2.column()
        row = col.row(align=True)
        col.label(text="Visibility:")
        row = col.row(align=True)
        row.prop(context.object, "visible_camera", text='Cam', toggle=True)
        row.prop(context.object, "visible_diffuse", text='Diff', toggle=True)
        row.prop(context.object, "visible_glossy", text='Gloss', toggle=True)

#############################################
#   Lattice Controler    
#############################################    
def UILattice(context, layout):
    lat = context.object.data

    col = layout.column()

    sub = col.column(align=True)
    sub.prop(lat, "points_u", text="Resolution U")
    sub.prop(lat, "points_v", text="V")
    sub.prop(lat, "points_w", text="W")

    col.separator()

    sub = col.column(align=True)
    sub.prop(lat, "interpolation_type_u", text="Interpolation U")
    sub.prop(lat, "interpolation_type_v", text="V")
    sub.prop(lat, "interpolation_type_w", text="W")

    col.separator()

    col.prop(lat, "use_outside")

    col.separator()

    col.prop_search(lat, "vertex_group", context.object, "vertex_groups")
    
#############################################
#   Curve Controler    
#############################################    
def UICurve(context, layout):
    curve = context.object.data
    layout.row().prop(curve,"dimensions",text="Curve Type", expand=True)
    
    split = layout.split()

    col = split.column()
    col.label(text="Resolution:")
    sub = col.column(align=True)
    sub.prop(curve, "resolution_u", text="Preview U")
    sub.prop(curve, "render_resolution_u", text="Render U")
    
    col = split.column()    
    col.label(text="Fill:")
    col.row().prop(curve,"fill_mode", expand=True)
    col.prop(curve,"use_fill_deform")
                    
    split = layout.split()
    
    col = split.column()
    col.label(text="Modification:")
    col.prop(curve, "offset")
    col.prop(curve, "extrude")

    col = split.column()
    col.label(text="Bevel:")
    col.prop(curve, "bevel_depth", text="Depth")
    col.prop(curve, "bevel_resolution", text="Resolution")

#############################################
#   Empty Controler    
#############################################    
def UIEmpty(context, layout):
    empty = context.object
    layout.prop(empty, "empty_display_type", text="Display As")
    layout.prop(empty, "empty_display_size", text="Size")

    if empty.empty_display_type == 'IMAGE':
        col = layout.column(align=True)
        col.prop(empty, "empty_image_offset", text="Offset X", index=0)
        col.prop(empty, "empty_image_offset", text="Y", index=1)

        col = layout.column()
        col.prop(empty, "empty_image_depth", text="Depth", expand=False)
        col.prop(empty, "empty_image_side", text="Side", expand=False)

        col = layout.column(heading="Show in", align=True)
        col.prop(empty, "show_empty_image_orthographic", text="Orthographic")
        col.prop(empty, "show_empty_image_perspective", text="Perspective")
        col.prop(empty, "show_empty_image_only_axis_aligned", text="Only Axis Aligned")

        col = layout.column()
        col.prop(empty, "use_empty_image_alpha", text= "Use Transparency", toggle=False)
        if empty.use_empty_image_alpha == True:
            col.prop(empty, "color", text="", index=3, slider=True)
        else:
            col.separator()

#############################################
#   Camera Projection    
############################################# 
def cam_proj_list(context,layout):
    tomatoes = context.scene.tomatoes_props
    
    cam_list=[cam.name for cam in context.scene.objects if cam.type=='CAMERA']
    cam_list.sort(key=str.lower)
    
    box = layout.box()
    col = box.column()
    split = col.split()
    col = split.column()
    
    for cam in cam_list:     
        row = col.row(align=True) 
        row.operator("cameras.set_view", text=cam, emboss=True).camera=cam
        row.operator("quick.rename_cam_proj", text="", icon='COLOR_RED')
        row.operator("add.image_to_camera", text="", icon='OUTLINER_OB_IMAGE').camera=cam
        row.separator()
        row.operator("cameras.delete", text="", icon="PANEL_CLOSE").camera=cam

    col = split.column()
    col.scale_x = 1.2
    col.scale_y = 1.2
    col.operator("cameras.new_from_view", text="New Camera from View", icon="ADD")
    col.operator("view3d.modal_cam_info")
    
    cam = context.object.data
    ccam = cam.cycles
    scene = bpy.context.scene
    rd = scene.render
    
    box = layout.box()
    row = box.row()
    row.prop(tomatoes, "UICam", expand=True)

    split = box.split()
    col = split.column()
    sub = col.column(align=True)
        
    if tomatoes.UICam == "ui_expand_cam_settings":
        
        sub.label(text="Resolution:")
        sub.prop(rd, "resolution_x", text="X")
        sub.prop(rd, "resolution_y", text="Y")
        sub.prop(rd, "resolution_percentage", text="")
        
        sub.separator()
        sub.operator("swithres.toggle", icon="FILE_REFRESH")
        sub.separator()
        
        rend = context.scene.render
        rend_percent = rend.resolution_percentage * 0.01
        x = (str(rend.resolution_x * rend_percent).split('.'))[0]
        y = (str(rend.resolution_y * rend_percent).split('.'))[0]
        sub.label(text="Resolution: " + x + " x " + y)
        
        if context.object.type == "CAMERA":
            col = split.column()
            sub = col.column(align=True)
            sub.label(text="Clipping")
            sub.prop(cam, "clip_start", text="Start")
            sub.prop(cam, "clip_end", text="End")        

            sub = col.column() 
            sub.separator()
            sub.prop(cam, "show_passepartout") 
            sub.prop(cam, "passepartout_alpha")  
            if bpy.context.scene.render.engine == 'CYCLES':
                sub.prop(bpy.context.scene.cycles,"film_transparent",text="Transparent Film")
            sub.separator()
        
            col = box.column()
            row = col.row()
            row.prop(cam, "type", expand=True)
            
            split = box.split()
            col = split.column()
            if cam.type == 'PERSP':
                row = col.row()
                if cam.lens_unit == 'MILLIMETERS':
                    row.prop(cam, "lens")
                elif cam.lens_unit == 'FOV':
                    row.prop(cam, "angle")
                row.prop(cam, "lens_unit", text="")

            if cam.type == 'ORTHO':
                col.prop(cam, "ortho_scale")

            if cam.type == 'PANO':
                engine = bpy.context.scene.render.engine
                if engine == 'CYCLES':
                    ccam = cam.cycles
                    col.prop(ccam, "panorama_type", text="Panorama Type")
                    if ccam.panorama_type == 'FISHEYE_EQUIDISTANT':
                        col.prop(ccam, "fisheye_fov")
                    elif ccam.panorama_type == 'FISHEYE_EQUISOLID':
                        row = col.row()
                        row.prop(ccam, "fisheye_lens", text="Lens")
                        row.prop(ccam, "fisheye_fov")
                    
            split = box.split()
            col = split.column()

            box.prop(cam.dof, "use_dof", text="Depth of Field")
            row = box.row(align=True)
            row.active = cam.dof.use_dof
            row.prop(cam.dof, "focus_object", text="")
            col = row.column()
            sub = col.row()
            sub.active = cam.dof.focus_object is None
            sub.prop(cam.dof, "focus_distance", text="Distance")
            
    if tomatoes.UICam == "ui_expand_cam_bg_settings":
        box1 = layout.box()
        if context.object.type == "CAMERA":
            cam = bpy.context.object.data
            for i, bg in enumerate(cam.background_images):
                col = box1.column()
                col.prop(bg, "alpha", slider=True)
                col.row().prop(bg, "display_depth", expand=True)

                col.row().prop(bg, "frame_method", expand=True)

                col = box1.column()
                col.prop(bg, "rotation")
                col.prop(bg, "scale")

                col.prop(bg, "use_flip_x")
                col.prop(bg, "use_flip_y") 
        else:
            box1.label(text="Make Sure Camera Has Image Data And Select Camera First!", icon="ERROR")
        
    if tomatoes.UICam == "ui_expand_cam_proj_settings":
        box2 = layout.box()
        if context.object.type == "CAMERA":
            box2.label(text="For Bake Image Texture :", icon='TRIA_DOWN')
            box2.template_ID(context.tool_settings.image_paint, "canvas", \
            new="image.new", open="image.open")
            box2.separator()
            box2.label(text="For Image Projection :", icon='TRIA_DOWN')
            box2.operator("paint.project_image", text="Apply Camera Image")
        else:
            box2.label(text="Make Sure Camera Has Image Data And Select Camera First!", icon="ERROR")
        
                
def rename_camera_list(context, layout):
    col = layout.column()    
    for obj in context.selected_objects:
        col.prop(obj, 'name', text='', icon='OBJECT_DATA')