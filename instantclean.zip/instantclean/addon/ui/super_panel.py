# This file is part of Instant Clean
# Copyright (C) 2023  Ruben Messerschmidt

import bpy


class Super_Panel(bpy.types.Panel):
    bl_idname='bc.super_panel'
    bl_label='super'
    bl_space_type='VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Instant Clean'
    bl_options={"DEFAULT_CLOSED"}