import bpy
import os
from bpy.props import *
from .. properties import *
 
 # Reference https://blenderartists.org/t/getting-selection-from-a-menu/600082/4

 
class PxAssetLoader(bpy.types.Operator):
    bl_idname = "wm.asset_loader"
    bl_label = "Asset Loader"
    
    openType_list_property : EnumProperty(
            name="Select",
            items=(('OPEN','Open','Open the asset'),
                    ('IMPORT','Import','Import the asset'),
                    ('REFERENCE','Reference','Reference the asset')),
            options={'ENUM_FLAG'},
            default={'OPEN'},
            )        
    
    def execute(self, context):
        scenechk = bpy.context.scene.scenechk_props
        project_path = "D:/Brandoville Work/Props/NepenthesLowii/01_Model/WIP/Backup/"  + scenechk.Category + "/" + scenechk.Asset
        print ("ASA" + project_path)
        bpy.ops.wm.open_mainfile(filepath=project_path)
        print('LOADED FILE')
        return {'FINISHED'}
    
    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=300)
    
    def draw(self, context):
        scenechk = bpy.context.scene.scenechk_props
        layout = self.layout  
        box = layout.box()
        col = box.column()
        col.label(text="Asset")
        col.prop(scenechk, "Category")
        col.prop(scenechk, "Asset")
        row = col.row()
        row.prop(self, "openType_list_property")
        