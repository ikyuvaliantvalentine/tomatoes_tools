import bpy, os
from bpy.types import Operator

class QuickSettingsEevee(Operator):
    """
    Turn On AO, Volumetric Shadows, Reflections
    Eevee Sample set : 64

    On Indirect Lighting
    Cube Map set : 512
    Diffuse Bounces set : 3
    Diffuse Occlusion set : 3
    Irradiances Smooth set : 0.20
    """
    bl_idname = "engine.speedeevee"
    bl_label = "Simple Eevee Settings"

    def execute(self, context):
        eevee = bpy.context.scene.eevee

        bpy.context.scene.render.engine = 'BLENDER_EEVEE'
        eevee.taa_samples = 64
        eevee.taa_render_samples = 64
        eevee.use_taa_reprojection = True

        eevee.shadow_cube_size = '1024'
        eevee.shadow_cascade_size = '1024'
        eevee.use_soft_shadows = True

        eevee.use_ssr = True
        eevee.use_ssr_refraction = True
        eevee.ssr_quality = 0.7

        eevee.use_gtao = True
        eevee.gtao_distance = 1

        eevee.use_volumetric_shadows = True
        eevee.volumetric_tile_size = '2'

        eevee.gi_diffuse_bounces = 3
        eevee.gi_cubemap_resolution = '512'
        eevee.gi_visibility_resolution = '32'
        eevee.gi_irradiance_smoothing = 0.2
        return {'FINISHED'}