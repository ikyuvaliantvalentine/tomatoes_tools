import bpy
from bpy.types import Panel, UIList
from bpy.props import *
from .. properties import *
from . ui_panel_draw import *
from . invoke_draw import *
                                
class VIEW3D_PT_Object_Data_panel(Panel):
    bl_space_type = "PROPERTIES"
    bl_region_type = "WINDOW"
    bl_context = "object"
    bl_label = "Object Data"
    
    def draw_header(self, context):
        layout = self.layout
        layout.label(text="", icon="OUTLINER_OB_MESH")

    def draw(self, context):
        addon_preferences = get_addon_preferences()
        layout = self.layout
        if addon_preferences.UIObjectData == "light":
            if context.scene.render.engine == "CYCLES":
                UICyclesListLight(self, context)
            elif context.scene.render.engine == "BLENDER_EEVEE":
                UIEeveeListLight(self, context)
        else:
            UIObjectData(context, layout)
                                    
class VIEW3D_PT_Tomatoes_Panel(Panel):
    """A Custom Panel in the Properties Toolbar"""
    bl_label = "Tomatoes Panel"
    bl_idname = "VIEW3D_PT_Tomatoes_Panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Tomatoes Panel"
    # bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        tomatoes = context.scene.tomatoes_props
        layout = self.layout
        layout.prop(tomatoes, "UIPanelsEnum", text = "", expand = True)
        if tomatoes.UIPanelsEnum ==  "ui_retopo":
            UIRetopo(context, layout)
        if tomatoes.UIPanelsEnum ==  "ui_world":
            UIWorld(self, context)
        elif tomatoes.UIPanelsEnum ==  "ui_vfxsim":
            UIVFX(context, layout)
        
            
                                