import bpy
from .. properties import *
      
def Red_UIRenamer(self, context, layout):
    red = context.scene.red_props
    
    box_regex = layout.box()
    box_rename = layout.box()
    box_extra = layout.box()

    if context.active_object and context.active_object.mode == 'OBJECT':
        box_regex.enabled = True
        box_rename.enabled = True
    else:
        box_regex.enabled = False
        box_rename.enabled = False

    col1 = box_regex.column()
    col1.prop(red, "regex_search_pattern")
    col1.prop(red, "regex_replacement_string")
    col1ok = box_regex.column()
    col1ok.scale_x = 1.3
    col1ok.scale_y = 1.3
    col1ok.operator("op.click_to_replace")

    col = box_rename.column()
    row = col.row()
    row.label(text='Custom Prefix:')
    row.label(text='Custom Suffix:')
    row = col.row(align=True)
    row.prop(red, "prefix", text="")
    row.separator()
    row.prop(red, "suffix", text="")

    col.separator()

    if red.hide_name == True:
        col.prop(red, 'hide_name', text='Close List Object', icon="DISCLOSURE_TRI_DOWN")
    else:
        col.prop(red, 'hide_name', text='Open List Object', icon="TRIA_RIGHT")

    if red.hide_name == True:
        for obj in context.selected_objects:
            row = col.row(align=True)
            sel = row.operator("op.renamer_select", text='', icon='BORDERMOVE')
            sel.ob = obj.name
            sel.type = 'obj'
            row.prop(obj, 'name', text='', icon='OBJECT_DATA')

    col.separator()

    col_ok = box_rename.column()
    col_ok.scale_x = 1.3
    col_ok.scale_y = 1.3
    col_ok.operator("op.click_to_rename")

    col_extra = box_extra.column()
    col_extra.label(text="Extras :")
    col_extra.scale_x = 1.3
    col_extra.scale_y = 1.3
    col_extra.operator("op.remove_replace_numbering")
    col_extra.operator("op.replace_dot")
