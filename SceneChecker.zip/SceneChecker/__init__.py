bl_info = {
    "name": "Scene Checker",
    "description": "Check Scene To Find Problem",
    "author": "IkyuValiantValentine",
    "version": (0, 1),
    "blender": (2, 93, 0),
    "location": "View3dPanel > Scene Checker",
    "category": "Tomatoes"}

import bpy
# load and reload submodules
##################################

import importlib
from . import developer_utils
from . import auto_load

from bpy.types import (
        Operator,
        Panel,
        PropertyGroup,
        )
        
from bpy.props import (StringProperty,
                       BoolProperty,
                       FloatVectorProperty,
                       FloatProperty,
                       EnumProperty,
                       IntProperty,
                       PointerProperty)
from bpy.app.handlers import persistent
from . properties import *

importlib.reload(developer_utils)
modules = developer_utils.setup_addon_modules(__path__, __name__, "bpy" in locals())     
                                     
class Scene_Checker_Preferences(bpy.types.AddonPreferences):
    bl_idname = __name__
    
    scale : FloatProperty(
            name="",
            description="Dialog Box Scale",
            default=0.2,
            min=0.1, max=1
            )    

    WorkflowOptions : EnumProperty(
            name="Preferences Scene Checker",
            items=(
                ("game_flow", "Game", "Game Scene Checker Workflow UI", 1),
                ("animation_flow", "Animation", "Animation Scene Checker Workflow UI", 2)),
            default='game_flow',
            description = "Choose UI") 

    SoftwareWorkflowOptions : EnumProperty(
            name="Preferences Scene Checker",
            items=(
                ("blender", "Blender", "Workflow For Blender", 1),
                ("maya", "Maya", "Workflow For Maya", 2)),
            default='blender',
            description = "Choose UI") 

    save_prefix : StringProperty(name="Prefix calculation",
                    description="Python string that calculates the file prefix.",
                    default="DPR ")

    default_prefix_name: StringProperty(default="geo")
                
    def draw(self, context):
        layout = self.layout 
        box = layout.box()     
        
        box.prop(self, "scale", text="Dialog Box Scale")

        box.prop(self, "save_prefix")   

        box.prop(self, "default_prefix_name", text="Default Prefix")      

        box = layout.box()
        row = box.row()
        row.label(text="Workflow:")
        row.prop(self, "WorkflowOptions", expand=True)   

        box = layout.box()
        row = box.row()
        row.label(text="Set Software Option:")
        row.prop(self, "SoftwareWorkflowOptions", expand=True)   
      
##################################
# register
##################################
addon_keymaps = []
auto_load.init()
        
def register():            
    auto_load.register()
    bpy.utils.register_class(Scene_Checker_Preferences)
    bpy.types.Scene.scenechk_props = PointerProperty(type=SceneCheckerProperties)   
    
def unregister():
    auto_load.unregister()
    bpy.utils.unregister_class(Scene_Checker_Preferences)    
    del bpy.types.Scene.scenechk_props  


