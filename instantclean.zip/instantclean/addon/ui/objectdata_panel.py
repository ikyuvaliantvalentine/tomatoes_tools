# This file is part of Instant Clean
# Copyright (C) 2023  Ruben Messerschmidt

import bpy
from .super_panel import Super_Panel
from .layout_temps import sub_layout, sub_panel_header, results_layout


class BC_PT_Objectdata_Panel(Super_Panel):
    bl_idname='bc.objectdata_panel'
    bl_label=''

    @classmethod
    def poll(cls, context):
        return not context.scene.bc_misc.results or (context.scene.bc_states.objectdata and bpy.context.scene['Objectdata'] is not None and [v for k, v in bpy.context.scene['Objectdata'].items() if type(v) != type(False)])

    def draw_header(self, context):
        sub_panel_header(self.layout, 'objectdata', context.scene.bc_misc.results, 'Objectdata')

    def draw(self, context):
        layout = self.layout
        layout.enabled = context.scene.bc_states.objectdata
        pg = context.scene.bc_objectdata

        sub = sub_layout(layout, 3)

        if not context.scene.bc_misc.results:
            sub.label(text='Clear Empty')

            box = sub.box()
            col = box.column()
            col.prop(pg, 'unused_material_slots')
            col.prop(pg, 'empty_vertex_groups')
        
        else:
            results_layout(sub, bpy.context.scene['Objectdata'])
