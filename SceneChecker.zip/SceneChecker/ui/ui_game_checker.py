import bpy
from .. function import *
from .. properties import *

# Refernce CODE

# https://github.com/PieceOCode/photogrammetry-addon/blob/06e5b4c2a1aae5dc363363cf6d9b628c21bde669/photogrammetry_addon.py line 169
# https://github.com/MikeFesta/3xr/blob/67579ef88d3a6f5694aba030961089bfbf862dc1/blender-add-on/xrs/tools.py

####################################
# Panel Animation
####################################   
def UIGameChecker(self, context):
    errorloc = object_location(self, context)
    errorscale = object_scale(self, context)
    errorrot = object_rotation(self, context)

    erroruvmore = uv_object_more_than_one(self, context)
    erroruvempty = uv_object_empty(self, context)
    erroruvmapone = uv_object_name(self, context)
    errorvaliduv = valid_uv_name(self, context)

    errorvcol = object_vertex_color(self, context)
    errorngon = ngon_meshcalc(self, context)
    errorsuffixgeo = check_suffix_geo(self, context)

    errornonmanifold = check_non_manifold_edges(self, context)

    errormaterialemptyslot = check_empty_mat_slot(self, context)

    ##########################################################
    # Detect Active Scene
    ##########################################################
    layout = self.layout  
    col = layout.column()
    scenechk = bpy.context.scene.scenechk_props
    
    col.label(text="Blend File Size:     " + calculate_blend_size())
    
    col.label(text='Check: {}'.format(
            bpy.context.scene.name))

    ############################################
    # GEO CHECK UI
    ############################################
    if not scenechk.geo_checking_ui_is_visible:
        col.prop(scenechk, "geo_checking_ui_is_visible", icon = 'TRIA_RIGHT', toggle = True)
    else:
        col.prop(scenechk, "geo_checking_ui_is_visible", icon = 'TRIA_DOWN', toggle = True)

        box_check_uv = col.column(align=True).box().column()
        split = box_check_uv.split()
        col_check_geo = split.column()

        col_check_geo.label(text='Freeze Location : {}'.format(
            len(object_location(self, context))))

        col_check_geo.label(text='Freeze Scale : {}'.format(
                len(object_scale(self, context))))
        
        col_check_geo.label(text='Freeze Rotation : {}'.format(
                len(object_rotation(self, context))))

        col_check_geo.label(text='Ngon Polygon : {}'.format(
            len(ngon_meshcalc(self, context))))

        col_check_geo.label(text='Check Vertex Color : {}'.format(
            len(object_vertex_color(self, context))))

        col_check_geo.label(text='Suffix Name _geo : {}'.format(
            len(check_suffix_geo(self, context))))

        col_check_geo.label(text='Non Manifold Edge: {}'.format(
            len(check_non_manifold_edges(self, context))))
    
        col_stats_geo = split.column()

        if errorloc:
            subrow = col_stats_geo.row(align=True)
            subrow.operator("ob.get_obj_loc", text="Select")
            subrow.operator("ob.applyloc", text="Fix")
        else:
            col_stats_geo.label(text="Pass", icon="CHECKMARK")

        if errorscale:
            subrow = col_stats_geo.row(align=True)
            subrow.operator("ob.get_obj_scale", text="Select")
            subrow.operator("ob.applyscale", text="Fix")
        else:
            col_stats_geo.label(text="Pass", icon="CHECKMARK")

        if errorrot:
            subrow = col_stats_geo.row(align=True)
            subrow.operator("ob.get_apply_rot", text="Select")
            subrow.operator("ob.applyrot", text="Fix")
        else:
            col_stats_geo.label(text="Pass", icon="CHECKMARK")
  
        if errorngon:
            col_stats_geo.operator("ob.sel_ngon", text="Select")
        else:
            col_stats_geo.label(text="Pass", icon="CHECKMARK")

        if errorvcol:
            col_stats_geo.operator("ob.remove_vcol", text="Select")
        else:
            col_stats_geo.label(text="Pass", icon="CHECKMARK")

        if errorsuffixgeo:
            col_stats_geo.operator("ob.remove_vcol", text="Warning", icon="ERROR")
        else:
            col_stats_geo.label(text="Pass", icon="CHECKMARK")

        if errornonmanifold:
            col_stats_geo.operator("ob.sel_nonmanifold" , text="Select")
        else:
            col_stats_geo.label(text="Pass", icon="CHECKMARK")
            
    ############################################
    # UV CHECK UI
    ############################################
    if not scenechk.uv_checking_ui_is_visible:
        col.prop(scenechk, "uv_checking_ui_is_visible", icon = 'TRIA_RIGHT', toggle = True)
    else:
        col.prop(scenechk, "uv_checking_ui_is_visible", icon = 'TRIA_DOWN', toggle = True)

        box_check_uv = col.column(align=True).box().column()
        split = box_check_uv.split()
        col_check_uv = split.column()

        col_check_uv.label(text='UV More Than One : {}'.format(
            len(uv_object_more_than_one(self, context))))
    
        col_check_uv.label(text='Zero UV : {}'.format(
                len(uv_object_empty(self, context))))

        col_check_uv.label(text='UV Not map1 : {}'.format(
                len(uv_object_name(self, context))))

        col_check_uv.label(text='UV Not Valid Name : {}'.format(
                len(valid_uv_name(self, context))))

        col_stats_uv = split.column()

        if erroruvmore:
            col_stats_uv.operator("ob.get_uv_more_than_one_object", text="Select")
        else:
            col_stats_uv.label(text="Pass", icon="CHECKMARK")

        if erroruvempty:
            col_stats_uv.operator("ob.get_zero_uv_object", text="Select")
        else:
            col_stats_uv.label(text="Pass", icon="CHECKMARK")

        if erroruvmapone:
            col_stats_uv.operator("ob.get_uv_map_one_object", text="Select")
        else:
            col_stats_uv.label(text="Pass", icon="CHECKMARK")

        if errorvaliduv:
            col_stats_uv.operator("ob.get_uv_map_one_object", text="Select")
        else:
            col_stats_uv.label(text="Pass", icon="CHECKMARK")

    ############################################
    # MATERIAL CHECK UI
    ############################################
    if not scenechk.mat_checking_ui_is_visible:
        col.prop(scenechk, "mat_checking_ui_is_visible", icon = 'TRIA_RIGHT', toggle = True)
    else:
        col.prop(scenechk, "mat_checking_ui_is_visible", icon = 'TRIA_DOWN', toggle = True)

        box_check_mat = col.column(align=True).box().column()
        split = box_check_mat.split()
        col_check_mat = split.column()

        col_check_mat.label(text='Empty Material Slot : {}'.format(
            len(check_empty_mat_slot(self, context))))
    
        col_check_mat = split.column()

        if errormaterialemptyslot:
            subrow = col_check_mat.row(align=True)
            subrow.operator("ob.sel_hasemptymatslot", text="Select")
            subrow.operator("ob.fix_sel_hasemptymatslot", text ="Fix")
        else:
            col_check_mat.label(text="Pass", icon="CHECKMARK")
