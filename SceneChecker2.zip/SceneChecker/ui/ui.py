import bpy
from bpy.types import Panel, Menu
from .. function import *
from . ui_game_checker import *
from .. properties import *

class MatListMenu(Menu):
    bl_label = "Material List Menu"
    bl_idname = "OBJECT_MT_mat_list_menu"
 
    def draw(self, context):
        layout = self.layout
        col = layout.column(align=True)

        if len(bpy.data.materials):
                for mat in bpy.data.materials:  
                        name = mat.name
                        try:
                                icon_val = layout.icon(mat)
                        except:
                                icon_val = 1
                                print ("WARNING [Mat Panel]: Could not get icon value for %s" % name)
                        col.label(text=name, icon_value=icon_val)
        else:
            layout.label(text="No data materials")
 
class VIEW3D_PT_Scene_Checker(Panel):
    bl_label = "Project Autosave"
    bl_idname = "VIEW3D_PT_Demo"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Brandoville"

    def draw(self, context):
        layout = self.layout
        scenechk = bpy.context.scene.scenechk_props
        
        # addon_preferences = get_addon_preferences()
        # workflow = addon_preferences.WorkflowOptions
        # software = addon_preferences.SoftwareWorkflowOptions
        
        # layout1 = self.layout
        # layout1.scale_x = 1.4
        # layout1.scale_y = 1.4
        # layout1.prop(scenechk,"UISchk", text ="", expand = True)
        
        # ##########################################################
        # # Custom Save
        # ##########################################################
        # if scenechk.UISchk == "save_ui":
        #     layout.prop(scenechk, "settingsFilePath")
        #     layout.prop(scenechk, "save_filename")
        #     row = layout.row()
        #     row.scale_x = 1.5
        #     row.scale_y = 1.5
        #     row.operator("op.save_wip")
        #     row.operator("file.save_incremental_backup")
        #     row.operator("op.save_publish")

        #     layout.operator("wm.asset_loader")
            
        # ##########################################################
        # # Scene Checker
        # ##########################################################
        # elif scenechk.UISchk == "scene_chk":
        #     layout.operator("quick.change_settings_schk", icon = "SETTINGS")
            
        #     UIGameChecker(self, layout)

        layout.prop(scenechk, "settingsFilePath")
        layout.prop(scenechk, "save_filename")
        row = layout.row()
        row.scale_x = 1.5
        row.scale_y = 1.5
        row.operator("op.save_wip")
        row.operator("file.save_incremental_backup")
        row.operator("op.save_publish")