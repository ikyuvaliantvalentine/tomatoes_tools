import bpy, bmesh
from bpy.types import Operator

class OP_Set_Seam_By_Sharp(Operator):
    bl_idname = "uv.set_sharp_to_seams"
    bl_label = "Sharp to Seams"
    bl_options = {'REGISTER', 'UNDO'}
    bl_description = "Set all sharp to seam edge"

    def execute(self, context):
        obj = bpy.context.object
        me = obj.data
        bm = bmesh.from_edit_mesh(me)
        for obj in context.objects_in_mode: 
            for edge in bm.edges:
                edge.seam = not edge.smooth
            bmesh.update_edit_mesh(me)
        return {'FINISHED'}


class OP_Set_Sharp_By_Seam(Operator):
    bl_idname = "uv.set_seams_to_sharp"
    bl_label = "Seams to Sharp"
    bl_options = {'REGISTER', 'UNDO'}
    bl_description = "Set all seam to sharp edge"

    def execute(self, context):
        obj = bpy.context.object
        me = obj.data
        bm = bmesh.from_edit_mesh(me)
        for obj in context.objects_in_mode:
            for edge in bm.edges:
                edge.smooth = not edge.seam
            bmesh.update_edit_mesh(me)
        return {'FINISHED'}