import bpy, os
from bpy.types import Operator

class QuickSettingsEevee(Operator):
    """
    Turn On AO, Volumetric Shadows, Reflections
    Eevee Sample set : 64

    On Indirect Lighting
    Cube Map set : 512
    Diffuse Bounces set : 3
    Diffuse Occlusion set : 3
    Irradiances Smooth set : 0.20
    """
    bl_idname = "engine.speedeevee"
    bl_label = "Simple Eevee Settings"

    def execute(self, context):
        eevee = bpy.context.scene.eevee

        bpy.context.scene.render.engine = 'BLENDER_EEVEE'
        eevee.taa_samples = 64
        eevee.taa_render_samples = 64
        eevee.use_taa_reprojection = True

        eevee.shadow_cube_size = '1024'
        eevee.shadow_cascade_size = '1024'
        eevee.use_soft_shadows = True

        eevee.use_ssr = True
        eevee.use_ssr_refraction = True
        eevee.ssr_quality = 0.7

        eevee.use_gtao = True
        eevee.gtao_distance = 1

        eevee.use_volumetric_shadows = True
        eevee.volumetric_tile_size = '2'

        eevee.gi_diffuse_bounces = 3
        eevee.gi_cubemap_resolution = '512'
        eevee.gi_visibility_resolution = '32'
        eevee.gi_irradiance_smoothing = 0.2
        return {'FINISHED'}
    
class HighShadowSettingsEevee(Operator):
    """
    Cube Size : 2048
    Cascade Size : 4096
    Turn On High Bit Depth
    Turn On Sof Shadow
    """
    bl_idname = "op.highshadoweevee"
    bl_label = "High Quality Shadow"

    def execute(self, context):
        bpy.context.scene.eevee.shadow_cube_size = '2048'
        bpy.context.scene.eevee.shadow_cascade_size = '4096'
        bpy.context.scene.eevee.use_shadow_high_bitdepth = True 
        bpy.context.scene.eevee.use_soft_shadows = True
        return {'FINISHED'}

class JinKepepetBasicBG(Operator):
    "Simple Setup For BG Jin Kepepet"
    bl_idname = "op.jkbasicbg"
    bl_label = "Basic BG"

    def execute(self, context):
        bpy.context.scene.render.resolution_x = 1920
        bpy.context.scene.render.resolution_y = 1080
        bpy.context.scene.render.resolution_percentage = 100
        bpy.context.scene.tool_settings.use_keyframe_insert_auto = False
        
        bpy.context.scene.render.use_lock_interface = True
        bpy.context.scene.render.film_transparent = True
        
        bpy.context.scene.eevee.taa_render_samples = 64
        bpy.context.scene.eevee.use_gtao = True
        bpy.context.scene.eevee.gtao_distance = 0.5
        bpy.context.scene.eevee.use_ssr = True
        bpy.context.scene.eevee.use_ssr_refraction = True
        bpy.context.scene.eevee.ssr_quality = 1
        bpy.context.scene.eevee.ssr_border_fade = 0.1
        bpy.context.scene.eevee.shadow_cube_size = '1024'
        bpy.context.scene.eevee.shadow_cascade_size = '2048'
        bpy.context.scene.eevee.use_shadow_high_bitdepth = True
        bpy.context.scene.eevee.use_soft_shadows = True
        
        list = ["CHAR", "PROP", "DUMMY", "SET"]

        for item in list:
            try:
                self.report({'INFO'}, "All collection avaible")
                bpy.data.collections[list[0]].hide_render = True
                bpy.data.collections[list[1]].hide_render = True
                bpy.data.collections[list[2]].hide_render = True
                bpy.data.collections[list[2]].hide_viewport = True
                bpy.context.view_layer.layer_collection.children[list[3]].holdout = False
            except KeyError:
                self.report({'INFO'}, "Collection missing / not avaible / have different name. Operation still Continue")
                
        return {'FINISHED'}
    
class JinKepepetBasicChar(Operator):
    "Simple Setup For Char Jin Kepepet"
    bl_idname = "op.jkbasicchar"
    bl_label = "Basic Char"

    def execute(self, context):
        bpy.context.scene.render.resolution_x = 1920
        bpy.context.scene.render.resolution_y = 1080
        bpy.context.scene.render.resolution_percentage = 100
        bpy.context.scene.tool_settings.use_keyframe_insert_auto = False
        
        bpy.context.scene.render.use_lock_interface = True
        bpy.context.scene.render.film_transparent = True
        
        bpy.context.scene.eevee.taa_render_samples = 64
        bpy.context.scene.eevee.use_gtao = True
        bpy.context.scene.eevee.gtao_distance = 0.5
        bpy.context.scene.eevee.use_ssr = True
        bpy.context.scene.eevee.use_ssr_refraction = True
        bpy.context.scene.eevee.ssr_quality = 1
        bpy.context.scene.eevee.ssr_border_fade = 0.1
        bpy.context.scene.eevee.shadow_cube_size = '1024'
        bpy.context.scene.eevee.shadow_cascade_size = '2048'
        bpy.context.scene.eevee.use_shadow_high_bitdepth = True
        bpy.context.scene.eevee.use_soft_shadows = True
        
        list = ["CHAR", "PROP", "DUMMY", "SET"]

        for item in list:
            try:
                self.report({'INFO'}, "All collection avaible")
                bpy.data.collections[list[0]].hide_render = False
                bpy.data.collections[list[1]].hide_render = False
                bpy.data.collections[list[2]].hide_render = True
                bpy.data.collections[list[2]].hide_viewport = True
                bpy.context.view_layer.layer_collection.children[list[3]].holdout = True
            except KeyError:
                self.report({'INFO'}, "Collection missing / not avaible / have different name. Operation still Continue")
                
        return {'FINISHED'}
    
class JinKepepetBasicTest(Operator):
    "Simple Setup For Test Jin Kepepet"
    bl_idname = "op.jktest"
    bl_label = "Test"

    def execute(self, context):
        bpy.context.scene.render.resolution_x = 1920
        bpy.context.scene.render.resolution_y = 1080
        bpy.context.scene.render.resolution_percentage = 50
        bpy.context.scene.tool_settings.use_keyframe_insert_auto = False
        
        bpy.context.scene.render.use_lock_interface = True
        bpy.context.scene.render.film_transparent = True
        
        bpy.context.scene.eevee.taa_render_samples = 16
        bpy.context.scene.eevee.use_gtao = True
        bpy.context.scene.eevee.gtao_distance = 0.5
        bpy.context.scene.eevee.use_ssr = True
        bpy.context.scene.eevee.use_ssr_refraction = True
        bpy.context.scene.eevee.ssr_quality = 1
        bpy.context.scene.eevee.ssr_border_fade = 0.1
        bpy.context.scene.eevee.shadow_cube_size = '1024'
        bpy.context.scene.eevee.shadow_cascade_size = '2048'
        bpy.context.scene.eevee.use_shadow_high_bitdepth = True
        bpy.context.scene.eevee.use_soft_shadows = True
        return {'FINISHED'}
    
class ShadowJinKepepet(Operator):
    """Quick Shadow Preset"""
    bl_idname = "op.shadowjinkepepet"
    bl_label = "Set Shadow"

    def execute(self, context):
        bpy.context.scene.eevee.shadow_cube_size = '2048'
        bpy.context.scene.eevee.shadow_cascade_size = '4096'
        bpy.context.scene.eevee.use_shadow_high_bitdepth = True 
        bpy.context.scene.eevee.use_soft_shadows = True
        
        list = ["CHAR", "PROP", "DUMMY", "SET"]

        for item in list:
            try:
                self.report({'INFO'}, "All collection avaible")
                bpy.context.view_layer.layer_collection.children[list[0]].holdout = True
                bpy.context.view_layer.layer_collection.children[list[1]].holdout = True
                bpy.data.collections[list[2]].hide_render = True
                bpy.context.view_layer.layer_collection.children[list[3]].hide_viewport = True
                bpy.context.view_layer.layer_collection.children[list[3]].holdout = True
            except KeyError:
                self.report({'INFO'}, "Collection missing / not avaible / have different name. Operation still Continue")
                
        return {'FINISHED'}

class PresetsCombineJinKepepet(Operator):
    "Presets for compose 2 image"
    bl_idname = "node.compose_image"
    bl_label = "Compose Image"

    def execute(self, context):
        # switch on nodes and get reference
        bpy.context.scene.use_nodes = True
        tree = bpy.context.scene.node_tree
        links = tree.links

        prev = bpy.context.area.type
        bpy.context.area.type = 'NODE_EDITOR'

        area = bpy.context.area      
        
        # clear default nodes
        for n in tree.nodes:
            tree.nodes.remove(n)

        # create input image
        im = tree.nodes.new('CompositorNodeImage')
        im.location = 0, 500
        # create input render layer node
        im2 = tree.nodes.new('CompositorNodeImage')
        im2.location = 0,200
        # create alpha Over
        ap = tree.nodes.new('CompositorNodeAlphaOver')
        ap.location = 300, 400
        links.new(im.outputs[0],ap.inputs[1])    
        links.new(im2.outputs[0],ap.inputs[2])    
        # create output node
        comp = tree.nodes.new('CompositorNodeComposite')   
        comp.location = 600,350
        links.new(ap.outputs[0],comp.inputs[0])

        bpy.context.area.type = prev
        return {'FINISHED'}

class PresetsBGJinKepepet(Operator):
    "Presets Background Jin kepepet"
    bl_idname = "node.bg"
    bl_label = "Background"

    def execute(self, context):
        # switch on nodes and get reference
        bpy.context.scene.use_nodes = True
        tree = bpy.context.scene.node_tree
        links = tree.links

        prev = bpy.context.area.type
        bpy.context.area.type = 'NODE_EDITOR'

        area = bpy.context.area      
        
        # clear default nodes
        for n in tree.nodes:
            tree.nodes.remove(n)

        # create input image
        im = tree.nodes.new('CompositorNodeImage')
        im.location = 0, 500
        # create input render layer node
        im2 = tree.nodes.new('CompositorNodeImage')
        im2.location = 0,200
        # create alpha Over
        ap = tree.nodes.new('CompositorNodeAlphaOver')
        ap.location = 300, 400
        links.new(im.outputs[0],ap.inputs[1])    
        links.new(im2.outputs[0],ap.inputs[2])    
        # create output node
        comp = tree.nodes.new('CompositorNodeComposite')   
        comp.location = 600,350
        links.new(ap.outputs[0],comp.inputs[0])

        bpy.context.area.type = prev
        return {'FINISHED'}