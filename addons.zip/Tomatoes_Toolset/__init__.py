bl_info = {
    "name": "Tomatoes Toolset",
    "description": "A collection of tools and settings to improve productivity",
    "author": "IkyuValiantValentine (Tomatoes)",
    "version": (0, 0, 1),
    "blender": (2, 80, 0),
    "location": "View3D",
    "warning": "This addon is still in development.",
    "category": "Tomatoes" }

import bpy, rna_keymap_ui
# load and reload submodules
##################################

import importlib
from . import developer_utils
from . import auto_load

from bpy.types import (
        Operator,
        Panel,
        PropertyGroup,
        )
        
from bpy.props import (StringProperty,
                       BoolProperty,
                       FloatVectorProperty,
                       FloatProperty,
                       EnumProperty,
                       IntProperty,
                       PointerProperty)
from bpy.app.handlers import persistent
from . properties import *

importlib.reload(developer_utils)
modules = developer_utils.setup_addon_modules(__path__, __name__, "bpy" in locals())     
  
@persistent
def pref_settings(self):    
    bpy.context.scene.world.use_nodes = True
    
    bpy.context.preferences.view.pie_animation_timeout = 0
    bpy.context.preferences.view.pie_menu_radius = 120
    bpy.context.preferences.view.show_splash = False
    bpy.context.preferences.view.show_tooltips_python = True
    bpy.context.preferences.view.render_display_type = 'AREA'  
    bpy.context.preferences.view.filebrowser_display_type = 'SCREEN'  
    bpy.context.preferences.inputs.use_auto_perspective = True
    bpy.context.preferences.filepaths.use_scripts_auto_execute = True
    bpy.context.preferences.filepaths.use_file_compression = True
    bpy.context.preferences.filepaths.save_version = 0
    bpy.context.preferences.filepaths.use_load_ui = False    
#    bpy.context.scene.render.engine = 'CYCLES'
    
    areas = bpy.context.workspace.screens[0].areas

    for area in areas:
        for space in area.spaces:
            if space.type == 'VIEW_3D':
                space.show_gizmo_object_translate = True
                
                                         
class AddonPreferences(bpy.types.AddonPreferences):
    bl_idname = __name__
                
    scale : FloatProperty(
            name="",
            description="Atur Ukuran Kotak Invoke",
            default=0.2,
            min=0.1, max=1
            )              
                                   
    base_color : FloatVectorProperty(name="Base Color", 
                                        subtype='COLOR', 
                                        size = 4,
                                        default=[1.0, 1.0, 1.0, 1.0])
                                        
    bool_color : FloatVectorProperty(name="Bool Color", 
                                        subtype='COLOR', 
                                        size = 4,
                                        default=[0.0, 0.8, 1.0, 1.0])
                                        
                                                                                                                                                                                                                
    FontSizeModal : IntProperty(
        name = "Font Size",
        default = 10,
        min = 10,
        max=50,
        description = "Ganti Ukuran Text")
                
    PositionXModal : IntProperty(
        name = "X Offset",
        description = "X Offset of the Viewport GUI")
        
    PositionYModal : IntProperty(
        name = "Y Offset",
        description = "Y Offset of the Viewport GUI")
        
    PositionXLampModal : IntProperty(
        name = "X Offset",
        description = "X Offset of the Viewport GUI")
        
    PositionYLampModal : IntProperty(
        name = "Y Offset",
        description = "Y Offset of the Viewport GUI")
            
    Font_Space : IntProperty(
        name = "Font Space",
        default = 1,
        min = -50,
        max=50,
        description = "Font Space on the Viewport GUI")
        
    Font_Space_Y : IntProperty(
        name = "Font Space Y",
        default = 1,
        min = -50,
        max=50,
        description = "Font Space Y Offset on the Viewport GUI")

    UIObjectData : EnumProperty(
            name="Choose UI",
            items=(
                ("object", "Object", "Object Data UI", 'OBJECT_DATA', 1),
                ("light", "Light", "Light Data UI", 'LIGHT_DATA', 2)),
            default='object',
            description = "Choose UI")    
                
    expand_preferences : BoolProperty(default = False)   
    expand_modal_base : BoolProperty(default = False)  
    
    def draw(self, context):
        layout = self.layout 
        box = layout.box()                  
        
        row = box.row()
        row.alignment = 'LEFT'
        row.prop(self, "expand_preferences", text="Asset Preferences", icon="TRIA_DOWN" if self.expand_preferences else "TRIA_RIGHT", emboss=False)
        
        if self.expand_preferences:
            row = box.row()
            row.label(text="Options:")
            row.prop(self, "scale", text="Dialog Box Scale")

        box = layout.box()
        row = box.row()
        row.alignment = "LEFT"
        row.prop(self, "expand_modal_base", text="Modal Base", icon="TRIA_DOWN" if self.expand_modal_base else "TRIA_RIGHT", emboss=False)
                
        if self.expand_modal_base:
            row = box.row()
            split = row.split()
            subcol = split.column()
            subrow = subcol.row()
            modal = subrow.column(align=True)
            modal.prop(self, "FontSizeModal")
            modal.prop(self, "Font_Space")
            modal.prop(self, "Font_Space_Y")
            modal = subrow.column(align=True)
            modal.prop(self, "PositionXModal")
            modal.prop(self, "PositionYModal")
            
            row = box.row()
            col = row.column()
            subcol = col.row(align=True)
            split = subcol.split(align=True)
            split.prop(self, "base_color", expand=False)
            split.prop(self, "bool_color", expand=False)
            split.prop(self, "end_color", expand=False)

        box = layout.box()
        row = box.row()
        row.alignment = "LEFT"
        row.label(text="Set UI Object Data:")
        row.prop(self, "UIObjectData", expand=True)
  
def topbar_shortcut_info(self, context):    
    layout = self.layout
    layout.scale_x = 1.2
    layout.scale_y = 1.2
    layout.label(text="")
    layout.operator("shortcut.info")
    
def menu_final_res(self, context):
    layout = self.layout
    rend = context.scene.render
    rend_percent = rend.resolution_percentage * 0.01
    x = (str(rend.resolution_x * rend_percent).split('.'))[0]
    y = (str(rend.resolution_y * rend_percent).split('.'))[0]
    layout.label(text="Resolution: " + x + " x " + y)
    layout.operator("swithres.toggle", icon="FILE_REFRESH")
            
##################################
# register
##################################
addon_keymaps = []
auto_load.init()

def get_hotkey_entry_item(km, kmi_name, kmi_value):

    for i, km_item in enumerate(km.keymap_items):
        if km.keymap_items.keys()[i] == kmi_name:
            if kmi_value:
                if km.keymap_items[i].properties.name == kmi_value:
                    return km_item
            return km_item

    return None

def add_hotkey():
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon                
    km = wm.keyconfigs.addon.keymaps.new(name = '3D View Generic', space_type = 'VIEW_3D')
    kmi = km.keymap_items.new('rename.tools', 'LEFTMOUSE', 'PRESS', alt=True)  
    kmi = km.keymap_items.new('quick.worldtool', 'RIGHTMOUSE', 'PRESS', ctrl=True, alt=True)  
    kmi = km.keymap_items.new('mod.stacks', 'LEFTMOUSE', 'PRESS', shift=True, alt=True)
    kmi = km.keymap_items.new('quick.cycles_tools', 'RIGHTMOUSE', 'PRESS', ctrl=True)
    kmi = km.keymap_items.new('quick.lamptool', 'RIGHTMOUSE', 'PRESS', alt=True, ctrl=True, shift=True)
    kmi = km.keymap_items.new('quick.viewsetscene', 'Z', 'PRESS', alt=True, shift=True)
    kmi = km.keymap_items.new('rotate.toninety', 'R', 'PRESS', shift=True, alt=True)
    kmi = km.keymap_items.new('shortcut.polycount', 'F3', 'PRESS')
#    kmi = km.keymap_items.new('stream.pivot', 'D', 'PRESS', shift=True, alt=True)
    kmi = km.keymap_items.new('reload.image', 'Z', 'PRESS', ctrl=True, shift=True)
    kmi = km.keymap_items.new('quick.cam_proj', 'LEFTMOUSE', 'PRESS', ctrl=True, alt=True)
    kmi = km.keymap_items.new('popup.hp_materials', 'Z', 'PRESS', ctrl=True, alt=True, shift=True)
    
    km = wm.keyconfigs.addon.keymaps.new(name='Mesh')
    kmi = km.keymap_items.new('op.set_custom_orient', 'Z', 'PRESS', ctrl=True, shift=True)
    kmi = km.keymap_items.new('op.delete_custom_orient', 'Z', 'PRESS', ctrl=True, shift=True, alt=True)
                        
    #Add  Object Menu
    km = wm.keyconfigs.addon.keymaps.new(name = '3D View Generic', space_type = 'VIEW_3D')
    kmi = km.keymap_items.new('wm.call_menu', 'A', 'PRESS', alt=True, ctrl=True, shift=True)
    kmi.properties.name = 'VIEW3D_MT_quick_add_objects'   
                     
    # Toggle Edit Menu
    km = wm.keyconfigs.addon.keymaps.new(name='Mesh')
    kmi = km.keymap_items.new('wm.call_menu', 'LEFTMOUSE', 'PRESS', alt=True)
    kmi.properties.name = "VIEW3D_MT_Toggle_Edit_Mode"
    kmi.active = True
    addon_keymaps.append((km, kmi))
    
    #Sculpt Menu
    km = wm.keyconfigs.addon.keymaps.new(name='Sculpt', space_type='EMPTY')
    kmi = km.keymap_items.new('wm.call_menu', 'SPACE', 'PRESS', alt=True)
    kmi.properties.name = 'VIEW3D_MT_SculptingMenu' 

    #File Browser Menu
    km = wm.keyconfigs.addon.keymaps.new(name='File Browser', space_type = 'FILE_BROWSER')
    kmi = km.keymap_items.new('wm.call_menu', 'Z', 'PRESS', alt=True, shift=True)
    kmi.properties.name = 'VIEW3D_MT_menu_file_browser' 
    
    #################################
    #   Pie Menu UI
    #################################
    
    #ALT + MIDDLEMOUSE
    km = wm.keyconfigs.addon.keymaps.new(name='Screen')
    kmi = km.keymap_items.new('wm.call_menu_pie', 'MIDDLEMOUSE', 'PRESS', alt=True)
    kmi.properties.name = "PIE_MT_QuickLayout"
    kmi.active = True
    addon_keymaps.append((km, kmi))

    #A
    km = wm.keyconfigs.addon.keymaps.new(name='Object Mode')
    kmi = km.keymap_items.new('wm.call_menu_pie', 'A', 'PRESS')
    kmi.properties.name = "PIE_MT_Selection"
    kmi.active = True
    addon_keymaps.append((km, kmi))

    # A Selection Edit Mode
    km = wm.keyconfigs.addon.keymaps.new(name='Mesh')
    kmi = km.keymap_items.new('wm.call_menu_pie', 'A', 'PRESS')
    kmi.properties.name = "PIE_MT_Selection_Edit"
    kmi.active = True
    addon_keymaps.append((km, kmi))
    
    # CTRL + SPACE
    km = wm.keyconfigs.addon.keymaps.new(name = '3D View Generic', space_type = 'VIEW_3D')
    kmi = km.keymap_items.new('wm.call_menu_pie', 'SPACE', 'PRESS', ctrl=True)
    kmi.properties.name = "PIE_MT_Manipulator"
    kmi.active = True
    addon_keymaps.append((km, kmi))
    
    #SPACE
    km = wm.keyconfigs.addon.keymaps.new(name='Screen')
    kmi = km.keymap_items.new('wm.call_menu_pie', 'SPACE', 'PRESS')
    kmi.properties.name = "PIE_MT_AreaViews"
    kmi.active = True
    addon_keymaps.append((km, kmi))

    #TAB
    km = wm.keyconfigs.addon.keymaps.new(name='Object Non-modal')
    kmi = km.keymap_items.new('wm.call_menu_pie', 'TAB', 'PRESS')
    kmi.properties.name = "PIE_MT_Mode"
    kmi.active = True
    addon_keymaps.append((km, kmi))
    
    #SHIFT + TAB
    km = wm.keyconfigs.addon.keymaps.new(name = '3D View Generic', space_type = 'VIEW_3D')
    kmi = km.keymap_items.new('wm.call_menu_pie', 'TAB', 'PRESS', shift=True)
    kmi.properties.name = "PIE_MT_Snaping"
    kmi.active = True
    addon_keymaps.append((km, kmi))
    
    #ALT + A
    km = wm.keyconfigs.addon.keymaps.new(name='Object Non-modal')
    kmi = km.keymap_items.new('wm.call_menu_pie', 'A', 'PRESS', alt=True)
    kmi.properties.name = "PIE_MT_Animation"  

    #Q
    km = wm.keyconfigs.addon.keymaps.new(name = '3D View Generic', space_type = 'VIEW_3D')
    kmi = km.keymap_items.new('wm.call_menu_pie', 'Q', 'PRESS')
    kmi.properties.name = "PIE_MT_ViewNumpad"
    kmi.active = True
    addon_keymaps.append((km, kmi))

    #ALT + RIGHTMOUSE TEXT EDITOR
    km = wm.keyconfigs.addon.keymaps.new(name = 'Text', space_type = 'TEXT_EDITOR')
    kmi = km.keymap_items.new('wm.call_menu_pie', 'RIGHTMOUSE', 'PRESS', alt=True)
    kmi.properties.name = "PIE_MT_TextEdit"
    kmi.active = True
    addon_keymaps.append((km, kmi))

    #Z
    km = wm.keyconfigs.addon.keymaps.new(name = '3D View Generic', space_type = 'VIEW_3D')
    kmi = km.keymap_items.new('wm.call_menu_pie', 'Z', 'PRESS')
    kmi.properties.name = "PIE_MT_ShadingView"
    kmi.active = True
    addon_keymaps.append((km, kmi))

    #SHIFT + LEFTMOUSE
    km = wm.keyconfigs.addon.keymaps.new(name = '3D View Generic', space_type = 'VIEW_3D')
    kmi = km.keymap_items.new('wm.call_menu_pie', 'LEFTMOUSE', 'PRESS', shift=True)
    kmi.properties.name = "PIE_MT_MoreMenu"
    kmi.active = True
    addon_keymaps.append((km, kmi))
    
    #ALT + Q
    km = wm.keyconfigs.addon.keymaps.new(name = '3D View Generic', space_type = 'VIEW_3D')
    kmi = km.keymap_items.new('wm.call_menu_pie', 'Q', 'PRESS', alt=True)
    kmi.properties.name = "PIE_MT_Transform"
    kmi.active = True
    addon_keymaps.append((km, kmi))
    
    #ALT + SPACE
    km = wm.keyconfigs.addon.keymaps.new(name = '3D View Generic', space_type = 'VIEW_3D')
    kmi = km.keymap_items.new('wm.call_menu_pie', 'SPACE', 'PRESS', alt=True)
    kmi.properties.name = "PIE_MT_ADD_NEW_MODIFIER"
    kmi.active = True
    addon_keymaps.append((km, kmi))
    
    #SHIFT + X
    km = wm.keyconfigs.addon.keymaps.new(name = '3D View Generic', space_type = 'VIEW_3D')
    kmi = km.keymap_items.new('wm.call_menu_pie', 'X', 'PRESS', shift=True)
    kmi.properties.name = "PIE_MT_Fast_Modelling"
    kmi.active = True
    addon_keymaps.append((km, kmi))
    
    #CTRL + S
    km = wm.keyconfigs.addon.keymaps.new(name='Window')
    kmi = km.keymap_items.new('wm.call_menu_pie', 'S', 'PRESS', ctrl=True)
    kmi.properties.name = "PIE_MT_SaveOpen"
    kmi.active = True
    addon_keymaps.append((km, kmi))
        
    #ALT + W (PROPORTIONAL OBJECT MODE)
    km = wm.keyconfigs.addon.keymaps.new(name='Object Mode')
    kmi = km.keymap_items.new('wm.call_menu_pie', 'W', 'PRESS', alt=True)
    kmi.properties.name = "PIE_MT_ProportionalObj"
    kmi.active = True
    addon_keymaps.append((km, kmi))

    #ALT + W (PROPORTIONAL EDIT MODE)
    km = wm.keyconfigs.addon.keymaps.new(name='Mesh')
    kmi = km.keymap_items.new('wm.call_menu_pie', 'W', 'PRESS', alt=True)
    kmi.properties.name = "PIE_MT_ProportionalEdt"
    kmi.active = True
    addon_keymaps.append((km, kmi))

    #A UV Mapping
    km = wm.keyconfigs.addon.keymaps.new(name = 'UV Editor')
    kmi = km.keymap_items.new('wm.call_menu_pie', 'A', 'PRESS')
    kmi.properties.name = "PIE_MT_UVSelection"

    #W
    km = wm.keyconfigs.addon.keymaps.new(name = 'UV Editor')
    kmi = km.keymap_items.new('wm.call_menu_pie', 'W', 'PRESS')
    kmi.properties.name = "PIE_MT_UV_ALIGN"
    kmi.active = True
    addon_keymaps.append((km, kmi))
    
    #W (Sculpt Pie)
    km = wm.keyconfigs.addon.keymaps.new(name = 'Sculpt')
    kmi = km.keymap_items.new('wm.call_menu_pie', 'W', 'PRESS')
    kmi.properties.name = "PIE_MT_SculptPie"
    kmi.active = True
    addon_keymaps.append((km, kmi))
    
    #ALT + Q
    km = wm.keyconfigs.addon.keymaps.new(name = 'UV Editor')
    kmi = km.keymap_items.new('wm.call_menu_pie', 'Q', 'PRESS', alt=True)
    kmi.properties.name = "PIE_MT_PivotPoint_UV_Editor"
    kmi.active = True
    addon_keymaps.append((km, kmi))
    

    #TAB (UV EDITOR)
    km = wm.keyconfigs.addon.keymaps.new(name = 'UV Editor')
    kmi = km.keymap_items.new('wm.call_menu_pie', 'TAB', 'PRESS')
    kmi.properties.name = "PIE_MT_UV_SELECTION"
    kmi.active = True
    addon_keymaps.append((km, kmi))

        
def register():            
    auto_load.register()
    bpy.utils.register_class(AddonPreferences)
    
    register_icons()    
    bpy.types.Scene.tomatoes_props = PointerProperty(type=TomatoesProperties)   
    bpy.types.VIEW3D_MT_editor_menus.append(topbar_shortcut_info)    
    bpy.types.RENDER_PT_dimensions.append(menu_final_res)
    bpy.app.handlers.load_post.append(pref_settings)

    #Keymap
    add_hotkey()

def unregister():
    auto_load.unregister()
    bpy.utils.unregister_class(AddonPreferences)    
    
    bpy.types.VIEW3D_MT_editor_menus.remove(topbar_shortcut_info)    
    bpy.types.RENDER_PT_dimensions.remove(menu_final_res)
    unregister_icons()    
    del bpy.types.Scene.tomatoes_props  
    bpy.app.handlers.load_post.remove(pref_settings)
        
    # clear the list
    del addon_keymaps[:]
    

