import bpy, bmesh
from bpy.types import Operator


class MeshEditable_Cylinder(bpy.types.Operator):
    bl_idname = "mesh.editable_cylinder"
    bl_label = "Editable Cyclinder"
    bl_description = "Make Editable Cyclinder"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        #Make Object
        cyl = bpy.data.meshes.new("GEO_Editable_Cylinder")
        obj = bpy.data.objects.new("GEO_Editable_Cylinder", cyl)

        scene = bpy.context.scene
        scene.collection.objects.link(obj)
        bpy.context.view_layer.objects.active = obj
        obj.select_set ( True )

        #Modifier
        bpy.ops.object.modifier_add(type='SCREW')
        bpy.context.object.modifiers["Screw"].axis = 'Y'
        bpy.context.object.modifiers["Screw"].use_smooth_shade = False

        #bpy.ops.view3d.snap_cursor_to_selected()
        bpy.ops.object.origin_set(type='ORIGIN_GEOMETRY', center='MEDIAN')
        bpy.ops.object.transform_apply(location=False, rotation=True, scale=True)

        #BMESH Data
        mesh = bpy.context.object.data
        bm = bmesh.new()
        t_v1 = bm.verts.new((0, 0.1, 0.1)) # the created vertex
        t_v2 = bm.verts.new((-0.1, 0.1, 0.1))
        t_v3 = bm.verts.new((-0.1, -0.1, 0.1))
        t_v4= bm.verts.new((0, -0.1, 0.1))

        bm.edges.new((t_v1, t_v2))
        bm.edges.new((t_v2, t_v3))
        bm.edges.new((t_v3, t_v4))

        # make the bmesh the object's mesh
        bm.to_mesh(mesh)  
        bm.free()
        return {'FINISHED'}
