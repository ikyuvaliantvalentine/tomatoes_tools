import bpy
from bpy.types import Operator
from bpy.props import *

class NameSelect(Operator):
    bl_idname = "scene.object_select"
    bl_label = "Select Object"
    bl_description = "Select Object Dengan Nama"
    object : StringProperty()
    
    def execute(self, context):    
        if self.object:
            object = bpy.data.objects[self.object]
            bpy.ops.object.select_all(action="DESELECT")
            object.select_set(True)
            context.view_layer.objects.active = object         
        else:
            object = bpy.data.objects[self.object]
            object.select = True
            context.view_layer.objects.active = object
        return {"FINISHED"}   
    
class HideSelectedLight(Operator):
    bl_idname = "sel.hide_light"
    bl_label = "Hide Selected Light"
    bl_description = "Hide Selected Light"
    
    def execute(self, context):    
        selection = bpy.context.selected_objects 

        for obj in selection: 
            if obj.type == 'LIGHT':
                bpy.data.objects[obj.name].hide_set(True)
        #        bpy.data.objects[obj.name].hide_render =True
        return {"FINISHED"}   
    
class HideSelectedRenderLight(Operator):
    bl_idname = "sel.hide_render_light"
    bl_label = "Hide Selected Render Light"
    bl_description = "Hide Selected Render Light"
    
    def execute(self, context):    
        selection = bpy.context.selected_objects 

        for obj in selection: 
            if obj.type == 'LIGHT':
                bpy.data.objects[obj.name].hide_render =True 
        return {"FINISHED"}   