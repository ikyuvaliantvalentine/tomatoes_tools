import bpy
from bpy.types import Operator
from bpy.props import *

######################
#Primitives  
######################    
class AddNewPrimitive(Operator):
    bl_idname = "view3d.addprim"
    bl_label = "Add Primitive"

    type : EnumProperty(
        items = (('Vertex', "Vertex", ""),
                 ('Draw_Curve', "Draw_Curve", ""),
                 ('Circle_6', "Circle_6", ""),
                 ('Circle_8', "Circle_8", ""),
                 ('Circle_12', "Circle_12", ""),
                 ('Circle_24', "Circle_24", ""),
                 ('Circle_32', "Circle_32", ""),
                 ('Cylinder_6', "Cylinder_6", ""),
                 ('Cylinder_8', "Cylinder_8", ""),
                 ('Cylinder_12', "Cylinder_12", ""),
                 ('Cylinder_24', "Cylinder_24", ""),
                 ('Cylinder_32', "Cylinder_32", ""),
                 ('Cylinder_64', "Cylinder_64", ""),
                 ('Cylinder_128', "Cylinder_128", ""),
                 ('Sphere_8', "Sphere_8", ""),
                 ('Sphere_12', "Sphere_12", ""),
                 ('Sphere_24', "Sphere_24", ""),
                 ('Sphere_32', "Sphere_32", "")),
                 default = 'Circle_6'
                 )
                 
    def execute(self, context):  
        obj = context.active_object    
        
        if self.type == 'Vertex':                    
            bpy.ops.view3d.cursor3d('INVOKE_DEFAULT')
            bpy.ops.mesh.primitive_plane_add()
            bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)
                        
            bpy.ops.object.mode_set(mode = 'EDIT')
            bpy.ops.mesh.select_mode(use_extend=False, use_expand=False, type='VERT')
            bpy.ops.mesh.merge(type='CENTER')              
            bpy.ops.transform.translate('INVOKE_DEFAULT')
                
        if self.type == 'Draw_Curve':                
             if context.object is not None and obj.type == 'MESH':
                bpy.ops.object.mode_set(mode = 'OBJECT') 
                bpy.ops.curve.primitive_bezier_curve_add() 
                bpy.ops.object.mode_set(mode = 'EDIT')
                bpy.ops.curve.select_all(action='SELECT')

                bpy.ops.curve.delete(type='VERT')
                bpy.ops.object.mode_set(mode = 'OBJECT')
                bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)
                bpy.ops.object.mode_set(mode = 'EDIT')                      
                bpy.ops.curve.draw('INVOKE_DEFAULT')
                    
        if self.type == 'Circle_6':
            bpy.ops.mesh.primitive_circle_add(vertices=6, enter_editmode=True)
        if self.type == 'Circle_8':
            bpy.ops.mesh.primitive_circle_add(vertices=8, enter_editmode=True)
        if self.type == 'Circle_12':
            bpy.ops.mesh.primitive_circle_add(vertices=12, enter_editmode=True)
        if self.type == 'Circle_24':
            bpy.ops.mesh.primitive_circle_add(vertices=24, enter_editmode=True)
        if self.type == 'Circle_32':
            bpy.ops.mesh.primitive_circle_add(vertices=32, enter_editmode=True)

                            
        if self.type == 'Cylinder_6':
            bpy.ops.mesh.primitive_cylinder_add(vertices=6, end_fill_type='NOTHING', enter_editmode=True)
        if self.type == 'Cylinder_8':
            bpy.ops.mesh.primitive_cylinder_add(vertices=8, end_fill_type='NOTHING', enter_editmode=True)
        if self.type == 'Cylinder_12':
            bpy.ops.mesh.primitive_cylinder_add(vertices=12, end_fill_type='NOTHING', enter_editmode=True)
        if self.type == 'Cylinder_24':
            bpy.ops.mesh.primitive_cylinder_add(vertices=24, end_fill_type='NOTHING', enter_editmode=True)
        if self.type == 'Cylinder_32':
            bpy.ops.mesh.primitive_cylinder_add(vertices=32, end_fill_type='NOTHING', enter_editmode=True)
        if self.type == 'Cylinder_64':
            bpy.ops.mesh.primitive_cylinder_add(vertices=64, end_fill_type='NOTHING', enter_editmode=True)            
        if self.type == 'Cylinder_128':
            bpy.ops.mesh.primitive_cylinder_add(vertices=128, end_fill_type='NOTHING', enter_editmode=True)
            
        if self.type == 'Sphere_8':           
            bpy.ops.mesh.primitive_uv_sphere_add(segments=8, ring_count=8, enter_editmode=True)                        
        if self.type == 'Sphere_12':           
            bpy.ops.mesh.primitive_uv_sphere_add(segments=12, ring_count=6, enter_editmode=True)
        if self.type == 'Sphere_24':           
            bpy.ops.mesh.primitive_uv_sphere_add(segments=24, ring_count=12, enter_editmode=True)
        if self.type == 'Sphere_32':           
            bpy.ops.mesh.primitive_uv_sphere_add(segments=32, enter_editmode=True)
        return {'FINISHED'}
    
######################
#   Display Viewport               
######################
class Display_Viewport(Operator):
    bl_idname = "view3d.display_viewport"
    bl_label = "Display Viewport"

    type_view : EnumProperty(
        items = (('show_only_render', "show_only_render", ""),
                 ('show_face_normal', "show_face_normal", ""),
                 ('show_xray', "show_xray", ""),
                 ('show_wireframe', "show_wireframe", ""),
                 ('show_cavity', "show_cavity", "")),
                 default = 'show_only_render'
                 )
                 
    def execute(self, context):        
        space = bpy.context.space_data.overlay
        shd = bpy.context.space_data.shading
           
        if self.type_view == 'show_only_render':                    
            if space.show_overlays:
                space.show_overlays = False
            else:
                space.show_overlays = True
                
        if self.type_view == 'show_face_normal':                    
            if space.show_face_orientation:
                space.show_face_orientation = False
            else:
                space.show_face_orientation = True
                
        if self.type_view == 'show_xray':                    
            if shd.show_xray:
                shd.show_xray = False
            else:
                shd.show_xray = True
                
        if self.type_view == 'show_wireframe':                    
            if space.show_wireframes:
                space.show_wireframes = False
            else:
                space.show_wireframes = True
            space.wireframe_threshold = 1  
        
        if self.type_view == 'show_cavity':                    
            if shd.show_cavity:
                shd.show_cavity = False
            else:
                shd.show_cavity = True
                              
        return {'FINISHED'}
    
#Merge
class Toggle_merge(Operator):   
    """ Toggle Menu Merge """
    bl_idname = "object.toggle_merge"
    bl_label = "Merge Tool"
    bl_options = {"REGISTER", "UNDO"}
    
    type_merge : EnumProperty(
        items = (('last', "Last", ""),
                 ('center', "Center", ""),
                 ('first', "First", ""),
                 ('cursor', "Cursor", ""),
                 ('collapse', "Collapse", "")),
                 default = 'first'
                 )

    @classmethod                                     
    def poll(cls, context):                         
        obj = context.active_object
        if len([obj for obj in context.selected_objects if context.object is not None if obj.type == 'MESH' if bpy.context.object.mode == "EDIT"]) == 1:
            return True

    def execute(self, context):          
        #Collapse
        if self.type_merge == 'collapse':   
            bpy.ops.mesh.merge(type='COLLAPSE')   
                     
        #At First
        if self.type_merge == 'first':   
            bpy.ops.mesh.merge(type='FIRST') 
                        
        #At Last
        if self.type_merge == 'last':   
            bpy.ops.mesh.merge(type='LAST')  
                  
        #At cursor
        if self.type_merge == 'cursor':   
            bpy.ops.mesh.merge(type='CURSOR')    
                    
        #Center    
        if self.type_merge == 'center': 
            bpy.ops.mesh.merge(type='CENTER')                        
        return {"FINISHED"}   

##################################
#    Restrict View Unselected Menu               
##################################
class op_restrict_view_unselectd(Operator):
    """CLICK - HIDE UNSELECTED """    
    bl_idname = 'op.hide_unselected_light'
    bl_label = "Restrict View Unselected (LIGHT)"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):                         
        obj = context.active_object
        if len([obj for obj in context.selected_objects if context.object is not None if obj.type == "LIGHT"]) >= 1:
            return True

    def execute(self, context):      
        for ob in bpy.data.objects:
            if ob.type == "LIGHT":
                if ob.hide_viewport == True:
                    ob.hide_viewport  = False
                else:
                    ob.hide_viewport  = True
                ao = bpy.context.view_layer.objects.active            
                ao.hide_viewport  = False
                ao.select_set(True)
        return {'FINISHED'}

##################################
#    Aim Light To Selected              
##################################
class op_aim_light(Operator):
    """CLICK - Aim To Selected Object """    
    bl_idname = "op.aim_light"
    bl_label = "Aim Light"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):    
        obj = bpy.context.object
        if bpy.context.mode != 'OBJECT':
            return {'FINISHED'}
        if obj == None:
            return {'FINISHED'}
        slist = bpy.context.selected_objects
        ct = 0
        for i in slist:
            ct += 1
        if ct == 1:
            return {'FINISHED'}
        bpy.ops.object.track_set(type='TRACKTO')
        bpy.ops.object.track_clear(type='CLEAR_KEEP_TRANSFORM')
        return {'FINISHED'}

##################################
#    Show Name       
##################################
class op_aim_light(Operator):
    """CLICK - Aim To Selected Object """    
    bl_idname = "op.aim_light"
    bl_label = "Aim Light"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):    
        obj = bpy.context.object
        if bpy.context.mode != 'OBJECT':
            return {'FINISHED'}
        if obj == None:
            return {'FINISHED'}
        slist = bpy.context.selected_objects
        ct = 0
        for i in slist:
            ct += 1
        if ct == 1:
            return {'FINISHED'}
        bpy.ops.object.track_set(type='TRACKTO')
        bpy.ops.object.track_clear(type='CLEAR_KEEP_TRANSFORM')
        return {'FINISHED'}
    
####################
#    Brush Menu    #               
####################
class SculptingBrushSelect(Operator):
    """Update the current sculpting brush with the selected brush"""
    bl_idname = "ob.sculpt_brush_select"
    bl_label = "Select Sculpt Brush"
    bl_options = {"REGISTER", "UNDO"}

    # add enum property
    ### When an item only contains 4 items they define (identifier, name, description, number).
    # Tricky...
    mode_options = [
        ("Clay Strips", "Clay Strips", "Clay Strips", "BRUSH_CLAY", 0),
        ("Crease", "Crease", "Crease", "BRUSH_CREASE", 1),
        ("Grab", "Grab", "Grab", "BRUSH_GRAB", 2),
        ("Draw", "Sculpt Draw", "Sculpt Draw", "BRUSH_SCULPT_DRAW", 3),
        ("Scrape/Peaks", "Scrape/Peaks", "Scrape/Peaks", "BRUSH_SCRAPE", 4),
        ("Clay", "Clay", "Clay", "BRUSH_CLAY", 5),
        ("Flatten/Contrast", "Flatten/Contrast", "Flatten/Contrast", "BRUSH_FLATTEN", 6),
        ("Snake Hook", "Snake Hook", "Snake Hook", "BRUSH_SNAKE_HOOK", 7),
        ("Inflate/Deflate", "Inflate/Deflate", "Inflate/Deflate", "BRUSH_INFLATE", 8),
        ("Mask", "Mask", "Mask", "BRUSH_MASK", 9),
        ("Fill/Deepen", "Fill/Deepen", "Fill/Deepen", "BRUSH_FILL", 10),
        ("Blob", "Blob", "Blob", "BRUSH_BLOB", 11),
        ("Layer", "Layer", "Layer", "BRUSH_LAYER", 12),
        ("Smooth", "Smooth", "Smooth", "BRUSH_SMOOTH", 13),
        ("Thumb", "Thumb", "Thumb", "BRUSH_THUMB", 14),
        ("Nudge", "Nudge", "Nudge", "BRUSH_NUDGE", 15),
        ("Pinch/Magnify", "Pinch/Magnify", "Pinch/Magnify", "BRUSH_PINCH", 16)]

    selected_mode : bpy.props.EnumProperty(
            items=mode_options,
            description="Sculpt Brushes",
            default="Clay Strips")

    def execute(self, context):
        context.tool_settings.sculpt.brush = bpy.data.brushes[self.selected_mode]
        return {"FINISHED"}