import bpy
import os
import math
import subprocess
import bmesh
from bpy.types import Operator, OperatorFileListElement
from bpy_extras.io_utils import ImportHelper, ExportHelper
from bpy.props import *
        
#FBX-Export
class Multi_FBX_export(Operator):
    """Export FBX"""
    bl_idname = "object.multi_fbx_export"
    bl_label = "Export FBX"

    def execute(self, context):
        brandoville = context.scene.brandoville_props
        blend_not_saved = False
        
        brandoville.export_dir = ""
        
        #check saved blend file
#        if len(bpy.data.filepath) == 0:
#            self.report({'INFO'}, 'Objects don\'t export, because Blend file is not saved')
#            blend_not_saved = True
#        if blend_not_saved == False:    
        path = bpy.path.abspath('//FBXs/')
        if brandoville.custom_export_path:
            if not os.path.exists(os.path.realpath(bpy.path.abspath(brandoville.export_path))):
                self.report({'INFO'}, 'Directory for export not exist. Objects will be export to \'FBXs\' folder')
            else:
                path = os.path.realpath(bpy.path.abspath(brandoville.export_path)) + '/'
            
            #Create export folder
            if not os.path.exists(path):
                os.makedirs(path)
            
            # Save selected objects and active object
            start_selected_obj = bpy.context.selected_objects
            start_active_obj = bpy.context.active_object
            current_selected_obj = bpy.context.selected_objects
            
            #Delete All Material Before Export
            if brandoville.delete_all_materials:
                for o in current_selected_obj:
                    if o.type == 'MESH' and len(o.data.materials) > 0:
                        for q in reversed(range(len(o.data.materials))):
                            bpy.context.object.active_material_index = q
                            o.data.materials.pop(index = q)
            
            #Check "Pivot Point Align" option and disable it
            current_pivot_point_align = bpy.context.scene.tool_settings.use_transform_pivot_point_align

            if current_pivot_point_align:
                bpy.context.scene.tool_settings.use_transform_pivot_point_align = False
            
            #Save Cursor Location and Pivot Point Mode
            saved_cursor_loc = bpy.context.scene.cursor.location.copy()
            current_pivot_point = bpy.context.scene.tool_settings.transform_pivot_point
            
            #Name for FBX
            name = bpy.context.active_object.name
            
            #Filtering Selected Objects. Exclude All not meshes, empties and armatures
            bpy.ops.object.select_all(action='DESELECT')
            for x in current_selected_obj:
                if x.type == 'MESH' or x.type == 'EMPTY' or x.type == 'ARMATURE':
                    x.select_set(True)
            current_selected_obj = bpy.context.selected_objects
            
            #Apply Scale
            if brandoville.apply_scale:
                bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
                bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

            #Rotation Fix. Rotate X -90, Apply, Rotate X 90
            if brandoville.apply_rot:
                bpy.context.scene.tool_settings.transform_pivot_point = 'MEDIAN_POINT'
                #Operate only with higher level parents 
                for x in current_selected_obj:
                    bpy.ops.object.select_all(action='DESELECT')
                    if x.parent == None:
                        x.select_set(True)
                        bpy.context.view_layer.objects.active = x
                        
                        # X-rotation fix
                        bpy.ops.object.transform_apply(location=False, rotation=True, scale=False)
                        bpy.ops.transform.rotate(value= (math.pi * -90 / 180), orient_axis='X', orient_matrix=((1, 0, 0), (0, 1, 0), (0, 0, 1)), orient_type='GLOBAL', constraint_axis=(True, False, False), orient_matrix_type='GLOBAL', mirror=False, use_proportional_edit=False, proportional_edit_falloff='SMOOTH', proportional_size=1)                       
                        bpy.ops.object.select_grouped(extend=True, type='CHILDREN_RECURSIVE')
                        bpy.ops.object.transform_apply(location=False, rotation=True, scale=False)
                        bpy.ops.object.select_all(action='DESELECT')
                        x.select_set(True)
                        bpy.ops.transform.rotate(value= (math.pi * 90 / 180), orient_axis='X', orient_matrix=((1, 0, 0), (0, 1, 0), (0, 0, 1)), orient_type='GLOBAL', constraint_axis=(True, False, False), orient_matrix_type='GLOBAL', mirror=False, use_proportional_edit=False, proportional_edit_falloff='SMOOTH', proportional_size=1)
                        bpy.ops.object.select_grouped(extend=True, type='CHILDREN_RECURSIVE')
                        x.select_set(False)
                        bpy.ops.object.transform_apply(location=False, rotation=True, scale=False)

            bpy.ops.object.select_all(action='DESELECT')
            for x in current_selected_obj:
                if x.type == 'MESH' or x.type == 'EMPTY' or x.type == 'ARMATURE':
                    x.select_set(True)

            #Export All as one fbx
            if brandoville.fbx_export_mode == '1':
                if brandoville.set_custom_fbx_name:
                    name = brandoville.custom_fbx_name
                
                #Export FBX
                bpy.ops.export_scene.fbx(filepath=str(path + name + '.fbx'), use_selection=True, apply_scale_options = 'FBX_SCALE_ALL')

            #Individual Export
            if brandoville.fbx_export_mode == '0':
                for x in current_selected_obj:
                    bpy.context.scene.tool_settings.transform_pivot_point = 'MEDIAN_POINT'
                    # Select only current object
                    bpy.ops.object.select_all(action='DESELECT')
                    x.select_set(True)
                    bpy.context.view_layer.objects.active = x

                    if brandoville.apply_loc:
                        #Copy Object Location
                        bpy.ops.view3d.snap_cursor_to_selected()
                        object_loc = bpy.context.scene.cursor.location.copy()
                        #Move Object to Center
                        bpy.ops.object.location_clear(clear_delta=False)
                    else:
                        bpy.ops.view3d.snap_cursor_to_center()
                        bpy.context.scene.tool_settings.transform_pivot_point = 'CURSOR'
                    name = x.name

                    #Export FBX
                    bpy.ops.export_scene.fbx(filepath=str(path + name + '.fbx'), use_selection=True, apply_scale_options = 'FBX_SCALE_ALL')
                    
                    #Restore Object Location
                    if brandoville.apply_loc:
                        bpy.context.scene.cursor.location = object_loc
                        bpy.ops.view3d.snap_selected_to_cursor(use_offset=True)
                                    
            #Select again objects and set active object
            bpy.ops.object.select_all(action='DESELECT')
            for j in start_selected_obj:
                j.select_set(True)
    
            bpy.context.view_layer.objects.active = start_active_obj

            #Apply Rotation
            if brandoville.apply_rot:
                bpy.ops.object.transform_apply(location=False, rotation=True, scale=False)

            #Restore "Pivot Point Align" option
            bpy.context.scene.tool_settings.use_transform_pivot_point_align = current_pivot_point_align

            #Restore Cursor Location and Pivot Point Mode
            bpy.context.scene.cursor.location = saved_cursor_loc
            bpy.context.scene.tool_settings.transform_pivot_point = current_pivot_point     
            
            #save export dir
            brandoville.export_dir = path   
        return {'FINISHED'}
    
class ImportFBXOBJ(Operator, ImportHelper):
    """Batch Import FBX and OBJ"""
    bl_idname = "object.import_fbxobj"
    bl_label = "Import FBXs/OBJs"
    files: CollectionProperty(name="File Path", type=OperatorFileListElement)
    directory: StringProperty(subtype="DIR_PATH")
    
    filter_glob: StringProperty(
        default="*.fbx; *.obj",
        options={'HIDDEN'})
    
    def execute(self, context):
        directory = self.directory
        for f in self.files:
            filepath = os.path.join(directory, f.name)
            extension = (os.path.splitext(f.name)[1])[1:]
            if extension == "fbx" or extension == "FBX":
                bpy.ops.import_scene.fbx(filepath = filepath)
            if extension == "obj" or extension == "OBJ":
                bpy.ops.import_scene.obj(filepath = filepath)   
        return {'FINISHED'}
    
#-------------------------------------------------------
#Open Export Directory
#-------------------------------------------------------
class OpenExportDir(Operator):
    """Open Export Directory in OS"""
    bl_idname = "object.open_export_dir"
    bl_label = "Open Export Directory in OS"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        brandoville = context.scene.brandoville_props

        if len(brandoville.export_dir) > 0:
            try:
                os.startfile(brandoville.export_dir)
            except:
                subprocess.Popen(['xdg-open', act.export_dir])
        else:
            self.report({'INFO'}, 'Export FBX\'s before')
            return {'FINISHED'}

        return {'FINISHED'}