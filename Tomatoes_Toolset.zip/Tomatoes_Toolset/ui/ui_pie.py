import bpy, os
from bpy.types import Menu
from .. properties import *

########################################################################
#Pie Quick layout
######################################################################## 
class PIE_MT_QuickLayout(Menu):
    bl_idname = "PIE_MT_QuickLayout"
    bl_label = "Pie Quick Menu"
    
    def draw(self, context):
        layout = self.layout
        rd = context.scene.render    
        view = context.space_data
        pie = layout.menu_pie()
#        #4 - LEFT       
        pie.operator("render.opengl", text="Render OpenGL", icon='RENDER_STILL')
        #6 - RIGHT
        pie.operator("render.render", text="Render", icon = "RENDER_STILL") 
        #2 - BOTTOM
        box = pie.split().box().column()
        col = box.column(align=True)
        col.prop(rd, "use_simplify", text="Use Simplify", icon='META_CUBE')
        if context.scene.render.use_simplify:
            split = col.split()
            simpl = split.column()
            simpl.scale_x = 0.5
            simpl.label(text="Viewport:")
            simpl.prop(rd, "simplify_subdivision", text="Viewport")
            simpl.prop(rd, "simplify_child_particles", text="Child Particles")
            simpl = split.column()
            simpl.label(text="Render:")
            simpl.prop(rd, "simplify_subdivision_render", text="Render")
            simpl.prop(rd, "simplify_child_particles_render", text="Child Particles")
        #8 - TOP
        pie.operator("wm.search_menu", icon="VIEWZOOM")        
        #7 - TOP - LEFT 
        split = pie.split()
        col = split.column(align=True)
        col.scale_x=1.3
        col.scale_y=1.2
        col.operator("view3d.switch_workspace", text="Layout").name="Layout"
        col.operator("view3d.switch_workspace", text="Shading").name="Shading"
        # 9 - TOP - RIGHT
        split = pie.split()
        col = split.column(align=True)
        col.scale_x=1.3
        col.scale_y=1.2
        col.operator("view3d.switch_workspace", text="Compositing").name="Compositing"       
        col.operator("view3d.switch_workspace", text="Scripting").name="Scripting"
        #1 - BOTTOM - LEFT 
        pie.separator()
        #3 - BOTTOM - RIGHT  
        pie.separator()
        
####################################################### 
# Pie Selection Object Mode 
#######################################################   
class PIE_MT_Selection(Menu):
    bl_idname = "PIE_MT_Selection"
    bl_label = "Pie Selections Object Mode"

    def draw(self, context):
        layout = self.layout
        pie = layout.menu_pie()
        # 4 - LEFT
        if context.object is None:
            pie.operator("object.select_all", text="Select All",icon='SELECT_EXTEND').action='TOGGLE'
        else:
            pie.operator("object.mesh_selection", text="Select Object",icon='SELECT_EXTEND')
        # 6 - RIGHT
        pie.operator("view3d.select_box", text="Border Select", icon='BORDERMOVE')
        # 2 - BOTTOM
        pie.operator("object.move_to_collection", icon='COLLECTION_NEW')    
        # 8 - TOP
        pie.operator("object.viewrestrict", icon="GHOST_DISABLED")
        # 7 - TOP - LEFT
        box = pie.split().column()
        col = box.column(align=True)
        col.scale_x=1.2
        col.scale_y=1.2
        col.operator("selectby.modal" ,icon ="VIEWZOOM")
        col.operator("sel.lamps", icon='OUTLINER_OB_LIGHT')  
        # 9 - TOP - RIGHT
        box = pie.split().column()
        col = box.column(align=True)
        col.scale_x=1.2
        col.scale_y=1.2
        row = col.row(align=True)
        row.operator("meshedge.select_seams", icon='UV_EDGESEL')
        row.operator("meshedge.select_sharp", icon='UV_EDGESEL')
        col.operator("object.mark_seams_from_uv_islands", icon='UV_ISLANDSEL')
        # 1 - BOTTOM - LEFT
        pie.separator()
        # 3 - BOTTOM - RIGHT 
        col = pie.split().column()
        col.scale_x=1.2
        col.scale_y=1.2
        col.operator("view3d.toggle_background", icon ='SHADING_WIRE')
        col.operator("datamesh.facetype_select", text="Select Tris", icon_value=get_icon("triangle")).face_type = "3"
        col.operator("datamesh.facetype_select", text="Select Ngon", icon_value=get_icon("ngon")).face_type = "5"
        
####################################################### 
# Pie Selection Edit Mode
#######################################################   
class PIE_MT_Selection_Edit(Menu):
    bl_idname = "PIE_MT_Selection_Edit"
    bl_label = "Pie Selections Edit Mode"

    def draw(self, context):
        layout = self.layout
        pie = layout.menu_pie()
        #4 - LEFT
        pie.operator("object.mesh_selection", text="Select Object",icon='SELECT_EXTEND')
        #6 - RIGHT
        pie.operator("view3d.select_box", text="Border Select", icon='BORDERMOVE')
        #2 - BOTTOM
        pie.operator("mesh.edges_select_sharp")
        #8 - TOP
        pie.operator("object.viewrestrict", icon="GHOST_DISABLED")
        #7 - TOP - LEFT
        box = pie.split().column()
        col = box.column(align=True)
        col.scale_x=1.2
        col.scale_y=1.2
        col.operator("mesh.loop_to_region", text="Select Loop Inner Region", icon='FACESEL')
        col.operator("mesh.select_nth", icon="GROUP_VERTEX")
        row = col.row(align=True)
        row.operator("mesh.loop_multi_select", text="Select Loop").ring=False
        row.operator("mesh.loop_multi_select", text="Select Ring").ring=True
        #9 - TOP - RIGHT
        box = pie.split().column()
        col = box.column(align=True)
        col.scale_x=1.2
        col.scale_y=1.2
        row = col.row(align=True)
        row.operator("mesh.select_non_manifold")
        row.operator("mesh.select_interior_faces")
        row = col.row(align=True)
        row.operator("meshedge.select_seams", icon='UV_EDGESEL')
        row.operator("meshedge.select_sharp", icon='UV_EDGESEL')
        #1 - BOTTOM - LEFT
        pie.operator("mesh.select_linked", icon="UV_VERTEXSEL")
        #3 - BOTTOM - RIGHT  
        box = pie.split().column()
        col = box.column(align=True)
        col.scale_x=1.2
        col.scale_y=1.2
        col.operator("view3d.toggle_background", icon ='SHADING_WIRE')
        col.operator("datamesh.facetype_select", text="Select Tris", icon_value=get_icon("triangle")).face_type = "3"
        col.operator("datamesh.facetype_select", text="Select Ngon", icon_value=get_icon("ngon")).face_type = "5"

####################################################### 
# Pie Curve Edit Mode
#######################################################   
class PIE_MT_Curve_Selection_Edit(Menu):
    bl_idname = "PIE_MT_Curve_Selection_Edit"
    bl_label = "Pie Selections Curve Edit Mode"

    def draw(self, context):
        layout = self.layout
        pie = layout.menu_pie()
        #4 - LEFT
        pie.operator("curve.select_all", text="Select Object",icon='SELECT_EXTEND')
        #6 - RIGHT
        pie.operator("view3d.select_box", text="Border Select", icon='BORDERMOVE')
        #2 - BOTTOM
        pie.separator()
        #8 - TOP
        pie.separator()
        #7 - TOP - LEFT
        pie.separator()
        #9 - TOP - RIGHT
        pie.separator()
        #1 - BOTTOM - LEFT
        pie.operator("curve.select_linked", icon="UV_VERTEXSEL")
        #3 - BOTTOM - RIGHT  
        pie.separator()

#################################
#Pie Views Menu
#################################    
class PIE_MT_AreaViews(Menu):
    bl_idname = "PIE_MT_AreaViews"
    bl_label = "Pie Area Views"
    def draw(self, context):
        layout = self.layout
        pie = layout.menu_pie()        
        #4 - LEFT
        col = pie.split().column()
        col.scale_x = 1.2
        col.scale_y = 1.2
        col.operator("object.view_menu", text="Shader Editor", icon='NODE_MATERIAL').ui_type_variable = "ShaderNodeTree"
        col.operator("object.view_menu", text="Compositor", icon='NODE_COMPOSITING').ui_type_variable = "CompositorNodeTree"
        #6 - RIGHT
        col = pie.split().column()
        col.scale_x = 1.2
        col.scale_y = 1.2
        col.operator("object.view_menu", text="UV Editor", icon='UV').ui_type_variable = "UV"
        if bpy.app.version >= (2, 90, 0):
            col.operator("object.view_menu", text="Image Editor", icon='IMAGE').ui_type_variable = "IMAGE_EDITOR"
        else:
            col.operator("object.view_menu", text="Image Editor", icon='IMAGE').ui_type_variable = "VIEW"
        #2 - BOTTOM
        if bpy.app.version >= (3, 0, 0):
            pie.operator("screen.area_close",text="Close Area",icon='X')
        else:
            pie.operator("area.joinarea",text="Join Viewports",icon='X')
        #8 - TOP
        pie.operator("object.view_menu", text="3D Viewport", icon='VIEW3D').ui_type_variable="VIEW_3D"
        #7 - TOP - LEFT 
        box = pie.split().box().column()
        col = box.column(align=True)
        col.operator("object.view_menu", text="User Pref", icon= 'PREFERENCES').ui_type_variable="PREFERENCES"
        col.operator("object.view_menu", text="Text Edit", icon= 'TEXT').ui_type_variable="TEXT_EDITOR"
        col.operator("object.view_menu", text="File Browser", icon= 'FILE_FOLDER').ui_type_variable="FILE_BROWSER"
        col.operator("object.view_menu", text="Outliner", icon= 'OUTLINER').ui_type_variable="OUTLINER"
        col.operator("object.view_menu", text="Properties", icon= 'PROPERTIES').ui_type_variable="PROPERTIES"
        #9 - TOP - RIGHT
        box = pie.split().box().column()
        col = box.column(align=True)
        col.operator("object.view_menu", text="Sequece Editor", icon= 'SEQ_SEQUENCER').ui_type_variable="SEQUENCE_EDITOR"
        col.operator("object.view_menu", text="Movie Editor", icon= 'SEQUENCE').ui_type_variable="CLIP_EDITOR"
        col.operator("object.view_menu", text="Graph Editor", icon= 'GRAPH').ui_type_variable="FCURVES"
        col.operator("object.view_menu", text="Dope Sheet", icon= 'ACTION').ui_type_variable="DOPESHEET"
        col.operator("object.view_menu", text="Timeline", icon= 'TIME').ui_type_variable="TIMELINE"
        #1 - BOTTOM - LEFT        		
        pie.operator("split.vertical", text="Split Vertical", icon= 'TRIA_RIGHT')
        #3 - BOTTOM - RIGHT 
        pie.operator("split.horizontal", text="Split Horizontal", icon= 'TRIA_UP')

####################################################### 
#Pie Views
####################################################### 
class PIE_MT_ViewNumpad(Menu):
    bl_idname = "PIE_MT_ViewNumpad"
    bl_label = "Pie Views Numpad"
 
    def draw(self, context):
        layout = self.layout
        pie = layout.menu_pie()
 
        #4 - LEFT
        pie.operator("view3d.view_axis", text="Left", icon='TRIA_LEFT').type='LEFT'
        #6 - RIGHT
        pie.operator("view3d.view_axis", text="Right", icon='TRIA_RIGHT').type='RIGHT'
        #2 - BOTTOM
        pie.operator("view3d.view_axis", text="Bottom", icon='TRIA_DOWN').type='BOTTOM'
        #8 - TOP
        pie.operator("view3d.view_axis", text="Top", icon='TRIA_UP').type='TOP'
        #7 - TOP - LEFT 
        pie.operator("view3d.view_axis", text="Front").type='FRONT'
        #9 - TOP - RIGHT
        pie.operator("view3d.view_axis", text="Back").type='BACK'
        #1 - BOTTOM - LEFT
        box = pie.split().column()
        box.prop(context.scene, "camera", text="")
        row = box.row(align=True)
        row.scale_x=1.0
        row.scale_y=1.2
        if context.space_data.lock_camera is False:
            row.operator("wm.context_toggle", text="Lock Cam to View",
                         icon='UNLOCKED').data_path = "space_data.lock_camera"
        elif context.space_data.lock_camera is True:
            row.operator("wm.context_toggle", text="Lock Cam to View",
                         icon='LOCKED').data_path = "space_data.lock_camera"
        row = box.row(align=True)
        row.scale_x=1.0
        row.scale_y=1.2
        row.operator("view3d.view_camera", text="View Cam", icon='HIDE_OFF')
        row.operator("view3d.camera_to_view", text="Cam to view", icon='NONE')
        row = box.row(align=True)
        row.scale_x=1.0
        row.scale_y=1.2
        row.operator("view3d.render_border", text="Render Border")
        row.operator("view3d.render_border_camera", text="", icon='CANCEL')
        #3 - BOTTOM - RIGHT
        box = pie.split().column()
        col = box.column(align=True)
        col.scale_x=1.2
        col.scale_y=1.2
        col.operator("view3d.view_selected", text="View Selected", icon='VIEWZOOM')
        col.operator("view3d.view_all", text="View All", icon='BORDERMOVE').center = True

########################################################################
#Pie Animation
########################################################################          
class PIE_MT_Animation(Menu):
    bl_idname = "PIE_MT_Animation"
    bl_label = "Pie Animation"
 
    def draw(self, context):
        layout = self.layout
        pie = layout.menu_pie()
        
        #4 - LEFT
        pie.operator("screen.animation_play", text="Reverse", icon='PLAY_REVERSE').reverse = True
        #6 - RIGHT
        if not context.screen.is_animation_playing:# Play / Pause
            pie.operator("screen.animation_play", text="Play", icon='PLAY')
        else:
            pie.operator("screen.animation_play", text="Stop", icon='PAUSE')
        #2 - BOTTOM
        box = pie.split().box().column()
        box.label(text="Current Frame :", icon='TIME')
        box.prop(context.scene, "frame_current", text="Frame")
        #8 - TOP
        pie.menu("VIEW3D_MT_object_animation", icon = "FILE_MOVIE")
        #7 - TOP - LEFT
        pie.operator("screen.frame_jump", text="Jump First Frame", icon='REW').end = False   
        #9 - TOP - RIGHT
        pie.operator("screen.frame_jump", text="Jump End Frame", icon='FF').end = True
        #1 - BOTTOM - LEFT 
        pie.operator("screen.keyframe_jump", text="Next Frame", icon='NEXT_KEYFRAME').next = True
        #3 - BOTTOM - RIGHT  
        pie.operator("screen.keyframe_jump", text="Prev Frame", icon='PREV_KEYFRAME').next = False
                
########################################################################
#Pie Quick Text Edit
########################################################################        
class PIE_MT_TextEdit(Menu):
    bl_idname = "PIE_MT_TextEdit"
    bl_label = "Pie Text Edit"
    def draw(self, context):
        layout = self.layout
        pie = layout.menu_pie()
        if bpy.context.area.type == 'TEXT_EDITOR':     
            #4 - LEFT
            pie.operator("text.save_as", text="Save As Script", icon='FILE_TICK')   
            #6 - RIGHT
            pie.operator("text.save", text="Save Script", icon='FILE_TICK')
            #2 - BOTTOM
            pie.operator("text.run_script", text="Run Script", icon='BACK')
            #8 - TOP
            pie.operator("text.start_find", text="Search", icon='VIEWZOOM')
            #7 - TOP - LEFT     
            pie.operator("text.comment_toggle")
            #9 - TOP - RIGHT
            pie.operator("text.reload", icon='FILE_REFRESH')
            #1 - BOTTOM - LEFT
            pie.operator("text.unindent", text="UnTab (unindent)", icon='BACK')
            #3 - BOTTOM - RIGHT
            pie.operator("text.indent", text="Tab (indent)", icon='FORWARD')

####################################################### 
# Pie Object Mode
####################################################### 
class PIE_MT_Mode(Menu):
    bl_idname = "PIE_MT_Mode"
    bl_label = "Pie Mode"

    @classmethod
    def poll(cls, context):
        return context.active_object is not None

    def draw(self, context):
        layout = self.layout
        toolsettings = context.tool_settings
        if context.object.type == 'MESH':
            pie = layout.menu_pie()
            #4 - LEFT
            pie.operator("class.object", text="Edit/Object", icon='OBJECT_DATAMODE')
            #6 - RIGHT
            pie.separator()
            #2 - BOTTOM
            if bpy.context.object.mode == "EDIT":
                box = pie.split().box().column()
                box.label(text="Show Normals :")
                box.prop(context.space_data.overlay, "normals_length")
                box.prop(context.space_data.overlay, "show_face_normals", text="Face", icon='FACESEL')
                box.prop(context.space_data.overlay, "show_split_normals", text="Edge", icon='EDGESEL')
                box.prop(context.space_data.overlay, "show_vertex_normals", text="Vertex", icon='VERTEXSEL')
                box.label(text="Show Overlays :")
                box.prop(context.space_data.overlay, "show_edge_seams", text="Seams (UV)")
                box.prop(context.space_data.overlay, "show_edge_sharp", text="Sharpness")
                box.prop(context.space_data.overlay, "show_freestyle_edge_marks", text="Freestyle")
                box.prop(context.space_data.overlay, "show_edge_crease", text="Crease (SubSurf)")
                box.prop(context.space_data.overlay, "show_edge_bevel_weight", text="Bevel")
            else:
                pie.separator()
            #8 - TOP
            pie.operator("class.vertex", text="Vertex", icon='VERTEXSEL')
            #7 - TOP - LEFT 
            pie.operator("class.face", text="Face", icon='FACESEL')
            #9 - TOP - RIGHT
            pie.operator("class.edge", text="Edge", icon='EDGESEL')
            #1 - BOTTOM - LEFT
            box = pie.split().column()
            row = box.row(align=True)
            row.operator("class.pieweightpaint", text="Weight Paint", icon='MOD_VERTEX_WEIGHT')
            row = box.row(align=True)
            row.operator("class.pievertexpaint", text="Vertex Paint", icon='GPBRUSH_WEIGHT')
            row = box.row(align=True)
            row.operator("class.pietexturepaint", text="Texture Paint", icon='TPAINT_HLT')
            row = box.row(align=True)
            row.operator("sculpt.sculptmode_toggle", text="Sculpt", icon='SCULPTMODE_HLT')
            row = box.row(align=True)
            row.operator("class.pieparticleedit", text="Particle Edit", icon='PARTICLEMODE')
            #3 - BOTTOM - RIGHT   
            box = pie.split().column()
            row = box.row(align=True)
            row.operator("edges.faces", text="Edges/Faces", icon='FACESEL')
            row = box.row(align=True)
            row.operator("verts.edgesfaces", text="Vertex/Edges/Faces", icon='OBJECT_DATAMODE') 
            row = box.row(align=True)
            row.operator("verts.faces", text="Vertex/Faces", icon='GROUP_VERTEX')  
            row = box.row(align=True)
            row.operator("verts.edges", text="Vertex/Edges", icon='GROUP_VERTEX')  

        elif context.object.type == 'EMPTY':
            pie = layout.menu_pie()
            pie.separator()
            pie.operator("quick.handle", text="Empty Settings", icon='IMAGE_REFERENCE')

        elif context.object.type == 'CURVE':
            pie = layout.menu_pie()
            pie.operator("class.object", text="Edit/Object", icon='OBJECT_DATAMODE')
            pie.operator("quick.handle", text="Curve Settings", icon='OUTLINER_OB_CURVE')
        
        elif context.object.type == 'ARMATURE':
            pie = layout.menu_pie()
            pie.operator("class.object", text="Edit/Object", icon='OBJECT_DATAMODE')
            pie.operator("object.posemode_toggle", text="Pose", icon='POSE_HLT')
            pie.operator("class.object", text="Object Mode", icon='OBJECT_DATAMODE')
            
        elif context.object.type == 'FONT':
            pie = layout.menu_pie()
            pie.operator("class.object", text="Edit/Object", icon='OBJECT_DATAMODE')
        
        elif context.object.type == 'SURFACE':
            pie = layout.menu_pie()
            pie.operator("class.object", text="Edit/Object", icon='OBJECT_DATAMODE')
        
        elif context.object.type == 'ARMATURE':
            pie = layout.menu_pie()
            pie.operator("class.object", text="Edit/Object", icon='OBJECT_DATAMODE')
        
        elif context.object.type == 'META':
            pie = layout.menu_pie()
            pie.operator("class.object", text="Edit/Object", icon='OBJECT_DATAMODE')
        
        elif context.object.type == 'LATTICE':
            pie = layout.menu_pie()
            pie.operator("class.object", text="Edit/Object", icon='OBJECT_DATAMODE')
            pie.operator("quick.handle", text="Lattice Settings", icon='CAMERA_DATA')

########################################################################
#Pie Shading
######################################################################## 
class PIE_MT_ShadingView(Menu):
    bl_idname = "PIE_MT_ShadingView"
    bl_label = "Pie Shading"
 
    def draw(self, context):
        obj = bpy.context.object
        layout = self.layout
        pie = layout.menu_pie()
        #4 - LEFT
        pie.operator("object.shadingvariable", text="Material", icon='MATERIAL').variable = 'MATERIAL'
        #6 - RIGHT
        pie.operator("object.shadingvariable", text="Wireframe", icon='SHADING_WIRE').variable = 'WIREFRAME'
        #2 - BOTTOM
        pie.operator("object.shadingvariable", text="Render", icon='SHADING_RENDERED').variable = 'RENDERED'
        #8 - TOP
        pie.operator("object.shadingvariable", text="Solid", icon='SHADING_SOLID').variable = 'SOLID'
        #7 - TOP - LEFT 
        pie.prop(bpy.context.preferences.system, "gl_texture_limit")
        # pie.separator()
        #9 - TOP - RIGHT
        pie.separator()
        #1 - BOTTOM - LEFT
        split = pie.split()
        col = split.column()
        col.scale_x=1.15
        col.scale_y=1.15
        col.operator("tomatoes.modal_auto_smooth")
        col.operator("shading.smoothflat", text="Smooth / Flat")
        if obj:
            if obj.type == 'MESH':
                row = col.row(align=True)
                row.prop(context.object.data, "use_auto_smooth")
                row.prop(context.object.data, "auto_smooth_angle", text="")
                row = col.row(align=True)
                row.operator("auto.smooth_options", text="30").type_smooth = '30'
                row.operator("auto.smooth_options", text="60").type_smooth = '60'
                row.operator("auto.smooth_options", text="90").type_smooth = '90'
                row.operator("auto.smooth_options", text="180").type_smooth = '180'
        #3 - BOTTOM - RIGHT
        pie.operator("quick.listmaterial", text="List Material", icon='BRUSH_TEXMASK') 
                                
####################################################### 
# Pie More Menu
#######################################################             
class PIE_MT_MoreMenu(Menu):
    bl_idname = "PIE_MT_MoreMenu"
    bl_label = "Pie More Menu"
    
    @classmethod
    def poll(cls, context):
        return context.active_object is not None
        
    def draw(self, context):
        layout = self.layout
        tomatoes = context.scene.tomatoes_props
        obj = context.active_object
        view = context.space_data
        pie = layout.menu_pie()            
        if bpy.context.area.type == 'VIEW_3D' and bpy.context.object.mode == 'EDIT': 
            #4 - LEFT
            pie.operator("recalculate.normals", icon="MESH_CUBE")
            #6 - RIGHT
            if obj.type == 'MESH':
                pie.operator("mesh.separate", icon_value=get_icon("maya_separate"))
            elif obj.type == 'CURVE':
                pie.operator("curve.separate", icon_value=get_icon("maya_separate"))
            #2 - BOTTOM
            split = pie.split()
            col = split.column()
            col.scale_x=1.3
            col.scale_y=1.3
            row = col.row(align=True)
            row.operator("mesh.aligntozero", text="X", icon='EMPTY_ARROWS').type_align = 'x'
            row.operator("mesh.aligntozero", text="Y", icon='EMPTY_ARROWS').type_align = 'y'
            row.operator("mesh.aligntozero", text="Z", icon='EMPTY_ARROWS').type_align = 'z'
            row = col.row(align=True)
            row.operator("object.smart_merge", text="Merge", icon_value=get_icon("maya_target_weld"))   
            #8 - TOP
            split = pie.split()
            col = split.column()
            col.scale_x=1.3
            col.scale_y=1.3
            row = col.row(align=True)
            col.operator("unwrap.modal", icon="SHADING_TEXTURE")
            row = col.row(align=True)
            row.operator("screen.redo_last", text="F6", icon='PREFERENCES')
            #7 - TOP - LEFT  
            pie.separator()
            #9 - TOP - RIGHT
            pie.prop(bpy.context.scene.tool_settings, "use_transform_correct_face_attributes", text="Preserve UV")
            #1 - BOTTOM - LEFT 
            pie.operator("mesh.symmetrize", icon='MOD_MIRROR')
            #3 - BOTTOM - RIGHT
            split = pie.split()
            col = split.column(align=True)
            col.scale_x=1.3
            col.scale_y=1.2
            row = col.row(align=True)
            row.operator("object.clean_ngons", icon="FACESEL")
            row.operator("object.meshcreatehole", text="Create Hole", icon='SURFACE_NCIRCLE')  
            row = col.row(align=True)
            row.operator("mesh.knife_tool", text="Knife tool", icon="VPAINT_HLT")
            row.operator("mesh.remove_doubles", text="Doubles", icon="X")   
                     
        elif bpy.context.area.type == 'VIEW_3D' and bpy.context.object.mode == 'OBJECT':      
            #4 - LEFT
            pie.operator("recalculate.normals", icon="MESH_CUBE")
            #6 - RIGHT
            pie.operator("object.duplicate_or_join", icon='FULLSCREEN_EXIT')   
            #2 - BOTTOM   
            pie.operator("bevel.set_operator")
            #8 - TOP
            pie.operator("screen.redo_last", text="F6", icon='PREFERENCES')
            #7 - TOP - LEFT 
            pie.separator()
            #9 - TOP - RIGHT
            pie.separator()
            #1 - BOTTOM - LEFT   
            split = pie.split()
            col = split.column(align=True)
            col.scale_x=1.3
            col.scale_y=1.2
            col.menu("VIEW3D_MT_make_links", text="Make Links", icon="LINKED")
            col.menu("VIEW3D_MT_make_single_user", text="Single Users", icon="UNLINKED")
            #3 - BOTTOM - RIGHT
            split = pie.split()
            col = split.column(align=True)
            col.scale_x=1.3
            col.scale_y=1.2
            col.operator("ob.set_parent_to_empty", icon = "OUTLINER_OB_EMPTY")
            col.operator("object.parent_set", text="Set Parent")
            col.operator("ob.clear_parent")
        elif bpy.context.area.type == 'VIEW_3D' and bpy.context.object.mode == 'POSE':      
            #4 - LEFT
            pie.separator()
            #6 - RIGHT
            pie.separator()
            #2 - BOTTOM   
            pie.separator()
            #8 - TOP
            pie.separator()
            #7 - TOP - LEFT 
            pie.separator()
            #9 - TOP - RIGHT
            pie.separator()
            #1 - BOTTOM - LEFT            
            pie.separator()
            #3 - BOTTOM - RIGHT
            split = pie.split()
            col = split.column(align=True)
            col.scale_x=1.3
            col.scale_y=1.2
            col.operator("object.parent_set", text="Set Parent")
            col.operator("ob.clear_parent")
            
########################################################################
#Pie Save/Open
########################################################################  
class PIE_MT_SaveOpen(Menu):
    bl_idname = "PIE_MT_SaveOpen"
    bl_label = "Pie Save/Open"
 
    def draw(self, context):
        layout = self.layout
        pie = layout.menu_pie()
        #4 - LEFT
        pie.operator("wm.read_homefile", text="New", icon='FILE_NEW')
        #6 - RIGHT
        pie.operator("wm.open_mainfile", text="Open file", icon='FILE_FOLDER')
        #2 - BOTTOM
        pie.operator("wm.save_as_mainfile", text="Save As...", icon='FILE')
        #8 - TOP
        pie.operator("wm.save_mainfile", text="Save", icon='FILE_TICK')  
        #7 - TOP - LEFT 
        pie.operator("save_file.increment", icon='COPYDOWN')  
        #9 - TOP - RIGHT
        pie.operator("quick.custom_save", icon="MODIFIER") 
        #1 - BOTTOM - LEFT
        col = pie.split().column()
        box = col.box().column()
        box.scale_x = 1.3
        box.scale_y = 1.3
        box.menu("TOPBAR_MT_file_import", icon='IMPORT', text="Import")       
        box.menu("TOPBAR_MT_file_export", icon='EXPORT', text="Export")   
        box.menu("TOPBAR_MT_file_external_data", icon='EXTERNAL_DRIVE', text="External Data")  
        box.menu("TOPBAR_MT_file_cleanup", icon='EXTERNAL_DRIVE', text="CleanUp")  
        #3 - BOTTOM - RIGHT  
        col = pie.split().column()
        box = col.box().column()
        box.scale_x = 1.3
        box.scale_y = 1.3
        box.menu("TOPBAR_MT_file_open_recent")
        box.menu("TOPBAR_MT_file_recover")

        # pie.separator()
        # pie.separator()
        # other = pie.column()
        # other.scale_x = 1.2
        # other.scale_y = 1.3
        # gap = other.column()
        # gap.separator()
        # gap.scale_y = 3.8

        # other_menu = other.box().column()
        # other_menu.menu("TOPBAR_MT_file_external_data", icon='EXTERNAL_DRIVE', text="External Data")  
        # other_menu.menu("TOPBAR_MT_file_cleanup", icon='EXTERNAL_DRIVE', text="CleanUp")  

        # pie.separator()
        # pie.separator()
        # pie.separator()
        # pie.separator()
        # other = pie.column()
        # other.scale_x = 1.05
        # other.scale_y = 1.3
        # gap = other.column()
        # gap.separator()
        # gap.scale_y = 20

        # other_menu = other.box().column()
        # other_menu.operator("wm.link", text="Link", icon='LINK_BLEND') 
        # other_menu.operator("wm.append", text="Append", icon='BLENDER')

        # pie.separator()
        # pie.separator()
        # pie.separator()
        # pie.separator()
        # pie.separator()
        # pie.separator()
        # other = pie.column()
        # other.scale_x = 1.05
        # other.scale_y = 1.3
        # gap = other.column()
        # gap.separator()
        # gap.scale_y = 24

        # other_menu = other.box().column()
        # other_menu.label(text= "Scene Manager", icon= 'SCENE_DATA')
        # other_menu.operator("op.scene_empty_coll")    
        # other_menu.operator("op.scene_light_coll")    
        # other_menu.operator("op.scene_lattice_coll")    
        
########################################################################
#Pie Pivot UV
########################################################################                 
class PIE_MT_PivotPoint_UV_Editor(Menu):
    bl_idname = "PIE_MT_PivotPoint_UV_Editor"
    bl_label = "Pie Pivot Point"
 
    def draw(self, context):
        layout = self.layout 
        pie = layout.menu_pie()
        # 4 - LEFT
        pie.operator("uv.pivot_point", text="Bounding Box", icon='PIVOT_BOUNDBOX').uv_pivot_point='bbox'
        # 6 - RIGHT
        pie.operator("uv.pivot_point", text="Median Point", icon='PIVOT_MEDIAN').uv_pivot_point='median'
        # # 2 - BOTTOM
        pie.operator("uv.pivot_point", text="Individual Origin ", icon='PIVOT_INDIVIDUAL').uv_pivot_point='individual'
        # # 8 - TOP
        pie.operator("uv.pivot_point", text="Cursor", icon='PIVOT_CURSOR').uv_pivot_point='cursor'
        # # 7 - TOP - LEFT
        pie.separator()
        # # 9 - TOP - RIGHT
        pie.separator()
        # 1 - BOTTOM - LEFT
        pie.separator()
        # 3 - BOTTOM - RIGHT
        pie.separator()

########################################################################
#Pie Propotional Editing
######################################################################## 
class PIE_MT_ProportionalObj(Menu):
    bl_idname = "PIE_MT_ProportionalObj"
    bl_label = "Pie Proportional Obj"
    
    def draw(self, context):
        layout = self.layout
        pie = layout.menu_pie()
        #4 - LEFT
        pie.operator("proportional_obj.sphere", text="Sphere", icon='SPHERECURVE')
        #6 - RIGHT
        pie.operator("proportional_obj.root", text="Root", icon='ROOTCURVE')
        #2 - BOTTOM
        pie.operator("proportional_obj.smooth", text="Smooth", icon='SMOOTHCURVE')
        #8 - TOP
        pie.prop(context.tool_settings, "use_proportional_edit_objects", text="Proportional On/Off")
        #7 - TOP - LEFT 
        pie.operator("proportional_obj.linear", text="Linear", icon='LINCURVE')
        #9 - TOP - RIGHT
        pie.operator("proportional_obj.sharp", text="Sharp", icon='SHARPCURVE')
        #1 - BOTTOM - LEFT
        pie.operator("proportional_obj.constant", text="Constant", icon='NOCURVE')
        #3 - BOTTOM - RIGHT
        pie.operator("proportional_obj.random", text="Random", icon='RNDCURVE')
        
class PIE_MT_ProportionalEdt(Menu):
    bl_idname = "PIE_MT_ProportionalEdt"
    bl_label = "Pie Proportional Edit"
 
    def draw(self, context):
        layout = self.layout
        pie = layout.menu_pie()                                                
        #4 - LEFT
        pie.operator("proportional_edt.connected", text="Connected", icon='PROP_CON')
        #6 - RIGHT
        pie.operator("proportional_edt.projected", text="Projected", icon='PROP_ON')
        #2 - BOTTOM
        pie.operator("proportional_edt.smooth", text="Smooth", icon='SMOOTHCURVE')
        #8 - TOP
        pie.operator("proportional_edt.active", text="Proportional On/Off", icon='PROP_ON')
        #7 - TOP - LEFT 
        pie.operator("proportional_edt.sphere", text="Sphere", icon='SPHERECURVE')
        #9 - TOP - RIGHT
        pie.operator("proportional_edt.root", text="Root", icon='ROOTCURVE')
        #1 - BOTTOM - LEFT
        pie.operator("proportional_edt.constant", text="Constant", icon='NOCURVE')
        #3 - BOTTOM - RIGHT
        box = pie.split().column()
        row = box.row(align=True)
        box.operator("proportional_edt.linear", text="Linear", icon='LINCURVE')
        box.operator("proportional_edt.sharp", text="Sharp", icon='SHARPCURVE')
        box.operator("proportional_edt.random", text="Random", icon='RNDCURVE')   
        
####################################################### 
#Pie Snapping
#######################################################   
class PIE_MT_Snaping(Menu):
    bl_idname = "PIE_MT_Snaping"
    bl_label = "Pie Snapping"

    def draw(self, context):
        layout = self.layout
        pie = layout.menu_pie()
        # 4 - LEFT
        pie.operator("object.snapping", text="Snap Vertex", icon='SNAP_VERTEX').snap_elements='vertex'
        # 6 - RIGHT
        pie.operator("object.snapping", text="Snap Face", icon='SNAP_FACE').snap_elements = 'face'
        # # 2 - BOTTOM
        pie.operator("object.snapping", text="Snap Edge", icon='SNAP_EDGE').snap_elements = 'edge'
        # # 8 - TOP
        pie.prop(context.tool_settings, "use_snap", text="Snap On/Off")
        # # 7 - TOP - LEFT
        pie.operator("object.snapping", text="Snap Volume", icon='SNAP_VOLUME').snap_elements = 'volume'
        # # 9 - TOP - RIGHT
        pie.operator("object.snapping", text="Snap Increment", icon='SNAP_INCREMENT').snap_elements = 'increment'
        # 1 - BOTTOM - LEFT
        split = pie.split()
        col = split.column(align=True)
        if bpy.context.scene.tool_settings.snap_elements == {'INCREMENT'}:
            col.separator()
        else:
            col.prop(context.tool_settings, "snap_target", expand=True)
            
        col.separator()
        
        if bpy.context.scene.tool_settings.snap_elements in ['VERTEX', 'EDGE', 'FACE', 'VOLUME']:
            col.prop(context.tool_settings, "use_snap_align_rotation", text="Align rotation", icon='SNAP_NORMAL')

        if bpy.context.scene.tool_settings.snap_elements == {'INCREMENT'}:
            col.prop(context.tool_settings, "use_snap_grid_absolute", text="Absolute Grid Snap", icon='SNAP_GRID')

        elif bpy.context.scene.tool_settings.snap_elements == {'VOLUME'}:
            col.prop(context.tool_settings, "use_snap_peel_object", text="Snap Peel Object", icon='SNAP_PEEL_OBJECT')

        elif bpy.context.scene.tool_settings.snap_elements == {'FACE'}:
            col.prop(context.tool_settings, "use_snap_project", text="Snap Object", icon='PIVOT_CURSOR')

        else:
            col.separator()

        # 3 - BOTTOM - RIGHT
        pie.operator("object.snapping", text="Snap Grid", icon='SNAP_EDGE').snap_elements = 'grid'

########################################################################
#Pie Tranform Orientation
########################################################################
class PIE_MT_Transform(Menu):
    bl_idname = "PIE_MT_Transform"
    bl_label = "Pie Transform"

    def draw(self, context):
        layout = self.layout
        pie = layout.menu_pie()

        scene = context.scene
        
        # 4 - LEFT
        col = pie.split().column(align=True)
        col.scale_x =1.2
        col.scale_y =1.2
        if bpy.context.area.type == 'VIEW_3D' and bpy.context.object.mode == 'OBJECT': 
            col.operator("object.origin_set", text="Orig To Geometry",icon='OBJECT_ORIGIN').type = 'ORIGIN_GEOMETRY'
            col.operator("object.origin_set", text="Geo To Origin",icon='SHADING_BBOX').type = 'GEOMETRY_ORIGIN'
            col.operator("object.origin_set", text="Orig To Cursor",icon='CURSOR').type = 'ORIGIN_CURSOR'
        
        elif bpy.context.area.type == 'VIEW_3D' and bpy.context.object.mode == 'EDIT': 
            col.operator("ob.origin_to_selected", icon='CURSOR') 

        # 6 - RIGHT
        pie.operator("test.edit_origin")

        # 2 - BOTTOM
        pie.separator()

        # 8 - TOP
        box = pie.split()
        # box = pie.box().split()

        b = box.box()
        column = b.column()
        self.draw_left_column(scene, column)

        b = box.box()
        column = b.column()
        self.draw_center_column(scene, column)

        b = box.box()
        column = b.column()
        self.draw_right_column(context, scene, column)


        # 7 - TOP - LEFT
        pie.separator()

        # 9 - TOP - RIGHT
        pie.separator()

        # 1 - BOTTOM - LEFT
        pie.separator()

        # 3 - BOTTOM - RIGHT
        pie.separator()


    def draw_left_column(self, scene, layout):
        layout.scale_x = 3

        column = layout.column(align=True)
        column.label(text="Pivot Point")

        column.prop(scene.tool_settings, "transform_pivot_point", expand=True)
        column.separator()
        column.operator("ob.pivotobottom")

    def draw_center_column(self, scene, layout):
        slot = scene.transform_orientation_slots[0]
        custom = slot.custom_orientation

        column = layout.column(align=True)
        column.label(text="Orientation")

        column.prop(slot, "type", expand=True)

        column = layout.column(align=True)
        row = column.row(align=True)
        row.scale_y = 1.2
        row.operator("transform.create_orientation", text="Custom", icon='ADD', emboss=True).use = True

        if custom:
            row = column.row(align=True)
            row.prop(custom, "name", text="")
            row.operator("transform.delete_orientation", text="X", emboss=True)


    def draw_right_column(self, context, scene, layout):
        column = layout.column(align=True)

        if context.mode == 'OBJECT':
            column.label(text="Affect Only")

            col = column.column(align=True)
            col.scale_y = 1.2
            col.prop(scene.tool_settings, "use_transform_data_origin", text="Origins")
            col.prop(scene.tool_settings, "use_transform_pivot_point_align", text="Locations")
            col.prop(scene.tool_settings, "use_transform_skip_children", text="Parents")

        elif context.mode == 'EDIT_MESH':
            column.label(text="Mirror Editing")

            active = context.active_object

            row = column.row(align=True)
            row.prop(active.data, "use_mirror_x")
            row.prop(active.data, "use_mirror_y")
            row.prop(active.data, "use_mirror_z")

            column.prop(active.data, "use_mirror_topology", toggle=True)
                        
########################################################################
#Pie Fast Modelling
########################################################################
class PIE_MT_Fast_Modelling(Menu):
    bl_idname = "PIE_MT_Fast_Modelling"
    bl_label = "Pie Fast Modelling"
 
    def draw(self, context):
        tomatoes = context.scene.tomatoes_props
        layout = self.layout
        pie = layout.menu_pie()
        #4 - LEFT
        pie.menu("VIEW3D_MT_menu_add_mod", icon="MODIFIER")      
        # col = pie.split().column()
        # col.scale_x=1.2
        # col.scale_y=1.2
        # col.label(text="Boolean")
        # col.operator("mesh.boolean", text="Cutter")
        #6 - RIGHT
        pie.menu("VIEW3D_MT_menu_control_mod", icon="CHECKMARK")   
        # col = pie.split().column()
        # col = col.column(align=True)
        # col.operator("mesh.re_cylinder")
        #2 - BOTTOM   
        col = pie.split().column()
        col.scale_x = 1.3
        col.scale_y = 1.3
        col.operator("glob.sub", icon="MOD_SUBSURF")
        row = col.row()
        row.operator("object.modifier_remove_all", icon='CANCEL') 
        row.operator("object.modifier_apply_all", icon_value=get_icon("check_icon"))
        #8 - TOP
        pie.separator()
        #7 - TOP - LEFT 
        pie.separator()
        #9 - TOP - RIGHT
        pie.separator()
        #1 - BOTTOM - LEFT
        pie.separator()
        # col = pie.split().column()
        # row = col.row(align=True)
        # row.operator("mesh.editable_cylinder", icon='MESH_CYLINDER')     
        #3 - BOTTOM - RIGHT
        pie.separator()
                                    
####################################################### 
# Pie Selection UV
#######################################################   
class PIE_MT_UVSelection(Menu):
    bl_idname = "PIE_MT_UVSelection"
    bl_label = "Pie UV Selections"

    def draw(self, context):
        tomatoes = context.scene.tomatoes_props
        layout = self.layout
        if bpy.context.area.type == 'IMAGE_EDITOR':
            pie = layout.menu_pie()
            # 4 - LEFT
            pie.operator("uv.select_all", text="De/Select All", icon='SELECT_EXTEND')
            # 6 - RIGHT
            pie.separator()
            # 2 - BOTTOM
            pie.separator()
            # 8 - TOP
            pie.separator()
            # 7 - TOP - LEFT
            split = pie.split()
            col = split.column(align=True)
            col.scale_x=1.3
            col.scale_y=1.2
            col.operator("uv.export_layout", text="Export UV")
            row = col.row(align=True)
            row.operator("image.open", text="Open Image", icon='FILEBROWSER')
            row.operator("image.new", text="New Image", icon='ADD')
            row = col.row(align=True)
            row.operator("image.save", text="Save IMG")
            row.operator("image.save_as", text="Save As IMG")
            # 9 - TOP - RIGHT
            pie.operator("uv.pinunpin", text="Pin/Unpin", icon='UNPINNED')
            # 1 - BOTTOM - LEFT
            pie.operator("uv.select_linked", text="Select Linked", icon='STICKY_UVS_VERT')
            # 3 - BOTTOM - RIGHT
            pie.operator("uv.select_all", text="Select Invert").action='INVERT'


####################################################### 
# Pie Sculpt
#######################################################   
# Sculpt Draw
class PIE_OT_SculptSculptDraw(bpy.types.Operator):
    bl_idname = "sculpt.sculptraw"
    bl_label = "Sculpt SculptDraw"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        context.tool_settings.sculpt.brush = bpy.data.brushes['SculptDraw']
        return {'FINISHED'}


# Pie Sculp Pie Menus - W
class PIE_MT_SculptPie(Menu):
    bl_idname = "PIE_MT_SculptPie"
    bl_label = "Pie Sculpt"

    def draw(self, context):
        global brush_icons
        layout = self.layout
        pie = layout.menu_pie()
        pie.scale_y = 1.2
        # 4 - LEFT
        pie.menu(PIE_MT_SculptDraw.bl_idname, text="Draw Brushes", icon_value=brush_icons["clay"])
        ## 6 - RIGHT
        pie.menu(PIE_MT_SculptSmooth.bl_idname, text="Smooth Brushes", icon_value=brush_icons["smooth"])    
        # 2 - BOTTOM
        pie.menu(PIE_MT_SculptGrab.bl_idname, text="Grab Brushes", icon_value=brush_icons["grab"])
        ## 8 - TOP
        row = pie.row(align = True)
        row.scale_x = 1.3
        row.scale_y = 1.3
        row.prop(context.object, "use_mesh_mirror_x", text="X", toggle=True)
        row.prop(context.object, "use_mesh_mirror_y", text="Y", toggle=True)
        row.prop(context.object, "use_mesh_mirror_z", text="Z", toggle=True)
        ## 7 - TOP - LEFT
        pie.operator("wm.tool_set_by_id",text='Crease', icon_value=brush_icons["crease"]).name = "builtin_brush.Crease"
        ## 9 - TOP - RIGHT
        pie.operator("wm.tool_set_by_id",text='Clay Strips', icon_value=brush_icons["clay_strips"]).name = "builtin_brush.Clay Strips"
        ## 1 - BOTTOM - LEFT
        pie.menu(PIE_MT_SculptMaskTrim.bl_idname,
                text="    Mask & Trim", icon_value=brush_icons["mask"])
        ## 3 - BOTTOM - RIGHT
        pie.menu(PIE_MT_SculptExtras.bl_idname,
                text="    More Tools", icon_value=brush_icons["cloth"])

# Pie Sculpt Draw - Draw tool brushes
class PIE_MT_SculptDraw(Menu):
    bl_idname = "PIE_MT_sculptDraw"
    bl_label = "Pie Sculpt Draw"

    def draw(self, context):
        global brush_icons
        layout = self.layout    
        layout.scale_y = 1.5    
        layout.operator("wm.tool_set_by_id",text='Draw', icon_value=brush_icons["draw"]).name = "builtin_brush.Draw"
        layout.operator("wm.tool_set_by_id",text='Clay', icon_value=brush_icons["clay"]).name = "builtin_brush.Clay"
        layout.operator("wm.tool_set_by_id",text='Draw Sharp', icon_value=brush_icons["draw_sharp"]).name = "builtin_brush.Draw Sharp"
        layout.operator("wm.tool_set_by_id",text='Inflate', icon_value=brush_icons["inflate"]).name = "builtin_brush.Inflate"
        layout.operator("wm.tool_set_by_id",text='Blob', icon_value=brush_icons["blob"]).name = "builtin_brush.Blob"
        layout.operator("wm.tool_set_by_id",text='Layer', icon_value=brush_icons["layer"]).name = "builtin_brush.Layer"
        layout.operator("wm.tool_set_by_id",text='Clay Thumb', icon_value=brush_icons["clay_thumb"]).name = "builtin_brush.Clay Thumb"

# Pie Sculpt Grab - Grab Tool Brushes
class PIE_MT_SculptGrab(Menu):
    bl_idname = "PIE_MT_sculptGrab"
    bl_label = "Pie Sculpt Grab"

    def draw(self, context):
        global brush_icons
        layout = self.layout
        layout.scale_y = 1.5

        layout.operator("wm.tool_set_by_id",text='Grab', icon_value=brush_icons["grab"]).name = "builtin_brush.Grab"
        layout.operator("wm.tool_set_by_id",text='Snake Hook', icon_value=brush_icons["snake_hook"]).name = "builtin_brush.Snake Hook"
        layout.operator("wm.tool_set_by_id",text='Pose', icon_value=brush_icons["pose"]).name = "builtin_brush.Pose"
        layout.operator("wm.tool_set_by_id",text='Nudge', icon_value=brush_icons["nudge"]).name = "builtin_brush.Nudge"
        layout.operator("wm.tool_set_by_id",text='Boundary', icon_value=brush_icons["boundary"]).name = "builtin_brush.Boundary"
        layout.operator("wm.tool_set_by_id",text='Multi-plane Scrape', icon_value=brush_icons["multiplane_scrape"]).name = "builtin_brush.Multi-plane Scrape"
        layout.operator("wm.tool_set_by_id",text='Thumb', icon_value=brush_icons["thumb"]).name = "builtin_brush.Thumb"
        layout.operator("wm.tool_set_by_id",text='Rotate', icon_value=brush_icons["rotate"]).name = "builtin_brush.Rotate"
        layout.operator("wm.tool_set_by_id",text='Thumb', icon_value=brush_icons["thumb"]).name = "builtin_brush.Thumb"
        layout.operator("wm.tool_set_by_id",text='Pinch', icon_value=brush_icons["pinch"]).name = "builtin_brush.Pinch"
        
# Pie Sculpt Smooth (Red) - Smooth tool Brushes
class PIE_MT_SculptSmooth(Menu):
    bl_idname = "PIE_MT_sculptSmooth"
    bl_label = "Pie Sculpt Smooth"

    def draw(self, context):
        global brush_icons
        layout = self.layout
        layout.scale_y = 1.5
        layout.operator("wm.tool_set_by_id",text='Smooth',icon_value=brush_icons["smooth"]).name = "builtin_brush.Smooth"
        layout.operator("wm.tool_set_by_id",text='Scrape', icon_value=brush_icons["scrape"]).name = "builtin_brush.Scrape"
        layout.operator("wm.tool_set_by_id",text='Fill', icon_value=brush_icons["fill"]).name = "builtin_brush.Fill"
        layout.operator("wm.tool_set_by_id",text='Flatten', icon_value=brush_icons["flatten"]).name = "builtin_brush.Flatten"

# Pie Sculpt Mask - Mask & Trim tool Brushes
class PIE_MT_SculptMaskTrim(Menu):
    bl_idname = "PIE_MT_sculptMaskTrim"
    bl_label = "Pie Sculpt Mask"

    def draw(self, context):    
        global brush_icons
        layout = self.layout
        layout.scale_y = 1.5
        # Mask Draw tool
        layout.operator("wm.tool_set_by_id",text='Mask', icon_value=brush_icons["mask"]).name = "builtin_brush.Mask"
        layout.operator("wm.tool_set_by_id",text='Draw Face sets', icon_value=brush_icons["draw_face_sets"]).name = "builtin_brush.Draw Face Sets"
        # # Mask Tools
        pie = layout.menu_pie()
        col = pie.column()
        col.menu(PIE_MT_SculptMask.bl_idname,
                text="    Mask", icon_value=brush_icons["border_mask"])
        # # Trim Tools
        col.menu(PIE_MT_SculptTrim.bl_idname,
                text="    Trim", icon_value=brush_icons["box_trim"])
# Sub Menu Sculpt Mask  
class PIE_MT_SculptMask(Menu):
    bl_idname = "PIE_MT_sculptMask"
    bl_label = "Pie Sculpt Mask"

    def draw(self, context):
        global brush_icons
        layout = self.layout
        layout.scale_y = 1.5
        # Mask Tools
        layout.operator("wm.tool_set_by_id",text='Box mask', icon_value=brush_icons["border_mask"]).name = "builtin.box_mask"
        layout.operator("wm.tool_set_by_id",text='Lasso mask', icon_value=brush_icons["lasso_mask"]).name = "builtin.lasso_mask"
        layout.operator("wm.tool_set_by_id",text='Line mask', icon_value=brush_icons["line_mask"]).name = "builtin.line_mask"

# Sub Menu Sculpt Trim
class PIE_MT_SculptTrim(Menu):
    bl_idname = "PIE_MT_sculptTrim"
    bl_label = "Pie Sculpt Trim"

    def draw(self, context):
        global brush_icons
        layout = self.layout
        layout.scale_y = 1.5
        # Trim Tools
        layout.operator("wm.tool_set_by_id",text='Box Trim', icon_value=brush_icons["box_trim"]).name = "builtin.box_trim"
        layout.operator("wm.tool_set_by_id",text='Lasso Trim', icon_value=brush_icons["lasso_trim"]).name = "builtin.lasso_trim"
        layout.operator("wm.tool_set_by_id",text='Line project', icon_value=brush_icons["line_project"]).name = "builtin.line_project"
# Pie Sculpt Extras - More Tool Brushes
class PIE_MT_SculptExtras(Menu):
    bl_idname = "PIE_MT_sculptExtras"
    bl_label = "Pie Sculpt Extras"

    def draw(self, context):
        global brush_icons  
        layout = self.layout
        layout.scale_y = 1.5

        layout.operator("wm.tool_set_by_id",text='Cloth', icon_value=brush_icons["cloth"]).name = "builtin_brush.Cloth"
        layout.operator("wm.tool_set_by_id",text='Slide Relax', icon_value=brush_icons["topology"]).name = "builtin_brush.Slide Relax"
        layout.operator("wm.tool_set_by_id",text='Simplify' , icon_value=brush_icons["simplify"]).name = "builtin_brush.Simplify"
        layout.operator("wm.tool_set_by_id",text='Multires Displacement Eraser', icon_value=brush_icons["displacement_eraser"]).name = "builtin_brush.Multires Displacement Eraser"
        layout.operator("wm.tool_set_by_id",text='Mesh Filter', icon_value=brush_icons["mesh_filter"]).name = "builtin.mesh_filter"
        layout.operator("wm.tool_set_by_id",text='Cloth Filter', icon_value=brush_icons["cloth_filter"]).name = "builtin.cloth_filter"
                                    
####################################################### 
# Pie UV Align
#######################################################   
class PIE_MT_UV_ALIGN(Menu):
    bl_idname = "PIE_MT_UV_ALIGN"
    bl_label = "Pie UV's Weld/Align"
 
    def draw(self, context):
        layout = self.layout
        pie = layout.menu_pie()
        #4 - LEFT
        pie.operator("uv.align", text="Align X").axis = 'ALIGN_X'
        #6 - RIGHT
        pie.operator("uv.align", text="Align Y").axis = 'ALIGN_Y'
        #2 - BOTTOM
        pie.operator("uv.align", text="Straighten").axis = 'ALIGN_S'
        #8 - TOP
        pie.operator("uv.align", text="Align Auto").axis = 'ALIGN_AUTO'
        #7 - TOP - LEFT 
        pie.operator("uv.weld", text="Weld", icon='AUTOMERGE_ON')
        #9 - TOP - RIGHT
        pie.operator("uv.remove_doubles", text="Remouve doubles")
        #1 - BOTTOM - LEFT
        pie.operator("uv.align", text="Straighten X").axis = 'ALIGN_T'
        #3 - BOTTOM - RIGHT
        pie.operator("uv.align", text="Straighten Y").axis = 'ALIGN_U' 
        
########################################################################################################################
# PIE UV's -
########################################################################################################################
# Pie UV's Select Mode
class PIE_MT_UV_SELECTION(Menu):
    bl_label = "UV Select Mode"
    bl_idname = "PIE_MT_UV_SELECTION"

    def draw(self, context):
        layout = self.layout
        layout.operator_context = 'INVOKE_REGION_WIN'
        toolsettings = context.tool_settings
        uvedit = context.space_data.uv_editor
        pie = layout.menu_pie()

        #4 - LEFT
        pie.operator("class.object", text="Edit/Object", icon='OBJECT_DATAMODE')
        #6 - RIGHT
        pie.prop(context.tool_settings, "use_uv_select_sync", text="UV Sync", icon='UV_SYNC_SELECT')
        #2 - BOTTOM
        pie.prop(uvedit, "show_stretch", text="Show Stretch")
        #8 - TOP
        pie.operator("op.uv_mode", text="Face", icon='FACESEL').mode = "FACE"
        #7 - TOP - LEFT
        pie.operator("op.uv_mode", text="Vertex", icon='VERTEXSEL').mode = "VERTEX"
        #9 - TOP - RIGHT
        pie.operator("op.uv_mode", text="Edge", icon='EDGESEL').mode = "EDGE"
        #1 - BOTTOM - LEFT
        col = pie.split().column()
        col.scale_x = 1.2
        col.scale_y = 1.2
        col.operator("uv.select_flipped", text="Select Flipped", icon='UV_SYNC_SELECT')
        col.operator("uv.select_overlap", text="Select Overlap", icon='MOD_UVPROJECT')
        #3 - BOTTOM - RIGHT
        pie.separator()

#################################
#Pie Manioulator
#################################    
class PIE_MT_Manipulator(Menu):
    bl_idname = "PIE_MT_Manipulator"
    bl_label = "Pie Manipulator"
    def draw(self, context):
        layout = self.layout
        scene = context.scene
        pie = layout.menu_pie()  
        #4 - LEFT
        pie.operator("wm.tool_set_by_id",text="Move", icon_value=brush_icons["transform.translate"]).name = "builtin.move"
        #6 - RIGHT
        pie.operator("wm.tool_set_by_id",text="Rotate", icon_value=brush_icons["transform.rotate"]).name = "builtin.rotate"
        #2 - BOTTOM
        pie.operator("wm.tool_set_by_id",text="Scale", icon_value=brush_icons["transform.resize"]).name = "builtin.scale"
        #8 - TOP
        pie.operator("w.manupulators", text="Off/On Gizmo", icon_value=brush_icons["transform.transform"]).name = "builtin.transform"
        #7 - TOP - LEFT
        pie.operator("manip.locrotate", text="Translate & Rotate") 	
        #9 - TOP - RIGHT
        pie.separator()
        #1 - BOTTOM - LEFT
        pie.separator()
        #3 - BOTTOM - RIGHT
        pie.separator()        

###################################################
#   Register Default Icon Sculpt
###################################################
brush_icons = {}

def create_icons():
    global brush_icons
    if bpy.app.version >= (2, 93, 0):
        icons_directory = bpy.utils.system_resource('DATAFILES', path="icons")
    else:
        icons_directory = bpy.utils.system_resource('DATAFILES', "icons")
    brushes = ["crease", "blob", "draw", "draw_sharp", "clay", "clay_strips","clay_thumb", "inflate","layer",
        "grab", "nudge", "thumb", "snake_hook", "rotate", "pose", "multiplane_scrape", "boundary", "topology", "pinch",
        "flatten", "scrape", "fill", "smooth",
        "simplify", "cloth", "displacement_eraser", "mask", "draw_face_sets",
        "border_mask","lasso_mask","line_mask","box_trim","lasso_trim","line_project","mesh_filter","cloth_filter"
        ]
    transform = ["transform.translate","transform.rotate","transform.resize","transform.transform"]
    for brush in brushes:
        try:
            filename = os.path.join(icons_directory, f"brush.sculpt.{brush}.dat")
            icon_value = bpy.app.icons.new_triangles_from_file(filename)
            brush_icons[brush] = icon_value
        except ValueError:
            filename = os.path.join(icons_directory, f"ops.sculpt.{brush}.dat")
            icon_value = bpy.app.icons.new_triangles_from_file(filename)
            brush_icons[brush] = icon_value
    for transform_ops in transform:
        filename = os.path.join(icons_directory, f"ops.{transform_ops}.dat")
        icon_value = bpy.app.icons.new_triangles_from_file(filename)
        brush_icons[transform_ops] = icon_value

def release_icons():
    global brush_icons
    for value in brush_icons.values():
        bpy.app.icons.release(value)