import bpy
import bmesh
from bpy.types import Operator


from mathutils import * 
import collections



def bone_select():
    C = bpy.context

    if C.mode in {'EDIT_ARMATURE'}:
        viewlayer = C.view_layer
        collection = C.scene.statistics(viewlayer).split(" | ")

        verts_sel = collection[1]
        verts_str = verts_sel[6:].replace(',', '')
        verts_get = verts_str.split("/")[0]

        bone_sel = collection[2]
        bone_str = bone_sel[6:].replace(',', '')
        bone_get = bone_str.split("/")[0]

        verts, bones = int(verts_get), int(bone_get)

    elif C.mode in {'POSE'}:
        viewlayer = C.view_layer
        collection = C.scene.statistics(viewlayer).split(" | ")

        bone_sel = collection[1]
        bone_str = bone_sel[6:].replace(',', '')
        bone_get = bone_str.split("/")[0]
        
        verts, bones = 0, int(bone_get)

    else:
        verts, bones = 0, 0
    

    return verts, bones


def activate():
    context = bpy.context
    if len(context.selected_objects) > 0: #context.active_object != None and  context.object.select_get()
        if context.object.type == 'MESH':
            me = context.object.data
            if context.mode == 'EDIT_MESH':
                bm = bmesh.from_edit_mesh(me)
                items = [v for v in bm.verts if v.select]
            else:
                items = [v for v in me.vertices if v.select]


        elif context.mode in {'EDIT_ARMATURE'}:
                verts, bone = bone_select()
                if verts > 0:
                    items = [ verts ]
                elif bone > 0:
                    items = [ bone ]

        elif context.mode in {'POSE'}:
            bone = bone_select()[1]
            if bone > 0:
                items = [ bone ]
       

        elif context.object.type == 'CURVE':
            items = []
            for obj in context.selected_objects:
                for s in obj.data.splines:
                    for p in s.bezier_points:
                        if p.select_control_point:
                            items.append(p)
                        else:
                            if p.select_left_handle:
                                items.append(p)
                            if p.select_right_handle:
                                items.append(p)
        else:
            items = []

        v = len(items)
        
        #print(v)
        return v != 0


# Delete Duplicate Vector
def del_duplicate(list):
    newList = []
    for i in list:
        if i not in newList:
            newList.append(i)
    return newList


# Change Pivot From Cursor
def cursorPivot(loc):
    context = bpy.context

    cursor_pos = context.scene.cursor.location.copy()
    context.scene.cursor.location = loc

    if context.mode == 'OBJECT':
        bpy.ops.object.origin_set(type='ORIGIN_CURSOR', center='MEDIAN')
        context.scene.cursor.location = cursor_pos


    else:
        bpy.ops.object.mode_set(mode='OBJECT')
        bpy.ops.object.origin_set(type='ORIGIN_CURSOR', center='MEDIAN')
        context.scene.cursor.location = cursor_pos
        bpy.ops.object.mode_set(mode='EDIT')


# FLIP NORMALS 
def flip_normals(operator=False):
    C = bpy.context
    for ob in C.selected_objects:
        if ob.type == 'MESH':
            if (ob.scale[0] < 0 or ob.scale[1] < 0 or ob.scale[2] < 0) or operator:
                
                me = ob.data
                if C.mode == 'EDIT_MESH':
                    bm = bmesh.from_edit_mesh(me)

                    for f in bm.faces:
                        f.normal_flip()

                    bmesh.update_edit_mesh(me) 

                else:
                    bm = bmesh.new()
                    bm.from_mesh(me)

                    #bm.normal_update()
                    for f in bm.faces:
                        f.normal_flip()

                    bm.to_mesh(me)
                    bm.free()
            else:
                pass

class PT_OT_flip_normals(Operator):
    bl_idname = 'pt.flip_normals'
    bl_label = 'Flip Normals'
    bl_description = 'Flip Normals'
    bl_options = {'REGISTER', 'UNDO', 'INTERNAL'}

    #flip_normals: BoolProperty(default=False, name='Flip Normals')

    @classmethod
    def poll(self, context):
        return context.active_object

    def execute(self, context):
        props = context.preferences.addons[__package__.split(".")[0]].preferences
        if props.flip_normals:
            if activate():
                flip_normals(operator=True)
                return {'FINISHED'}
            else:
                self.report({'WARNING'}, 'None Selected!')
                return {'CANCELLED'}  
        else:
            return {'CANCELLED'}       




# --- GET COORDINATES 
def co_elements(obj, edit): # TODO FIXME это не используется
    co = []

    mw = obj.matrix_world
    
    if obj.type == 'MESH':
        co = [mw @ v.co for v in obj.data.vertices] 


    elif obj.type == 'ARMATURE':
        coOld = []
        if edit == True:
            for bone in obj.data.bones:
                coOld.append(mw @ bone.head_local)
                coOld.append(mw @ bone.tail_local)
        else:
            for bone in obj.pose.bones:
                coOld.append(mw @ bone.head)
                coOld.append(mw @ bone.tail)


        co = del_duplicate(coOld)


    elif obj.type == 'CURVE':
        co = []
        for s in obj.data.splines:
            for p in s.bezier_points:
                co.append(mw @ p.co)


    elif obj.type == 'SURFACE':
        co = []
        for s in obj.data.splines:
            for p in s.points:
                co.append(mw @ p.co)


    elif obj.type == 'META':
        co = []
        for e in obj.data.elements:
            co.append(mw @ e.co)


    elif obj.type == 'LATTICE':
        co = []
        for p in obj.data.points:
            co.append(mw @ p.co)


    else:
        return False


    return co




import mathutils
def pivot_to_select(context, loc=None):
    cursor = context.scene.cursor
    cursor_pos = cursor.location.copy()

    rotation_mode = cursor.rotation_mode
    cursor.rotation_mode = 'XYZ'
    cursor_rot = cursor.rotation_euler.copy()

    cursor.rotation_quaternion =  context.region_data.view_rotation


    user_orient = context.window.scene.transform_orientation_slots[0].type
    
    if loc is None:
        bpy.ops.view3d.snap_cursor_to_selected()
    else:
        cursor.location = loc

    # Создание кастомной матрицы ориентации
    name = "PivotTransform"
    #context.window.scene.transform_orientation_slots[0].type = 'NORMAL'
    bpy.ops.transform.create_orientation(name=name, use=True, overwrite=True)
    user_matrix = context.scene.transform_orientation_slots[0].custom_orientation.matrix.to_4x4()
    

    # Изменение матрицы курсора
    center = mathutils.Matrix.Translation(context.scene.cursor.location)
    cursor.matrix = center @ user_matrix
    


    # Перемещение пивота только у активного объекта
    bpy.ops.object.mode_set(mode = 'OBJECT')

    activeObj = context.active_object
    selectObjs = context.selected_objects
    bpy.ops.object.select_all(action='DESELECT')
    
    activeObj.select_set(state=True)
    context.view_layer.objects.active = activeObj

    
    bpy.ops.pivot.apply() # Применение пивота

    for obj in selectObjs:
        obj.select_set(state=True)
    context.view_layer.objects.active = activeObj

    bpy.ops.object.mode_set(mode='EDIT')


    # Итоговое позиционирование курсора
    cursor.location = cursor_pos
    cursor.rotation_euler = cursor_rot
    cursor.rotation_mode = rotation_mode

    # Сброс к начальным настройкам пользовательских настроек
    context.window.scene.transform_orientation_slots[0].type = name
    bpy.ops.transform.delete_orientation('INVOKE_DEFAULT')
    context.window.scene.transform_orientation_slots[0].type = user_orient



# --- Get Coord
def co_elements(obj, edit):
    props = bpy.context.preferences.addons[__package__.split(".")[0]].preferences

    co = []

    mw = obj.matrix_world
    
    if obj.type == 'MESH':
        co = [mw @ v.co for v in obj.data.vertices] 


    elif obj.type == 'ARMATURE':
     
        coOld = []
        if edit == True:
            for bone in obj.data.bones:
                coOld.append(mw @ bone.head_local)
                coOld.append(mw @ bone.tail_local)

        else:
            for bone in obj.pose.bones:
                coOld.append(mw @ bone.head)
                coOld.append(mw @ bone.tail)
    

        co = del_duplicate(coOld)


    elif obj.type == 'CURVE':
        co = []
        for s in obj.data.splines:
            for p in s.bezier_points:
                co.append(mw @ p.co)

    elif obj.type == 'SURFACE':
        co = []
        for s in obj.data.splines:
            for p in s.points:
                co.append(mw @ p.co)

    elif obj.type == 'META':
        co = []
        for e in obj.data.elements:
            co.append(mw @ e.co)

    elif obj.type == 'LATTICE':
        co = []
        for p in obj.data.points:
            co.append(mw @ p.co)
    else:
        return False

    return co

#####################################################################
#   Quick lattice
#####################################################################
allowed_object_types = set(['MESH', 'CURVE', 'SURFACE',
                            'FONT', 'GPENCIL', 'LATTICE'])

# https://blender.stackexchange.com/questions/32283/what-are-all-values-in-bound-box
def bounds(local_coords, orientation=None):
    if orientation:
        def apply_orientation(p): return orientation @ Vector(p[:])
        coords = [apply_orientation(p).to_tuple() for p in local_coords]
    else:
        coords = [p[:] for p in local_coords]

    rotated = zip(*coords[::-1])

    push_axis = []
    for (axis, _list) in zip('xyz', rotated):
        def info(): return None
        info.max = max(_list)
        info.min = min(_list)
        info.distance = info.max - info.min
        push_axis.append(info)

    originals = dict(zip(['x', 'y', 'z'], push_axis))

    o_details = collections.namedtuple('object_details', 'x y z')
    return o_details(**originals)