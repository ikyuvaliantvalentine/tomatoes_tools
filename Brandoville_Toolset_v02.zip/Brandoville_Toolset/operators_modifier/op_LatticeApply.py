import bpy

from ..utils.utils import *

class Apply_Lattice_Op(bpy.types.Operator):
    bl_idname = "op.lattice_apply"
    bl_label = "Apply Lattice"
    bl_description = "Applies the lattice to all objects whose FFD modifiers are targeting it"
    bl_space_type = "VIEW_3D"
    bl_region_type = "TOOLS"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        lattice = context.active_object

        if lattice.mode == "EDIT":
            bpy.ops.object.editmode_toggle()

        vertex_groups = []
                    
        for obj in context.view_layer.objects:
            if obj.type in allowed_object_types:
                vertex_groups.clear()                
      
                for modifier in obj.modifiers:   
                    if modifier.type == 'LATTICE' and "SimpleLattice" in modifier.name:
                        if modifier.object == lattice:
                            # checking for lattice on top of the modifiers stack (for any reason)
                            # https://blender.stackexchange.com/questions/233357/how-to-get-modifier-position
                            if obj.modifiers[0].type == "LATTICE" and obj.modifiers[0].object == lattice:
                                self.report({'INFO'}, 'Modifier applied')
                            else:
                                self.report({'INFO'}, 'Applied modifier was not first, result may not be as expected')
                                
                            vertex_group = self.kill_lattice_modifer(
                                context, modifier, lattice)
                            if vertex_group:
                                vertex_groups.append(vertex_group)

                                # Clear any selection
                                for f in obj.data.polygons:
                                    f.select = False
                                for e in obj.data.edges:
                                    e.select = False
                                for v in obj.data.vertices:
                                    v.select = False
                                # Get verts in vertex group
                                verts = [v for v in obj.data.vertices if obj.vertex_groups[vertex_group].index in [i.group for i in v.groups]]
                                # Select verts in vertex group
                                for v in verts:
                                    v.select = True
                
                                # if apply with vertex groups 
                                # then select all objects and switch to EDIT mode
                                obj.select_set(True)
                                bpy.ops.object.editmode_toggle()
                                bpy.ops.mesh.select_mode(type="VERT")

                            if not vertex_group:
                                # if apply without vertex groups 
                                # then select all objects and stay in OBJECT mode
                                obj.select_set(True)
                
                self.kill_vertex_groups(obj, vertex_groups)
                
#        try:
#            self.kill_custom_orientation()
#        except:
#            pass

        # removing Lattice object with its data
        # https://blender.stackexchange.com/questions/233204/how-can-i-purge-recently-deleted-objects
        lattice_obs = [o for o in context.selected_objects if o.type == 'LATTICE']
        purge_data = set(o.data for o in lattice_obs)
        bpy.data.batch_remove(lattice_obs)
        bpy.data.batch_remove([o for o in purge_data if not o.users])
        #self.report({'INFO'}, 'Applied modifier was not first, result may not be as expected')
                
        context.view_layer.update()
        return {'FINISHED'}

    @classmethod
    def poll(self, context):
        return (len(context.selected_objects) == 1 and
                context.active_object and
                context.active_object.type == 'LATTICE' and
                context.active_object.select_get())

    def set_active(self, context, object):
        context.view_layer.objects.active = object

    def kill_lattice_modifer(self, context, modifier, target):
        vertex_group = ""

        if modifier.type != "LATTICE" or modifier.object != target:
            return vertex_group

        if context.active_object != modifier.id_data:
            self.set_active(context, modifier.id_data)

        if modifier.vertex_group != None:
            vertex_group = modifier.vertex_group

        if modifier.show_viewport:

            if modifier.id_data.mode != 'OBJECT':
                bpy.ops.object.editmode_toggle()

            bpy.ops.object.modifier_apply(modifier=modifier.name)

        else:
            bpy.ops.object.modifier_remove(
                modifier=modifier.name)

        return vertex_group

    def kill_vertex_groups(self, obj, vertex_groups):
        if len(vertex_groups) == 0:
            return

        modifiers = filter(lambda modifier: hasattr(modifier, "vertex_group")
                           and modifier.vertex_group, obj.modifiers)
        used_vertex_groups = set(
            map(lambda modifier: modifier.vertex_group, modifiers))

        obsolete = filter(
            lambda group: group not in used_vertex_groups, vertex_groups)

        for group in obsolete:
            print(f"removed vertex_group: {group}")
            vg = obj.vertex_groups.get(group)
            obj.vertex_groups.remove(vg)

#    def kill_custom_orientation(self):
#        orig_transform = bpy.context.scene.transform_orientation_slots[0].type
#        bpy.context.scene.transform_orientation_slots[0].type = 'SimpleLattice_Orientation'
#        bpy.ops.transform.delete_orientation()
#        bpy.data.scenes[0].transform_orientation_slots[0].type = orig_transform

#Apply Lattice Modifier
class OP_apply_lattice_modifier(Operator):
    bl_idname = "op.apply_lattice_modifier"
    bl_label = "Apply Lattice Modifier"
    bl_description = "Apply Lattice on selected objects"
    bl_options = {"REGISTER","UNDO"}

    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        obj = context.active_object
        obj_list = [obj for obj in context.selected_objects]
        
        bpy.ops.object.mode_set(mode = 'OBJECT')
        bpy.ops.object.select_all(action='DESELECT')
        for obj in obj_list:
            obj.select_set(state=True)
            context.view_layer.objects.active = obj
            
            lattice = False
            for mod in obj.modifiers:
                if mod.type == "LATTICE":
                    lattice = True
            if lattice:
                if bpy.app.version >= (2, 90, 0):
                    bpy.ops.object.modifier_apply(modifier=mod.name)
                else:
                    bpy.ops.object.modifier_apply(apply_as='DATA', modifier=mod.name)
        
        del(obj_list[:])    
        return {"FINISHED"}