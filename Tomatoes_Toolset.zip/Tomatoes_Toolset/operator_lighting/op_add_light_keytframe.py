import bpy
from bpy.types import Operator

###################
# WIP
###################
class OP_Add_Light_Keyframe(Operator):
    bl_idname = "add.light_keyframe"
    bl_label = "Add Light Keyframe "
    bl_description = "Add Keyframe To Selected Lighting"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        for l in bpy.data.lights:
            if l.type == "POINT":
                l.energy = 200
                
        objects = bpy.context.selected_objects
        for obj in objects:
            obj.data.keyframe_insert(data_path='energy', frame=4)
            obj.data.keyframe_insert(data_path='energy', frame=10)
            obj.data.keyframe_delete(data_path='energy', frame=4)
        return {'FINISHED'}
