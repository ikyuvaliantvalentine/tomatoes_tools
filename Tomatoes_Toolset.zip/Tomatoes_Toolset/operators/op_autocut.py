import bpy
from bpy.types import Operator
from .. properties import *
from mathutils import Vector
################################################### 
# AutoCut 
################################################### 
bpy.types.Scene.AutoCut_axis = bpy.props.EnumProperty(items = [("x",   "X",   "", 1), ("y",   "Y",   "", 2), ("z",   "Z",   "", 3)], description="Axis used by the mirror modifier")
bpy.types.Scene.AutoCut_orientation = bpy.props.EnumProperty(items = [("positive", "Positive", "", 1),("negative", "Negative", "", 2)], description="Choose the side along the axis of the editable part (+/- coordinates)")
bpy.types.Scene.AutoCut_cut = bpy.props.BoolProperty(default= True, description="If enabeled, cut the mesh in two parts and mirror it. If not, just make a loopcut")
bpy.types.Scene.tp_edit = bpy.props.BoolProperty(name="Switch Mode", description="Switch Mode", default=False)     

class VIEW3D_TP_AutoCut(Operator):
    """cut and delete choosen sides"""
    bl_idname = "tp_ops.mods_autocut_obm"
    bl_label = "AutoCuts"
                                       
    def execute(self, context):
         tomatoes = context.scene.tomatoes_props
         if tomatoes.tp_axis == "positiv":
             
            if tomatoes.tp_axis_cut == "x":
                bpy.ops.tp_ops.mods_positiv_x_cut_obm()
                bpy.ops.object.editmode_toggle()                 
                act_obj = context.active_object
                if tomatoes.auto_cut_mirror:
                    newMod = act_obj.modifiers.new("Mirror", 'MIRROR')
                    newMod.show_in_editmode = True
                    newMod.use_axis[0] = True
                    newMod.use_axis[1] = False
                    newMod.use_axis[2] = False
                    newMod.use_clip = True   
                   
            if tomatoes.tp_axis_cut == "y":            
                bpy.ops.tp_ops.mods_positiv_y_cut_obm()
                bpy.ops.object.editmode_toggle() 
                if tomatoes.auto_cut_mirror:
                    act_obj = context.active_object
                    newMod = act_obj.modifiers.new("Mirror", 'MIRROR')
                    newMod.show_in_editmode = True
                    newMod.use_axis[0] = False
                    newMod.use_axis[1] = True
                    newMod.use_axis[2] = False
                    newMod.use_clip = True 
                
            if tomatoes.tp_axis_cut == "z":  
                bpy.ops.tp_ops.mods_positiv_z_cut_obm()       
                bpy.ops.object.editmode_toggle() 
                if tomatoes.auto_cut_mirror:
                    act_obj = context.active_object
                    newMod = act_obj.modifiers.new("Mirror", 'MIRROR')
                    newMod.show_in_editmode = True
                    newMod.use_axis[0] = False
                    newMod.use_axis[1] = False
                    newMod.use_axis[2] = True
                    newMod.use_clip = True 
                
            if tomatoes.tp_axis_cut == "xy":  
                bpy.ops.tp_ops.mods_positiv_xy_cut_obm()
                bpy.ops.object.editmode_toggle()
                if tomatoes.auto_cut_mirror: 
                    act_obj = context.active_object
                    newMod = act_obj.modifiers.new("Mirror", 'MIRROR')
                    newMod.show_in_editmode = True
                    newMod.use_axis[0] = True
                    newMod.use_axis[1] = True
                    newMod.use_axis[2] = False
                    newMod.use_clip = True 
                
            if tomatoes.tp_axis_cut == "xz":  
                bpy.ops.tp_ops.mods_positiv_xz_cut_obm()
                bpy.ops.object.editmode_toggle()  
                if tomatoes.auto_cut_mirror:               
                    act_obj = context.active_object
                    newMod = act_obj.modifiers.new("Mirror", 'MIRROR')
                    newMod.show_in_editmode = True
                    newMod.use_axis[0] = True
                    newMod.use_axis[1] = False
                    newMod.use_axis[2] = True
                    newMod.use_clip = True 
                
            if tomatoes.tp_axis_cut == "yz":  
                bpy.ops.tp_ops.mods_positiv_yz_cut_obm()
                bpy.ops.object.editmode_toggle() 
                if tomatoes.auto_cut_mirror:
                    act_obj = context.active_object
                    newMod = act_obj.modifiers.new("Mirror", 'MIRROR')
                    newMod.show_in_editmode = True
                    newMod.use_axis[0] = False
                    newMod.use_axis[1] = True
                    newMod.use_axis[2] = True
                    newMod.use_clip = True 
                
            if tomatoes.tp_axis_cut == "xyz":            
                bpy.ops.tp_ops.mods_positiv_xyz_cut_obm()
                bpy.ops.object.editmode_toggle()  
                if tomatoes.auto_cut_mirror:
                    act_obj = context.active_object
                    newMod = act_obj.modifiers.new("Mirror", 'MIRROR')
                    newMod.show_in_editmode = True
                    newMod.use_axis[0] = True
                    newMod.use_axis[1] = True
                    newMod.use_axis[2] = True
                    newMod.use_clip = True            
                    
         if tomatoes.tp_axis == "negativ":

            if tomatoes.tp_axis_cut == "x":  
                bpy.ops.tp_ops.mods_negativ_x_cut_obm()
                bpy.ops.object.editmode_toggle() 
                if tomatoes.auto_cut_mirror:
                    act_obj = context.active_object
                    newMod = act_obj.modifiers.new("Mirror", 'MIRROR')
                    newMod.show_in_editmode = True
                    newMod.use_axis[0] = True
                    newMod.use_axis[1] = False
                    newMod.use_axis[2] = False
                    newMod.use_clip = True     
                    
            if tomatoes.tp_axis_cut == "y":            
                bpy.ops.tp_ops.mods_negativ_y_cut_obm()   
                bpy.ops.object.editmode_toggle() 
                if tomatoes.auto_cut_mirror:
                    act_obj = context.active_object
                    newMod = act_obj.modifiers.new("Mirror", 'MIRROR')
                    newMod.show_in_editmode = True
                    newMod.use_axis[0] = False
                    newMod.use_axis[1] = True
                    newMod.use_axis[2] = False
                    newMod.use_clip = True     
                    
            if tomatoes.tp_axis_cut == "z":             
                bpy.ops.tp_ops.mods_negativ_z_cut_obm()
                bpy.ops.object.editmode_toggle() 
                if tomatoes.auto_cut_mirror:
                    act_obj = context.active_object
                    newMod = act_obj.modifiers.new("Mirror", 'MIRROR')
                    newMod.show_in_editmode = True
                    newMod.use_axis[0] = False
                    newMod.use_axis[1] = False
                    newMod.use_axis[2] = True
                    newMod.use_clip = True     
                    
            if tomatoes.tp_axis_cut == "xy":  
                bpy.ops.tp_ops.mods_negativ_xy_cut_obm()
                bpy.ops.object.editmode_toggle() 
                if tomatoes.auto_cut_mirror:
                    act_obj = context.active_object
                    newMod = act_obj.modifiers.new("Mirror", 'MIRROR')
                    newMod.show_in_editmode = True
                    newMod.use_axis[0] = True
                    newMod.use_axis[1] = True
                    newMod.use_axis[2] = False
                    newMod.use_clip = True     
                    
            if tomatoes.tp_axis_cut == "xz":            
                bpy.ops.tp_ops.mods_negativ_xz_cut_obm()
                bpy.ops.object.editmode_toggle() 
                if tomatoes.auto_cut_mirror:
                    act_obj = context.active_object
                    newMod = act_obj.modifiers.new("Mirror", 'MIRROR')
                    newMod.show_in_editmode = True
                    newMod.use_axis[0] = True
                    newMod.use_axis[1] = False
                    newMod.use_axis[2] = True
                    newMod.use_clip = True 
                    
            if tomatoes.tp_axis_cut == "yz":             
                bpy.ops.tp_ops.mods_negativ_yz_cut_obm()
                bpy.ops.object.editmode_toggle() 
                if tomatoes.auto_cut_mirror:
                    act_obj = context.active_object
                    newMod = act_obj.modifiers.new("Mirror", 'MIRROR')
                    newMod.show_in_editmode = True
                    newMod.use_axis[0] = False
                    newMod.use_axis[1] = True
                    newMod.use_axis[2] = True
                    newMod.use_clip = True 
                    
            if tomatoes.tp_axis_cut == "xyz":             
                bpy.ops.tp_ops.mods_negativ_xyz_cut_obm()
                bpy.ops.object.editmode_toggle() 
                if tomatoes.auto_cut_mirror:
                    act_obj = context.active_object
                    newMod = act_obj.modifiers.new("Mirror", 'MIRROR')
                    newMod.show_in_editmode = True
                    newMod.use_axis[0] = True
                    newMod.use_axis[1] = True
                    newMod.use_axis[2] = True
                    newMod.use_clip = True  
                
         if bpy.context.scene.tp_edit == True:
            
            if context.mode == 'EDIT_MESH': 
                bpy.ops.object.editmode_toggle()

            bpy.ops.object.editmode_toggle() 

         else:
             for obj in context.selected_objects:                    
                for i, mod in enumerate(obj.modifiers):
                    if mod.type == 'MIRROR':
                        bpy.context.view_layer.objects.active = obj
                        for x in range(0, i):
                            bpy.ops.object.modifier_move_up(modifier=mod.name)
                            self.report({'INFO'}, "Move Up Mirror modifier to first") 
         return {'FINISHED'}
      
class View3D_TP_Align_Vertices(Operator):
    """Align Vertices on 1 Axis"""
    bl_idname = "tp_ops.align_vertices"
    bl_label = "Align Vertices on 1 Axis"

    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        bpy.ops.object.mode_set(mode = 'OBJECT')

        x1,y1,z1 = bpy.context.scene.cursor.location
        bpy.ops.view3d.snap_cursor_to_selected()

        x2,y2,z2 = bpy.context.scene.cursor.location

        bpy.context.scene.cursor.location[0],bpy.context.scene.cursor.location[1],bpy.context.scene.cursor.location[2]  = 0,0,0

        #Vertices coordinate to 0 (local coordinate, so on the origin)
        for vert in bpy.context.object.data.vertices:
            if vert.select:
                if bpy.context.scene.AutoCut_axis == 'x':
                    axis = 0
                elif bpy.context.scene.AutoCut_axis == 'y':
                    axis = 1
                elif bpy.context.scene.AutoCut_axis == 'z':
                    axis = 2
                vert.co[axis] = 0
        
        bpy.context.scene.cursor.location = x2,y2,z2

        bpy.ops.object.origin_set(type='ORIGIN_CURSOR')

        bpy.context.scene.cursor.location = x1,y1,z1

        return {'FINISHED'}
   
class View3D_TP_AutoCut(Operator):
    """ Automatically cut an object along an axis """
    bl_idname = "tp_ops.autocut"
    bl_label = "AutoCut"

    @classmethod
    def poll(cls, context):
        return True
            
    def get_local_axis_vector(self, context, X, Y, Z, orientation):
        loc = context.object.location
        bpy.ops.object.mode_set(mode="OBJECT") # Needed to avoid to translate vertices
        
        v1 = Vector((loc[0],loc[1],loc[2]))
        bpy.ops.transform.translate(value=(X*orientation, Y*orientation, Z*orientation), constraint_axis=((X==1), (Y==1), (Z==1)), orient_matrix_type='LOCAL')
        v2 = Vector((loc[0],loc[1],loc[2]))
        bpy.ops.transform.translate(value=(-X*orientation, -Y*orientation, -Z*orientation), constraint_axis=((X==1), (Y==1), (Z==1)), orient_matrix_type='LOCAL')
        
        bpy.ops.object.mode_set(mode="EDIT")
        return v2-v1
    
    def execute(self, context):
        X,Y,Z = 0,0,0
        if bpy.context.scene.AutoCut_axis == 'x':
            X = 1
        elif bpy.context.scene.AutoCut_axis == 'y':
            Y = 1
        elif bpy.context.scene.AutoCut_axis == 'z':
            Z = 1
            
        bpy.ops.object.mode_set(mode="EDIT") # Go to edit mode
        
        bpy.ops.mesh.select_all(action='SELECT') # Select all the vertices
        
        if bpy.context.scene.AutoCut_orientation == 'positive':
            orientation = 1
        else:
            orientation = -1
            
        cut_normal = self.get_local_axis_vector(context, X, Y, Z, orientation)
            
        bpy.ops.mesh.bisect(plane_co=(bpy.context.object.location[0], bpy.context.object.location[1], bpy.context.object.location[2]), plane_no=cut_normal, use_fill= False, clear_inner= bpy.context.scene.AutoCut_cut, clear_outer= 0) # Cut the mesh
        
        bpy.ops.tp_ops.align_vertices() # Use to align the vertices on the origin
        bpy.ops.object.mode_set(mode="EDIT")

        return {'FINISHED'}

class VIEW3D_TP_Negativ_X_cut_obm(Operator):
    """cut object and delete negative X"""
    bl_idname = "tp_ops.mods_negativ_x_cut_obm"
    bl_label = "Cut -X"

    edit : bpy.props.BoolProperty(name="Switch Mode",  description="Switch Mode", default=True) 

    def draw(self, context):
        layout = self.layout   
              
        box = layout.box().column(1)

        row = box.column(1)
        row.prop(self, 'edit')

    def execute(self, context):

        if context.mode == 'EDIT_MESH':            
            bpy.ops.object.editmode_toggle() 
          
        bpy.context.scene.AutoCut_axis = 'x'
        bpy.context.scene.AutoCut_orientation = 'positive'
        bpy.ops.tp_ops.autocut()

        for i in range(self.edit):
            bpy.ops.object.editmode_toggle() 
        return {'FINISHED'}


class VIEW3D_TP_Positiv_X_cut_obm(Operator):
    """cut object and delete positiv X"""
    bl_idname = "tp_ops.mods_positiv_x_cut_obm"
    bl_label = "Cut +X"

    edit : bpy.props.BoolProperty(name="Switch Mode",  description="Switch Mode", default=True) 

    def draw(self, context):
        layout = self.layout   
              
        box = layout.box().column(1)

        row = box.column(1)
        row.prop(self, 'edit')

    def execute(self, context):

        if context.mode == 'EDIT_MESH':            
            bpy.ops.object.editmode_toggle() 
          
        bpy.context.scene.AutoCut_axis = 'x'
        bpy.context.scene.AutoCut_orientation = 'negative'
        bpy.ops.tp_ops.autocut()
                
        for i in range(self.edit):
            bpy.ops.object.editmode_toggle()        

        return {'FINISHED'}


class VIEW3D_TP_Negativ_Y_cut_obm(Operator):
    """cut object and delete negative Y"""
    bl_idname = "tp_ops.mods_negativ_y_cut_obm"
    bl_label = "Cut -Y"

    edit : bpy.props.BoolProperty(name="Switch Mode",  description="Switch Mode", default=True) 

    def draw(self, context):
        layout = self.layout   
              
        box = layout.box().column(1)

        row = box.column(1)
        row.prop(self, 'edit')

    def execute(self, context):

        if context.mode == 'EDIT_MESH':            
            bpy.ops.object.editmode_toggle() 
          
        bpy.context.scene.AutoCut_axis = 'y'
        bpy.context.scene.AutoCut_orientation = 'positive'
        bpy.ops.tp_ops.autocut()

        for i in range(self.edit):
            bpy.ops.object.editmode_toggle()        

        return {'FINISHED'}


class VIEW3D_TP_Positiv_Y_cut_obm(Operator):
    """cut object and delete positiv Y"""
    bl_idname = "tp_ops.mods_positiv_y_cut_obm"
    bl_label = "Cut +Y"

    edit : bpy.props.BoolProperty(name="Switch Mode",  description="Switch Mode", default=True) 

    def draw(self, context):
        layout = self.layout   
              
        box = layout.box().column(1)

        row = box.column(1)
        row.prop(self, 'edit')

    def execute(self, context):

        if context.mode == 'EDIT_MESH':            
            bpy.ops.object.editmode_toggle() 
          
        bpy.context.scene.AutoCut_axis = 'y'
        bpy.context.scene.AutoCut_orientation = 'negative'
        bpy.ops.tp_ops.autocut()

        for i in range(self.edit):
            bpy.ops.object.editmode_toggle()        

        return {'FINISHED'}


class VIEW3D_TP_Negativ_Z_cut_obm(Operator):
    """cut object and delete negative Z"""
    bl_idname = "tp_ops.mods_negativ_z_cut_obm"
    bl_label = "Cut -Z"

    edit : bpy.props.BoolProperty(name="Switch Mode",  description="Switch Mode", default=True) 

    def draw(self, context):
        layout = self.layout   
              
        box = layout.box().column(1)

        row = box.column(1)
        row.prop(self, 'edit')

    def execute(self, context):

        if context.mode == 'EDIT_MESH':            
            bpy.ops.object.editmode_toggle() 
          
        bpy.context.scene.AutoCut_axis = 'z'
        bpy.context.scene.AutoCut_orientation = 'positive'
        bpy.ops.tp_ops.autocut()

        for i in range(self.edit):
            bpy.ops.object.editmode_toggle()        

        return {'FINISHED'}


class VIEW3D_TP_Positiv_Z_cut_obm(Operator):
    """cut object and delete positiv Z"""
    bl_idname = "tp_ops.mods_positiv_z_cut_obm"
    bl_label = "Cut +Z"

    edit : bpy.props.BoolProperty(name="Switch Mode",  description="Switch Mode", default=True) 

    def draw(self, context):
        layout = self.layout   
              
        box = layout.box().column(1)

        row = box.column(1)
        row.prop(self, 'edit')

    def execute(self, context):

        if context.mode == 'EDIT_MESH':            
            bpy.ops.object.editmode_toggle() 
            
        bpy.context.scene.AutoCut_axis = 'z'
        bpy.context.scene.AutoCut_orientation = 'negative'
        bpy.ops.tp_ops.autocut()

        for i in range(self.edit):
            bpy.ops.object.editmode_toggle()        

        return {'FINISHED'}



class VIEW3D_TP_Negativ_X_cut_obm(Operator):
    """cut object and delete negative X"""
    bl_idname = "tp_ops.mods_negativ_x_cut_obm"
    bl_label = "Cut -X"

    edit : bpy.props.BoolProperty(name="Switch Mode",  description="Switch Mode", default=True) 

    def draw(self, context):
        layout = self.layout   
              
        box = layout.box().column(1)

        row = box.column(1)
        row.prop(self, 'edit')

    def execute(self, context):

        if context.mode == 'EDIT_MESH':
            bpy.ops.object.editmode_toggle() 
            
        bpy.context.scene.AutoCut_axis = 'x'
        bpy.context.scene.AutoCut_orientation = 'positive'
        bpy.ops.tp_ops.autocut()

        for i in range(self.edit):
            bpy.ops.object.editmode_toggle()        
          
        return {'FINISHED'}


class VIEW3D_TP_Positiv_X_Cut_obm(Operator):
    """cut object on the positiv X-Ais"""
    bl_idname = "tp_ops.mods_positiv_x_cut_obm"
    bl_label = "Cut +X"

    edit : bpy.props.BoolProperty(name="Switch Mode",  description="Switch Mode", default=True) 

    def draw(self, context):
        layout = self.layout   
              
        box = layout.box().column(1)

        row = box.column(1)
        row.prop(self, 'edit')

    def execute(self, context):

        if context.mode == 'EDIT_MESH':
            bpy.ops.object.editmode_toggle() 
        
        bpy.context.scene.AutoCut_axis = 'x'
        bpy.context.scene.AutoCut_orientation = 'negative'
        bpy.ops.tp_ops.autocut()

        for i in range(self.edit):
            bpy.ops.object.editmode_toggle()                
                 
        return {'FINISHED'}


class VIEW3D_TP_Negativ_Y_Cut_obm(Operator):
    """cut object and delete negative Y"""
    bl_idname = "tp_ops.mods_negativ_y_cut_obm"
    bl_label = "Cut -Y"

    edit : bpy.props.BoolProperty(name="Switch Mode",  description="Switch Mode", default=True) 

    def draw(self, context):
        layout = self.layout   
              
        box = layout.box().column(1)

        row = box.column(1)
        row.prop(self, 'edit')

    def execute(self, context):

        if context.mode == 'EDIT_MESH':
            bpy.ops.object.editmode_toggle() 
            
        bpy.context.scene.AutoCut_axis = 'y'
        bpy.context.scene.AutoCut_orientation = 'positive'
        bpy.ops.tp_ops.autocut()

        for i in range(self.edit):
            bpy.ops.object.editmode_toggle()        
                  
        return {'FINISHED'}


class VIEW3D_TP_Positiv_Y_Cut_obm(Operator):
    """cut object and delete positiv Y"""
    bl_idname = "tp_ops.mods_positiv_y_cut_obm"
    bl_label = "Cut +Y"

    edit : bpy.props.BoolProperty(name="Switch Mode",  description="Switch Mode", default=True) 

    def draw(self, context):
        layout = self.layout   
              
        box = layout.box().column(1)

        row = box.column(1)
        row.prop(self, 'edit')
    
    def execute(self, context):

        if context.mode == 'EDIT_MESH':
            bpy.ops.object.editmode_toggle() 
            
        bpy.context.scene.AutoCut_axis = 'y'
        bpy.context.scene.AutoCut_orientation = 'negative'
        bpy.ops.tp_ops.autocut()

        for i in range(self.edit):
            bpy.ops.object.editmode_toggle()        
         
        return {'FINISHED'}


class VIEW3D_TP_Negativ_Z_Cut_obm(Operator):
    """cut object and delete positive Z"""
    bl_idname = "tp_ops.mods_negativ_z_cut_obm"
    bl_label = "Cut -Z"

    edit : bpy.props.BoolProperty(name="Switch Mode",  description="Switch Mode", default=True) 

    def draw(self, context):
        layout = self.layout   
              
        box = layout.box().column(1)

        row = box.column(1)
        row.prop(self, 'edit')

    def execute(self, context):

        if context.mode == 'EDIT_MESH':
            bpy.ops.object.editmode_toggle() 
            
        bpy.context.scene.AutoCut_axis = 'z'
        bpy.context.scene.AutoCut_orientation = 'positive'
        bpy.ops.tp_ops.autocut()
        bpy.ops.object.modifier_remove(modifier="Mirror")

        for i in range(self.edit):
            bpy.ops.object.editmode_toggle()        

        return {'FINISHED'}


class VIEW3D_TP_PositivZ_Cut_obm(Operator):
    """cut object and delete positive Z  """
    bl_idname = "tp_ops.mods_positiv_z_cut_obm"
    bl_label = "Cut +Z"

    edit : bpy.props.BoolProperty(name="Switch Mode",  description="Switch Mode", default=True) 

    def draw(self, context):
        layout = self.layout   
              
        box = layout.box().column(1)

        row = box.column(1)
        row.prop(self, 'edit')

    def execute(self, context):
        
        if context.mode == 'EDIT_MESH':
            bpy.ops.object.editmode_toggle() 
            
        bpy.context.scene.AutoCut_axis = 'z'
        bpy.context.scene.AutoCut_orientation = 'negative'
        bpy.ops.tp_ops.autocut()
        bpy.ops.object.modifier_remove(modifier="Mirror")  

        for i in range(self.edit):
            bpy.ops.object.editmode_toggle()        

        return {'FINISHED'}


class VIEW3D_TP_Positiv_XY_Cut_obm(Operator):
    """cut object and delete positive XY  """
    bl_idname = "tp_ops.mods_positiv_xy_cut_obm"
    bl_label = "Cut +XY"

    edit : bpy.props.BoolProperty(name="Switch Mode",  description="Switch Mode", default=True) 

    def draw(self, context):
        layout = self.layout   
              
        box = layout.box().column(1)

        row = box.column(1)
        row.prop(self, 'edit')

    def execute(self, context):
        
        if context.mode == 'EDIT_MESH':
            bpy.ops.object.editmode_toggle() 
            
        bpy.context.scene.AutoCut_axis = 'x'
        bpy.context.scene.AutoCut_orientation = 'negative'
        bpy.ops.tp_ops.autocut()

        bpy.context.scene.AutoCut_axis = 'y'
        bpy.context.scene.AutoCut_orientation = 'negative'
        bpy.ops.tp_ops.autocut()            

        for i in range(self.edit):
            bpy.ops.object.editmode_toggle()        

        return {'FINISHED'}

class VIEW3D_TP_Positiv_XZ_Cut_obm(Operator):
    """cut object and delete positive XZ  """
    bl_idname = "tp_ops.mods_positiv_xz_cut_obm"
    bl_label = "Cut +XZ"

    edit : bpy.props.BoolProperty(name="Switch Mode",  description="Switch Mode", default=True) 

    def draw(self, context):
        layout = self.layout   
              
        box = layout.box().column(1)

        row = box.column(1)
        row.prop(self, 'edit')

    def execute(self, context):
        
        if context.mode == 'EDIT_MESH':
            bpy.ops.object.editmode_toggle() 
            
        bpy.context.scene.AutoCut_axis = 'x'
        bpy.context.scene.AutoCut_orientation = 'negative'
        bpy.ops.tp_ops.autocut()     
        
        bpy.context.scene.AutoCut_axis = 'z'
        bpy.context.scene.AutoCut_orientation = 'negative'
        bpy.ops.tp_ops.autocut()

        for i in range(self.edit):
            bpy.ops.object.editmode_toggle()        

        return {'FINISHED'}

class VIEW3D_TP_Positiv_YZ_Cut_obm(Operator):
    """cut object and delete positive YZ  """
    bl_idname = "tp_ops.mods_positiv_yz_cut_obm"
    bl_label = "Cut +YZ"

    edit : bpy.props.BoolProperty(name="Switch Mode",  description="Switch Mode", default=True) 

    def draw(self, context):
        layout = self.layout   
              
        box = layout.box().column(1)

        row = box.column(1)
        row.prop(self, 'edit')

    def execute(self, context):
        
        if context.mode == 'EDIT_MESH':
            bpy.ops.object.editmode_toggle() 

        bpy.context.scene.AutoCut_axis = 'y'
        bpy.context.scene.AutoCut_orientation = 'negative'
        bpy.ops.tp_ops.autocut()            
        
        bpy.context.scene.AutoCut_axis = 'z'
        bpy.context.scene.AutoCut_orientation = 'negative'
        bpy.ops.tp_ops.autocut()

        for i in range(self.edit):
            bpy.ops.object.editmode_toggle()         

        return {'FINISHED'}


class VIEW3D_TP_Positiv_XYZ_Cut_obm(Operator):
    """cut object and delete positive XYZ  """
    bl_idname = "tp_ops.mods_positiv_xyz_cut_obm"
    bl_label = "Cut +XYZ"

    edit : bpy.props.BoolProperty(name="Switch Mode",  description="Switch Mode", default=True) 

    def draw(self, context):
        layout = self.layout   
              
        box = layout.box().column(1)

        row = box.column(1)
        row.prop(self, 'edit')

    def execute(self, context):
        
        if context.mode == 'EDIT_MESH':
            bpy.ops.object.editmode_toggle() 
            
        bpy.context.scene.AutoCut_axis = 'x'
        bpy.context.scene.AutoCut_orientation = 'negative'
        bpy.ops.tp_ops.autocut()

        bpy.context.scene.AutoCut_axis = 'y'
        bpy.context.scene.AutoCut_orientation = 'negative'
        bpy.ops.tp_ops.autocut()            
        
        bpy.context.scene.AutoCut_axis = 'z'
        bpy.context.scene.AutoCut_orientation = 'negative'
        bpy.ops.tp_ops.autocut()

        for i in range(self.edit):
            bpy.ops.object.editmode_toggle()        

        return {'FINISHED'}


class VIEW3D_TP_Negativ_XY_Cut_obm(Operator):
    """cut object and delete negativ XY"""
    bl_idname = "tp_ops.mods_negativ_xy_cut_obm"
    bl_label = "Cut -XY"

    edit : bpy.props.BoolProperty(name="Switch Mode",  description="Switch Mode", default=True) 

    def draw(self, context):
        layout = self.layout   
              
        box = layout.box().column(1)

        row = box.column(1)
        row.prop(self, 'edit')

    def execute(self, context):

        if context.mode == 'EDIT_MESH':
            bpy.ops.object.editmode_toggle() 
            
        bpy.context.scene.AutoCut_axis = 'x'
        bpy.context.scene.AutoCut_orientation = 'positive'
        bpy.ops.tp_ops.autocut()

        bpy.context.scene.AutoCut_axis = 'y'
        bpy.context.scene.AutoCut_orientation = 'positive'
        bpy.ops.tp_ops.autocut()            

        for i in range(self.edit):
            bpy.ops.object.editmode_toggle()        
                  
        return {'FINISHED'}


class VIEW3D_TP_Negativ_XZ_Cut_obm(Operator):
    """cut object and delete negativ XZ"""
    bl_idname = "tp_ops.mods_negativ_xz_cut_obm"
    bl_label = "Cut -XZ"

    edit : bpy.props.BoolProperty(name="Switch Mode",  description="Switch Mode", default=True) 

    def draw(self, context):
        layout = self.layout   
              
        box = layout.box().column(1)

        row = box.column(1)
        row.prop(self, 'edit')

    def execute(self, context):

        if context.mode == 'EDIT_MESH':
            bpy.ops.object.editmode_toggle() 
            
        bpy.context.scene.AutoCut_axis = 'x'
        bpy.context.scene.AutoCut_orientation = 'positive'
        bpy.ops.tp_ops.autocut()

        bpy.context.scene.AutoCut_axis = 'z'
        bpy.context.scene.AutoCut_orientation = 'positive'
        bpy.ops.tp_ops.autocut()


        for i in range(self.edit):
            bpy.ops.object.editmode_toggle()        
                  
        return {'FINISHED'}


class VIEW3D_TP_Negativ_YZ_Cut_obm(Operator):
    """cut object and delete negativ YZ"""
    bl_idname = "tp_ops.mods_negativ_yz_cut_obm"
    bl_label = "Cut -YZ"

    edit : bpy.props.BoolProperty(name="Switch Mode",  description="Switch Mode", default=True) 

    def draw(self, context):
        layout = self.layout   
              
        box = layout.box().column(1)

        row = box.column(1)
        row.prop(self, 'edit')

    def execute(self, context):

        if context.mode == 'EDIT_MESH':
            bpy.ops.object.editmode_toggle() 

        bpy.context.scene.AutoCut_axis = 'y'
        bpy.context.scene.AutoCut_orientation = 'positive'
        bpy.ops.tp_ops.autocut()            
        
        bpy.context.scene.AutoCut_axis = 'z'
        bpy.context.scene.AutoCut_orientation = 'positive'
        bpy.ops.tp_ops.autocut()

        for i in range(self.edit):
            bpy.ops.object.editmode_toggle()        
                  
        return {'FINISHED'}

class VIEW3D_TP_Negativ_XYZ_Cut_obm(Operator):
    """cut object and delete negativ XYZ"""
    bl_idname = "tp_ops.mods_negativ_xyz_cut_obm"
    bl_label = "Cut -XYZ"

    edit : bpy.props.BoolProperty(name="Switch Mode",  description="Switch Mode", default=True) 

    def draw(self, context):
        layout = self.layout   
              
        box = layout.box().column(1)

        row = box.column(1)
        row.prop(self, 'edit')

    def execute(self, context):

        if context.mode == 'EDIT_MESH':
            bpy.ops.object.editmode_toggle() 
            
        bpy.context.scene.AutoCut_axis = 'x'
        bpy.context.scene.AutoCut_orientation = 'positive'
        bpy.ops.tp_ops.autocut()

        bpy.context.scene.AutoCut_axis = 'y'
        bpy.context.scene.AutoCut_orientation = 'positive'
        bpy.ops.tp_ops.autocut()            
        
        bpy.context.scene.AutoCut_axis = 'z'
        bpy.context.scene.AutoCut_orientation = 'positive'
        bpy.ops.tp_ops.autocut()
        
        obj = bpy.context.active_object
        obj.modifiers.clear()

        for i in range(self.edit):
            bpy.ops.object.editmode_toggle()        
                  
        return {'FINISHED'}