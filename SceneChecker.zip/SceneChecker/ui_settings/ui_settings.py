import bpy
from bpy.types import Operator
from .. properties import *

#########################################
#   Change Settings UI
#########################################     
class UI_Settings_SCHK(Operator):
    bl_label = "Settings"
    bl_idname = "quick.change_settings_schk"
    bl_description = "UI Change Settings"
    dialog_width =  300
              
    def draw(self, context): 
        layout = self.layout
        addon_preferences = get_addon_preferences()
        workflow = addon_preferences.WorkflowOptions
        software = addon_preferences.SoftwareWorkflowOptions
        
        row = layout.row()
        row.label(text="Workflow : ")
        row.prop(addon_preferences, "WorkflowOptions", expand = True)
        row = layout.row()
        row.label(text="Software : ")
        row.prop(addon_preferences, "SoftwareWorkflowOptions", expand = True)
             
    def check(self, context):
        return True            
    def execute(self, context):
        return {'FINISHED'}    
    def invoke(self, context, event):
        wm = context.window_manager
        self.scale = get_addon_preferences().scale
        window_size = (context.window.width/250)/dpifac()
        wm.invoke_props_dialog(self, width = self.dialog_width * window_size * self.scale)
        return {'RUNNING_MODAL'} 
    