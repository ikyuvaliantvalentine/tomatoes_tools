import bpy
from .. properties import *
from .. ui.ui_camera import *

def draw_lookdev_ui(self, context, layout):
    ui_cam_list(context,layout)

    col = layout.column()
    col.separator()
    col.scale_x = 1.2
    col.scale_y = 1.2
    col.operator("op.setup_turntable_operator")