# This file is part of Instant Clean
# Copyright (C) 2023  Ruben Messerschmidt

import bpy
from bpy.props import BoolProperty


class BC_PG_States(bpy.types.PropertyGroup):
    repair: BoolProperty(
        name='Repair',
        default=True,
        description='Toggle Repair operations'
    )

    limdiss: BoolProperty(
        name='Dissolve',
        default=True,
        description='Toggle Dissolve operations'
    )

    topology: BoolProperty(
        name='Topology',
        default=True,
        description='Toggle Topology operations'
    )

    normals: BoolProperty(
        name='Normals',
        default=True,
        description='Toggle Normals operations'
    )

    objectdata: BoolProperty(
        name='Objectdata',
        default=True,
        description='Toggle Objectdata operations'
    )
