import bpy
from bpy.types import Operator  

########################################################
#   Remove all unused material slot
########################################################
class Red_OT_Remove_Unused_Mat_Slot(Operator):
    bl_label = "Remove Unused Mat Slot"
    bl_description = "Remove Unused Mat Slot from all objects"
    bl_idname = "op.rem_mat_slot"
    bl_options = {'REGISTER', 'UNDO'}
        
    def execute(self, context):
        selected = bpy.context.selected_objects
        total_removed = 0
        count = 0
        for obj in selected:
            if(obj.type=='MESH'):
                bpy.context.view_layer.objects.active = obj
                count = len(obj.material_slots)
                bpy.ops.object.material_slot_remove_unused()
                removed = count - len(obj.material_slots)
                total_removed += removed

        for block in bpy.data.materials:
            if block.users == 0:
                bpy.data.materials.remove(block)

        return {'FINISHED'}