import bpy
from bpy.types import Panel
from .. ui.ui_draw_shading_ui import *
from .. ui.ui_relation import *
from .. ui.ui_uv_sets import *
from .. ui.ui_origin import *
from .. ui.ui_add_modifier import *
from .. ui.ui_renamer import *
from .. ui.ui_assetmanagement import *
from .. ui.ui_lookdev import *
from .. properties import *

class VIEW3D_PT_MOD_Brandoville_Project(Panel):
    bl_label = "(MODELLER) Brandoville Tools"
    bl_idname = "VIEW3D_PT_MOD_Brandoville_Project"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Brandoville"

    def draw(self, context):
        layout = self.layout    
        red = context.scene.red_props

        category_layout = layout.column(align=True)
        category_layout.scale_x=1.5
        category_layout.scale_y=1.5
        category_layout.prop(red, "red_create", expand=False)
        category_layout.separator()

        if red.red_create == "red_c0":
            draw_assetmanagement_ui(self, context, layout)
        elif red.red_create == "red_c1":
            draw_uv_sets_ui(self, context, layout)
            draw_pivot_and_cursor_ui(self, context, layout)
            draw_mesh_ui(self, context, layout)
            draw_relation_ui(self, context, layout)
            draw_add_modifier_ui(self, context, layout)

        elif red.red_create == "red_c2":
            draw_shading_ui(self, context, layout)
        elif red.red_create == "red_c3":
            Red_UIRenamer(self, context, layout)
        elif red.red_create == "red_c4":
            draw_lookdev_ui(self, context, layout)


class VIEW3D_PT_Modelling_Utilities_Subpanel(Panel):
    """Subpanel for Modelling Utilities"""
    bl_label = "Others"
    bl_idname = "VIEW3D_PT_Subpanel_ModellingUtilities"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_parent_id = "VIEW3D_PT_MOD_Brandoville_Project"
    bl_options = {"DEFAULT_CLOSED"}

    @classmethod
    def poll(cls, context):
        red = context.scene.red_props
        return red.red_create == "red_c1"

    def draw(self, context):
        layout = self.layout  
        layout.scale_x = 1.2
        layout.scale_y = 1.2
        layout.separator()
        layout.operator("op.add_character_scale")

