import bpy
from bpy.types import Panel
from .. ui.ui_assetmanagement import *
from .. properties import *

class VIEW3D_PT_ANM_Brandoville_Project(Panel):
    bl_label = "(ANM) Brandoville Tools"
    bl_idname = "VIEW3D_PT_ANM_Brandoville_Project"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Brandoville"

    def draw(self, context):
        layout = self.layout    
        red = context.scene.red_props

        category_layout = layout.column(align=True)
        category_layout.scale_x=1.5
        category_layout.scale_y=1.5
        category_layout.prop(red, "red_create", expand=False)
        category_layout.separator()

        if red.red_create == "red_c0":
            draw_assetmanagement_ui(self, context, layout)
        elif red.red_create == "red_c1":
            layout.scale_x = 1.2
            layout.scale_y = 1.2
            layout.operator("op.scene_playblast")


