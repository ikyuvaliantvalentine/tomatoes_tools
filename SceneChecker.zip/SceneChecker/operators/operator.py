import bpy
from bpy.types import Operator
from mathutils import Vector, Euler

###########################################
#   for ob in context.scene.objects:
#   for ob in bpy.context.view_layer.objects # Change To This To Avoid Error Object Not Visible In ViewLayer Because Collection is Hide
###########################################
class Get_Object_Apply_Loc(Operator):
    "CLICK - Select all objects that need to Apply Location then apply it"
    bl_idname = "ob.applyloc"
    bl_label = "Check Object Need To Apply Location"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):        
        with_eye = []

        for ob in bpy.context.view_layer.objects:
            if ob.type == "MESH":
                if ob.location != Vector((0,0,0)):
                    ob.select_set(state=True) 
                    bpy.ops.object.transform_apply(location=True, rotation=False, scale=False) 
                if ob.data.users > 1:
                    continue
        return {'FINISHED'}

class Get_Object_Apply_Scale(Operator):
    "CLICK - Select all objects that need to Apply Scale then apply it"
    bl_idname = "ob.applyscale"
    bl_label = "Check Object Need To Apply Scale"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):               
        for ob in bpy.context.view_layer.objects:
            if ob.type == "MESH":
                if ob.scale != Vector((1.0,1.0,1.0)):
                    ob.select_set(state=True) 
                    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)         
        return {'FINISHED'}

class Get_Object_Apply_Rotation(Operator):
    "CLICK - Select all objects that need to Apply Rotation then apply it"
    bl_idname = "ob.applyrot"
    bl_label = "Check Object Need To Apply Rotation"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):               
        for ob in bpy.context.view_layer.objects:
            if ob.type == "MESH":
                if ob.rotation_euler != Euler((0,0,0), 'XYZ'):
                    ob.select_set(state=True) 
                    bpy.ops.object.transform_apply(location=False, rotation=True, scale=False)         
        return {'FINISHED'}

class OB_Clear_Vertex_Color(Operator):
    "CLICK - Remove All Vertex Color"
    bl_idname = "ob.remove_vcol"
    bl_label = "Remove Vertex Color"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):               
        for ob in bpy.context.view_layer.objects:
            if ob.type == "MESH":
                for vcol in ob.data.vertex_colors :
                    ob.select_set(True)  
                    bpy.context.view_layer.objects.active = ob
                    bpy.ops.mesh.vertex_color_remove()
        return {'FINISHED'}
 
class OB_Select_Ngon_Mesh(Operator):
    "CLICK - Select Faces Ngon "
    bl_idname = "ob.sel_ngon"
    bl_label = "Select Ngon"

    def execute(self, context):
        for ob in bpy.context.view_layer.objects:
            if ob.type == "MESH":
                ob.select_set(True) 
                bpy.ops.object.mode_set(mode='EDIT')
                bpy.ops.mesh.select_mode(use_extend=False, use_expand=False, type='FACE')
                bpy.ops.mesh.select_face_by_sides(number=4, type='GREATER')   
        return {'FINISHED'}