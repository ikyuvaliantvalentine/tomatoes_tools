import bpy
from bpy.types import Operator, Panel

class SpeedUpPath(Operator):
    "Speed Up Path Tracing"
    bl_idname = "object.speeduppath"
    bl_label = "Speed Up Path"

    def execute(self, context):
        if bpy.app.version < (3, 0, 0):
            bpy.context.scene.cycles.use_square_samples = True
            bpy.context.scene.cycles.tile_order = 'CENTER'

            bpy.context.scene.cycles.max_bounces = 2
            bpy.context.scene.cycles.glossy_bounces = 2
            bpy.context.scene.cycles.transmission_bounces = 2
            bpy.context.scene.cycles.volume_bounces = 2
            bpy.context.scene.cycles.transparent_max_bounces = 2

            bpy.context.scene.cycles.denoiser = 'OPENIMAGEDENOISE'
            bpy.context.scene.cycles.preview_denoiser = 'OPENIMAGEDENOISE'
            bpy.context.scene.cycles.preview_denoising_input_passes = 'RGB_ALBEDO_NORMAL'
            bpy.context.scene.cycles.preview_denoising_start_sample = 64

            bpy.context.scene.render.tile_x = 256
            bpy.context.scene.render.tile_y = 256

        else:

            bpy.context.scene.cycles.max_bounces = 2
            bpy.context.scene.cycles.glossy_bounces = 2
            bpy.context.scene.cycles.transmission_bounces = 2
            bpy.context.scene.cycles.volume_bounces = 2
            bpy.context.scene.cycles.transparent_max_bounces = 2

            bpy.context.scene.cycles.use_preview_denoising = True
            bpy.context.scene.cycles.denoiser = 'OPENIMAGEDENOISE'
            bpy.context.scene.cycles.preview_denoiser = 'OPENIMAGEDENOISE'
            bpy.context.scene.cycles.preview_denoising_input_passes = 'RGB_ALBEDO_NORMAL'
            bpy.context.scene.cycles.preview_denoising_prefilter = 'ACCURATE'
            bpy.context.scene.cycles.preview_denoising_start_sample = 64

        bpy.context.scene.cycles.samples = 20
        bpy.context.scene.cycles.preview_samples = 6
        context.scene.render.engine = 'CYCLES'
        context.scene.cycles.device = 'GPU'
        
        alllamps = bpy.data.lights
        for lamp in alllamps:
            lamp.cycles.max_bounces = 3  
      
        return {'FINISHED'}

class MaxPath(Operator):
    "Max Settings Path Tracing"
    bl_idname = "object.maxpath"
    bl_label = "Max Path"

    def execute(self, context):
        if bpy.app.version < (3, 0, 0):
            bpy.context.scene.cycles.use_square_samples = True
            bpy.context.scene.cycles.tile_order = 'CENTER'

            bpy.context.scene.cycles.max_bounces = 180
            bpy.context.scene.cycles.glossy_bounces = 180
            bpy.context.scene.cycles.transmission_bounces = 36
            bpy.context.scene.cycles.volume_bounces = 2
            bpy.context.scene.cycles.transparent_max_bounces = 19

            bpy.context.scene.cycles.denoiser = 'OPENIMAGEDENOISE'
            bpy.context.scene.cycles.preview_denoiser = 'OPENIMAGEDENOISE'
            bpy.context.scene.cycles.preview_denoising_input_passes = 'RGB_ALBEDO_NORMAL'
            bpy.context.scene.cycles.preview_denoising_start_sample = 64

            context.scene.render.tile_x = 256
            context.scene.render.tile_y = 256

        else:

            bpy.context.scene.cycles.max_bounces = 180
            bpy.context.scene.cycles.glossy_bounces = 180
            bpy.context.scene.cycles.transmission_bounces = 36
            bpy.context.scene.cycles.volume_bounces = 2
            bpy.context.scene.cycles.transparent_max_bounces = 19

            bpy.context.scene.cycles.use_preview_denoising = True
            bpy.context.scene.cycles.denoiser = 'OPENIMAGEDENOISE'
            bpy.context.scene.cycles.preview_denoiser = 'OPENIMAGEDENOISE'
            bpy.context.scene.cycles.preview_denoising_input_passes = 'RGB_ALBEDO_NORMAL'
            bpy.context.scene.cycles.preview_denoising_prefilter = 'ACCURATE'
            bpy.context.scene.cycles.preview_denoising_start_sample = 64

        bpy.context.scene.cycles.samples = 20
        bpy.context.scene.cycles.preview_samples = 6
        context.scene.render.engine = 'CYCLES'
        context.scene.cycles.device = 'GPU'
        
        alllamps = bpy.data.lights
        for lamp in alllamps:
            lamp.cycles.max_bounces = 1024  

        return {'FINISHED'} 

######################################
#   Emission
######################################  
class MaterialEmissions(Operator):
    """
    CLICK - ADD EMISSION MATERIAL
    SHIFT - ADD NEW EMISSION MATERIAL
    """
    bl_idname = "object.to_emission"
    bl_label = "Add Emission"

    @classmethod                                     
    def poll(cls, context):                         
        obj = context.active_object
        if len([obj for obj in context.selected_objects if context.object is not None if obj.type in ['MESH','CURVE'] ]) >= 1:
            return True

    def invoke(self, context, event):
        ob = bpy.context.active_object
        if event.shift :
            material = bpy.data.materials.get("Emission")
            material = bpy.data.materials.new(name="Emission")
            material.use_nodes = True     
            material_output = material.node_tree.nodes.get('Material Output')
            emission = material.node_tree.nodes.new('ShaderNodeEmission')
            emission.inputs[1].default_value = 5.0
            
            # link emission shader to material
            material.node_tree.links.new(material_output.inputs[0], emission.outputs[0])  
                 
        else:
            material = bpy.data.materials.get("Emission")
            if material is None:
                material = bpy.data.materials.new(name="Emission")
                material.use_nodes = True
                
                # Remove default
                material.node_tree.nodes.remove(material.node_tree.nodes.get('Principled BSDF'))
                material_output = material.node_tree.nodes.get('Material Output')
                emission = material.node_tree.nodes.new('ShaderNodeEmission')
                emission.inputs[1].default_value = 5.0
                
                # link emission shader to material
                material.node_tree.links.new(material_output.inputs[0], emission.outputs[0])

        # Assign it to object
        if ob.data.materials:
            # assign to 1st material slot
            ob.data.materials[0] = material
        else:
            # no slots
            ob.data.materials.append(material)
        return {'FINISHED'}

class FalloffEmission(Operator):
    'Use the "light falloff" node to control the strength of the emitter'
    bl_idname = "lamp.use_falloff"
    bl_label = "Add Falloff"

    def execute(self, context):
        obj = context.active_object
        if obj.type == 'LIGHT':
            lamp = context.object.data
            add = bpy.data.lights[lamp.name].node_tree

            fallNode = add.nodes.new(type="ShaderNodeLightFalloff")
            
            #Location Node
            emiNode = add.nodes['Emission']
            fallNode.location.x = emiNode.location.x-200
            fallNode.location.y = emiNode.location.y
            
            #Connect
            fallOut = fallNode.outputs[0]
            emiIn = emiNode.inputs[1]
            add.links.new(fallOut, emiIn)
            
        elif obj.type in ['MESH', 'CURVE', 'TEXT']:
            mat = context.active_object.active_material
            add = bpy.context.active_object.data.materials[mat.name].node_tree

            fallNode = add.nodes.new(type="ShaderNodeLightFalloff")
            
            #Location Node
            emiNode = add.nodes['Emission']
            fallNode.location.x = emiNode.location.x-200
            fallNode.location.y = emiNode.location.y
            
            #Connect
            fallOut = fallNode.outputs[0]
            emiIn = emiNode.inputs[1]
            add.links.new(fallOut, emiIn)
        return {'FINISHED'}    
    
######################################
#   Base Texture
######################################  
class DiplayTextureSetup(Operator):
    """
    CLICK - ADD EMISSION MATERIAL
    """
    bl_idname = "object.display_texture"
    bl_label = "Display Texture"

    @classmethod                                     
    def poll(cls, context):                         
        obj = context.active_object
        if len([obj for obj in context.selected_objects if context.object is not None if obj.type in ['MESH','CURVE'] ]) >= 1:
            return True
        
    def execute(self, context):
        ob = bpy.context.active_object
        mat = context.active_object.active_material
        add = bpy.context.active_object.data.materials[mat.name].node_tree
            
        material = bpy.data.materials.get("Emission")
        if material is None:
            material = bpy.data.materials.new(name="Emission")
            material.use_nodes = True
    
            # Remove default
            material.node_tree.nodes.remove(material.node_tree.nodes.get('Principled BSDF'))
            material_output = material.node_tree.nodes.get('Material Output')
            
            # Add Emission
            emission = material.node_tree.nodes.new('ShaderNodeEmission')
            emission.inputs[1].default_value = 1.0
            
            emission.location.x = material_output.location.x-200
            emission.location.y = material_output.location.y
            
            # link emission shader to material
            material.node_tree.links.new(material_output.inputs[0], emission.outputs[0])
            
            # Add Image Texture
            teximage = material.node_tree.nodes.new('ShaderNodeTexImage')  
            teximage.location.x = emission.location.x-300
            teximage.location.y = emission.location.y 
                     
            # link texture to emission
            material.node_tree.links.new(emission.inputs[0], teximage.outputs[0])
            
            # Add Mapping
            map = material.node_tree.nodes.new('ShaderNodeMapping')  
            map.location.x = teximage.location.x-400
            map.location.y = teximage.location.y 
                     
            # link mapping to image texture
            material.node_tree.links.new(teximage.inputs[0], map.outputs[0])
            
            # Add Tex Coordinate
            coord = material.node_tree.nodes.new('ShaderNodeTexCoord')  
            coord.location.x = map.location.x-450
            coord.location.y = map.location.y 
                     
            # link text coord to mapping
            material.node_tree.links.new(map.inputs[0], coord.outputs[2])
            
        # Assign it to object
        if ob.data.materials:
            # assign to 1st material slot
            ob.data.materials[0] = material
        else:
            # no slots
            ob.data.materials.append(material)
        return {'FINISHED'}    
            