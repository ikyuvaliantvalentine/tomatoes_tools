# This file is part of Instant Clean
# Copyright (C) 2023  Ruben Messerschmidt

import bpy
from bpy.props import (BoolProperty, IntProperty, FloatProperty, EnumProperty)


class BC_PG_Objectdata_Settings(bpy.types.PropertyGroup):
    unused_material_slots: BoolProperty(
        name='Material Slots',
        default=True,
        description='Removes all material slots whose materials are not assigned to the mesh'
    )

    empty_vertex_groups: BoolProperty(
        name='Vertex Groups',
        default=True,
        description='Removes all vertex groups which have no vertices assigned to it'
    )