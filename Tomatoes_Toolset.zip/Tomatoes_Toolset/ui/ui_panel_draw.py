import bpy
from bpy.types import Panel, UIList
from bpy.props import *
from .. properties import *

#############################################
#   World UI
#############################################         
def draw_WORLD_Cycles_UI(context, layout):
    if context.scene.world:
        box = layout.box()
        col = box.column(align=True)
        row = col.row(align=True)
        
        row.label(text=context.scene.world.name, icon='WORLD')
        
        if context.scene.world.use_nodes:
            for node in context.scene.world.node_tree.nodes:
                if node.type == 'BACKGROUND':
                    row = col.row(align=True)
                    
                    ### COLOR ###
                    if not node.inputs[0].is_linked:
                        row.prop(node.inputs[0], 'default_value', text='')
                    else:
                        row.label(text='Connected')
                        
                    ### STRENGHT ###
                    if not node.inputs[1].is_linked:
                        row.prop(node.inputs[1], 'default_value', text='Strength')
                    else:
                        row.label(text='Connected')
                        
                if node.type == 'MAPPING':
                    col.prop(node,'rotation')
                        
        else:
            col.prop(context.scene.world, 'use_nodes', toggle=True)
            col.prop(context.scene.world, 'horizon_color', text='')
                                        
        split = box.split()

        col = split.column()

        col.label(text="Surface:")
        col.prop(context.scene.world.cycles, "sampling_method", text="Sampling")

        sub = col.column()
        sub.active = context.scene.world.cycles.sampling_method != 'NONE'
        subsub = sub.row(align=True)
        subsub.active = context.scene.world.cycles.sampling_method == 'MANUAL'
        subsub.prop(context.scene.world.cycles, "sample_map_resolution")

        col = split.column()
        col.label(text="Volume:")
        sub = col.column()
        sub.prop(context.scene.world.cycles, "volume_sampling", text="")
        sub.prop(context.scene.world.cycles, "volume_interpolation", text="")
        col.prop(context.scene.world.cycles, "homogeneous_volume", text="Homogeneous")
        
        col = box.column()
        col.label(text="Visibility:")
        row = col.row(align=True)
        row.prop(context.scene.world.cycles_visibility, "camera", text='Cam', toggle=True)
        row.prop(context.scene.world.cycles_visibility, "diffuse", text='Diff', toggle=True)
        row.prop(context.scene.world.cycles_visibility, "glossy", text='Spec', toggle=True)
        row.prop(context.scene.world.cycles_visibility, "transmission", text='Trans', toggle=True)
        row.prop(context.scene.world.cycles_visibility, "scatter", text='Vol_Scatter', toggle=True)
        
def UIWorld(self, context):
    layout = self.layout     
    tomatoes = context.scene.tomatoes_props
    row = layout.row()
    row.scale_y = 1.3        
    row.menu("VIEW3D_MT_menu_add_world",icon='WORLD')
    row.operator("word.open_world_editor",text="",icon='NODETREE')
    if context.scene.world:
        layout.prop(context.scene.world,'name')
    if len(bpy.data.worlds) > 0:
        layout.template_list("VIEW3D_UL_ListWorld", "", bpy.data, "worlds", tomatoes, "selected_world_index", rows=4)
        
    draw_WORLD_Cycles_UI(context, layout)

class VIEW3D_UL_ListWorld(UIList):    
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        layout.label(text=item.name,icon='WORLD_DATA')
        if item.name == bpy.context.scene.world.name:
            layout.label(text='',icon_value=get_icon("check_icon"))
        layout.operator('world.delete_world',icon='X',text="",emboss=False).world_name = item.name

####################################
# Panel Retopo 
####################################     
def UIRetopo(context, layout):
    layout.operator("object.tomatoes_setup_retopo")       
    layout.operator("laltools.sharpen_operator")      
    layout.operator("laltools.convert_operator")        
    
####################################
# Panel VFX 
####################################     
def UIVFX(context, layout):
    layout.label(text= "Rain Creator", icon= 'TRIA_RIGHT')
    layout.operator('add.new_emit_operator', text= "New Add Emitter")         
    layout.operator('add.collision_operator', text= "Make Collide")
    layout.label(text= "Add Ground", icon= 'TRIA_RIGHT')
    layout.operator('add.groundwater_operator', text= "Water")
    layout.label(text= "Add Field", icon= 'TRIA_RIGHT')
    layout.operator('add.wind_operator', text= "Wind")
    layout.operator('add.turbulance_operator', text= "Turbulance")
    layout.label(text= "Add Rigid body", icon= 'TRIA_RIGHT')
    row = layout.row()
    row.operator("add.rigidbody_operator", text="Active").type_rigid='active'
    row.operator("add.rigidbody_operator", text="Passive").type_rigid='passive'
    layout.operator("apply.rigidbody_operator", text="Apply")