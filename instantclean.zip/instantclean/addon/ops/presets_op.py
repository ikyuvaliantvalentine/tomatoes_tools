# This file is part of Instant Clean
# Copyright (C) 2023  Ruben Messerschmidt

import bpy
from bl_operators.presets import AddPresetBase
from bpy.types import Menu, Operator


class BC_MT_Preset_Menu(Menu):
    bl_label='Presets'
    bl_description='Choose Preset'
    preset_subdir='Instant Clean'
    preset_operator='script.execute_preset'
    draw = Menu.draw_preset

class BC_OT_Override_Preset(Operator):
    bl_idname='bc.override_preset'
    bl_label=''
    bl_description='Save changes to Preset'

    def execute(self, context):
        bpy.ops.bc.add_preset(name=BC_MT_Preset_Menu.bl_label)
        return {'FINISHED'}

class BC_OT_Add_Preset(AddPresetBase, Operator):
    bl_idname='bc.add_preset'
    bl_label=''
    bl_description='Add/Remove Preset'
    preset_menu='BC_MT_Preset_Menu'
    preset_subdir='Instant Clean'

    preset_defines=[
        'bc_states = bpy.context.scene.bc_states',
        'bc_repair = bpy.context.scene.bc_repair',
        'bc_limdiss = bpy.context.scene.bc_limdiss',
        'bc_topology = bpy.context.scene.bc_topology',
        'bc_normals = bpy.context.scene.bc_normals',
        'bc_objectdata = bpy.context.scene.bc_objectdata'
    ]

    preset_values=[
        # Repair
        'bc_states.repair',
        'bc_repair.loose',
        'bc_repair.loose_verts',
        'bc_repair.loose_edges',
        'bc_repair.loose_faces',
        'bc_repair.doubles',
        'bc_repair.doubles_dst',
        'bc_repair.zero_faces',
        'bc_repair.zero_faces_area',
        'bc_repair.dispensables',
        'bc_repair.dispensables_ang',
        'bc_repair.interiors',

        # Dissolve
        'bc_states.limdiss',
        'bc_limdiss.max_angle',
        'bc_limdiss.boundaries',
        'bc_limdiss.protect_sharp',
        'bc_limdiss.protect_seam',
        'bc_limdiss.protect_uv',
        'bc_limdiss.protect_materials',

        # Topology
        'bc_states.topology',
        'bc_topology.type',
        'bc_topology.quad_method',
        'bc_topology.ngon_method',
        'bc_topology.compare_sharp',
        'bc_topology.compare_seam',
        'bc_topology.compare_vcol',
        'bc_topology.compare_uv',
        'bc_topology.compare_material',

        # Normals
        'bc_states.normals',
        'bc_normals.recalculate',
        'bc_normals.recalculate_orientation',
        'bc_normals.auto_smooth',
        'bc_normals.auto_smooth_ang',
        'bc_normals.weighted_normals',

        # Objectdata
        'bc_states.objectdata',
        'bc_objectdata.unused_material_slots',
        'bc_objectdata.empty_vertex_groups'
    ]
