import bpy
from bpy.types import Operator

def multiply():
    bpy.context.scene.render.image_settings.file_format = 'PNG'
    bpy.context.scene.render.image_settings.color_mode = 'RGBA'
    bpy.context.scene.render.filepath = "/tmp\\"
    bpy.context.scene.view_layers["View Layer"].use_pass_ambient_occlusion = True
    bpy.context.scene.render.use_stamp_note = False
    bpy.context.scene.render.use_stamp = False

    bpy.context.scene.use_nodes = True
    tree = bpy.context.scene.node_tree
    links = tree.links
    
    for n in tree.nodes:
        tree.nodes.remove(n) 
        
    # create input render layer node
    rl = tree.nodes.new('CompositorNodeRLayers')
    rl.location = 0,200
    # create mix node
    mx = tree.nodes.new('CompositorNodeMixRGB')
    mx.location = 300,200
    links.new(rl.outputs[0],mx.inputs[1])
    links.new(rl.outputs["AO"],mx.inputs[2])
    mx.blend_type = "MULTIPLY"
    # create output node
    comp = tree.nodes.new('CompositorNodeComposite')   
    comp.location = 600,200
    links.new(mx.outputs[0],comp.inputs[0])

def multiply_char():
    bpy.context.scene.render.image_settings.file_format = 'PNG'
    bpy.context.scene.render.image_settings.color_mode = 'RGBA'
    bpy.context.scene.render.filepath = "/tmp\\"
    bpy.context.scene.view_layers["View Layer"].use_pass_ambient_occlusion = True
    bpy.context.scene.render.use_stamp_note = False
    bpy.context.scene.render.use_stamp = False

    bpy.context.scene.use_nodes = True
    tree = bpy.context.scene.node_tree
    links = tree.links
    
    for n in tree.nodes:
        tree.nodes.remove(n) 
        
    # create input image
    im = tree.nodes.new('CompositorNodeImage')
    im.location = 0, 500
    # create alpha Over
    ap = tree.nodes.new('CompositorNodeAlphaOver')
    ap.location = 600, 400
    links.new(im.outputs[0],ap.inputs[1])    
    # create input render layer node
    rl = tree.nodes.new('CompositorNodeRLayers')
    rl.location = 0,200
    # create mix node
    mx = tree.nodes.new('CompositorNodeMixRGB')
    mx.location = 300,200
    links.new(rl.outputs[0],mx.inputs[1])
    links.new(rl.outputs["AO"],mx.inputs[2])
    mx.blend_type = "MULTIPLY"
    # create output node
    comp = tree.nodes.new('CompositorNodeComposite')   
    comp.location = 900,350
    links.new(mx.outputs[0],ap.inputs[2])
    links.new(ap.outputs[0],comp.inputs[0])
    
class JinKepepetBasicBG(Operator):
    "Simple Setup For BG Jin Kepepet"
    bl_idname = "op.jkbasicbg"
    bl_label = "Basic BG"

    def execute(self, context):
        bpy.context.scene.transform_orientation_slots[0].type = 'GLOBAL'

        bpy.context.scene.render.resolution_x = 1920
        bpy.context.scene.render.resolution_y = 1080
        bpy.context.scene.render.resolution_percentage = 100
        bpy.context.scene.tool_settings.use_keyframe_insert_auto = False
        
        bpy.context.scene.render.use_lock_interface = True
        bpy.context.scene.render.film_transparent = True
        
        bpy.context.scene.eevee.taa_render_samples = 64
        bpy.context.scene.eevee.use_gtao = True
        bpy.context.scene.eevee.gtao_distance = 0.5
        bpy.context.scene.eevee.use_ssr = True
        bpy.context.scene.eevee.use_ssr_refraction = True
        bpy.context.scene.eevee.use_ssr_halfres = False
        bpy.context.scene.eevee.ssr_max_roughness = 0.3
        bpy.context.scene.eevee.ssr_quality = 1
        bpy.context.scene.eevee.ssr_border_fade = 0.1
        bpy.context.scene.eevee.shadow_cube_size = '1024'
        bpy.context.scene.eevee.shadow_cascade_size = '2048'
        bpy.context.scene.eevee.use_shadow_high_bitdepth = True
        bpy.context.scene.eevee.use_soft_shadows = True
        
        bpy.context.scene.render.use_simplify = True
        bpy.context.scene.render.simplify_subdivision = 0
        
        list = ["CHAR", "PROP", "SET"]
        for item in list:
            try:
                bpy.data.collections[list[0]].hide_render = True
                bpy.data.collections[list[0]].hide_viewport = True
                bpy.data.collections[list[1]].hide_render = True
                bpy.data.collections[list[1]].hide_viewport = True
                bpy.context.view_layer.layer_collection.children[list[2]].holdout = False
            except KeyError:
                self.report({'INFO'}, "Collection missing / not avaible / have different name. Operation still Continue")
                
        multiply()
        return {'FINISHED'}
    
class JinKepepetBasicChar(Operator):
    "Simple Setup For Char Jin Kepepet"
    bl_idname = "op.jkbasicchar"
    bl_label = "Basic Char"

    def execute(self, context):
        bpy.context.scene.transform_orientation_slots[0].type = 'GLOBAL'

        bpy.context.scene.render.resolution_x = 1920
        bpy.context.scene.render.resolution_y = 1080
        bpy.context.scene.render.resolution_percentage = 100
        bpy.context.scene.tool_settings.use_keyframe_insert_auto = False
        
        bpy.context.scene.render.use_lock_interface = True
        bpy.context.scene.render.film_transparent = True
        
        bpy.context.scene.eevee.taa_render_samples = 64
        bpy.context.scene.eevee.use_gtao = True
        bpy.context.scene.eevee.gtao_distance = 0.5
        bpy.context.scene.eevee.use_ssr = True
        bpy.context.scene.eevee.use_ssr_refraction = True
        bpy.context.scene.eevee.ssr_max_roughness = 0.1
        bpy.context.scene.eevee.ssr_quality = 1
        bpy.context.scene.eevee.ssr_border_fade = 0.1
        bpy.context.scene.eevee.shadow_cube_size = '1024'
        bpy.context.scene.eevee.shadow_cascade_size = '2048'
        bpy.context.scene.eevee.use_shadow_high_bitdepth = True
        bpy.context.scene.eevee.use_soft_shadows = True
        
        bpy.context.scene.render.use_simplify = True
        bpy.context.scene.render.simplify_subdivision = 0
        
        list = ["CHAR", "PROP", "SET"]
        for item in list:
            try:
                bpy.data.collections[list[0]].hide_render = False
                bpy.data.collections[list[0]].hide_viewport = False
                bpy.data.collections[list[1]].hide_render = False
                bpy.data.collections[list[1]].hide_viewport = False
                bpy.context.view_layer.layer_collection.children[list[2]].holdout = True
            except KeyError:
                self.report({'INFO'}, "Collection missing / not avaible / have different name. Operation still Continue")
        
        multiply_char()
        return {'FINISHED'}
    
class JinKepepetBasicTest(Operator):
    "Simple Setup For Test Jin Kepepet"
    bl_idname = "op.jktest"
    bl_label = "Test"

    def execute(self, context):
        bpy.context.scene.transform_orientation_slots[0].type = 'GLOBAL'

        bpy.context.scene.render.resolution_x = 1920
        bpy.context.scene.render.resolution_y = 1080
        bpy.context.scene.render.resolution_percentage = 50
        bpy.context.scene.tool_settings.use_keyframe_insert_auto = False
        
        bpy.context.scene.render.use_lock_interface = True
        bpy.context.scene.render.film_transparent = True
        
        bpy.context.scene.eevee.taa_render_samples = 16
        bpy.context.scene.eevee.use_gtao = True
        bpy.context.scene.eevee.gtao_distance = 0.5
        bpy.context.scene.eevee.use_ssr = True
        bpy.context.scene.eevee.use_ssr_refraction = True
        bpy.context.scene.eevee.ssr_quality = 1
        bpy.context.scene.eevee.ssr_border_fade = 0.1
        bpy.context.scene.eevee.shadow_cube_size = '1024'
        bpy.context.scene.eevee.shadow_cascade_size = '2048'
        bpy.context.scene.eevee.use_shadow_high_bitdepth = True
        bpy.context.scene.eevee.use_soft_shadows = True
        
        multiply()
        return {'FINISHED'}
    
class ShadowJinKepepet(Operator):
    """Quick Shadow Preset"""
    bl_idname = "op.shadowjinkepepet"
    bl_label = "Set Shadow"

    def execute(self, context):
        bpy.context.scene.eevee.shadow_cube_size = '2048'
        bpy.context.scene.eevee.shadow_cascade_size = '4096'
        bpy.context.scene.eevee.use_shadow_high_bitdepth = True 
        bpy.context.scene.eevee.use_soft_shadows = True
        
        list = ["CHAR", "PROP", "SET"]
        for item in list:
            try:
                bpy.context.view_layer.layer_collection.children[list[0]].holdout = True
                bpy.context.view_layer.layer_collection.children[list[1]].holdout = True
                bpy.context.view_layer.layer_collection.children[list[2]].hide_viewport = True
                bpy.context.view_layer.layer_collection.children[list[2]].holdout = True
            except KeyError:
                self.report({'INFO'}, "Collection missing / not avaible / have different name. Operation still Continue")
                
        return {'FINISHED'}

class PresetsCombineJinKepepet(Operator):
    "Presets for compose 2 image"
    bl_idname = "node.compose_image"
    bl_label = "Compose Image"

    def execute(self, context):
        # switch on nodes and get reference
        bpy.context.scene.use_nodes = True
        tree = bpy.context.scene.node_tree
        links = tree.links

        prev = bpy.context.area.type
        bpy.context.area.type = 'NODE_EDITOR'

        area = bpy.context.area      
        
        # clear default nodes
        for n in tree.nodes:
            tree.nodes.remove(n)

        # create input image
        im = tree.nodes.new('CompositorNodeImage')
        im.location = 0, 500
        # create input render layer node
        im2 = tree.nodes.new('CompositorNodeImage')
        im2.location = 0,200
        # create alpha Over
        ap = tree.nodes.new('CompositorNodeAlphaOver')
        ap.location = 300, 400
        links.new(im.outputs[0],ap.inputs[1])    
        links.new(im2.outputs[0],ap.inputs[2])    
        # create output node
        comp = tree.nodes.new('CompositorNodeComposite')   
        comp.location = 600,350
        links.new(ap.outputs[0],comp.inputs[0])

        bpy.context.area.type = prev
        return {'FINISHED'}

class PresetsBGJinKepepet(Operator):
    "Presets Background Jin kepepet"
    bl_idname = "node.bg"
    bl_label = "Background"

    def execute(self, context):
        # switch on nodes and get reference
        bpy.context.scene.use_nodes = True
        tree = bpy.context.scene.node_tree
        links = tree.links

        prev = bpy.context.area.type
        bpy.context.area.type = 'NODE_EDITOR'

        area = bpy.context.area      
        
        # clear default nodes
        for n in tree.nodes:
            tree.nodes.remove(n)

        # create input image
        im = tree.nodes.new('CompositorNodeImage')
        im.location = 0, 500
        # create input render layer node
        im2 = tree.nodes.new('CompositorNodeImage')
        im2.location = 0,200
        # create alpha Over
        ap = tree.nodes.new('CompositorNodeAlphaOver')
        ap.location = 300, 400
        links.new(im.outputs[0],ap.inputs[1])    
        links.new(im2.outputs[0],ap.inputs[2])    
        # create output node
        comp = tree.nodes.new('CompositorNodeComposite')   
        comp.location = 600,350
        links.new(ap.outputs[0],comp.inputs[0])

        bpy.context.area.type = prev
        return {'FINISHED'}