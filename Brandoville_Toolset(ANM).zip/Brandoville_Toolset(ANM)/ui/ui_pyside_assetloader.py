import os
import re
import bpy
from PySide2.QtWidgets import *
from PySide2.QtCore import Qt
from PySide2.QtGui  import QIcon
from PySide2 import QtWidgets, QtCore, QtGui
from os.path import join, dirname, normpath
import shutil

class BlendFileSelector(QWidget):
    @staticmethod
    def show_message_box(message):
        msg = QtWidgets.QMessageBox()
        msg.setWindowFlags(QtCore.Qt.WindowStaysOnTopHint)
        msg.setWindowTitle("Info Popup")
        msg.setIcon(QtWidgets.QMessageBox.Warning)
        msg.setText(message)
        msg.setStandardButtons(QtWidgets.QMessageBox.Ok)
        msg.setStyleSheet("background-color: #5d5d5d; color: white;")
        msg.exec_()

    @staticmethod
    def show_info_message_box(message):
        msg = QtWidgets.QMessageBox()
        msg.setWindowFlags(QtCore.Qt.WindowStaysOnTopHint)
        msg.setWindowTitle("Info Popup")
        msg.setIcon(QtWidgets.QMessageBox.Information)
        msg.setText(message)
        msg.setStandardButtons(QtWidgets.QMessageBox.Ok)
        msg.setStyleSheet("background-color: #5d5d5d; color: white;")
        msg.exec_()

    @staticmethod
    def get_current_context():
        win = bpy.context.window_manager.windows[0]
        area = win.screen.areas[0]
        return win, area

    def __init__(self, base_directory):
        super().__init__()

        self.base_directory = base_directory

        self.initUI()
        
    def initUI(self):

        # Set the background color
        self.setStyleSheet("background-color: #494949;")

        self.setWindowTitle("Shot Loader v02")
        self.setGeometry(100, 100, 800, 300)
        self.setWindowFlags(self.windowFlags() | Qt.WindowStaysOnTopHint)

        layout = QVBoxLayout()

        # Add a base directory selection dropdown
        category_layout = QHBoxLayout()

        category_label = QLabel("Episode:")
        category_label.setStyleSheet("color: white;")

        self.base_directory_combo = QComboBox()
        self.base_directory_combo.setStyleSheet("color: white;")
        self.base_directory_combo.currentIndexChanged.connect(self.populate_assets)

        category_layout.addWidget(category_label)
        category_layout.addWidget(self.base_directory_combo)

        category_layout.setSpacing(10)
        category_layout.setAlignment(Qt.AlignLeft)

        self.base_directory_combo.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)

        layout.addLayout(category_layout)

        # Left Column Layout
        left_column_layout = QVBoxLayout()
        
        spacer_item = QSpacerItem(20, 25)

        self.search_input = QLineEdit()
        self.search_input.setPlaceholderText("Search Sequence Name...")
        self.search_input.setStyleSheet("color: white;")
        self.search_input.textChanged.connect(self.search_assets)
        self.search_input.setFixedHeight(25)

        # Connect both signals to populate assets and update search filter
        self.base_directory_combo.currentIndexChanged.connect(self.populate_assets)
        self.base_directory_combo.currentIndexChanged.connect(self.search_assets)

        asset_name_label = QLabel("Sequence :")
        asset_name_label.setStyleSheet("color: white;")
        asset_name_label.setAlignment(Qt.AlignLeft)

        self.asset_list = QListWidget()

        self.asset_list.setStyleSheet('''
            QWidget {
                background-color: #2b2b2b;
                color: white;
            }
            QListWidget::item:selected {
                background: rgb(128,128,255);
            }
        ''')

        # Asset List List Need Update for Subfolder List
        self.asset_list.itemClicked.connect(self.populate_subfolders)

        left_column_layout.addItem(spacer_item)
        left_column_layout.addWidget(self.search_input)
        left_column_layout.addWidget(asset_name_label)
        left_column_layout.addWidget(self.asset_list)
        
        
        # Add a list widget for listing subfolders
        subfolder_list_label = QLabel("Shot :")
        subfolder_list_label.setStyleSheet("color: white;")
        subfolder_list_label.setAlignment(Qt.AlignLeft)

        self.subfolder_list = QListWidget()

        self.subfolder_list.setStyleSheet('''
            QWidget {
                background-color: #2b2b2b;
                color: white;
            }
            QListWidget::item:selected {
                background: rgb(128,128,255);
            }
        ''')

        left_column_layout.addWidget(subfolder_list_label)
        left_column_layout.addWidget(self.subfolder_list)
        
        # Subfolder List Need Update the Blend_List
        self.subfolder_list.itemClicked.connect(self.update_blend_files)
    

        # Right Column Layout
        right_column_layout = QVBoxLayout()

        stage_groupbox = QGroupBox("Stage")
        stage_groupbox.setStyleSheet("color: white;")
        stage_groupbox.setAlignment(Qt.AlignLeft)

        stage_layout = QHBoxLayout()

        self.layout_radio = QRadioButton("Layout")
        self.layout_radio.setStyleSheet("color: white;")
        self.primary_radio = QRadioButton("Primary")
        self.primary_radio.setStyleSheet("color: white;")
        self.secondary_radio = QRadioButton("Secondary")
        self.secondary_radio.setStyleSheet("color: white;")

        self.layout_radio.toggled.connect(self.update_blend_files)
        self.primary_radio.toggled.connect(self.update_blend_files)
        self.secondary_radio.toggled.connect(self.update_blend_files)

        stage_layout.addWidget(self.layout_radio)
        stage_layout.addWidget(self.primary_radio)
        stage_layout.addWidget(self.secondary_radio)

        stage_groupbox.setLayout(stage_layout)

        blend_list_label = QLabel("Versions:")
        blend_list_label.setStyleSheet("color: white;")
        blend_list_label.setAlignment(Qt.AlignLeft)

        self.blend_list = QListWidget()
        
        self.blend_list.setStyleSheet('''
            QWidget {
                background-color: #2b2b2b;
                color: white;
            }
            QListWidget::item:selected {
                background: rgb(128,128,255);
            }
        ''')

        right_column_layout.addWidget(stage_groupbox)
        right_column_layout.addWidget(blend_list_label)
        right_column_layout.addWidget(self.blend_list)

        # Combine Left and Right Columns in Main Layout
        main_layout = QHBoxLayout()
        main_layout.addLayout(left_column_layout)
        main_layout.addLayout(right_column_layout)

        layout.addLayout(category_layout)
        layout.addLayout(main_layout)

        # Add a link/append option checkbox
        option_layout = QHBoxLayout()

        self.button_group = QButtonGroup()  # Create a button group

        self.open_option = QRadioButton("Open")
        self.save_option = QRadioButton("Save")

        self.button_group.addButton(self.open_option)
        self.button_group.addButton(self.save_option)

        # Add the "Open Blend File" button
        self.refresh_assets_button = QPushButton("Refresh", clicked=self.refresh_assets)
        self.save_button = QPushButton("Save", clicked=self.save_blend_file)
        self.open_button = QPushButton("Load", clicked=self.open_blend_file)

        self.refresh_assets_button.setStyleSheet("background-color: #5d5d5d; color: white;")
        self.save_button.setStyleSheet("background-color: #5d5d5d; color: white;")
        self.open_button.setStyleSheet("background-color: #5d5d5d; color: white;")

        # Set the fixed size for the button (adjust the values as needed)
        self.refresh_assets_button.setFixedSize(70, 30)
        self.open_button.setFixedSize(100, 30)
        self.save_button.setFixedSize(100, 30)

        # Set the icon for the "Refresh" button
        icons_folder = join(dirname(__file__), "custom_icons")
        icon_path = join(icons_folder, "refresh.png")
        icon_path = icon_path.replace("\\", "/")
        icon_path = icon_path.replace("/ui/", "/") # Modify the path to change "ui/custom_icons" to "custom_icons"
        self.refresh_assets_button.setIcon(QIcon(icon_path))

        # Add a vertical separator
        separator = QFrame()
        separator.setFrameShape(QFrame.VLine)
        separator.setFrameShadow(QFrame.Sunken)

        spacer = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)
        option_layout.addItem(spacer)
        option_layout.addWidget(self.refresh_assets_button)

        option_layout.addWidget(separator)
        
        option_layout.addWidget(self.save_button)
        option_layout.addWidget(self.open_button)
 
        layout.addLayout(option_layout)

        self.setLayout(layout)

        self.populate_base_directories()
        self.populate_assets()

        # Connect the contextMenuEvent to self.asset_list
        self.asset_list.setContextMenuPolicy(Qt.CustomContextMenu)
        self.asset_list.customContextMenuRequested.connect(self.show_asset_list_context_menu)

        self.subfolder_list.setContextMenuPolicy(Qt.CustomContextMenu)
        self.subfolder_list.customContextMenuRequested.connect(self.show_asset_list_context_menu)

    def show_asset_list_context_menu(self, pos):
        sender = self.sender()

        context_menu = QMenu(self)

        # Check if an item is selected in the corresponding list
        # if sender == self.asset_list and self.asset_list.currentItem() is not None:
        if sender == self.asset_list:
            # Create a new folder action
            create_folder_action = QAction('Create New Folder', self)
            create_folder_action.triggered.connect(self.create_new_folder)
            context_menu.addAction(create_folder_action)

        elif sender == self.subfolder_list:
            # Create a new subfolder action
            create_subfolder_action = QAction('Create New SubFolder', self)
            create_subfolder_action.triggered.connect(self.create_new_subfolder)
            context_menu.addAction(create_subfolder_action)

        context_menu.setStyleSheet("QMenu { background-color: #8080ff; }")  # Set your desired color

        context_menu.exec_(sender.mapToGlobal(pos))

    def create_new_folder(self):
        selected_asset = self.asset_list.currentItem()

        # if selected_asset is not None:
        custom_input_dialog = QInputDialog(self)
        custom_input_dialog.setInputMode(QInputDialog.TextInput)
        custom_input_dialog.setWindowTitle('Create New Folder')
        # custom_input_dialog.setLabelText('Enter folder name:')
        custom_input_dialog.setLabelText('<font color="white">Enter folder name:</font>')
        custom_input_dialog.setStyleSheet("color: white;")

        # line_edit = custom_input_dialog.findChild(QLineEdit)
        # line_edit.setStyleSheet("color: white;")

        custom_input_dialog.setStyleSheet("""
                QLabel { color: white; }
                QLineEdit { color: white;}
                QPushButton { color: white;}
            """)

        ok_pressed = custom_input_dialog.exec_()
        new_folder_name = custom_input_dialog.textValue()

        if ok_pressed and new_folder_name:
            base_dir = os.path.join(self.base_directory, self.base_directory_combo.currentText())
            asset_path = os.path.join(base_dir, new_folder_name)

            try:
                os.makedirs(asset_path)
                self.show_info_message_box(f"New folder created successfully:\n{asset_path}")
                # Refresh the assets after creating a new folder
                self.populate_assets()
            except Exception as e:
                self.show_message_box(f"Error creating new folder:\n{str(e)}")

    def create_new_subfolder(self):
        selected_asset = self.asset_list.currentItem()

        if selected_asset is not None:
            selected_asset_name = selected_asset.text()
            
            # Create a custom input dialog
            custom_input_dialog = QInputDialog(self)
            custom_input_dialog.setInputMode(QInputDialog.TextInput)
            custom_input_dialog.setWindowTitle('Create New Subfolder')
            custom_input_dialog.setLabelText('<font color="white">Enter subfolder name:</font>')
            
            # Set the stylesheet for the dialog, label, and input field
            custom_input_dialog.setStyleSheet("""
                QLabel { color: white; }
                QLineEdit { color: white;}
                QPushButton { color: white;}
            """)

            # Show the dialog and get the input
            ok_pressed = custom_input_dialog.exec_()
            new_subfolder_name = custom_input_dialog.textValue()

            if ok_pressed and new_subfolder_name:
                base_dir = os.path.join(self.base_directory, self.base_directory_combo.currentText())
                asset_path = os.path.join(base_dir, selected_asset_name)
                subfolder_path = os.path.join(asset_path, new_subfolder_name)

                try:
                    os.makedirs(subfolder_path)
                    self.show_info_message_box(f"New subfolder created successfully:\n{subfolder_path}")
                    # Refresh the subfolders after creating a new subfolder
                    self.populate_subfolders()
                except Exception as e:
                    self.show_message_box(f"Error creating new subfolder:\n{str(e)}")
        else:
            self.show_message_box("Please select an item in the asset list before creating a new subfolder.")

    def populate_base_directories(self):
        base_directories = os.listdir(self.base_directory)
        self.base_directory_combo.addItems(base_directories)

    def populate_assets(self):
        selected_folder = self.base_directory_combo.currentText()
        assets = os.listdir(os.path.join(self.base_directory, selected_folder))
        self.asset_list.clear()
        self.asset_list.addItems(assets)
        
        # Populate subfolders
        self.populate_subfolders()
        
        # # Update blend files
        # self.update_blend_files()
        
    def populate_subfolders(self):
        selected_asset = self.asset_list.currentItem()
        self.subfolder_list.clear()

        if selected_asset is not None:
            base_dir = os.path.join(self.base_directory, self.base_directory_combo.currentText())
            asset_path = os.path.join(base_dir, selected_asset.text())

            subfolders = [f for f in os.listdir(asset_path) if os.path.isdir(os.path.join(asset_path, f))]
            self.subfolder_list.addItems(subfolders)
        
        # # Update blend files
        # self.update_blend_files()
        
    def update_blend_files(self):
        self.blend_list.clear()
        selected_asset = self.asset_list.currentItem()
        selected_subfolder = self.subfolder_list.currentItem()
        
        if selected_asset is not None and selected_subfolder is not None:
            base_dir = os.path.join(self.base_directory, self.base_directory_combo.currentText())
            asset_path = os.path.join(base_dir, selected_asset.text())
            
            # Determine the selected stage based on the radio buttons
            if self.layout_radio.isChecked():
                stage_folder = "Layout"
            elif self.primary_radio.isChecked():
                stage_folder = "Primary"
            elif self.secondary_radio.isChecked():
                stage_folder = "Secondary"
            else:
                print("Error: No stage selected.")
                return  
     
            # Update the stage_folder attribute
            self.stage_folder = stage_folder
        
            subfolder = selected_subfolder.text()
            stage_path = os.path.join(asset_path, subfolder, "WIP", stage_folder)
            
            if os.path.exists(stage_path):
                blend_files = [os.path.splitext(f)[0] for f in os.listdir(stage_path) if f.endswith(".blend")]
                self.blend_list.addItems(blend_files)
            else:
                print(f"No '{stage_folder}' folder found in {asset_path}")
      
    def search_assets(self):
        search_text = self.search_input.text().lower()
        items = self.asset_list.findItems("", Qt.MatchContains)

        for item in items:
            if search_text in item.text().lower():
                item.setHidden(False)
            else:
                item.setHidden(True)

        # Search in subfolder list
        subfolder_items = self.subfolder_list.findItems("", Qt.MatchContains)
        for subfolder_item in subfolder_items:
            if search_text in subfolder_item.text().lower():
                subfolder_item.setHidden(False)
            else:
                subfolder_item.setHidden(True)

    def refresh_assets(self):
        # Store the currently selected items' text
        selected_asset_text = None
        current_asset_item = self.asset_list.currentItem()
        if current_asset_item:
            selected_asset_text = current_asset_item.text()

        selected_subfolder_text = None
        current_subfolder_item = self.subfolder_list.currentItem()
        if current_subfolder_item:
            selected_subfolder_text = current_subfolder_item.text()

        selected_blend_text = None
        current_blend_item = self.blend_list.currentItem()
        if current_blend_item:
            selected_blend_text = current_blend_item.text()

        # Clear existing items in subfolder_list and blend_list
        self.subfolder_list.clear()
        self.blend_list.clear()

        # Repopulate subfolders
        self.populate_subfolders()

        # Attempt to select the previously selected items
        if selected_asset_text:
            items = self.asset_list.findItems(selected_asset_text, Qt.MatchExactly)
            if items:
                self.asset_list.setCurrentItem(items[0])

        if selected_subfolder_text:
            items = self.subfolder_list.findItems(selected_subfolder_text, Qt.MatchExactly)
            if items:
                self.subfolder_list.setCurrentItem(items[0])

        # Update blend files after subfolders are populated
        self.update_blend_files()

        if selected_blend_text:
            items = self.blend_list.findItems(selected_blend_text, Qt.MatchExactly)
            if items:
                self.blend_list.setCurrentItem(items[0])

    def save_blend_file(self):
        win, area = self.get_current_context()
        with bpy.context.temp_override(window=win, screen=win.screen, area=area):
            selected_subfolder_item = self.subfolder_list.currentItem()

            if not selected_subfolder_item:
                self.show_message_box("Please select a subfolder to save.")
                return

            subfolder_name = selected_subfolder_item.text()
            selected_folder = self.base_directory_combo.currentText()

            # Determine the selected stage
            stage = ""
            if self.layout_radio.isChecked():
                stage = "Layout"
                type = "ANIM"  # Change type for Layout stage
                jobtype = "Lay"  # Change jobtype for Layout stage
            elif self.primary_radio.isChecked():
                stage = "Primary"
                type = "ANIM"  # Restore original type for Primary stage
                jobtype = "Prim"  # Restore original jobtype for Primary stage
            elif self.secondary_radio.isChecked():
                stage = "Secondary"
                type = "ANIM"  # Restore original type for Secondary stage
                jobtype = "Sec"  # Restore original jobtype for Secondary stage
            else:
                self.show_message_box("Please select a stage (Layout, Primary, or Secondary) to save.")
                return

            # Get the source blend file path
            selected_asset_item = self.asset_list.currentItem()
            if not selected_asset_item:
                self.show_message_box("Please select an asset to save.")
                return

            asset_name = selected_asset_item.text()
            source_blend_path = os.path.join(self.base_directory, selected_folder, asset_name, subfolder_name, "WIP", stage)

            # Ensure the folder for the selected stage and WIP exists
            if not os.path.exists(source_blend_path):
                os.makedirs(source_blend_path)

            # Set the version number to 1
            version = 1

            prefix = "ETY"
            savename = asset_name + "_" + subfolder_name

            file_exists = True
            while file_exists:
                # Generate the filename with the current version number
                target_blend_path = os.path.join(
                    source_blend_path,
                    f"{prefix}_{savename}_{type}_{jobtype}_v{version:03d}.blend"
                )

                # Check if the file already exists
                if os.path.exists(target_blend_path):
                    version += 1
                else:
                    file_exists = False

            try:
                # Save the blend file using bpy.ops.wm.save_as_mainfile
                bpy.ops.wm.save_as_mainfile(filepath=target_blend_path, relative_remap=True, compress=True, check_existing=True)
                self.show_info_message_box(f"Blend file saved successfully to:\n{target_blend_path}")
            except Exception as e:
                self.show_message_box(f"Error saving blend file:\n{str(e)}")

        self.update_blend_files()

        
    def open_blend_file(self):
        selected_blend = self.blend_list.currentItem()
        selected_asset = self.asset_list.currentItem()
        if selected_blend is not None and selected_asset is not None:
            base_dir = os.path.join(self.base_directory, self.base_directory_combo.currentText())
            asset_path = os.path.join(base_dir, selected_asset.text())

            # Determine the selected stage based on the radio buttons
            if self.layout_radio.isChecked():
                stage_folder = "Layout"
            elif self.primary_radio.isChecked():
                stage_folder = "Primary"
            elif self.secondary_radio.isChecked():
                stage_folder = "Secondary"
  
            subfolder = self.subfolder_list.currentItem().text()
            publish_path = os.path.join(asset_path, subfolder, "WIP", stage_folder, selected_blend.text() + ".blend")

            # print(f"Selected Asset: {selected_asset.text()}")
            # print(f"Base Directory: {base_dir}")
            # print(f"Asset Path: {asset_path}")
            # print(f"Publish Path: {publish_path}")

            bpy.ops.wm.open_mainfile(filepath=publish_path)
            
     