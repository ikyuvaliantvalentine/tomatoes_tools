import bpy
import re
import os
import shutil
from bpy.types import Operator 

class Playblast(Operator):
    "Render Animation Preview"
    bl_idname = "op.scene_playblast"
    bl_label = "Playblast"
    
    def get_parent_directory(self, path):
        path_components = os.path.normpath(path).split(os.path.sep)
        parent_path = os.path.sep.join(path_components[:-1])
        return parent_path
    
    def execute(self, context):
        current_file = bpy.data.filepath
        file_name_with_version = os.path.splitext(os.path.basename(current_file))[0]
        
        src_folder = os.path.dirname(os.path.dirname(current_file))
        archive_folder = os.path.join(src_folder, "archive")
        
        # Extract file name and version number
        file_name, version_str = file_name_with_version.rsplit("_v", 1)
        version = int(version_str) if version_str.isdigit() else 1

#         # Find the highest existing version number
# #        existing_versions = [f for f in os.listdir(src_folder) if f.startswith(f"{file_name}_v") and f.endswith(".mp4")]
#         existing_versions = [f for f in os.listdir(src_folder) if f.startswith(f"{file_name}_v") and f.endswith(".mov")]
#         if existing_versions:
#             existing_versions = [int(v.split("_v")[1].split(".mov")[0]) for v in existing_versions]
# #            existing_versions = [int(v.split("_v")[1].split(".mp4")[0]) for v in existing_versions]
#             version = max(existing_versions) + 1
#         else:
#             version = 1

        # # Find the highest existing version number
        # existing_versions = [f for f in os.listdir(src_folder) if f.startswith(f"{file_name}_v") and f.endswith(".mov")]
        # if existing_versions:
        #     existing_versions = [int(v.split("_v")[1].split(".mov")[0]) for v in existing_versions if v.split("_v")[1].split(".mov")[0].isdigit()]
        #     if existing_versions:
        #         version = max(existing_versions) + 1
        #     else:
        #         version += 1
        # else:
        #     version = 1

        # Find the highest existing version number
        existing_versions = [f for f in os.listdir(src_folder) if f.startswith(f"{file_name}_v") and f.endswith(".mov")]
        existing_version_numbers = []
        for v in existing_versions:
            try:
                v_number = int(v.split("_v")[1].split(".mov")[0])
                existing_version_numbers.append(v_number)
            except ValueError:
                pass
        
        if existing_version_numbers:
            version = max(existing_version_numbers) + 1

        # Create a new versioned filepath
        new_filepath = f"{src_folder}/{file_name}_v{version:04d}.mov"
        new_filepath = bpy.path.native_pathsep(new_filepath)
        bpy.context.scene.render.filepath = new_filepath

        # Check if archive folder exists, if not, create it
        if not os.path.exists(archive_folder):
            os.makedirs(archive_folder)

        # Move old version to the archive folder
        old_version = version - 1
        old_file = f"{src_folder}/{file_name}_v{old_version:04d}.mov"
        if os.path.exists(old_file):
            shutil.move(old_file, f"{archive_folder}/{os.path.basename(old_file)}")


        bpy.context.space_data.overlay.show_overlays = False
        bpy.context.scene.render.use_stamp = True
        bpy.context.scene.render.use_stamp_frame = True

        previous = bpy.context.scene.render.image_settings.file_format
        if(previous != "FFMPEG"):
            rd = bpy.context.scene.render
            rd.image_settings.file_format = "FFMPEG"
            rd.ffmpeg.format = "QUICKTIME"
            rd.ffmpeg.codec = "H264"

        try:
            bpy.ops.render.opengl(animation=True)
            bpy.ops.render.play_rendered_anim()
            
        except:
            self.report({'ERROR'}, "Scene has to be saved first!")
                    
        if(previous != "FFMPEG"):
            bpy.context.scene.render.image_settings.file_format = previous

        return {'FINISHED'}


class Local_Playblast(Operator):
    "Render Animation Preview"
    bl_idname = "op.local_playblast"
    bl_label = "Local Playblast"

    def execute(self, context):
        lpb_dir = os.path.join(os.path.expanduser("~"), "Documents", "local_playblasts")
        if not os.path.exists(lpb_dir):
            os.makedirs(lpb_dir)

        # Get the current blend file name
        shn = bpy.path.basename(bpy.data.filepath)
        shn_filename = os.path.splitext(shn)[0]
        pb_file = shn_filename + ".mp4"
        pb_path = os.path.join(lpb_dir, pb_file)

        # Save current shading and overlay state
        space = bpy.context.area.spaces.active
        original_shading_type = space.shading.color_type
        overlays_enabled = space.overlay.show_overlays

        space.shading.color_type = 'TEXTURE'
        space.overlay.show_overlays = False

        # Set Metadata
        bpy.context.scene.render.use_stamp = True
        bpy.context.scene.render.use_stamp_date = False
        bpy.context.scene.render.use_stamp_time = False
        bpy.context.scene.render.use_stamp_render_time = False
        bpy.context.scene.render.use_stamp_frame = True
        bpy.context.scene.render.use_stamp_frame_range = False
        bpy.context.scene.render.use_stamp_memory = False
        bpy.context.scene.render.use_stamp_hostname = True
        bpy.context.scene.render.use_stamp_camera = False
        bpy.context.scene.render.use_stamp_lens = True
        bpy.context.scene.render.use_stamp_scene = False
        bpy.context.scene.render.use_stamp_marker = False
        bpy.context.scene.render.use_stamp_filename = True
        bpy.context.scene.render.use_stamp_sequencer_strip = False
        bpy.context.scene.render.stamp_font_size = 20

        bpy.context.scene.render.image_settings.file_format = "FFMPEG"
        bpy.context.scene.render.ffmpeg.format = "MPEG4"
        bpy.context.scene.render.ffmpeg.codec = "H264"

        # Set the output file path
        bpy.context.scene.render.filepath = pb_path

        # Perform the playblast (render animation)
        try:
            bpy.ops.render.opengl(animation=True)
            bpy.ops.render.play_rendered_anim()
            self.report({'INFO'}, "Success: Playblast generated at {0}".format(pb_path))
        except Exception as e:
            self.report({'ERROR'}, "Error: {0}".format(str(e)))

        space.shading.color_type = original_shading_type
        space.overlay.show_overlays = overlays_enabled
        
        return {'FINISHED'}

def is_file_in_use(file_path):
    """Cek apakah file sedang digunakan oleh proses lain."""
    if not os.path.exists(file_path):
        return False
    
    try:
        temp_path = file_path + ".tmp"
        os.rename(file_path, temp_path)
        os.rename(temp_path, file_path)
        return False  # File tidak sedang digunakan
    except OSError:
        return True  # File sedang digunakan


# class PublishShotOperator(bpy.types.Operator):
#     bl_idname = "wm.publish_shot"
#     bl_label = "Publish Shot"

#     @staticmethod
#     def publish_playblast(base_dir):
#         shn = bpy.path.basename(bpy.data.filepath)
#         shn_filename = os.path.splitext(shn)[0]
#         pb_file = shn_filename + ".mp4"
#         split_shot_code = shn_filename.split("_")

#         if len(split_shot_code) < 5:
#             print("Error: Invalid shot name.")
#             return None, "Invalid shot name."

#         path = bpy.data.filepath
#         folder_name = os.path.basename(os.path.dirname(path))
#         published_pb_dir = os.path.join(base_dir, "Publish", folder_name, "Playblast")

#         if not os.path.exists(published_pb_dir):
#             os.makedirs(published_pb_dir)

#         # REMOVE EXTENSION from filepath to avoid Blender adding frame range into filename
#         pb_path_published = os.path.join(published_pb_dir, pb_file)

#         # Save current shading and overlay state
#         space = bpy.context.area.spaces.active
#         original_shading_type = space.shading.color_type
#         overlays_enabled = space.overlay.show_overlays

#         space.shading.color_type = 'TEXTURE'
#         space.overlay.show_overlays = False

#         # Set Metadata
#         bpy.context.scene.render.use_stamp = True
#         bpy.context.scene.render.use_stamp_date = False
#         bpy.context.scene.render.use_stamp_time = False
#         bpy.context.scene.render.use_stamp_render_time = False
#         bpy.context.scene.render.use_stamp_frame = True
#         bpy.context.scene.render.use_stamp_frame_range = False
#         bpy.context.scene.render.use_stamp_memory = False
#         bpy.context.scene.render.use_stamp_hostname = True
#         bpy.context.scene.render.use_stamp_camera = False
#         bpy.context.scene.render.use_stamp_lens = True
#         bpy.context.scene.render.use_stamp_scene = False
#         bpy.context.scene.render.use_stamp_marker = False
#         bpy.context.scene.render.use_stamp_filename = True
#         bpy.context.scene.render.use_stamp_sequencer_strip = False
#         bpy.context.scene.render.stamp_font_size = 20

#         bpy.context.scene.render.image_settings.file_format = "FFMPEG"
#         bpy.context.scene.render.ffmpeg.format = "MPEG4"
#         bpy.context.scene.render.ffmpeg.codec = "H264"


#         # SET FILEPATH (without extension)
#         bpy.context.scene.render.filepath = pb_path_published
        
#         # Perform the playblast (render animation)
#         try:
#             bpy.ops.render.opengl(animation=True)
#             bpy.ops.render.play_rendered_anim()
#             print("Success: Playblast generated at {0}".format(pb_path_published))

#         except Exception as e:
#             print(f"Error: {str(e)}")
#             return None, str(e)

#         space.shading.color_type = original_shading_type
#         space.overlay.show_overlays = overlays_enabled
#         return pb_path_published, None

#     def execute(self, context):
#         shn = bpy.path.basename(bpy.data.filepath)
#         sn = bpy.data.filepath
#         base_dir = os.path.dirname(os.path.dirname(os.path.dirname(sn)))
#         base_dir_compiled = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(sn))))

#         if shn:
#             long_shot_name = os.path.splitext(shn)[0]
#             file_ext = os.path.splitext(shn)[1][1:]
#             split_shot_code = long_shot_name.split("_")

#             if len(split_shot_code) < 5:
#                 self.report({'ERROR'}, "Invalid shot format.")
#                 return {'CANCELLED'}

#             pb_path, pb_err = self.publish_playblast(base_dir)

#             if pb_path:
#                 compiled_pb_dir = os.path.join(base_dir_compiled, "_compiled", "Playblast")
                
#                 if not os.path.exists(compiled_pb_dir):
#                     os.makedirs(compiled_pb_dir)
                
#                 compiled_pb = os.path.join(compiled_pb_dir, long_shot_name + ".mp4")
#                 if not is_file_in_use(compiled_pb):
#                     shutil.copy2(pb_path, compiled_pb)
#                 else:
#                     self.report({'ERROR'}, "Compiled playblast file is in use.")
#                     return {'CANCELLED'}

#                 compiled_scene_dir = os.path.join(base_dir_compiled, "_compiled", "Blender")
#                 if not os.path.exists(compiled_scene_dir):
#                     os.makedirs(compiled_scene_dir)
#                 compiled_scene = os.path.join(compiled_scene_dir, long_shot_name + "." + file_ext)
                
#                 if not is_file_in_use(compiled_scene):
#                     bpy.ops.wm.save_as_mainfile(filepath=compiled_scene)
#                 else:
#                     self.report({'ERROR'}, "Compiled Blender file is in use.")
#                     return {'CANCELLED'}
                
#                 published_scene_dir = os.path.join(os.path.dirname(sn), "Publish", long_shot_name, "Blender")
#                 if not os.path.exists(published_scene_dir):
#                     os.makedirs(published_scene_dir)
#                 published_scene = os.path.join(published_scene_dir, shn)
                
#                 if not is_file_in_use(published_scene):
#                     bpy.ops.wm.save_as_mainfile(filepath=published_scene)
#                 else:
#                     self.report({'ERROR'}, "Published Blender file is in use.")
#                     return {'CANCELLED'}

#                 bpy.ops.wm.open_mainfile(filepath=sn)
#                 self.report({'INFO'}, "Shot published successfully.")
#                 return {'FINISHED'}
#             else:
#                 self.report({'ERROR'}, pb_err)
#                 return {'CANCELLED'}

#         self.report({'ERROR'}, "Shot not found.")
#         return {'CANCELLED'}
    

class PublishShotOperator(bpy.types.Operator):
    bl_idname = "wm.publish_shot"
    bl_label = "Publish Shot"

    @staticmethod
    def remove_old_versions(target_dir, current_filename):
        current_base, ext = os.path.splitext(current_filename)
        
        # Match the version suffix (e.g., _v03)
        match = re.match(r"(.+)_v\d+$", current_base)
        if not match:
            print("No version pattern matched.")
            return

        base_name_no_version = match.group(1)

        for f in os.listdir(target_dir):
            file_base, file_ext = os.path.splitext(f)

            if file_ext != ext:
                continue

            # Check if filename starts with the same base and ends with _v##
            if file_base.startswith(base_name_no_version) and re.match(r".+_v\d+$", file_base) and file_base != current_base:
                try:
                    os.remove(os.path.join(target_dir, f))
                    print(f"Removed old version: {f}")
                except Exception as e:
                    print(f"Failed to remove {f}: {e}")

    @staticmethod
    def publish_playblast(base_dir):
        shn = bpy.path.basename(bpy.data.filepath)
        shn_filename = os.path.splitext(shn)[0]
        pb_file = shn_filename + ".mp4"
        split_shot_code = shn_filename.split("_")

        if len(split_shot_code) < 5:
            print("Error: Invalid shot name.")
            return None, "Invalid shot name."

        path = bpy.data.filepath
        folder_name = os.path.basename(os.path.dirname(path))
        published_pb_dir = os.path.join(base_dir, "Publish", folder_name, "Playblast")

        if not os.path.exists(published_pb_dir):
            os.makedirs(published_pb_dir)

        pb_path_published = os.path.join(published_pb_dir, pb_file)

        space = bpy.context.area.spaces.active
        original_shading_type = space.shading.color_type
        overlays_enabled = space.overlay.show_overlays

        space.shading.color_type = 'TEXTURE'
        space.overlay.show_overlays = False

        bpy.context.scene.render.use_stamp = True
        bpy.context.scene.render.use_stamp_date = False
        bpy.context.scene.render.use_stamp_time = False
        bpy.context.scene.render.use_stamp_render_time = False
        bpy.context.scene.render.use_stamp_frame = True
        bpy.context.scene.render.use_stamp_frame_range = False
        bpy.context.scene.render.use_stamp_memory = False
        bpy.context.scene.render.use_stamp_hostname = True
        bpy.context.scene.render.use_stamp_camera = False
        bpy.context.scene.render.use_stamp_lens = True
        bpy.context.scene.render.use_stamp_scene = False
        bpy.context.scene.render.use_stamp_marker = False
        bpy.context.scene.render.use_stamp_filename = True
        bpy.context.scene.render.use_stamp_sequencer_strip = False
        bpy.context.scene.render.stamp_font_size = 20

        bpy.context.scene.render.image_settings.file_format = "FFMPEG"
        bpy.context.scene.render.ffmpeg.format = "MPEG4"
        bpy.context.scene.render.ffmpeg.codec = "H264"

        bpy.context.scene.render.filepath = pb_path_published

        try:
            bpy.ops.render.opengl(animation=True)
            bpy.ops.render.play_rendered_anim()
            print("Success: Playblast generated at {0}".format(pb_path_published))
        except Exception as e:
            print(f"Error: {str(e)}")
            return None, str(e)

        space.shading.color_type = original_shading_type
        space.overlay.show_overlays = overlays_enabled
        return pb_path_published, None

    def execute(self, context):
        shn = bpy.path.basename(bpy.data.filepath)
        sn = bpy.data.filepath
        base_dir = os.path.dirname(os.path.dirname(os.path.dirname(sn)))
        base_dir_compiled = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(sn))))

        if shn:
            long_shot_name = os.path.splitext(shn)[0]
            file_ext = os.path.splitext(shn)[1][1:]
            split_shot_code = long_shot_name.split("_")

            if len(split_shot_code) < 5:
                self.report({'ERROR'}, "Invalid shot format.")
                return {'CANCELLED'}

            pb_path, pb_err = self.publish_playblast(base_dir)

            if pb_path:
                pb_base_name = "_".join(split_shot_code[:-1])  # remove version part

                # Playblast compiled
                compiled_pb_dir = os.path.join(base_dir_compiled, "_compiled", "Playblast")
                if not os.path.exists(compiled_pb_dir):
                    os.makedirs(compiled_pb_dir)

                self.remove_old_versions(compiled_pb_dir, long_shot_name + ".mp4")

                # compiled_pb = os.path.join(compiled_pb_dir, long_shot_name + ".mp4")
                compiled_pb = os.path.join(compiled_pb_dir, pb_base_name + ".mp4")
                if not is_file_in_use(compiled_pb):
                    shutil.copy2(pb_path, compiled_pb)
                else:
                    self.report({'ERROR'}, "Compiled playblast file is in use.")
                    return {'CANCELLED'}

                # Blender compiled
                compiled_scene_dir = os.path.join(base_dir_compiled, "_compiled", "Blender")
                if not os.path.exists(compiled_scene_dir):
                    os.makedirs(compiled_scene_dir)

                self.remove_old_versions(compiled_scene_dir, long_shot_name + "." + file_ext)

                compiled_scene = os.path.join(compiled_scene_dir, long_shot_name + "." + file_ext)
                if not is_file_in_use(compiled_scene):
                    bpy.ops.wm.save_as_mainfile(filepath=compiled_scene)
                else:
                    self.report({'ERROR'}, "Compiled Blender file is in use.")
                    return {'CANCELLED'}

                # Published Blender file
                published_scene_dir = os.path.join(os.path.dirname(sn), "Publish", long_shot_name, "Blender")
                if not os.path.exists(published_scene_dir):
                    os.makedirs(published_scene_dir)

                published_scene = os.path.join(published_scene_dir, shn)
                if not is_file_in_use(published_scene):
                    bpy.ops.wm.save_as_mainfile(filepath=published_scene)
                else:
                    self.report({'ERROR'}, "Published Blender file is in use.")
                    return {'CANCELLED'}

                bpy.ops.wm.open_mainfile(filepath=sn)
                self.report({'INFO'}, "Shot published successfully.")
                return {'FINISHED'}
            else:
                self.report({'ERROR'}, pb_err)
                return {'CANCELLED'}

        self.report({'ERROR'}, "Shot not found.")
        return {'CANCELLED'}