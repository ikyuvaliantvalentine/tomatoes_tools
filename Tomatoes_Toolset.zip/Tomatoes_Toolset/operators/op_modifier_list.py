import bpy
from bpy.types import Operator
from bpy.types import Operator, Modifier, Object, UILayout, Context, Menu
from bpy.props import *
from .. properties import *

class ModifierMoveUp(Operator):
    bl_idname = 'object.modifier_moveup'
    bl_label = 'Modifier Move Up'
    bl_options = {'REGISTER', 'UNDO'}
    
    @classmethod
    def poll(cls, context):
        return context.active_object is not None
    
    def execute(self, context):
        obj = context.active_object
        tomatoes = context.scene.tomatoes_props
        if len(obj.modifiers) == 0 or tomatoes.active_modifier_index == 0:
            return {'CANCELLED'}
        else:
            bpy.ops.object.modifier_move_up(modifier=obj.modifiers[tomatoes.active_modifier_index].name)
            tomatoes.active_modifier_index -= 1
        
        return {'FINISHED'}


class ModifierMoveDown(Operator):
    bl_idname = 'object.modifier_movedown'
    bl_label = 'Modifier Move Down'
    bl_options = {'REGISTER', 'UNDO'}
    
    @classmethod
    def poll(cls, context):
        return context.active_object is not None
    
    def execute(self, context):
        obj = context.active_object
        tomatoes = context.scene.tomatoes_props
        if len(obj.modifiers) == 0 or tomatoes.active_modifier_index == len(obj.modifiers)-1:
            return {'CANCELLED'}
        else:
            bpy.ops.object.modifier_move_down(modifier=obj.modifiers[tomatoes.active_modifier_index].name)
            tomatoes.active_modifier_index += 1
        
        return {'FINISHED'}
    
class ModifierRemove(Operator):
    bl_idname = 'object.remove_modifier'
    bl_label = 'Remove Modifier'
    bl_options = {'REGISTER', 'UNDO'}
    
    @classmethod
    def poll(cls, context):
        return context.active_object is not None
    
    def execute(self, context):
        obj = context.active_object
        tomatoes = context.scene.tomatoes_props
        if len(obj.modifiers) == 0:
            self.report({'INFO'}, 'No modifiers to remove.')
            return {'CANCELLED'}
        else:
            if tomatoes.active_modifier_index == 0:
                bpy.ops.object.modifier_remove(modifier=obj.modifiers[tomatoes.active_modifier_index].name)
            else:
                bpy.ops.object.modifier_remove(modifier=obj.modifiers[tomatoes.active_modifier_index].name)
                tomatoes.active_modifier_index -= 1
            
        return {'FINISHED'}
  
  