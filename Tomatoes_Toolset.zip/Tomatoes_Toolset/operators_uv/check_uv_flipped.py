import bpy, bmesh, array
from mathutils import Vector


class FlippedUVSelector(bpy.types.Operator):
    """Select polygons with flipped UV mapping."""
    
    # Algorithm stands on the thesis that order of polygon loop is defining direction of face normal
    # and that same loop order is used in uv data.
    # With this knowladge we can easily say that cross product:
    # (v2.uv-v1.uv)x(v3.uv-v2.uv) gives us uv normal direction of part of the polygon. Further
    # this normal has to be used in dot product with up vector (0,0,1) and result smaller than zero
    # means uv normal is pointed in opposite direction than it should be (partial polygon v1,v2,v3 is flipped).
    
    bl_idname = "uv.select_flipped"
    bl_label = "Flipped UVs"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.object and context.object.mode == "EDIT" and context.object.type == "MESH"

    def execute(self, context):
        ob = bpy.context.object
        
        bpy.ops.mesh.select_all(action="DESELECT")
        bpy.ops.object.mode_set(mode="OBJECT")
        
        for p in ob.data.polygons:
            
            # calculate uv differences between current and next face vertex for whole polygon	  
            diffs = []
            for l_i in p.loop_indices:
                
                next_l = l_i+1 if l_i < p.loop_start + p.loop_total - 1 else p.loop_start
                
                next_v_uv = ob.data.uv_layers.active.data[next_l].uv
                v_uv = ob.data.uv_layers.active.data[l_i].uv
                
                diffs.append((next_v_uv - v_uv).to_3d())	

            # go trough all uv differences and calculate cross product between current and next.
            # cross product gives us normal of the triangle. That normal then is used in dot product
            # with up vector (0,0,1). If result is negative we have found flipped part of polygon.
            for i, diff in enumerate(diffs):
                
                if i == len(diffs)-1:
                    break
                
                # as soon as we find partial flipped polygon we select it and finish search
                if diffs[i].cross(diffs[i+1]) @ Vector((0,0,1)) <= 0:
                    p.select = True
                    break

        bpy.ops.object.mode_set(mode="EDIT")
        
        return {'FINISHED'}