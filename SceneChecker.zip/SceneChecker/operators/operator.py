import bpy
from bpy.types import Operator
from mathutils import Vector, Euler
from .. properties import *

###########################################
#   LOCATION TRANSFORM CHECK
###########################################
class Get_Object_Apply_Loc(Operator):
    "CLICK - Select all objects that need to Apply Location"
    bl_idname = "ob.get_obj_loc"
    bl_label = "Select Object Need To Apply Transform Location"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):        
        bpy.context.active_object.select_set(False)
        for ob in bpy.context.visible_objects:
            if ob.type == 'MESH':
                bpy.context.view_layer.objects.active = ob
                if ob.location != Vector((0,0,0)):
                    ob.select_set(state=True) 
                if ob.data.users > 1:
                    continue
        return {'FINISHED'}

class Apply_Loc(Operator):
    "CLICK - Select all objects that need to Apply Location then apply it"
    bl_idname = "ob.applyloc"
    bl_label = "Select & Apply Object Need To Apply Transform Location"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):        
        bpy.context.active_object.select_set(False)
        for ob in bpy.context.visible_objects:
            if ob.type == 'MESH':
                bpy.context.view_layer.objects.active = ob
                if ob.location != Vector((0,0,0)):
                    ob.select_set(state=True) 
                    bpy.ops.object.transform_apply(location=True, rotation=False, scale=False) 
                if ob.data.users > 1:
                    continue
        return {'FINISHED'}

###########################################
#   SCALE TRANSFORM CHECK
###########################################
class Get_Object_Apply_Scale(Operator):
    "CLICK - Select all objects that need to Apply Scale then apply it"
    bl_idname = "ob.get_obj_scale"
    bl_label = "Select Object Need To Apply Scale"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):   
        bpy.context.active_object.select_set(False)            
        for ob in bpy.context.visible_objects:
            if ob.type == 'MESH':
                bpy.context.view_layer.objects.active = ob
                if ob.scale != Vector((1.0,1.0,1.0)):
                    ob.select_set(state=True) 
        return {'FINISHED'}

class Apply_Scale(Operator):
    "CLICK - Select all objects that need to Apply Scale then apply it"
    bl_idname = "ob.applyscale"
    bl_label = "Select & Apply Object Need To Apply Transform Scale"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):            
        bpy.context.active_object.select_set(False)   
        for ob in bpy.context.visible_objects:
            if ob.type == 'MESH':
                bpy.context.view_layer.objects.active = ob
                if ob.scale != Vector((1.0,1.0,1.0)):
                    ob.select_set(state=True) 
                    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)         
        return {'FINISHED'}

###########################################
#   ROTATION TRANSFORM CHECK
###########################################
class Get_Object_Apply_Rotation(Operator):
    "CLICK - Select all objects that need to Apply Rotation"
    bl_idname = "ob.get_apply_rot"
    bl_label = "Select Object Need To Apply Rotation"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):     
        bpy.context.active_object.select_set(False)          
        for ob in bpy.context.visible_objects:
            if ob.type == 'MESH':
                bpy.context.view_layer.objects.active = ob
                if ob.rotation_euler != Euler((0,0,0), 'XYZ'):
                    ob.select_set(state=True)   
        return {'FINISHED'}

class Apply_Rotation(Operator):
    "CLICK - Select all objects that need to Apply Rotation then apply it"
    bl_idname = "ob.applyrot"
    bl_label = "Check Object Need To Apply Rotation"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):               
        bpy.context.active_object.select_set(False)
        for ob in bpy.context.visible_objects:
            if ob.type == 'MESH':
                bpy.context.view_layer.objects.active = ob
                if ob.rotation_euler != Euler((0,0,0), 'XYZ'):
                    ob.select_set(state=True) 
                    bpy.ops.object.transform_apply(location=False, rotation=True, scale=False)         
        return {'FINISHED'}

###########################################
#   UV CHECK
###########################################
class OB_Select_UV_More_Than_One(Operator):
    "CLICK - Select all objects That Have More Than One UVMap "
    bl_idname = "ob.get_uv_more_than_one_object"
    bl_label = "Get Object >1 UV Map "
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):       
        bpy.context.active_object.select_set(False)        
        for ob in bpy.context.visible_objects:
            if ob.type == 'MESH':
                bpy.context.view_layer.objects.active = ob
                if(len(ob.data.uv_layers)) > 1:
                    ob.select_set(state=True)                
        return {'FINISHED'}

class OB_Select_Zero_UV(Operator):
    "CLICK - Select all objects That Dont Have UVMap "
    bl_idname = "ob.get_zero_uv_object"
    bl_label = "Get Object Zero UV "
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):    
        bpy.context.active_object.select_set(False)           
        for ob in bpy.context.visible_objects:
            if ob.type == 'MESH':
                bpy.context.view_layer.objects.active = ob
                if(len(ob.data.uv_layers)) < 1:
                    ob.select_set(state=True)                
        return {'FINISHED'}

class OB_Select_UV_Not_Match(Operator):
    "CLICK - Select all objects dont have match uv name "
    bl_idname = "ob.get_uv_map_one_object"
    bl_label = "Get Object Dont Have Name map1"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):        
        addon_preferences = get_addon_preferences()
        softwareworkflow = addon_preferences.SoftwareWorkflowOptions

        bpy.context.active_object.select_set(False)       
        for ob in bpy.context.visible_objects:
            if ob.type == 'MESH':
                bpy.context.view_layer.objects.active = ob
                for uvmap in  ob.data.uv_layers :
                    if softwareworkflow == "maya":
                        if not uvmap.name == 'map1':
                            ob.select_set(state=True)     
                    elif softwareworkflow == "blender":
                        if not uvmap.name == 'UVmap':
                            ob.select_set(state=True)  
        return {'FINISHED'}

###########################################
#   VERTEX COLOR CHECK
###########################################
class OB_Select_Vertex_Color(Operator):
    "CLICK - Select All Objects with Vertex Color"
    bl_idname = "ob.select_vcol"
    bl_label = "Select All Objects With Vertex Color"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):        
        bpy.context.active_object.select_set(False)       
        for ob in bpy.context.visible_objects:
            if ob.type == 'MESH':
                bpy.context.active_object.select_set(False)
                bpy.context.view_layer.objects.active = ob
                for vcol in ob.data.vertex_colors :
                    ob.select_set(True)  
        return {'FINISHED'}

class OB_Clear_Vertex_Color(Operator):
    "CLICK - Remove All Vertex Color"
    bl_idname = "ob.remove_vcol"
    bl_label = "Remove All Objects With Vertex Color"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):        
        bpy.context.active_object.select_set(False)       
        for ob in bpy.context.visible_objects:
            if ob.type == 'MESH':
                bpy.context.active_object.select_set(False)
                bpy.context.view_layer.objects.active = ob
                for vcol in ob.data.vertex_colors :
                    ob.select_set(True)  
                    bpy.context.view_layer.objects.active = ob
                    bpy.ops.mesh.vertex_color_remove()
        return {'FINISHED'}
 
###########################################
#   TRIS CHECK
###########################################
class OB_Select_Tris_Mesh(Operator):
    "CLICK - Select Faces Tris "
    bl_idname = "ob.sel_tris"
    bl_label = "Select Tris"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        bpy.context.active_object.select_set(False)
        for ob in bpy.context.visible_objects:
            if ob.type == 'MESH':
                bpy.context.view_layer.objects.active = ob
                ob.select_set(True) 
                bpy.ops.object.mode_set(mode='EDIT')
                bpy.ops.mesh.select_mode(type='FACE')
                bpy.ops.mesh.select_face_by_sides(number=3, type='EQUAL')
        return {'FINISHED'}

###########################################
#   NGON CHECK
###########################################
class OB_Select_Ngon_Mesh(Operator):
    "CLICK - Select Faces Ngon "
    bl_idname = "ob.sel_ngon"
    bl_label = "Select Ngon"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        bpy.context.active_object.select_set(False)
        for ob in bpy.context.visible_objects:
            if ob.type == 'MESH':
                bpy.context.view_layer.objects.active = ob
                ob.select_set(True) 
                bpy.ops.object.mode_set(mode='EDIT')
                bpy.ops.mesh.select_mode(type='FACE')
                bpy.ops.mesh.select_face_by_sides(number=4, type='GREATER')   
        return {'FINISHED'}

###########################################
#   NON MANIFOLD CHECK
###########################################
class OB_Select_NonManifold(Operator):
    "CLICK - Select Non Manifold "
    bl_idname = "ob.sel_nonmanifold"
    bl_label = "Select Non Manifold"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        bpy.context.active_object.select_set(False)
        for ob in bpy.context.visible_objects:
            if ob.type == 'MESH':
                bpy.context.view_layer.objects.active = ob
                ob.select_set(True) 
                bpy.ops.object.mode_set(mode='EDIT')
                bpy.ops.mesh.select_non_manifold(extend=False, use_wire=False, use_boundary=True)
        return {'FINISHED'}

###########################################
#   NEED APPLIED MODIFIER CHECK
###########################################
class OB_Select_HaveModifier(Operator):
    "CLICK - Select Object That Have Modiifer"
    bl_idname = "ob.sel_havemod"
    bl_label = "Select Object Modifier"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        bpy.context.active_object.select_set(False)
        for ob in bpy.context.visible_objects:
            if ob.type == 'MESH':
                if (len(ob.modifiers) > 0):
                    ob.select_set(True) 
        return {'FINISHED'}

class OB_Select_HaveSubsurfModifier(Operator):
    "CLICK - Select Object That Have Subsurf Modiifer"
    bl_idname = "ob.sel_havemodsubsurf"
    bl_label = "Select Object Modifier Subsurf"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        bpy.context.active_object.select_set(False)
        for ob in bpy.context.visible_objects:
            if ob.type == 'MESH':
                if (len(ob.modifiers) > 0):
                    if ob.modifiers.type == 'SUBSURF':
                        ob.select_set(True) 
        return {'FINISHED'}

###########################################
#   OBJECT EMPTY MATERIAL SLOT CHECK
###########################################
class OB_Select_HasEmptyMatSlot(Operator):
    "CLICK - Select Object Has Empty Material Slot "
    bl_idname = "ob.sel_hasemptymatslot"
    bl_label = "Select Object Has Material Slot"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        bpy.context.active_object.select_set(False)
        for ob in bpy.context.visible_objects:
            if ob.type == 'MESH':
                for slot in ob.material_slots:
                    mat = slot.material
                    if (mat is None):
                        ob.select_set(True) 
        return {'FINISHED'}

class FIX_OB_Select_HasEmptyMatSlot(Operator):
    "CLICK - Fix Object Has Empty Material Slot "
    bl_idname = "ob.fix_sel_hasemptymatslot"
    bl_label = "Fix Object Has Material Slot"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        bpy.context.active_object.select_set(False)
        for ob in bpy.context.visible_objects:
            if ob.type == 'MESH':
                for slot in ob.material_slots:
                    mat = slot.material
                    if (mat is None):
                        ob.select_set(True) 

                        bpy.context.view_layer.objects.active = ob
                        materialList = list(ob.material_slots)
                        
                        counter = 0

                        for mat in materialList:
                            if mat.material == None:
                                counter = counter + 1
                        for i in range(counter):
                            idx = ob.material_slots.find('')
                            bpy.context.object.active_material_index = idx
                            bpy.ops.object.material_slot_remove()
        return {'FINISHED'}