import bpy
from .. function import *
from .. properties import *

####################################
# Panel Animation
####################################   
def UIAnimationChecker(self, context):
    errorloc = object_location(self, context)
    errorscale = object_scale(self, context)
    errorrot = object_rotation(self, context)
    erroruvmore = uv_object_more_than_one(self, context)
    erroruvempty = uv_object_empty(self, context)
    erroruvmapone = uv_object_name(self, context)
    errorvcol = object_vertex_color(self, context)
    errortris = tris_meshcalc(self, context)
    errorngon = ngon_meshcalc(self, context)
    errorpackedimage = check_packed_image(self, context)
#     error_interior_faces = check_interior_faces(self, context)

    
    selectedObjects = []

    ##########################################################
    # Detect Active Scene
    ##########################################################
    layout = self.layout  
    scenechk = bpy.context.scene.scenechk_props
    
    layout.label(text='Check: {}'.format(
            bpy.context.scene.name))

    col = layout.column()
    col.label(text='Multi User Data : {}'.format(
            len(object_multiuser(self, context))))

    ##########################################################
    # Checker UI
    ##########################################################
    box1 = layout.box()
    row = box1.row()
    col = row.column(align=True)
    
    col.label(text='1.  Transform Location : {}'.format(
            len(object_location(self, context))))

    col.label(text='2.  Transform Scale : {}'.format(
            len(object_scale(self, context))))
    
    col.label(text='3.  Transform Rotation : {}'.format(
            len(object_rotation(self, context))))

    col.label(text='4.  UV More Than One : {}'.format(
            len(uv_object_more_than_one(self, context))))
    
    col.label(text='5.  Zero UV : {}'.format(
            len(uv_object_empty(self, context))))

    col.label(text='6.  UV Not map1 : {}'.format(
            len(uv_object_name(self, context))))

    col.label(text='7.  Vertex Color : {}'.format(
            len(object_vertex_color(self, context))))
            
    col.label(text='8.  Tris Polygon : {}'.format(
            len(tris_meshcalc(self, context))))

    col.label(text='9.  Ngon Polygon : {}'.format(
            len(ngon_meshcalc(self, context))))

    # col.label(text='9.  Check Prefix Name : {}'.format(
    #         len(prefix_check_count(self, context))))

    col.label(text='10.  Check Packed Image : {}'.format(
            len(check_packed_image(self, context))))

    
    # col.label(text='10.  Check Numeric Suffix : {}'.format(
    #         len(numeric_suffix_check_count(self, context))))

    col = row.column(align=True)

    if errorloc:
            col.operator("ob.applyloc", text="Warning", icon="ERROR")
    else:
            col.label(text="Pass", icon="CHECKMARK")

    if errorscale:
            col.operator("ob.applyscale", text="Warning", icon="ERROR")
    else:
            col.label(text="Pass", icon="CHECKMARK")

    if errorrot:
            col.operator("ob.applyrot", text="Warning", icon="ERROR")
    else:
            col.label(text="Pass", icon="CHECKMARK")

    if erroruvmore:
            col.label(text="Warning", icon="ERROR")
    else:
            col.label(text="Pass", icon="CHECKMARK")

    if erroruvempty:
            col.label(text="Warning", icon="ERROR")
    else:
            col.label(text="Pass", icon="CHECKMARK")

    if erroruvmapone:
            col.label(text="Warning", icon="ERROR")
    else:
            col.label(text="Pass", icon="CHECKMARK")

    if errorvcol:
            col.operator("ob.remove_vcol", text="Warning", icon="ERROR")
    else:
            col.label(text="Pass", icon="CHECKMARK")
            
    if errortris:
            col.operator("ob.sel_tris", text="Warning", icon="ERROR")
    else:
            col.label(text="Pass", icon="CHECKMARK")

    if errorngon:
            col.operator("ob.sel_ngon", text="Warning", icon="ERROR")
    else:
            col.label(text="Pass", icon="CHECKMARK")
    
    if errorpackedimage:
            col.label(text="Warning", icon="ERROR")
    else:
            col.label(text="Pass", icon="CHECKMARK")