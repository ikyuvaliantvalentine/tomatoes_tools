# This file is part of Instant Clean
# Copyright (C) 2023  Ruben Messerschmidt

import bpy
from .super_panel import Super_Panel
from .layout_temps import sub_layout, sub_panel_header, results_layout


class BC_PT_Topology_Panel(Super_Panel):
    bl_idname='bc.topology_panel'
    bl_label=''

    @classmethod
    def poll(cls, context):
        return not context.scene.bc_misc.results or (context.scene.bc_states.topology and bpy.context.scene['Topology'] is not None and [v for k, v in bpy.context.scene['Topology'].items() if type(v) != type(False)])

    def draw_header(self, context):
        sub_panel_header(self.layout, 'topology', context.scene.bc_misc.results, 'Topology')

    def draw(self, context):
        layout = self.layout
        layout.enabled = context.scene.bc_states.topology
        pg = context.scene.bc_topology

        sub = sub_layout(layout, 3)

        if not context.scene.bc_misc.results:
            sub.label(text='Convert to')

            col = sub.column()
            col.prop(pg, 'type', text='')

            sub.separator()

            if pg.type == 'TRIS':
                sub.label(text='Methods')
                box = sub.box()

                split = box.split(factor=0.3)

                col = split.column()
                col.label(text='Quads')
                col.label(text='NGons')

                col = split.column()
                col.prop(pg, 'quad_method', text='')
                col.prop(pg, 'ngon_method', text='')
            else:
                sub.label(text='Compare')
                box = sub.box()

                split = box.split()

                col = split.column()
                col.prop(pg, 'compare_sharp')
                col.prop(pg, 'compare_uv')
                col.prop(pg, 'compare_vcol')

                col = split.column()
                col.prop(pg, 'compare_seam')
                col.prop(pg, 'compare_material')
        else:
            results_layout(sub, bpy.context.scene['Topology'])