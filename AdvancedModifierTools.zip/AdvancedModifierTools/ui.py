import bpy

class LayoutPanel(bpy.types.Panel):
    bl_label = "Apply Modifiers"
    bl_idname = "SCENE_PT_layout"
    bl_space_type = 'PROPERTIES'
    bl_region_type = 'WINDOW'
    bl_context = "modifier"
    
    @classmethod
    def poll(cls, context):
        ob = context.object
        return ob and ob.modifiers  

    def draw(self, context):
        adv = context.scene.advmod_props
        layout = self.layout

        row = layout.row()
        
        layout.label(text="Choose your modifier to apply")
        layout.prop(adv, "M_prop",icon="MODIFIER",text="Modifiers")

        layout.label(text="Choose your modifier to remove")
        layout.prop(adv, "M_rem_prop",icon="MODIFIER",text="Modifiers")

        row.scale_y = 1.5
        row.operator("applyallmodifiers.func_2",icon="IMPORT")
        row.operator("removeallmodifiers.func_2",icon="TRASH")