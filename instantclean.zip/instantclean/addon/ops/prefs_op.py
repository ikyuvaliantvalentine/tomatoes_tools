# This file is part of Instant Clean
# Copyright (C) 2023  Ruben Messerschmidt

import bpy
import addon_utils
import shutil
import os
from bpy.types import Operator


class BC_OT_Reinstall_Presets(Operator):
    bl_idname='bc.reinstall_presets'
    bl_label='Reinstall Standard Presets'

    def execute(self, context):
        filepath: str
        for mod in addon_utils.modules():
            if mod.bl_info['name'] == "Instant Clean":
                filepath = mod.__file__

        presets_path = os.path.join(bpy.utils.user_resource('SCRIPTS', path='presets', create=True), 'Instant Clean')
        standard_presets = filepath.replace('__init__.py', 'standard_presets')
        files = os.listdir(standard_presets)
        installed = os.listdir(presets_path)
        for f in [f for f in files if f not in installed]:
            shutil.copy2(os.path.join(standard_presets, f), presets_path)

        self.report({'INFO'}, message='Reinstalled standard presets successfully!')

        return {'FINISHED'}