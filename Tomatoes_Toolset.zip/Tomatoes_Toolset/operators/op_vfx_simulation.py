import bpy
from bpy.types import Operator
from bpy.props import *

class New_Add_Emit(Operator):
    "Make base Emitter"
    bl_label = "NewAddEmit"
    bl_idname = "add.new_emit_operator"
    bl_options = {"REGISTER", "UNDO"}
    
    def execute (self,context):
        bpy.ops.mesh.primitive_plane_add(enter_editmode=False, align='WORLD', location=(0, 0, 10), scale=(1, 1, 1))
        bpy.ops.transform.resize(value=(5,5,5))
        bpy.context.object.name = "Emit"
        bpy.context.object.data.name = "Emit" #Buat Nama Object Sama Dengan Nama Data
        ##########################################
        # New Method
        ##########################################
        ob = bpy.context.object
        ps = ob.modifiers.new("Rain", 'PARTICLE_SYSTEM')
        rain_settings = ps.particle_system.settings
        rain_settings.frame_end = 250
        rain_settings.normal_factor = 0
        rain_settings.display_size = 0.05
        rain_settings.effector_weights.gravity = 10
        rain_settings.physics_type = 'FLUID'
        ##########################################
        
        bpy.ops.object.modifier_add(type='DYNAMIC_PAINT')
        bpy.context.object.modifiers["Dynamic Paint"].ui_type = 'BRUSH'
        bpy.ops.dpaint.type_toggle(type='BRUSH')
        bpy.context.object.modifiers["Dynamic Paint"].brush_settings.paint_source = 'PARTICLE_SYSTEM'
        bpy.context.object.modifiers["Dynamic Paint"].brush_settings.particle_system = bpy.data.objects["Emit"].particle_systems["Rain"]
        return {'FINISHED'}
    
     
class Add_GroundWater(Operator):
    "Make Ground Water"
    bl_label = "AddGroundWater"
    bl_idname = "add.groundwater_operator"
    bl_options = {"REGISTER", "UNDO"}
    
    def execute (self,context):
         bpy.ops.mesh.primitive_plane_add(enter_editmode=False, align='WORLD', location=(0, 0, 0), scale=(1, 1, 1))
         bpy.ops.transform.resize(value=(8,8,8))
         bpy.ops.object.editmode_toggle()
         bpy.ops.mesh.subdivide(number_cuts=100, smoothness=0)
         bpy.ops.object.editmode_toggle()
         bpy.ops.object.shade_smooth()
         bpy.context.object.name = "Ground_Water"
         bpy.ops.object.modifier_add(type='DYNAMIC_PAINT')
         bpy.ops.dpaint.type_toggle(type='CANVAS')
         bpy.context.object.modifiers["Dynamic Paint"].canvas_settings.canvas_surfaces["Surface"].use_antialiasing = True
         bpy.context.object.modifiers["Dynamic Paint"].canvas_settings.canvas_surfaces["Surface"].surface_type = 'WAVE'
         bpy.context.object.modifiers["Dynamic Paint"].canvas_settings.canvas_surfaces["Surface"].use_wave_open_border = True
         bpy.ops.object.modifier_add(type='COLLISION')
         bpy.context.object.collision.use_particle_kill = True
         return {'FINISHED'}
     
         
class Make_collide(Operator):
    "Bring Collision to Object"
    bl_label = "MakeCollide"
    bl_idname = "add.collision_operator"
    bl_options = {"REGISTER", "UNDO"}

    def execute (self,context):
        bpy.ops.object.modifier_add(type='COLLISION') 
        bpy.context.object.collision.stickiness = 5
        bpy.context.object.collision.damping_factor = 0.5
        bpy.context.object.collision.damping_random = 0.5
        bpy.context.object.collision.friction_factor = 0.5
        bpy.context.object.collision.friction_random = 0.5
        return {'FINISHED'}


class Add_Wind(Operator):
    "Add Wind Simulation"
    bl_label = "AddWind"
    bl_idname = "add.wind_operator"
    bl_options = {"REGISTER", "UNDO"}
    
    def execute (self,context):
        bpy.ops.object.effector_add(type='WIND', enter_editmode=False, align='WORLD', location=(0, 0, 2.5), rotation=(0, 1.5708, 0), scale=(1, 1, 1))
        bpy.context.object.field.strength = 25
        bpy.context.object.name = "Wind"
        return {'FINISHED'}
    
    
class Add_Turbulance(Operator):
    bl_label = "AddTurbulance"
    bl_idname = "add.turbulance_operator"
    bl_options = {"REGISTER", "UNDO"}
    
    def execute (self,context):    
        bpy.ops.object.effector_add(type='TURBULENCE', enter_editmode=False, align='WORLD', location=(0, 0, 2.5), scale=(1, 1, 1))
        bpy.ops.object.effector_add(type='TURBULENCE', enter_editmode=False, align='WORLD', location=(0, 0, 0), scale=(1, 1, 1))
        bpy.context.object.field.strength = 10
        bpy.context.object.field.noise = 5
        bpy.context.object.field.wind_factor = 1
        bpy.context.object.field.use_absorption = True
        bpy.context.object.field.use_global_coords = True
        return {'FINISHED'}

class Add_RigidBody(Operator):
    "Add Rigid Body To Selected Objects"
    bl_label = "Add Rigid Body"
    bl_idname = "add.rigidbody_operator"
    bl_options = {"REGISTER", "UNDO"}

    type_rigid : EnumProperty(
        items = (('active', "active", ""),
                 ('passive', "passive", "")),
                 default = 'active'
                 )
    
    def execute (self,context):    
        selected_objects = bpy.context.selected_objects
        for item in selected_objects:
            if self.type_rigid == 'active':    
                bpy.ops.rigidbody.objects_add(type='ACTIVE')
                item.rigid_body.mass = 1
                item.rigid_body.collision_shape = 'MESH'
                item.rigid_body.use_margin = True
                item.rigid_body.collision_margin = 0.0001
            elif self.type_rigid == 'passive':    
                bpy.ops.rigidbody.objects_add(type='PASSIVE')
                item.rigid_body.collision_shape = 'MESH'
                item.rigid_body.use_margin = True
                item.rigid_body.collision_margin = 0.0001
        return {'FINISHED'}

class Apply_RigidBody(Operator):
    "Apply Rigid Body To Selected Objects"
    bl_label = "Apply Rigid Body"
    bl_idname = "apply.rigidbody_operator"
    bl_options = {"REGISTER", "UNDO"}

    def execute (self,context):    
        selected_objects = bpy.context.selected_objects

        if selected_objects:
            bpy.ops.object.visual_transform_apply()
            bpy.ops.rigidbody.objects_remove()
        return {'FINISHED'}