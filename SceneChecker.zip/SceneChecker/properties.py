import bpy, os 
from bpy.props import *
from bpy.types import PropertyGroup

def get_addon_preferences():
    addon_name = os.path.basename(os.path.dirname(os.path.abspath(__file__).split("utils")[0]))
    user_preferences = bpy.context.preferences
    addon_prefs = user_preferences.addons[addon_name].preferences     
    return addon_prefs

def dpifac():
    prefs = bpy.context.preferences.system
    # python access to this was only added recently, assume non-retina display is used if using older blender
    if hasattr(prefs, 'pixel_size'):
        retinafac = bpy.context.preferences.system.pixel_size
    else:
        retinafac = 1
    return bpy.context.preferences.system.dpi / (72 / retinafac)

asset_categories=[
    ('CHARACTERS','Characters','Characters folder'),
    ('PROPS','Props','Props folder'),
    ('ENVIRONMENTS','Environments','Environments folder'),
    ('MATTES','Mattes','Mattes folder'),
    ]
    
project_path = "D:/Brandoville Work/Props/NepenthesLowii/01_Model/WIP/Backup/" 

def asset_populate(self, context):
    scenechk = bpy.context.scene.scenechk_props
    return [(filename, filename, "") for filename in os.listdir(project_path + scenechk.Category)]
    
def update_category_property(self, context):
    print("updating Category..." + bpy.context.scene.Category)
    
def update_asset_property(self, context):
    print("updating Asset..." + bpy.context.scene.Asset)


# ------------------------------------------------------------------------              
#   Property Group
# ------------------------------------------------------------------------    
class SceneCheckerProperties(PropertyGroup):
    settingsFilePath : StringProperty(
            name="Settings",
            default="",
            subtype='FILE_PATH',
            description="location for the settings save/load\n")  
    
    
    save_filename : StringProperty(
            name="Filename",
            default="",
            description="Set Filename")  
            
    # ------------------------------------------------------------------------              
    #   UI Scene Checker
    # ------------------------------------------------------------------------                         
    UISchk : EnumProperty(
            name="Choose UI",
            items=(
                ("save_ui", "Save", "Save UI", 'PACKAGE', 1),
                ("scene_chk", "Scene Checker", "Scene Checker UI", 'SCENE_DATA', 2)),
            default='save_ui',
            description = "Choose UI") 

    Category : EnumProperty(items=asset_categories, update=update_category_property)
    Asset : EnumProperty(items=asset_populate, update=update_asset_property)

     # UI Visibility
    geo_checking_ui_is_visible : BoolProperty(
        name = "Geo Checking",
        description = "Show/hide the Geo Checking UI.",
        default = False)
        
    uv_checking_ui_is_visible : BoolProperty(
        name = "UV Checking",
        description = "Show/hide the UV Checking UI.",
        default = False)

    mat_checking_ui_is_visible : BoolProperty(
        name = "Material Checking",
        description = "Show/hide the Material Checking UI.",
        default = False)
            